#!/usr/bin/env python3
"""V21 game-aware monetization discovery and aggregate performance analysis."""
from __future__ import annotations

import argparse
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

VERSION = "21.0.0"
EXCLUDED_DIRS = {
    ".git", ".agents", ".venv", "venv", "env", "node_modules", "Packages",
    "Library", "Temp", "Logs", "Build", "build", "dist", "target",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "v14", "v15", "v16", "v17", "v18", "v19", "v20", "v21",
}
TEXT_EXTENSIONS = {
    ".lua", ".luau", ".md", ".txt", ".json", ".toml", ".yaml", ".yml",
    ".xml", ".rbxlx", ".csv", ".cfg", ".ini",
}
MAX_FILES = 5000
MAX_FILE_BYTES = 512 * 1024
MAX_EVIDENCE_PER_SIGNAL = 4

GENRE_TERMS = {
    "simulator": ["simulator", "simulation"],
    "tycoon": ["tycoon", "factory tycoon", "business tycoon"],
    "roleplay": ["roleplay", "role play", "rp game"],
    "racing": ["racing", "race track", "vehicle race", "kart race"],
    "survival": ["survival game", "survival mode", "day night survival"],
    "obby": ["obby", "obstacle course", "parkour"],
    "combat": ["combat system", "arena combat", "player versus player", "pvp"],
    "rpg": ["rpg", "role playing game", "quest system", "character class"],
    "builder": ["building game", "build mode", "construction system", "plot building"],
    "horror": ["horror game", "horror map", "scare sequence"],
    "social": ["social hub", "hangout", "party system", "friend interaction"],
}

SIGNAL_TERMS = {
    "avatar_customization": ["avatar customization", "character customization", "outfit", "accessory", "skin catalog", "appearance editor", "customize character"],
    "emotes_animation": ["emote", "animation pack", "dance animation", "gesture", "emote wheel"],
    "vehicles": ["vehicle", "car garage", "garage", "kart", "racing vehicle", "vehicle customization"],
    "building_decoration": ["furniture", "decor", "decoration", "house builder", "plot building", "interior design"],
    "progression": ["level progression", "experience points", "xp", "quest", "mission", "level up", "mastery", "skill tree"],
    "currency_economy": ["currency", "coins", "credits", "cash balance", "soft currency", "wallet", "economy"],
    "social_sessions": ["party system", "friends", "social hub", "guild", "club", "group session", "hangout"],
    "inventory_loadouts": ["inventory", "loadout", "storage slots", "saved preset", "character slot", "outfit slot"],
    "seasonal_content": ["season pass", "seasonal event", "weekly event", "monthly event", "content update", "weekly challenge", "monthly challenge"],
    "private_server_support": ["private server", "reserved server", "private-server", "reservedserver"],
    "cosmetic_content": ["cosmetic", "visual effect", "trail effect", "vehicle paint", "decoration pack", "appearance"],
}

OFFER_RULES = [
    {
        "id": "avatar-cosmetic-catalog", "signal": "avatar_customization",
        "title": "Fixed-price avatar and character cosmetics", "purchase_type": "cosmetic_catalog",
        "player_value": "Lets players express a preferred look through named, previewable cosmetic items.",
        "effort": "medium", "guards": ["Cosmetics do not change competitive power.", "Show the exact item and price before purchase.", "Keep a free customization path."],
    },
    {
        "id": "emote-animation-collection", "signal": "emotes_animation",
        "title": "Fixed-price emotes and animation collection", "purchase_type": "cosmetic_catalog",
        "player_value": "Adds optional social expression and character animation choices.",
        "effort": "low", "guards": ["List every included emote or animation.", "Support all intended input devices.", "Do not use randomized bundles."],
    },
    {
        "id": "vehicle-visual-collection", "signal": "vehicles",
        "title": "Vehicle visual customization collection", "purchase_type": "cosmetic_catalog",
        "player_value": "Lets players personalize vehicles without changing speed, handling, or race outcomes.",
        "effort": "medium", "guards": ["Keep competitive vehicle stats unchanged.", "Preview exact paint, decals, and visual effects.", "Preserve earnable visual options."],
    },
    {
        "id": "build-decoration-collection", "signal": "building_decoration",
        "title": "Fixed-price building and decoration collection", "purchase_type": "cosmetic_catalog",
        "player_value": "Adds optional decorative choices for players who enjoy building and personalization.",
        "effort": "medium", "guards": ["Show all included assets before purchase.", "Do not sell functional requirements for ordinary progression.", "Keep core building tools accessible."],
    },
    {
        "id": "saved-cosmetic-presets", "signal": "inventory_loadouts",
        "title": "Optional saved cosmetic preset slots", "purchase_type": "game_pass",
        "player_value": "Saves additional cosmetic configurations for players who customize frequently.",
        "effort": "medium", "guards": ["Slots store cosmetic configurations only.", "Do not make inventory capacity a progression bottleneck.", "Disclose whether the entitlement is permanent."],
    },
    {
        "id": "fixed-currency-bundle", "signal": "currency_economy",
        "title": "Optional exact-quantity currency bundle", "purchase_type": "developer_product",
        "player_value": "Provides a clearly stated quantity of the existing earnable currency as an optional shortcut.",
        "effort": "medium", "guards": ["Grant an exact disclosed amount.", "Keep a meaningful earnable path through core progression.", "Do not let purchased currency fund uncertain outcomes."],
    },
    {
        "id": "seasonal-content-membership", "signal": "seasonal_content",
        "title": "Ongoing content membership", "purchase_type": "subscription",
        "player_value": "Can fund recurring, clearly described content when the team can reliably deliver it.",
        "effort": "high", "guards": ["List recurring benefits and renewal terms clearly.", "Deliver promised benefits for the full paid term.", "Provide accurate cancellation and entitlement handling."],
    },
    {
        "id": "private-play-access", "signal": "private_server_support",
        "title": "Optional private-server access", "purchase_type": "private_server",
        "player_value": "Provides private play for groups when the game has a meaningful social or session-based use case.",
        "effort": "medium", "guards": ["Verify the experience supports the platform feature.", "Show price and recurrence accurately.", "Keep public play useful."],
    },
    {
        "id": "fixed-time-progression-benefit", "signal": "progression",
        "title": "Optional fixed-duration progression benefit", "purchase_type": "developer_product",
        "player_value": "Can provide a precisely stated, time-limited progression convenience without changing any probability or uncertain outcome.",
        "effort": "medium", "guards": ["State exact effect and duration before purchase.", "Keep essential progression achievable without it.", "Do not adjust odds, random outcomes, or competitive balance."],
    },
]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def require_jsonschema():
    try:
        import jsonschema
    except ImportError as exc:
        raise RuntimeError("jsonschema is required; install requirements-ci.txt and v18/requirements-ci.txt") from exc
    return jsonschema


def compile_terms(mapping):
    return {
        key: [(term, re.compile(r"(?<![\w])" + re.escape(term).replace(r"\ ", r"\s+") + r"(?![\w])", re.IGNORECASE)) for term in terms]
        for key, terms in mapping.items()
    }


def iter_project_files(root: Path):
    count = 0
    for current, dirs, files in __import__("os").walk(root, topdown=True, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS and not (Path(current) / d).is_symlink())
        for filename in sorted(files):
            path = Path(current) / filename
            if path.suffix.lower() not in TEXT_EXTENSIONS or path.is_symlink():
                continue
            count += 1
            if count > MAX_FILES:
                return
            try:
                if path.stat().st_size > MAX_FILE_BYTES:
                    yield path, None, "oversized"
                    continue
                data = path.read_bytes()
                if b"\x00" in data[:4096]:
                    yield path, None, "binary"
                    continue
                yield path, data.decode("utf-8", errors="replace"), None
            except OSError:
                yield path, None, "unreadable"


def classify_confidence(matches: int):
    if matches >= 6:
        return "high"
    if matches >= 3:
        return "medium"
    return "low"


def build_project_report(root: Path, metrics_file: Path | None = None):
    root = root.resolve()
    genre_patterns = compile_terms(GENRE_TERMS)
    signal_patterns = compile_terms(SIGNAL_TERMS)
    genre_counts = {key: 0 for key in GENRE_TERMS}
    signal_counts = {key: 0 for key in SIGNAL_TERMS}
    genre_evidence = {key: [] for key in GENRE_TERMS}
    signal_evidence = {key: [] for key in SIGNAL_TERMS}
    scanned = source_files = docs = skipped = 0

    for path, content, skip_reason in iter_project_files(root):
        if content is None:
            skipped += 1
            continue
        scanned += 1
        relative = path.relative_to(root).as_posix()
        if path.suffix.lower() in {".lua", ".luau"}:
            source_files += 1
        else:
            docs += 1
        for line_number, line in enumerate(content.splitlines(), 1):
            for key, patterns in genre_patterns.items():
                for term, pattern in patterns:
                    if pattern.search(line):
                        genre_counts[key] += 1
                        if len(genre_evidence[key]) < MAX_EVIDENCE_PER_SIGNAL:
                            genre_evidence[key].append({"path": relative, "line": line_number, "term": term})
            for key, patterns in signal_patterns.items():
                for term, pattern in patterns:
                    if pattern.search(line):
                        signal_counts[key] += 1
                        if len(signal_evidence[key]) < MAX_EVIDENCE_PER_SIGNAL:
                            signal_evidence[key].append({"path": relative, "line": line_number, "term": term})

    detected_genres = [
        {"id": key, "matches": genre_counts[key], "evidence": genre_evidence[key]}
        for key in GENRE_TERMS if genre_counts[key] > 0
    ]
    detected_signals = [
        {"id": key, "matches": signal_counts[key], "evidence": signal_evidence[key]}
        for key in SIGNAL_TERMS if signal_counts[key] > 0
    ]
    detected_genres.sort(key=lambda item: (-item["matches"], item["id"]))
    detected_signals.sort(key=lambda item: (-item["matches"], item["id"]))
    top_genres = [item["id"] for item in detected_genres[:4]]
    genre_total = sum(item["matches"] for item in detected_genres)
    project_name = root.name or "Roblox Project"
    confidence = "unknown" if not detected_genres else classify_confidence(genre_total)

    signals = {item["id"]: item for item in detected_signals}
    offers = []
    for rule in OFFER_RULES:
        signal = signals.get(rule["signal"])
        if not signal:
            continue
        matches = signal["matches"]
        score = min(100, 60 + min(matches, 8) * 5)
        confidence_level = classify_confidence(matches)
        offers.append({
            "id": rule["id"],
            "title": rule["title"],
            "purchase_type": rule["purchase_type"],
            "player_value": rule["player_value"],
            "fit_score": score,
            "confidence": confidence_level,
            "evidence": [f"{item['path']}:{item['line']} — matched '{item['term']}'" for item in signal["evidence"]],
            "implementation_effort": rule["effort"],
            "fairness_guardrails": rule["guards"],
            "revenue_estimate": "NOT_ESTIMATED_WITHOUT_REAL_METRICS",
        })
    offers.sort(key=lambda item: (-item["fit_score"], item["id"]))

    metrics = analyze_metrics(read_json(metrics_file)) if metrics_file else None
    report = {
        "schema_version": 1,
        "tool_version": VERSION,
        "project": {"name": project_name, "genres": top_genres, "classification_confidence": confidence},
        "scan": {
            "files_scanned": scanned,
            "source_files": source_files,
            "design_documents": docs,
            "skipped_files": skipped,
            "signals_detected": len(detected_genres) + len(detected_signals),
        },
        "genres": detected_genres,
        "signals": detected_signals,
        "offers": offers,
        "metrics": metrics,
        "policy": {
            "purchase_model": "deterministic_only",
            "paid_random_rewards": "REJECTED",
            "paid_chance_modifiers": "REJECTED",
            "player_fairness_review": "REQUIRED_BEFORE_RELEASE",
        },
        "limitations": [
            "This scanner inspects readable local project files only; it does not inspect a live Roblox experience or binary place files.",
            "Keyword matches are evidence for human review, not proof that a feature is implemented or commercially viable.",
            "Fit scores are heuristic rankings and are not sales, conversion, or Robux revenue forecasts.",
            "Real purchase flows, Creator Dashboard settings, analytics, entitlements, and gameplay balance require authorized runtime verification.",
        ],
    }
    return report


def analyze_metrics(data: dict):
    schema_path = Path(__file__).resolve().parents[1] / "schemas" / "aggregate-monetization-metrics.schema.json"
    schema = read_json(schema_path)
    jsonschema = require_jsonschema()
    errors = sorted(jsonschema.Draft202012Validator(schema).iter_errors(data), key=lambda error: list(error.absolute_path))
    if errors:
        detail = "; ".join(f"{'/'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}" for e in errors[:10])
        raise ValueError(f"Aggregate metrics schema validation failed: {detail}")
    if data["unique_payers"] > data["unique_active_users"]:
        raise ValueError("unique_payers cannot exceed unique_active_users")
    if data["unique_purchasers"] > data["unique_shop_viewers"]:
        raise ValueError("unique_purchasers cannot exceed unique_shop_viewers")
    if data["purchase_transactions"] < data["unique_purchasers"]:
        raise ValueError("purchase_transactions cannot be lower than unique_purchasers")
    if data["average_daily_active_users"] > data["unique_active_users"]:
        raise ValueError("average_daily_active_users cannot exceed unique_active_users")
    if data["unique_shop_viewers"] > data["shop_views"]:
        raise ValueError("unique_shop_viewers cannot exceed shop_views")
    if data["shop_views"] > data["shop_impressions"]:
        raise ValueError("shop_views cannot exceed shop_impressions for this event definition")

    def ratio(numerator, denominator):
        return round(numerator / denominator, 6) if denominator else None

    offer_rows = []
    seen_offer_ids = set()
    for offer in data.get("offer_performance", []):
        offer_id = offer["offer_id"]
        if offer_id not in {rule["id"] for rule in OFFER_RULES}:
            raise ValueError(f"Unknown offer_id in aggregate metrics: {offer_id}")
        if offer_id in seen_offer_ids:
            raise ValueError(f"Duplicate offer_id in aggregate metrics: {offer_id}")
        seen_offer_ids.add(offer_id)
        if offer["unique_shop_viewers"] > offer["shop_views"]:
            raise ValueError(f"{offer_id}: unique_shop_viewers cannot exceed shop_views")
        if offer["shop_views"] > offer["eligible_impressions"]:
            raise ValueError(f"{offer_id}: shop_views cannot exceed eligible_impressions")
        if offer["unique_purchasers"] > offer["unique_shop_viewers"]:
            raise ValueError(f"{offer_id}: unique_purchasers cannot exceed unique_shop_viewers")
        if offer["purchase_transactions"] < offer["unique_purchasers"]:
            raise ValueError(f"{offer_id}: purchase_transactions cannot be lower than unique_purchasers")
        payers = offer["unique_purchasers"]
        impressions = offer["eligible_impressions"]
        viewers = offer["unique_shop_viewers"]
        offer_rows.append({
            "offer_id": offer_id,
            "eligible_impressions": impressions,
            "unique_shop_viewers": viewers,
            "unique_purchasers": payers,
            "purchase_transactions": offer["purchase_transactions"],
            "gross_robux": offer["gross_robux"],
            "shop_open_rate": ratio(viewers, impressions),
            "purchase_conversion": ratio(payers, viewers),
            "transactions_per_purchaser": ratio(offer["purchase_transactions"], payers),
            "arppu_robux": ratio(offer["gross_robux"], payers),
            "robux_per_eligible_impression": ratio(offer["gross_robux"], impressions),
            "sample_quality": "LOW_SAMPLE" if impressions < 100 or viewers < 30 or payers < 10 else "REVIEWABLE_NOT_CAUSAL",
        })
    offer_rows.sort(
        key=lambda row: (row["robux_per_eligible_impression"] is not None, row["robux_per_eligible_impression"] or -1, row["offer_id"]),
        reverse=True,
    )

    notes = []
    if not data["shop_impressions"]:
        notes.append("Shop open rate unavailable: no eligible shop impressions.")
    if not data["unique_shop_viewers"]:
        notes.append("Purchase conversion unavailable: no unique shop viewers.")
    if not data["unique_active_users"]:
        notes.append("Payer conversion unavailable: no unique active users.")
    if not data["unique_payers"]:
        notes.append("ARPPU unavailable: no unique payers.")
    if not data["average_daily_active_users"]:
        notes.append("ARPDAU unavailable: average daily active users is zero.")
    return {
        "period_days": data["period_days"],
        "shop_open_rate": ratio(data["unique_shop_viewers"], data["shop_impressions"]),
        "purchase_conversion": ratio(data["unique_purchasers"], data["unique_shop_viewers"]),
        "payer_conversion": ratio(data["unique_payers"], data["unique_active_users"]),
        "transactions_per_purchaser": ratio(data["purchase_transactions"], data["unique_purchasers"]),
        "arppu_robux": ratio(data["gross_robux"], data["unique_payers"]),
        "arpdau_robux": ratio(data["gross_robux"], data["average_daily_active_users"] * data["period_days"]),
        "offer_performance": offer_rows,
        "data_quality_notes": notes,
    }


def validate_report(root: Path, file_path: Path):
    root = root.resolve()
    path = file_path if file_path.is_absolute() else root / file_path
    data = read_json(path)
    jsonschema = require_jsonschema()
    schema = read_json(root / "v21/schemas/monetization-discovery.schema.json")
    errors = sorted(
        jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker()).iter_errors(data),
        key=lambda error: str(list(error.absolute_path)),
    )
    if errors:
        detail = "; ".join(
            f"{'/'.join(map(str, error.absolute_path)) or '<root>'}: {error.message}"
            for error in errors[:12]
        )
        raise ValueError(f"Monetization discovery report is invalid: {detail}")
    if any(offer["revenue_estimate"] != "NOT_ESTIMATED_WITHOUT_REAL_METRICS" for offer in data["offers"]):
        raise ValueError("V21 report must not invent revenue estimates")
    if data["policy"]["purchase_model"] != "deterministic_only":
        raise ValueError("V21 only accepts deterministic purchase outcomes")
    return {
        "status": "PASS",
        "project": data["project"]["name"],
        "offers": len(data["offers"]),
        "files_scanned": data["scan"]["files_scanned"],
        "scope": "Static report validation only; no Roblox runtime or live purchase behavior was executed.",
    }


def load_v18(root: Path):
    path = root / "v18/tools/v18.py"
    if not path.is_file():
        raise FileNotFoundError(f"V18 router not found: {path}")
    spec = importlib.util.spec_from_file_location("v18_cli_for_v21", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load V18 router: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def evaluate_routing(root: Path, cases_path: Path | None = None, max_specialists: int = 20):
    root = root.resolve()
    cases_path = cases_path or root / "v21/evals/routing-cases.json"
    dataset = read_json(cases_path)
    if dataset.get("schema_version") != 1 or not isinstance(dataset.get("cases"), list) or not dataset["cases"]:
        raise ValueError("V21 routing benchmark must use schema_version 1 and a non-empty cases array")
    router = load_v18(root)
    rows, seen = [], set()
    for case in dataset["cases"]:
        case_id, task = case.get("id"), case.get("task")
        if not isinstance(case_id, str) or not case_id or case_id in seen:
            raise ValueError(f"Invalid or duplicate V21 routing case ID: {case_id!r}")
        if not isinstance(task, str) or not task.strip():
            raise ValueError(f"{case_id}: task must be non-empty")
        seen.add(case_id)
        route = router.route_task(root, task, max_specialists=max_specialists)
        selected = set(route["selected_skills"])
        domains = {item["name"] for item in route["domains"]}
        missing_skills = sorted(set(case.get("required_skills", [])) - selected)
        missing_domains = sorted(set(case.get("required_domains", [])) - domains)
        forbidden_selected = sorted(set(case.get("forbidden_skills", [])) & selected)
        passed = not (missing_skills or missing_domains or forbidden_selected)
        rows.append({
            "id": case_id, "passed": passed, "missing_skills": missing_skills,
            "missing_domains": missing_domains, "forbidden_selected": forbidden_selected,
            "selected_skills": route["selected_skills"], "actual_domains": sorted(domains),
        })
    passed_count = sum(row["passed"] for row in rows)
    return {
        "schema_version": 1,
        "benchmark_id": dataset.get("benchmark_id", "roblox-codex-v21"),
        "status": "PASS" if passed_count == len(rows) else "FAIL",
        "summary": {"total_cases": len(rows), "passed_cases": passed_count, "failed_cases": len(rows) - passed_count},
        "cases": rows,
        "interpretation": "Tests deterministic skill routing only; it does not measure LLM reasoning, offer quality, revenue, or Roblox runtime correctness.",
    }


def verify(root: Path):
    command = [sys.executable, "v20/tools/v20.py", "verify", "--root", str(root)]
    print("$ " + " ".join(command))
    result = subprocess.run(command, cwd=root, check=False)
    if result.returncode:
        return result.returncode
    report = evaluate_routing(root)
    write_json(root / "v21/data/routing-benchmark-report.json", report)
    if report["status"] != "PASS":
        print(json.dumps(report, indent=2), file=sys.stderr)
        return 1
    discovery = build_project_report(root)
    write_json(root / "v21/data/monetization-discovery-report.json", discovery)
    validate_report(root, Path("v21/data/monetization-discovery-report.json"))
    audit_command = [sys.executable, "v21/tools/audit_cumulative_package.py", "--root", str(root)]
    audit = subprocess.run(audit_command, cwd=root, check=False)
    if audit.returncode:
        return audit.returncode
    print("V21 cumulative verification passed. Store, Creator Dashboard, and runtime purchase checks remain environment-specific.")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    discover = sub.add_parser("discover", help="scan a project and rank evidence-backed offer ideas")
    discover.add_argument("--root", type=Path, default=Path("."))
    discover.add_argument("--metrics-file", type=Path)
    discover.add_argument("--output", type=Path)
    validate = sub.add_parser("validate-report", help="validate a V21 monetization discovery report")
    validate.add_argument("--root", type=Path, default=Path("."))
    validate.add_argument("--file", required=True)
    routing = sub.add_parser("evaluate-routing", help="run deterministic V21 routing regressions")
    routing.add_argument("--root", type=Path, default=Path("."))
    routing.add_argument("--max-specialists", type=int, default=20)
    routing.add_argument("--output", type=Path)
    check = sub.add_parser("verify", help="run V20/V21 verification and the cumulative audit")
    check.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()
    root = args.root.resolve()
    try:
        if args.command == "discover":
            metrics_file = args.metrics_file
            if metrics_file and not metrics_file.is_absolute():
                metrics_file = root / metrics_file
            report = build_project_report(root, metrics_file)
            if args.output:
                target = args.output if args.output.is_absolute() else root / args.output
                write_json(target, report)
                print(f"Wrote {target}")
            print(json.dumps(report, indent=2, ensure_ascii=False))
            return 0
        if args.command == "validate-report":
            print(json.dumps(validate_report(root, Path(args.file)), indent=2, ensure_ascii=False))
            return 0
        if args.command == "evaluate-routing":
            if not 1 <= args.max_specialists <= 20:
                raise ValueError("--max-specialists must be between 1 and 20")
            report = evaluate_routing(root, max_specialists=args.max_specialists)
            if args.output:
                target = args.output if args.output.is_absolute() else root / args.output
                write_json(target, report)
                print(f"Wrote {target}")
            print(json.dumps(report, indent=2, ensure_ascii=False))
            return 0 if report["status"] == "PASS" else 1
        if args.command == "verify":
            return verify(root)
    except Exception as exc:
        print(f"V21 {args.command} failed: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
