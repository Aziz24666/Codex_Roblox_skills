#!/usr/bin/env python3
"""Validate V21 source skills, schemas, examples, routing, and tests."""
from __future__ import annotations
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
V21 = ROOT / "v21"
EXPECTED = {
    "roblox-game-aware-monetization-discovery",
    "roblox-monetization-product-strategy",
    "roblox-monetization-experiment-and-pricing",
    "roblox-monetization-purchase-integrity",
    "roblox-monetization-analytics-and-revenue-modeling",
    "roblox-monetization-storefront-ux-and-policy",
}
CONTRACTS = (
    "## V18 shared workflow and handoff contract",
    "## V19 verification and evaluation contract",
    "## V20 production reliability contract",
    "## V21 sustainable monetization contract",
)


def fail(message):
    raise SystemExit(f"V21 overlay validation failed: {message}")


def main():
    version = (V21 / "VERSION").read_text(encoding="utf-8").strip()
    if version != "21.0.0":
        fail(f"unexpected V21 version: {version}")
    files = sorted((V21 / "codex-skills").glob("*/SKILL.md"))
    if {p.parent.name for p in files} != EXPECTED or len(files) != len(EXPECTED):
        fail("V21 specialist skill inventory mismatch")
    for path in files:
        lines = path.read_text(encoding="utf-8").splitlines()
        if not lines or lines[0] != "---":
            fail(f"{path}: missing frontmatter")
        try:
            closing = lines.index("---", 1)
        except ValueError:
            fail(f"{path}: unterminated frontmatter")
        metadata = {}
        for line in lines[1:closing]:
            key, sep, value = line.partition(":")
            if not sep:
                fail(f"{path}: malformed frontmatter")
            metadata[key.strip()] = value.strip()
        if metadata.get("name") != path.parent.name:
            fail(f"{path}: name does not match directory")
        if not metadata.get("description") or len(metadata["description"]) > 160:
            fail(f"{path}: invalid skill description")
        body = "\n".join(lines[closing + 1:])
        for marker in CONTRACTS:
            if marker not in body:
                fail(f"{path}: missing {marker}")

    import jsonschema
    for schema_path in sorted((V21 / "schemas").glob("*.schema.json")):
        jsonschema.Draft202012Validator.check_schema(json.loads(schema_path.read_text(encoding="utf-8")))
    import_v21 = importlib.util.spec_from_file_location("v21_overlay_cli", V21 / "tools/v21.py")
    module = importlib.util.module_from_spec(import_v21)
    import_v21.loader.exec_module(module)
    example = module.validate_report(ROOT, Path("v21/examples/monetization-discovery.example.json"))
    if example["status"] != "PASS":
        fail("V21 discovery example did not validate")

    additions = json.loads((V21 / "workflow/routing-additions.json").read_text(encoding="utf-8"))
    base_routing_path = ROOT / "v18/workflow/skill-routing.json"
    if base_routing_path.is_file():
        base_domains = set(json.loads(base_routing_path.read_text(encoding="utf-8"))["domains"])
    else:
        # The overlay validator is also useful in an isolated source bundle.
        base_domains = {"character", "ui", "multiplayer", "persistence", "economy", "security", "performance", "assets", "reference", "testing", "studio", "release", "npc", "world"}
    unknown = set(additions["additions"]) - base_domains
    if unknown:
        fail(f"routing additions reference unknown domains: {sorted(unknown)}")
    routed = {skill for row in additions["additions"].values() for skill in row.get("skills", [])}
    if not EXPECTED <= routed:
        fail(f"routing additions omit skills: {sorted(EXPECTED-routed)}")
    cases = json.loads((V21 / "evals/routing-cases.json").read_text(encoding="utf-8"))
    rows = cases.get("cases", [])
    ids = [row.get("id") for row in rows]
    if cases.get("schema_version") != 1 or len(rows) < 6 or len(ids) != len(set(ids)):
        fail("routing corpus must contain at least six unique cases")
    # Full router evaluation runs after the cumulative package integration merges overlays.
    for doc in ("README.md", "INDEX_V21.md", "docs/MONETIZATION_DISCOVERY_AND_PLAYER_VALUE.md", "docs/OFFER_SELECTION_AND_EXPERIMENTS.md"):
        if not (V21 / doc).is_file():
            fail(f"missing V21 documentation: {doc}")
    print("V21 overlay validation passed.")
    print(f"V21 specialist skills: {len(files)}")
    print(f"Routing regression cases: {len(rows)}")
    print("Discovery schemas and example: PASS")
    print("Routing additions: structurally valid; cumulative routing is evaluated in the package job.")

if __name__ == "__main__":
    raise SystemExit(main())
