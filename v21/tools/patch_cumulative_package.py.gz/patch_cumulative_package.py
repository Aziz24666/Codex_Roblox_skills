#!/usr/bin/env python3
"""Integrate V21 into a fully verified V20 cumulative package."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1]
REPO = SOURCE.parent
EXCLUDED = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "target", "build"}
EXPECTED_V20 = 185
EXPECTED_V21 = 191
V21_CONTRACT = """## V21 sustainable monetization contract

- Inspect actual game design and implementation before suggesting an offer; cite project file/line evidence and label unknowns.
- Rank deterministic, clearly described optional offers by game-fit, player value, evidence confidence, implementation cost, and fairness risk. A fit score is not a revenue forecast.
- Use aggregate, privacy-safe metrics only; do not fabricate prices, demand, conversion, revenue, or causal lift.
- Keep the core game meaningfully playable without purchases. Avoid fake scarcity, deceptive pricing, pressure prompts, hidden costs, or vulnerability-based targeting.
- Preserve the mandatory V18 no-gambling economy policy and V20 server-authoritative, idempotent exact-grant requirements.
- Re-check current Roblox Creator Hub policy/API sources for each purchase class and verify all runtime behavior in authorized environments.
"""

OLD_V20_MANIFESTS = '''CURRENT_MANIFESTS = {
    "SHA256SUMS.txt": {"SHA256SUMS.txt", "V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V20_SHA256SUMS.txt"},
    "V20_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V20_SHA256SUMS.txt"},
    "V19_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt"},
    "V18_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt"},
    "V14_SHA256SUMS.txt": {"V14_SHA256SUMS.txt"},
}'''
NEW_V21_MANIFESTS = '''CURRENT_MANIFESTS = {
    "SHA256SUMS.txt": {"SHA256SUMS.txt", "V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V21_SHA256SUMS.txt"},
    "V21_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V21_SHA256SUMS.txt"},
    "V20_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V20_SHA256SUMS.txt"},
    "V19_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V19_SHA256SUMS.txt"},
    "V18_SHA256SUMS.txt": {"V14_SHA256SUMS.txt", "V18_SHA256SUMS.txt"},
    "V14_SHA256SUMS.txt": {"V14_SHA256SUMS.txt"},
}'''
OLD_V20_V18_POLICIES = '''policies={'SHA256SUMS.txt':{'SHA256SUMS.txt','V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt','V20_SHA256SUMS.txt'},
      'V20_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt','V20_SHA256SUMS.txt'},
      'V19_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt'},
      'V18_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt'},
      'V14_SHA256SUMS.txt':{'V14_SHA256SUMS.txt'}}'''
NEW_V21_V18_POLICIES = '''policies={'SHA256SUMS.txt':{'SHA256SUMS.txt','V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt','V20_SHA256SUMS.txt','V21_SHA256SUMS.txt'},
      'V21_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt','V20_SHA256SUMS.txt','V21_SHA256SUMS.txt'},
      'V20_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt','V20_SHA256SUMS.txt'},
      'V19_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt','V19_SHA256SUMS.txt'},
      'V18_SHA256SUMS.txt':{'V14_SHA256SUMS.txt','V18_SHA256SUMS.txt'},
      'V14_SHA256SUMS.txt':{'V14_SHA256SUMS.txt'}}'''
OLD_V20_AUDIT_POLICIES = '''MANIFEST_POLICIES = {
    "SHA256SUMS.txt": {"SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V20_SHA256SUMS.txt": {"V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V19_SHA256SUMS.txt": {"V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V18_SHA256SUMS.txt": {"V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V14_SHA256SUMS.txt": {"V14_SHA256SUMS.txt"},
}'''
NEW_V21_AUDIT_POLICIES = '''MANIFEST_POLICIES = {
    "SHA256SUMS.txt": {"SHA256SUMS.txt", "V21_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V21_SHA256SUMS.txt": {"V21_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V20_SHA256SUMS.txt": {"V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V19_SHA256SUMS.txt": {"V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V18_SHA256SUMS.txt": {"V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
    "V14_SHA256SUMS.txt": {"V14_SHA256SUMS.txt"},
}'''


def replace_once(content: str, old: str, new: str, label: str):
    if content.count(old) != 1:
        raise ValueError(f"Could not uniquely migrate {label}; found {content.count(old)} matches")
    return content.replace(old, new, 1)


def add_v21_contract(path: Path):
    content = path.read_text(encoding="utf-8")
    marker = "## V21 sustainable monetization contract"
    if marker in content:
        return False
    if not content.startswith("---\n") or "\n---\n" not in content[4:]:
        raise ValueError(f"Invalid skill frontmatter: {path}")
    path.write_text(content.rstrip() + "\n\n" + V21_CONTRACT + "\n", encoding="utf-8")
    return True


def merge_routing(root: Path):
    route_path = root / "v18/workflow/skill-routing.json"
    additions_path = root / "v21/workflow/routing-additions.json"
    routing = json.loads(route_path.read_text(encoding="utf-8"))
    additions = json.loads(additions_path.read_text(encoding="utf-8"))
    for name, extra in additions["additions"].items():
        if name not in routing["domains"]:
            raise ValueError(f"V21 cannot extend unknown routing domain: {name}")
        current = routing["domains"][name]
        for signal in extra.get("signals", []):
            if signal not in current["signals"]:
                current["signals"].append(signal)
        for skill in extra.get("skills", []):
            if skill not in current["skills"]:
                current["skills"].insert(0, skill)
    route_path.write_text(json.dumps(routing, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def migrate_cumulative_audits(root: Path):
    v17 = root / "v17/tools/audit_cumulative_package.py"
    content = v17.read_text(encoding="utf-8")
    content, count = re.subn(r"(?m)^EXPECTED_INSTALLED_SKILLS\s*=\s*185\s*$", "EXPECTED_INSTALLED_SKILLS = 191", content)
    if count != 1:
        raise ValueError(f"Expected one V20 installed-skill count in V17 audit, found {count}")
    content = replace_once(content, OLD_V20_MANIFESTS, NEW_V21_MANIFESTS, "V17 manifest policy")
    v17.write_text(content, encoding="utf-8")

    v18 = root / "v18/tools/audit_cumulative_package.py"
    content = v18.read_text(encoding="utf-8")
    content, count = re.subn(r"if len\(skills\)!=185:", "if len(skills)!=191:", content)
    if count != 1:
        raise ValueError(f"Expected one V20 skill-count check in V18 audit, found {count}")
    content = replace_once(content, OLD_V20_V18_POLICIES, NEW_V21_V18_POLICIES, "V18 manifest policy")
    v18.write_text(content, encoding="utf-8")

    for version in ("v19", "v20"):
        audit = root / version / "tools/audit_cumulative_package.py"
        content = audit.read_text(encoding="utf-8")
        content, count = re.subn(r"(?m)^EXPECTED_SKILLS\s*=\s*185\s*$", "EXPECTED_SKILLS = 191", content)
        if count != 1:
            raise ValueError(f"Expected one V20 skill-count check in {version} audit, found {count}")
        content = replace_once(content, OLD_V20_AUDIT_POLICIES, NEW_V21_AUDIT_POLICIES, f"{version.upper()} manifest policy")
        audit.write_text(content, encoding="utf-8")


def update_agents(root: Path):
    agents = root / "AGENTS.md"
    content = agents.read_text(encoding="utf-8")
    old_title = "Roblox Codex Game Studio Kit — V20 Operating Contract"
    if old_title not in content:
        raise ValueError("Could not find V20 operating-contract title in AGENTS.md")
    content = content.replace(old_title, "Roblox Codex Game Studio Kit — V21 Operating Contract", 1)
    content = content.replace("INDEX_V20.md", "INDEX_V21.md")
    section = """

## V21 game-aware monetization and sustainable revenue
- Run `python v21/tools/v21.py discover --root . --output reports/monetization-discovery.json` before proposing a new offer. Review file/line evidence and mark missing design/runtime evidence explicitly.
- Rank deterministic direct-purchase opportunities by game-fit, player value, evidence confidence, implementation/maintenance cost, and fairness risk. Fit scores are not revenue forecasts.
- Use only privacy-safe aggregate metrics. Do not invent demand, prices, conversion, revenue, or causal lift.
- Preserve the mandatory V18 no-gambling and fair monetization policy. Every paid outcome must be fixed and clearly known before purchase.
- Keep the core game meaningful without spending; prohibit fake scarcity, misleading prices, pressure prompts, hidden costs, and vulnerability-based targeting.
- Preserve V20 server-owned catalogs, verified receipts, exact idempotent grants, and safe entitlement reconciliation. Re-check current Roblox platform policies and verify live behavior in authorized environments.
"""
    if "## V21 game-aware monetization and sustainable revenue" not in content:
        content = content.rstrip() + section
    agents.write_text(content.rstrip() + "\n", encoding="utf-8")


def clean(root: Path):
    removed = 0
    for path in sorted(root.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        if path.is_dir() and path.name in EXCLUDED:
            shutil.rmtree(path)
            removed += 1
        elif path.is_file() and path.suffix in {".pyc", ".pyo"}:
            path.unlink()
            removed += 1
    return removed


def run(command, root):
    print("$ " + " ".join(str(item) for item in command))
    subprocess.run(command, cwd=root, check=True)


def package_files(root: Path):
    return sorted(
        path for path in root.rglob("*")
        if path.is_file() and not any(part in EXCLUDED for part in path.relative_to(root).parts)
    )


def manifests(root: Path):
    names = ["SHA256SUMS.txt", "V21_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"]
    paths = [root / name for name in names]
    for path in paths:
        if not path.exists():
            path.write_text("", encoding="utf-8")
    exclusions = [
        set(names),
        {"V21_SHA256SUMS.txt", "V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
        {"V20_SHA256SUMS.txt", "V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
        {"V19_SHA256SUMS.txt", "V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
        {"V18_SHA256SUMS.txt", "V14_SHA256SUMS.txt"},
        {"V14_SHA256SUMS.txt"},
    ]
    files = package_files(root)
    counts = {}
    for path, excluded in zip(paths, exclusions):
        rows = [
            hashlib.sha256(file.read_bytes()).hexdigest() + "  " + file.relative_to(root).as_posix()
            for file in files if file.name not in excluded
        ]
        path.write_text("\n".join(rows) + "\n", encoding="utf-8")
        counts[path.name] = len(rows)
        for row in rows:
            digest, relative = row.split("  ", 1)
            if hashlib.sha256((root / relative).read_bytes()).hexdigest() != digest:
                raise ValueError(f"Checksum verification failed: {relative}")
    return counts


def integrate(root: Path):
    if not (root / "AGENTS.md").is_file() or not (root / ".agents/skills").is_dir():
        raise ValueError("Target is not a reconstructed cumulative package")
    if not (root / "v20/VERSION").is_file():
        raise ValueError("A verified V20 package is required before V21 integration")
    if (root / "v21/VERSION").exists():
        raise ValueError("V21 is already integrated; use --finalize-only")
    if (root / "v20/VERSION").read_text(encoding="utf-8").strip() != "20.0.0":
        raise ValueError("Unexpected V20 package version; refusing an unreviewed baseline")

    skills_source = SOURCE / "codex-skills"
    source_names = {path.parent.name for path in skills_source.glob("*/SKILL.md")}
    if len(source_names) != 6:
        raise ValueError(f"Expected six V21 source skills, found {len(source_names)}")
    installed = root / ".agents/skills"
    collisions = sorted(name for name in source_names if (installed / name).exists())
    if collisions:
        raise ValueError(f"Refusing to overwrite inherited skills: {collisions}")

    for path in sorted(installed.glob("*/SKILL.md")):
        add_v21_contract(path)
    for version in ("v15", "v16", "v17", "v18", "v19", "v20"):
        source_dir = root / version / "codex-skills"
        if source_dir.is_dir():
            for path in sorted(source_dir.glob("*/SKILL.md")):
                add_v21_contract(path)
    for path in sorted(skills_source.glob("*/SKILL.md")):
        add_v21_contract(path)
    for folder in sorted(path for path in skills_source.iterdir() if path.is_dir()):
        shutil.copytree(folder, installed / folder.name)
    shutil.copytree(SOURCE, root / "v21")
    merge_routing(root)
    migrate_cumulative_audits(root)
    update_agents(root)

    (root / "INDEX_V21.md").write_text((REPO / "INDEX_V21.md").read_text(encoding="utf-8"), encoding="utf-8")
    (root / "RELEASE_NOTES_V21.md").write_text((REPO / "RELEASE_NOTES_V21.md").read_text(encoding="utf-8"), encoding="utf-8")
    (root / "INDEX.md").write_text(
        "# Current Index\n\nSee [INDEX_V21.md](INDEX_V21.md) for the current cumulative release and skill routing.\n",
        encoding="utf-8"
    )
    (root / "README.md").write_text((REPO / "README.md").read_text(encoding="utf-8"), encoding="utf-8")
    workflow = REPO / ".github/workflows/v21-quality.yml"
    if workflow.is_file():
        (root / ".github/workflows").mkdir(parents=True, exist_ok=True)
        shutil.copy2(workflow, root / ".github/workflows/v21-quality.yml")


def finalize(root: Path):
    removed = clean(root)
    version = (SOURCE / "VERSION").read_text(encoding="utf-8").strip()
    if version != "21.0.0":
        raise ValueError(f"Unexpected V21 version: {version}")
    skills = list((root / ".agents/skills").glob("*/SKILL.md"))
    if len(skills) != EXPECTED_V21:
        raise ValueError(f"Expected {EXPECTED_V21} installed skills; found {len(skills)}")

    run([sys.executable, "v18/tools/v18.py", "build-registry", "--root", str(root), "--write"], root)
    run([sys.executable, "v19/tools/v19.py", "evaluate-routing", "--root", str(root), "--output", str(root / "v19/data/routing-benchmark-report.json")], root)
    run([sys.executable, "v20/tools/v20.py", "evaluate-routing", "--root", str(root), "--output", str(root / "v20/data/routing-benchmark-report.json")], root)
    run([sys.executable, "v20/tools/v20.py", "validate-contract", "--root", str(root), "--file", "v20/examples/production-contract.example.json"], root)
    run([sys.executable, "v21/tools/v21.py", "evaluate-routing", "--root", str(root), "--output", str(root / "v21/data/routing-benchmark-report.json")], root)
    run([sys.executable, "v21/tools/v21.py", "discover", "--root", str(root), "--output", "v21/data/monetization-discovery-report.json"], root)

    files = package_files(root)
    counts = {
        "Installed native Codex skills": len(skills),
        "V19 verification specialists": len(list((root / "v19/codex-skills").glob("*/SKILL.md"))),
        "V20 production specialists": len(list((root / "v20/codex-skills").glob("*/SKILL.md"))),
        "V21 monetization specialists": len(list((root / "v21/codex-skills").glob("*/SKILL.md"))),
        "Markdown files": sum(path.suffix.lower() == ".md" for path in files),
        "JSON files": sum(path.suffix.lower() == ".json" for path in files),
        "Python files": sum(path.suffix.lower() == ".py" for path in files),
        "Luau files": sum(path.suffix.lower() in {".lua", ".luau"} for path in files),
        "GitHub Actions workflows": sum(".github/workflows" in path.as_posix() and path.suffix in {".yml", ".yaml"} for path in files),
        "Total regular files including six active manifests": len(files) + 1,
    }
    table = "\n".join(f"| {key} | {value} |" for key, value in counts.items())
    (root / "PACKAGE_INVENTORY.md").write_text(
        f"# Roblox Codex Game Studio Kit — V{version} Package Inventory\n\n"
        "Generated from the final cumulative package tree.\n\n"
        "| Category | Count |\n|---|---:|\n" + table +
        "\n\n## V21 additions\n"
        "- Six monetization specialists for project-aware discovery, product strategy, pricing experiments, purchase integrity, aggregate analytics, and storefront UX/policy.\n"
        "- A local project scanner, report schema, aggregate metrics schema, example report, and six deterministic routing regressions.\n\n"
        "## Evidence boundary\n"
        "Fit scores are heuristics, not revenue forecasts. Static validation does not prove Roblox Studio, live purchases, Creator Dashboard configuration, production analytics, or player demand.\n",
        encoding="utf-8"
    )
    # Seed current manifests before inherited verification reads them.
    checksum_counts = manifests(root)
    run([sys.executable, "v20/tools/v20.py", "verify", "--root", str(root)], root)
    # Inherited verification may refresh benchmark output; recompute every hierarchy after it.
    checksum_counts = manifests(root)
    run([sys.executable, "v21/tools/audit_cumulative_package.py", "--root", str(root)], root)
    print(f"Removed {removed} cache entries; skills={len(skills)}; checksums={checksum_counts}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--finalize-only", action="store_true")
    args = parser.parse_args()
    root = args.package_root.resolve()
    if not args.finalize_only:
        integrate(root)
    finalize(root)
    print(f"V21 package integration passed: {len(list((root/'.agents/skills').glob('*/SKILL.md')))} skills")

if __name__ == "__main__":
    raise SystemExit(main())
