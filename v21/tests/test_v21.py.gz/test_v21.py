import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location("v21_cli_tests", ROOT / "v21/tools/v21.py")
V21 = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(V21)


class V21DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, path: str, content: str):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target

    def test_discovers_game_specific_cosmetic_and_vehicle_offers(self):
        self.write("src/Garage.luau", "-- vehicle garage\nlocal vehicle = 'car'\n-- vehicle customization\nlocal paint = 'vehicle paint'\n")
        self.write("src/Avatar.luau", "-- character customization\nlocal outfit = true\nlocal accessory = true\n")
        report = V21.build_project_report(self.root)
        offer_ids = {offer["id"] for offer in report["offers"]}
        self.assertIn("vehicle-visual-collection", offer_ids)
        self.assertIn("avatar-cosmetic-catalog", offer_ids)
        self.assertEqual(report["project"]["classification_confidence"], "unknown")
        self.assertTrue(all(o["revenue_estimate"] == "NOT_ESTIMATED_WITHOUT_REAL_METRICS" for o in report["offers"]))

    def test_scan_excludes_generated_and_toolkit_directories(self):
        self.write("v20/docs/README.md", "vehicle garage avatar customization")
        self.write(".agents/skills/x/SKILL.md", "vehicle garage avatar customization")
        self.write("node_modules/lib/index.lua", "vehicle garage avatar customization")
        self.write("src/main.luau", "return true")
        report = V21.build_project_report(self.root)
        self.assertEqual(report["scan"]["files_scanned"], 1)
        self.assertEqual(report["offers"], [])

    def test_no_evidence_means_no_offer(self):
        self.write("src/main.luau", "print('hello world')")
        report = V21.build_project_report(self.root)
        self.assertEqual(report["offers"], [])
        self.assertEqual(report["project"]["classification_confidence"], "unknown")

    def test_fit_score_is_a_bounded_fit_heuristic_not_revenue(self):
        self.write("src/Race.luau", "\n".join(["vehicle garage" for _ in range(30)]))
        report = V21.build_project_report(self.root)
        offer = next(item for item in report["offers"] if item["id"] == "vehicle-visual-collection")
        self.assertEqual(offer["fit_score"], 100)
        self.assertEqual(offer["revenue_estimate"], "NOT_ESTIMATED_WITHOUT_REAL_METRICS")

    def test_example_report_matches_schema(self):
        path = ROOT / "v21/examples/monetization-discovery.example.json"
        result = V21.validate_report(ROOT, path)
        self.assertEqual(result["status"], "PASS")

    def test_metrics_use_consistent_aggregate_denominators(self):
        data = {
            "period_days": 7,
            "unique_active_users": 1000,
            "average_daily_active_users": 250,
            "shop_impressions": 1000,
            "shop_views": 500,
            "unique_shop_viewers": 450,
            "unique_purchasers": 45,
            "purchase_transactions": 60,
            "unique_payers": 45,
            "gross_robux": 9000,
        }
        report = V21.analyze_metrics(data)
        self.assertEqual(report["shop_open_rate"], 0.45)
        self.assertEqual(report["purchase_conversion"], 0.1)
        self.assertEqual(report["payer_conversion"], 0.045)
        self.assertEqual(report["transactions_per_purchaser"], round(60 / 45, 6))
        self.assertEqual(report["arppu_robux"], 200)
        self.assertEqual(report["arpdau_robux"], round(9000 / (250 * 7), 6))
        self.assertEqual(report["offer_performance"], [])

    def test_zero_denominators_are_unavailable_not_guessed(self):
        data = {
            "period_days": 7,
            "unique_active_users": 0,
            "average_daily_active_users": 0,
            "shop_impressions": 0,
            "shop_views": 0,
            "unique_shop_viewers": 0,
            "unique_purchasers": 0,
            "purchase_transactions": 0,
            "unique_payers": 0,
            "gross_robux": 0,
        }
        report = V21.analyze_metrics(data)
        self.assertIsNone(report["shop_open_rate"])
        self.assertIsNone(report["purchase_conversion"])
        self.assertIsNone(report["payer_conversion"])
        self.assertIsNone(report["transactions_per_purchaser"])
        self.assertIsNone(report["arppu_robux"])
        self.assertIsNone(report["arpdau_robux"])
        self.assertEqual(len(report["data_quality_notes"]), 5)

    def test_metrics_reject_inconsistent_counts(self):
        data = {
            "period_days": 7,
            "unique_active_users": 10,
            "average_daily_active_users": 20,
            "shop_impressions": 10,
            "shop_views": 8,
            "unique_shop_viewers": 9,
            "unique_purchasers": 9,
            "purchase_transactions": 9,
            "unique_payers": 11,
            "gross_robux": 100,
        }
        with self.assertRaises(ValueError):
            V21.analyze_metrics(data)

    def test_no_metrics_means_no_revenue_estimate(self):
        self.write("docs/GAME.md", "A roleplay world with character customization and outfits")
        report = V21.build_project_report(self.root)
        self.assertIsNone(report["metrics"])
        self.assertTrue(all(x["revenue_estimate"] == "NOT_ESTIMATED_WITHOUT_REAL_METRICS" for x in report["offers"]))

    def test_offer_performance_ranks_observed_yield_and_marks_small_samples(self):
        data = {
            "period_days": 14, "unique_active_users": 5000, "average_daily_active_users": 1200,
            "shop_impressions": 5000, "shop_views": 2400, "unique_shop_viewers": 2200,
            "unique_purchasers": 150, "purchase_transactions": 210, "unique_payers": 150, "gross_robux": 30000,
            "offer_performance": [
                {"offer_id":"avatar-cosmetic-catalog","eligible_impressions":1000,"shop_views":600,"unique_shop_viewers":500,"unique_purchasers":50,"purchase_transactions":70,"gross_robux":12000},
                {"offer_id":"emote-animation-collection","eligible_impressions":100,"shop_views":50,"unique_shop_viewers":40,"unique_purchasers":8,"purchase_transactions":8,"gross_robux":1000},
            ],
        }
        report = V21.analyze_metrics(data)
        self.assertEqual(report["offer_performance"][0]["offer_id"], "avatar-cosmetic-catalog")
        self.assertEqual(report["offer_performance"][0]["robux_per_eligible_impression"], 12)
        self.assertEqual(report["offer_performance"][0]["sample_quality"], "REVIEWABLE_NOT_CAUSAL")
        self.assertEqual(report["offer_performance"][1]["sample_quality"], "LOW_SAMPLE")

    def test_offer_metrics_reject_unknown_or_inconsistent_products(self):
        base = {
            "period_days": 7, "unique_active_users": 100, "average_daily_active_users": 30,
            "shop_impressions": 100, "shop_views": 50, "unique_shop_viewers": 40,
            "unique_purchasers": 5, "purchase_transactions": 5, "unique_payers": 5, "gross_robux": 100,
            "offer_performance": [
                {"offer_id":"not-a-v21-offer","eligible_impressions":10,"shop_views":5,"unique_shop_viewers":4,"unique_purchasers":2,"purchase_transactions":2,"gross_robux":20}
            ],
        }
        with self.assertRaisesRegex(ValueError, "Unknown offer_id"):
            V21.analyze_metrics(base)
        base["offer_performance"][0]["offer_id"] = "avatar-cosmetic-catalog"
        base["offer_performance"][0]["unique_purchasers"] = 8
        with self.assertRaisesRegex(ValueError, "unique_purchasers cannot exceed unique_shop_viewers"):
            V21.analyze_metrics(base)

    def test_policy_contract_is_always_deterministic(self):
        report = V21.build_project_report(self.root)
        self.assertEqual(report["policy"]["purchase_model"], "deterministic_only")
        self.assertEqual(report["policy"]["paid_random_rewards"], "REJECTED")
        self.assertEqual(report["policy"]["paid_chance_modifiers"], "REJECTED")


if __name__ == "__main__":
    unittest.main()
