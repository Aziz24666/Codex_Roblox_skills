# Roblox Codex Game Studio Kit — V7 Index

## Start here
1. `AGENTS.md` — concise project operating contract.
2. `.agents/skills/roblox-game-builder/SKILL.md` — orchestrator.
3. `docs/V7_CONTEXT_MANAGEMENT_AND_SKILL_ROUTING.md` — select a minimal skill set.
4. `docs/V7_END_TO_END_FEATURE_FACTORY.md` — feature delivery loop.
5. `docs/V7_DEFINITION_OF_DONE_AND_RELEASE_GATE.md` — quality requirements.
6. `README.md` — installation and local tools.
7. `PACKAGE_INVENTORY.md` — generated package counts.

## V7 docs
- `docs/V7_CONTEXT_MANAGEMENT_AND_SKILL_ROUTING.md`
- `docs/V7_END_TO_END_FEATURE_FACTORY.md`
- `docs/V7_DEFINITION_OF_DONE_AND_RELEASE_GATE.md`
- `docs/V7_PROJECT_RECONNAISSANCE_AND_REPO_MAP.md`
- `docs/V7_SKILL_ROUTING_MATRIX.md`
- `docs/V7_PLAYER_JOURNEY_AND_ONBOARDING.md`
- `docs/V7_ROUND_SESSION_STATE_MACHINES.md`
- `docs/V7_INVENTORY_AND_LOADOUT_CONTRACTS.md`
- `docs/V7_DATA_MIGRATION_RUNBOOK.md`
- `docs/V7_PERFORMANCE_BENCHMARKING.md`
- `docs/V7_REGRESSION_AND_TEST_EVIDENCE.md`
- `docs/V7_CROSS_PLATFORM_INPUT_AND_UI_QA.md`
- `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`
- `docs/V7_PLAYER_SUPPORT_AND_INCIDENT_TRIAGE.md`
- `docs/V7_CONTENT_CATALOG_GOVERNANCE.md`
- `docs/V7_TEAM_WORKSTREAMS_AND_INTEGRATION.md`
- `docs/V7_STUDIO_AUTOMATION_COMPATIBILITY.md`
- `docs/V7_SERVER_AUTHORITY_DECISION_GUIDE.md`
- `docs/V7_PROJECT_STRUCTURE_AND_MODULE_GRAPH.md`
- `docs/V7_OFFICIAL_REFERENCE_INDEX.md`

## V7 specialist skills
- `roblox-context-engineering`
- `roblox-experience-onboarding`
- `roblox-round-based-games`
- `roblox-inventory-loadouts`
- `roblox-data-migration-operations`
- `roblox-performance-benchmarking`
- `roblox-regression-engineering`
- `roblox-cross-platform-input`
- `roblox-player-generated-content`
- `roblox-player-support-triage`
- `roblox-content-catalog`
- `roblox-feature-orchestration`

## Useful tools
- `tools/skill_route.py` — heuristic skill suggestions.
- `tools/task_graph_lint.py` — dependency and cycle checks.
- `tools/feature_spec_lint.py` — feature spec required fields/trace links.
- `tools/evidence_bundle.py` — local evidence-path report.
- `tools/content_catalog_lint.py` — catalog IDs and local references.
- `tools/perf_budget_check.py` — compare recorded metrics with declared limits.
- `tools/module_dependency_map.py` — heuristic `require()` inventory.

All V1–V6 content is retained. Use prior version references only when a V7 document does not supersede them.
