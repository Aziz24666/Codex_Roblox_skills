# Changelog

## V10 — Research-First, Evidence-Gated Roblox Engineering
- Preserves the complete V9 schema-generated Studio editor and V1–V9 foundation.
- Adds a mandatory fresh online research gate before substantive Roblox design and implementation.
- Requires current official Creator Hub docs/API references, Roblox updates/release notes, and upstream/reputable sources for alternatives.
- Requires documented approach comparisons, exact source URLs, access dates, supported claims, assumptions, and recheck triggers.
- Adds research decision JSON Schema, source-record schema, API inventory schema, example records, linter, scope gate, indexer, and baseline source register.
- Adds Studio MCP discovery and safety workflows based on current Creator Hub docs.
- Adds a deliberate source-of-truth/toolchain decision guide for Studio-native, Script Sync, partial Rojo, and full Rojo.
- Strengthens modularity, schema governance, runtime lifecycle, security, DataStore reliability, test evidence, performance, asset provenance, and code review standards.
- Injects the V10 research gate into every inherited SKILL.md and adds V10 specialist skills.
- Adds API-surface and architecture-quality audits; both are explicitly heuristic and not compiler/security guarantees.
- Adds a current platform research snapshot accessed 2026-11-15; it is not a substitute for future fresh research.

## V11 — Project reliability and context-efficient engineering
- Shortened global instructions and oversized skill descriptions; added progressive-disclosure routing.
- Added 10 repository/reliability specialist skills.
- Added repository inventory, Luau require graph, change impact, research lint, release gate, generated drift, toolchain report, and skill audit utilities.
- Added V11 schemas, examples, prompts, templates, and maintenance playbooks.
- Added fresh official research snapshot for Studio MCP, Open Cloud scopes, Luau Execution, StudioTestService, and Codex skill design.

- V11 release gate now requires Studio evidence when runtime validation is in scope, or an explicit reason why it is not required.


## V12 — Runtime performance, streaming lifecycle, and observability
- Adds 10 specialist skills for runtime profiling, streaming readiness, CollectionService lifecycle, memory ownership, performance budgets, analytics governance, content loading, device tiers, regression testing, and observability.
- Adds 15 runtime-quality playbooks and a migration guide.
- Adds V12 schemas/examples for performance captures, budgets, analytics event catalogs, and device-tier matrices.
- Adds a strict-Luau tag lifecycle binder example that handles existing tags, new tags, removal, idempotent attach, and cleanup.
- Adds performance budget, streaming risk, tag lifecycle, analytics catalog, and package doctor utilities with negative-case tests.
- Adds fresh official research snapshot for Roblox performance, streaming, CollectionService, ScriptProfilerService permissions, AnalyticsService, DataStore best practices, and OpenAI skill packaging.

## V13 — 2026-11-15
- Added CI and quality-engineering skills, workflow profiles, test harness guidance, Luau static analysis, reproducible toolchain and artifact checks, GitHub Actions security review, and release evidence preflight.
- Added ten Python utilities, four schemas and four examples, focused prompts/templates, and a read-only GitHub Actions workflow with immutable action pins.
- Repaired 11 inherited SKILL.md YAML frontmatter blocks and added a strict metadata audit.
