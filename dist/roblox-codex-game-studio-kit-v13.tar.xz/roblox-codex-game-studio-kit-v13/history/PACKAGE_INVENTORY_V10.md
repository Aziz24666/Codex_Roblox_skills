# V10 Package Inventory

- Version: V10
- Generated: 2026-11-15
- Total files before inventory/manifest: 691
- Specialist skill folders: 96
- Markdown documents under docs/: 171
- Prompt files: 122
- Template files: 89

## File counts by top-level path

| Path | Files |
|---|---:|
| (root files) | 15 |
| `.agents/` | 99 |
| `artifacts/` | 5 |
| `docs/` | 171 |
| `examples/` | 53 |
| `project-template/` | 39 |
| `prompts/` | 122 |
| `research/` | 7 |
| `schemas/` | 33 |
| `studio-plugin/` | 14 |
| `templates/` | 89 |
| `tools/` | 44 |

## V10-specific additions

- New skills: 13
- Existing inherited skills updated with mandatory research gate: 83
- New V10 documentation guides: 24
- New V10 prompts: 16
- Research decision examples: 3
- New Python tools: 6
- New JSON Schemas: 3

See `INDEX_V10.md` and `CHANGELOG.md`.
