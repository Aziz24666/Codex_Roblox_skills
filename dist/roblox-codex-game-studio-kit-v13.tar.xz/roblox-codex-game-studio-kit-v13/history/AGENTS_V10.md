# Roblox Codex Game Studio Kit — V10 Operating Contract

## Mission
Build complete, maintainable Roblox experiences using current platform guidance, reusable systems, data-driven content, safe Studio automation, and verifiable tests. Optimize for player experience and human maintainability, not for file count or architectural novelty.

## Non-negotiable rule: research before design and implementation
**Before every substantive Roblox development task, Codex MUST perform fresh online research. Do not implement first and search afterward. Do not rely on memory, old project notes, prior skill text, or a previous version of this kit as proof that an API or practice is still current.**

This applies to gameplay systems, Luau/engine APIs, Studio plugins, MCP integrations, editor tooling, Rojo/Script Sync/toolchains, UI/input, networking, physics, persistence, assets, security, performance, testing, release workflows, and architecture choices. For purely editorial changes with no Roblox behavior/API implications, inspect the directly affected material and state why a wider research pass is not relevant.

### Mandatory research procedure
1. **Classify the change.** State the player/developer outcome, risk level, Roblox services/classes/methods/properties, tools, data flows, and decisions that need verification.
2. **Search official Roblox sources first.** Search and open current Creator Hub documentation, exact API reference pages, Studio documentation, relevant release notes/current updates, and official Roblox announcements/DevForum posts. Search the exact API names and the intended use case. Read pages, not just result snippets.
3. **Search online for the best clean approach.** Search upstream documentation for any third-party tool being considered (for example Rojo, Rokit, Wally, Selene, StyLua, or MCP client integration) and at least one reputable independent/primary source where relevant. Do not treat a random tutorial, copied code snippet, search summary, or unmaintained repository as authoritative.
4. **Compare approaches.** For architecture, tooling, performance, editor, data, or security choices, compare at least two viable approaches. Explain complexity, reliability, performance, maintenance, compatibility, team workflow, and migration cost. Choose the simplest stable approach that meets requirements. Do not adopt beta/experimental APIs just because they are new.
5. **Verify currency and context.** Check whether each API is stable, beta, deprecated, restricted, Studio-only, plugin-security-only, client-only, server-only, or subject to feature flags/permissions. Check release notes and changelogs for relevant changes. Record the date accessed and any publication/update date visible.
6. **Record the decision before implementation.** Create a research decision record under `research/decisions/` using `schemas/v10-research-decision.schema.json`. Include search queries, source URLs, claims supported, alternatives, chosen approach, limitations, exact files/systems in scope, and a verification plan.
7. **Prototype uncertainty.** If docs conflict, an API is new/beta, an example is ambiguous, or the approach has meaningful risk, create the smallest disposable Studio test/spike and verify before integrating. Keep the spike separate from production code.
8. **Implement against the verified approach.** Reopen relevant references if a task expands into a new API surface. Never invent signatures, properties, permission behavior, limits, or compatibility guarantees.
9. **Re-check after implementation.** Compare what was built to the researched contract. Update the decision record if the implementation or evidence changed.

### Minimum evidence standard
- At least one current official Roblox source for Roblox API/platform claims.
- At least two distinct source domains for meaningful technical decisions where credible sources exist; one should be an official Roblox source. For third-party tools, include the upstream tool documentation.
- At least two approaches for meaningful architecture/tooling/performance/security choices. A narrow API lookup may record one selected usage and explain why no alternative is relevant.
- Use official Creator Hub/API references as the source of truth for signatures and platform guarantees. Use official release notes/announcements to identify recency, rollout, beta and deprecation context. Use upstream docs for community tools. Use community discussion to discover pitfalls, not override primary API docs without verification.
- Search snippets are discovery aids only. Open and read the source page. Record exact URLs, title, domain, accessed date, relevant claim, and limitations.
- If web access or reliable sources are unavailable, mark the task `BLOCKED — RESEARCH NOT VERIFIED` before implementation. Do not claim a best/current practice from memory.

### Freshness policy
A prior research record is useful background but is **not** a substitute for fresh research on a new task. Re-open current relevant docs and check current updates each time the affected API/feature is touched. Re-check before migrations, releases, or adoption of a new API/tool. Record research date. Do not use V10's baseline research snapshot as a permanent truth source.

## First actions for every task
1. Read this file and applicable nested `AGENTS.md` files.
2. Inspect Git status/diff, source tree, project mappings, data model, assets, package/toolchain manifests, tests, generated files, and existing plugins.
3. Determine the source of truth: Studio-native, Script Sync, partially managed files/Rojo, fully managed Rojo, or mixed. Never migrate by assumption.
4. Inventory actual capabilities: local filesystem, CLI programs, internet search/browser, Roblox Studio session, Studio MCP, Rojo server, place/test environment, and credentials/permissions. Skills do not grant access.
5. Complete the mandatory research procedure before changing behavior or making a major design choice.
6. Read `INDEX_V10.md`, then route only to relevant specialist skills and docs. Load references progressively; do not read every skill for every task.
7. Create a short task plan with acceptance criteria, affected modules, test plan, and approval boundary.

## V10 engineering principles
- Prefer the simplest architecture that preserves clear ownership, strong contracts, testability, and extension points. Avoid abstractions that do not remove real duplication or clarify responsibility.
- Prefer `--!strict` for new or significantly modified Luau modules where practical. Define public types/contracts and validate untrusted data at boundaries.
- Separate definitions/configuration, shared behavior, per-instance runtime state, presentation, persistence, networking, editor tooling, and generated artifacts.
- Reuse systems through composition, data registries, schema-driven configuration, and small modules. Do not copy a controller per NPC/item/prop when a shared runtime + definition is appropriate.
- Keep definitions immutable at runtime; clone/configure per-instance state. Avoid shared mutable tables across entities.
- Keep module APIs small and explicit. Avoid mega-modules, circular dependencies, hidden global state, service-locator sprawl, needless singleton managers, and deep wrapper stacks.
- Every module must have a clear purpose, owner, public interface, execution context, dependencies, lifecycle, error behavior, and test seam.
- Prefer event-driven behavior and measured scheduling. Do not add per-frame work or object pooling without evidence and current platform guidance.
- Use a clear source-of-truth strategy. Do not maintain duplicate hand-edited copies of generated files.
- Generated code must be deterministic, reproducible, reviewable, and protected from untrusted string/code injection. Never turn data fields into executable source.
- Make editor previews read-only; make writes explicit, validated, undoable, collision-safe, and reportable.

## Roblox platform requirements
- Server is authoritative for progression, currency, inventories, ownership, permissions, purchases, rewards, matchmaking results, and durable writes.
- Treat every client argument and client-triggered event as untrusted. Validate type, shape, bounds, finite numbers, allowlists, ownership, distance, game state, cooldown/rate, and expected server-side cost where relevant.
- Use RemoteEvents for one-way communication; use RemoteFunctions only when synchronous request/response semantics are genuinely needed. Never let a client supply arbitrary instance paths, code, asset-loading instructions, or mutation targets.
- Keep persistent data schema-versioned and migrate with tested, recoverable procedures. Re-check current DataStore limits, retries, budgets, and UpdateAsync guidance before implementation.
- Design for instance streaming; do not assume every Workspace descendant is present on a client at join or at all times.
- Treat inserted models, plugins, packages, animations, audio, textures, and scripts as untrusted until provenance, permissions, moderation/availability, and embedded behavior are checked.
- Do not claim an asset ID is valid/usable just because it matches an ID pattern.

## V10 Roblox Studio MCP and tooling workflow
- Check whether the current Roblox Studio session exposes its official built-in MCP server and whether the active Codex client is connected. Read the current official MCP instructions before setup/use.
- If connected, use Studio MCP for appropriate DataModel inspection, script reads/edits, Luau execution, asset/editor tasks, and playtests. Confirm the target Studio/place identifier before every write when multiple sessions exist.
- Treat MCP as a powerful write-capable interface. Inspect before editing, make narrow changes, preserve backups/source-control diffs, and never run destructive or production actions without approval.
- If MCP is unavailable, use the project’s verified source-of-truth workflow and available CLI. Do not claim Studio was controlled when only files were edited.
- Select Studio-native, Script Sync, partially managed Rojo, or fully managed Rojo based on the project and official workflow comparison. Do not migrate a project merely to match a template.
- Pin external tool versions and verify upstream installation, compatibility, and release status before adding/upgrading tools.

## V9/V10 data-driven editor and content factory rules
1. Schema catalog is the single source of truth for field metadata; generated Luau catalog must be reproducible from it.
2. Keep schema, content definition, template, shared runtime, runtime state, editor UI, validator, preview, generator, and manifest separate.
3. Schema validation, definition validation, semantic validation, source/template validation, and asset-availability/permission checks are distinct stages.
4. Preview must not mutate the DataModel. Generate is explicit and gated by a complete dry-run report.
5. Generators must be deterministic, idempotence-aware, allowlisted, collision-safe, provenance-stamped, and undoable.
6. Do not overwrite content silently. Create-new/skip-existing is the default; replacement requires diff preview and explicit confirmation.
7. Use safe serialization for definition modules. Never interpolate arbitrary user text into executable Luau source.
8. Keep plugins as authoring tools; do not make production gameplay depend on a Studio plugin.
9. Test two or more variants through one family generator and shared runtime. Document how a human adds a family, field type, template, and generator.

## Quality and test truth
Use these statuses only: `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, `NOT APPLICABLE`.
- JSON/schema validation is not Luau compilation.
- Static scans are not a full security audit.
- A file diff is not a successful Studio sync.
- A Rojo build is not a Studio playtest.
- Solo play is not multiplayer verification.
- Device emulation is not physical-device verification.
- A test plan is not executed evidence.
Record environment, Studio/tool version, place/session ID where appropriate, test entrypoint, expected/actual, status, logs/screenshots, and limitations.

## Approval and safety boundaries
Make ordinary, reversible local edits independently. Ask before publishing/unpublishing, uploading or replacing public assets, spending Robux, creating/deleting places, changing permissions, accessing/migrating/resetting production player data, modifying live settings, committing/pushing externally, or destructive repository operations. Never ask for, print, commit, or store credentials, cookies, `.ROBLOSECURITY`, API keys, passwords, or tokens.

## Required project artifacts
Create only useful artifacts: project map, research decision records, source inventory, architecture decisions, module contracts, feature specs, schemas/definitions, generator manifests, test evidence, asset provenance, performance baselines, migration plans, and release manifests. Avoid empty or duplicate templates.

## Final report
State the player/developer outcome, implementation paths, research performed and key sources, chosen approach and alternatives, commands actually run, test levels/results, Studio/MCP status, evidence paths, known limitations, and next milestone. Never claim current, best, secure, production-ready, fully tested, published, or bug-free without evidence.

## V10 skill routing
Use `$roblox-game-builder` for whole-game work. Add `roblox-research-first-engineering` to every substantive Roblox task. Use the minimum additional specialist skills needed. For V9/V10 editor work, route to the schema editor, content factory, module-boundary, code-quality, plugin-tooling, and research skills. Read `INDEX_V10.md` and the relevant current research documents first.
