# Research Decision Index

Records are evidence snapshots. Re-open current sources on every new task; this index is not a currency guarantee.

| Record | Date | Status | Task | Source domains | File |
|---|---|---|---|---|---|
| `example-studio-mcp-agent-integration` | 2026-11-15 | RESEARCHED | Determine whether connected Roblox Studio MCP should be used by the coding agent | create.roblox.com, devforum.roblox.com | `v10-research-decision-record-mcp.json` |
| `example-remote-communication-contract` | 2026-11-15 | RESEARCHED | Choose a safe client-server communication pattern for game requests | create.roblox.com, devforum.roblox.com | `v10-research-decision-record-remotes.json` |
| `example-toolchain-workflow` | 2026-11-15 | RESEARCHED | Choose a source-of-truth workflow for an existing Roblox project | create.roblox.com, rojo.space | `v10-research-decision-record.json` |
