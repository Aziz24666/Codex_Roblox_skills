# V12 Source Register

Research snapshot accessed 2026-11-15. Re-open sources for future implementation work.

- Roblox Performance optimization: https://create.roblox.com/docs/performance-optimization
- Roblox Instance streaming: https://create.roblox.com/docs/workspace/streaming
- Roblox Streaming techniques: https://create.roblox.com/docs/workspace/streaming/techniques
- Roblox CollectionService API: https://create.roblox.com/docs/reference/engine/classes/CollectionService
- Roblox ScriptProfilerService API: https://create.roblox.com/docs/reference/engine/classes/ScriptProfilerService
- Roblox Analytics custom events: https://create.roblox.com/docs/production/analytics/custom-events
- Roblox Analytics event types and limits: https://create.roblox.com/docs/production/analytics/event-types
- Roblox DataStore best practices: https://create.roblox.com/docs/cloud-services/data-stores/best-practices
- OpenAI Agent Skills guide: https://developers.openai.com/api/docs/guides/tools-skills
- OpenAI skills/context guidance: https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
