# Task Research Decisions

Put one JSON decision record per substantive task here. Use the current date, open current official sources, search alternatives, and run the V10 linter/gate. The sample records in this directory are baseline examples; create a new record for your own work.
