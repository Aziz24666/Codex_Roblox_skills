# V13 CI and Quality Pipeline Decision

- Accessed: 2026-11-15
- Decision: add opt-in, read-only CI quality workflows and explicit profile-based checks; do not auto-publish.

## Primary sources and claims
- Roblox file-based workflow comparison: https://create.roblox.com/docs/projects/file-based-workflows — Studio-native, partially managed, fully managed workflows have distinct source-of-truth boundaries; CI scope should match the selected profile.
- Roblox Rojo docs: https://create.roblox.com/docs/projects/rojo — Rojo is community-maintained; tool versions should be pinned.
- Roblox Script Sync docs: https://create.roblox.com/docs/scripting/sync — Script Sync syncs scripts/folders and has specific limits; it is not full DataModel source control.
- Roblox Studio testing modes: https://create.roblox.com/docs/studio/testing-modes — client/server and scripted testing are distinct levels.
- Roblox StudioTestService: https://create.roblox.com/docs/reference/engine/classes/StudioTestService — scripted Studio tests require Studio/plugin context.
- Roblox Open Cloud Luau Execution: https://create.roblox.com/docs/cloud/reference/features/luau-execution — headless place execution is authenticated and external to a local-only CI run.
- Luau CLI: https://luau.org/getting-started/ — `luau-analyze` is a CLI static analysis/type-checking option.
- GitHub Actions security: https://docs.github.com/en/actions/reference/security/secure-use — least privilege and action dependency integrity matter.
- GitHub pull_request_target: https://docs.github.com/en/actions/reference/security/securely-using-pull_request_target — privileged workflows must not check out and execute untrusted PR code.
- OpenAI Codex skill guidance: https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra — short descriptions and progressive disclosure reduce unnecessary context.

## Alternatives considered
1. Fully-managed Rojo + CI build/publish for every project: rejected as default because it imposes migration and content-ownership complexity that many Studio-native or partially-managed projects do not need.
2. Minimal read-only CI profile plus optional project-specific build/Studio gates: selected because it fits more projects and separates routine checks from privileged release operations.

## Security properties
- Pull-request workflow has `contents: read` only.
- Checkout and setup-python actions are pinned to verified full commit SHAs.
- `persist-credentials: false` is set.
- No deployment, Open Cloud key, public asset upload, or production mutation occurs.
- `pull_request_target` is not used.

## Verification boundary
The sample GitHub workflow is structurally audited and the local Python preflight is tested. No remote GitHub Actions run, Roblox Studio session, Rojo build, or Open Cloud operation was performed during package creation.
