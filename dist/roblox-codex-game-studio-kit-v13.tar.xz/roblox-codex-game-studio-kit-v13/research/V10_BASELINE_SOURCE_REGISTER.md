# V10 Baseline Research Source Register

Accessed during V10 package research: 2026-11-15. Reopen every applicable source on each future task.

| Source | URL | Use for |
|---|---|---|
| Creator Hub — Studio MCP server | https://create.roblox.com/docs/studio/mcp | Studio MCP, available tools, client connection, safety |
| Creator Hub — Compare file-based workflows | https://create.roblox.com/docs/projects/file-based-workflows | Studio-native, Script Sync, partially managed and fully managed workflows |
| Creator Hub — Script Sync | https://create.roblox.com/docs/scripting/sync | Built-in external editor synchronization |
| Creator Hub — Rojo | https://create.roblox.com/docs/projects/rojo | Rojo capabilities and community-maintained status |
| Rojo upstream docs | https://rojo.space/docs/ | Project mapping, sync and build |
| Creator Hub — Luau | https://create.roblox.com/docs/luau | Luau language capabilities |
| Creator Hub — Type checking | https://create.roblox.com/docs/luau/type-checking | Gradual typing and strict mode |
| Creator Hub — Security tactics | https://create.roblox.com/docs/scripting/security/security-tactics | Server authority and client threat model |
| Creator Hub — Client/server boundary | https://create.roblox.com/docs/scripting/security/client-server-boundary | Request validation and remote boundaries |
| Creator Hub — Remote events | https://create.roblox.com/docs/scripting/events/remote | Remote semantics and delivery guarantees |
| Creator Hub — DataStore best practices | https://create.roblox.com/docs/cloud-services/data-stores/best-practices | Storage layout, buffering, retries, UpdateAsync |
| Creator Hub — Studio testing modes | https://create.roblox.com/docs/studio/testing-modes | Solo, client/server, multi-client, and scripted testing |
| Creator Hub — StudioTestService | https://create.roblox.com/docs/reference/engine/classes/StudioTestService | Plugin-driven Studio test automation |
| Creator Hub — Performance optimization | https://create.roblox.com/docs/performance-optimization | Performance workflow and measurements |
| Creator Hub — Improve performance | https://create.roblox.com/docs/performance-optimization/improve | Script, memory and streaming performance |
| Creator Hub — Test on hardware | https://create.roblox.com/docs/performance-optimization/test-on-hardware | Physical-device and network verification |
| Creator Hub — Packages | https://create.roblox.com/docs/projects/assets/packages | Reusable, versioned package hierarchies |
| Creator Hub — ChangeHistoryService | https://create.roblox.com/docs/reference/engine/classes/ChangeHistoryService | Undo/redo for plugin edits |
| Creator Updates | https://create.roblox.com/updates | Current official feature announcements and updates |
| Roblox Updates/Announcements | https://devforum.roblox.com/c/updates/announcements/36 | Official rollout and platform change discussions |
| Roblox Creator Docs source repository | https://github.com/Roblox/creator-docs | Official documentation source and changes |
