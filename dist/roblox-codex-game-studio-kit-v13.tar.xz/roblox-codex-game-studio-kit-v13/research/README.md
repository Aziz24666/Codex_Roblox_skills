# Research Records

Create one current decision record per substantive feature/architecture/API/tooling task. Use `schemas/v10-research-decision.schema.json` and the template in `templates/v10-research-decision-record.json`. Put records in `research/decisions/`. Run the linter and file-scope gate before implementation. The sample records in this directory are baseline examples; create a new record for your own work.

`python tools/v10_research_index.py` regenerates `research/RESEARCH_INDEX.md`.
