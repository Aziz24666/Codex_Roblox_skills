# V9 Editor Field Reference

Generated from the schema catalog. This is a documentation artifact, not runtime validation evidence.

## NPC (`NPC`)

Reusable non-hostile or neutral character variant.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `VillageGuide` |  |
| `displayName` | Display name | `text` | `Village Guide` | maxLength=48 |
| `behavior` | Behavior | `enum` | `Patrol` | options=['Wander', 'Patrol', 'Follow', 'Guide', 'VendorIdle'] |
| `movement.walkSpeed` | Walk speed | `number` | `10` | min=0; max=24 |
| `movement.arrivalRadius` | Arrival radius | `number` | `2.5` | min=0.5; max=30 |
| `movement.repathInterval` | Repath interval | `number` | `2` | min=0.5; max=15 |
| `movement.maxPathRetries` | Maximum path retries | `number` | `3` | min=0; max=8 |
| `perception.noticeDistance` | Notice distance | `number` | `40` | min=0; max=150 |
| `presentation.idleAnimationAssetId` | Idle animation | `assetId` | `` | assetKind=Animation |
| `presentation.walkAnimationAssetId` | Walk animation | `assetId` | `` | assetKind=Animation |
| `presentation.iconAssetId` | Icon image | `assetId` | `` | assetKind=Image |

## Companion (`Companion`)

Follow/stay/wander companion character variant.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `ForestCompanion` |  |
| `displayName` | Display name | `text` | `Forest Companion` | maxLength=48 |
| `behavior` | Behavior | `enum` | `Follow` | options=['Follow', 'Stay', 'WanderAroundOwner', 'ReturnHome'] |
| `follow.distance` | Follow distance | `number` | `7` | min=2; max=40 |
| `follow.moveSpeed` | Move speed | `number` | `13` | min=0; max=24 |
| `follow.leashRadius` | Leash radius | `number` | `80` | min=5; max=200 |
| `presentation.idleAnimationAssetId` | Idle animation | `assetId` | `` | assetKind=Animation |
| `presentation.followAnimationAssetId` | Follow animation | `assetId` | `` | assetKind=Animation |
| `audio.spawnSoundAssetId` | Spawn sound | `assetId` | `` | assetKind=Sound |

## Cosmetic (`Cosmetic`)

Accessory cosmetic definition from an approved Accessory template.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `LeafCrown` |  |
| `displayName` | Display name | `text` | `Leaf Crown` | maxLength=48 |
| `cosmetic.slot` | Slot | `enum` | `Head` | options=['Head', 'Back', 'Shoulder', 'Waist', 'Face'] |
| `cosmetic.rarity` | Rarity | `enum` | `Common` | options=['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'] |
| `visual.scale` | Visual scale | `number` | `1` | min=0.5; max=2 |
| `visual.iconAssetId` | Icon image | `assetId` | `` | assetKind=Image |
| `audio.equipSoundAssetId` | Equip sound | `assetId` | `` | assetKind=Sound |

## World Prop (`WorldProp`)

Static environment prop generated from an approved simple prop definition.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `TrailSign` |  |
| `displayName` | Display name | `text` | `Trail Sign` | maxLength=48 |
| `world.category` | Category | `enum` | `Signage` | options=['Decoration', 'Landmark', 'Furniture', 'Nature', 'Signage'] |
| `visual.meshAssetId` | Mesh reference | `assetId` | `` | assetKind=Mesh |
| `visual.textureAssetId` | Texture reference | `assetId` | `` | assetKind=Texture |
| `visual.scale` | Scale | `number` | `1` | min=0.1; max=5 |
| `world.nonCollidable` | Non-collidable | `boolean` | `False` |  |

## Interactive Prop (`InteractiveProp`)

World object with an allowlisted harmless interaction intent.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `TravelJournal` |  |
| `displayName` | Display name | `text` | `Travel Journal` | maxLength=48 |
| `interaction.kind` | Interaction | `enum` | `OpenJournal` | options=['OpenJournal', 'ShowWaypointMarker', 'PlaySoundCue', 'IlluminateArea', 'CollectNearbyTokens'] |
| `interaction.promptText` | Prompt text | `text` | `Read` | maxLength=32 |
| `interaction.radius` | Radius | `number` | `10` | min=1; max=40 |
| `interaction.cooldownSeconds` | Cooldown seconds | `number` | `1` | min=0; max=120 |
| `visual.meshAssetId` | Mesh reference | `assetId` | `` | assetKind=Mesh |
| `audio.useSoundAssetId` | Use sound | `assetId` | `` | assetKind=Sound |

## Utility Gadget (`UtilityGadget`)

Harmless utility Tool content definition.

| Field path | Label | Kind | Default | Constraints/options |
|---|---|---|---|---|
| `id` | Definition ID | `identifier` | `TrailLantern` |  |
| `displayName` | Display name | `text` | `Trail Lantern` | maxLength=48 |
| `utility.kind` | Utility action | `enum` | `IlluminateArea` | options=['IlluminateArea', 'PlaySoundCue', 'ShowWaypointMarker', 'OpenJournal', 'CapturePhoto'] |
| `utility.cooldownSeconds` | Cooldown seconds | `number` | `0.5` | min=0; max=120 |
| `utility.durationSeconds` | Effect duration | `number` | `8` | min=0; max=180 |
| `visual.meshAssetId` | Mesh reference | `assetId` | `` | assetKind=Mesh |
| `visual.textureAssetId` | Texture reference | `assetId` | `` | assetKind=Texture |
| `audio.useSoundAssetId` | Use sound | `assetId` | `` | assetKind=Sound |
| `audio.volume` | Sound volume | `number` | `0.7` | min=0; max=1 |
