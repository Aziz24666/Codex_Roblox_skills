# V8 Module Boundary Audit

Root: `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src`

> Heuristic only. Dynamic requires and Roblox DataModel paths may not be resolved accurately.

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/client/Bootstrap.client.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Bootstrap/NPCBootstrap.server.lua`
- require sites: 4
  - `ServerScriptService.Components.NPCController`
  - `ReplicatedStorage.Shared.Config.NPCDefinitionRegistry`
  - `ReplicatedStorage.Shared.Config.NPCDefinitionValidator`
  - `ServerScriptService.Components.RouteResolver`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Bootstrap.server.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/BehaviorRegistry.lua`
- require sites: 4
  - `script.Parent.Behaviors.Follow`
  - `script.Parent.Behaviors.VendorIdle`
  - `script.Parent.Behaviors.Patrol`
  - `script.Parent.Behaviors.Wander`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/Behaviors/Follow.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/Behaviors/Patrol.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/Behaviors/VendorIdle.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/Behaviors/Wander.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/MovementController.lua`
- require sites: 1
  - `s`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/NPCController.lua`
- require sites: 2
  - `script.Parent.MovementController`
  - `script.Parent.BehaviorRegistry`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/server/Components/RouteResolver.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/ConfigTypes.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/GadgetDefinitionRegistry.lua`
- require sites: 1
  - `script.Parent.GadgetDefinitions`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/GadgetDefinitions.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/NPCDefinitionRegistry.lua`
- require sites: 1
  - `script.Parent.NPCDefinitions`

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/NPCDefinitionValidator.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Config/NPCDefinitions.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Constants.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/ExperienceConfig.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/FeatureContracts.lua`
- require sites: 0

## `/mnt/data/roblox-codex-game-studio-kit-v8/project-template/src/shared/Types.lua`
- require sites: 0

## Warnings
- No heuristic warnings found.
