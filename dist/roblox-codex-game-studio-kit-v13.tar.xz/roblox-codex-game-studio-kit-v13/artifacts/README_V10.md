# V10 Generated Artifacts

The audit tools write generated Markdown/JSON here. Regenerate after each research or project audit. Treat these files as reports, not as a source of truth unless reviewed and committed deliberately.
