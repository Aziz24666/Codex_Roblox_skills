# Roblox Codex Game Studio Kit — V13 Repository Inventory

This is the complete cumulative V13 source package, prepared for a public GitHub repository under the MIT License. It preserves the research-first, modular/data-driven Roblox development framework and adds a real CI workflow for Python validation, Luau syntax compilation, and Rojo builds.

## Verified repository counts

| Category | Count |
|---|---:|
| Specialist skills (`SKILL.md`) | 126 |
| Documentation Markdown files in `docs/` | 223 |
| All Markdown files | 666 |
| Prompt files | 158 |
| Template files | 116 |
| Top-level JSON schemas | 33 |
| JSON files total | 115 |
| Top-level Python tools | 65 |
| Python files total (tools and tests) | 75 |
| Luau source files | 60 |
| Active GitHub Actions workflows | 1 |
| Total regular files (including checksum manifest) | 944 |
| SHA-256 manifest entries (excluding the manifest itself) | 943 |

Counts exclude `.git`, `__pycache__`, `node_modules`, and `.venv`.

## Public repository files

- `LICENSE`: MIT License.
- `README.md`: project overview, quick start, structure, tests, and CI details.
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`: project contribution and community policies.
- `.github/workflows/ci.yml`: Python tests, Luau source compilation, two Rojo builds, and artifact upload.
- `.github/dependabot.yml`: weekly dependency update proposals for GitHub Actions and pip.
- `GITHUB_REPOSITORY_METADATA.md`: prepared description and topics for the GitHub About panel.

## CI tool versions

- Python: 3.13.
- Luau CLI: 0.746; release archive SHA-256 is checked before installation.
- Rojo: 7.7.1; release archive SHA-256 is checked before installation.
- GitHub Actions are pinned to full commit SHAs.

## Local validation results

- Python unittest suite: 34 tests passed.
- V13 CI preflight: all constituent checks passed.
- GitHub Actions workflow YAML parsed and heuristic security audit passed with zero findings.
- Luau compile-helper tests passed. Actual Luau syntax compilation is delegated to GitHub Actions because the Luau CLI is not installed in this environment.
- Rojo build commands are configured in GitHub Actions. Actual builds have not run yet.

See `V13_TEST_RESULTS.md` for exact scope and limitations.
