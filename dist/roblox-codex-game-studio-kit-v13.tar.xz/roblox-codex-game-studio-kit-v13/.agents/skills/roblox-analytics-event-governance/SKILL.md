---
name: roblox-analytics-event-governance
description: Design minimal, privacy-conscious AnalyticsService event catalogs and meaningful product metrics.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- State the product question each event answers and why a built-in metric is insufficient.
- Keep event names and fields low-cardinality and minimal.
- Never include passwords, tokens, contact details, precise location, health, or other sensitive personal data.
- Validate catalog shape with `tools/v12_analytics_catalog_lint.py`.
- Research current AnalyticsService limits and delivery environment; custom events are not Studio test telemetry.

Read `docs/V12_ANALYTICS_EVENT_GOVERNANCE.md`.
