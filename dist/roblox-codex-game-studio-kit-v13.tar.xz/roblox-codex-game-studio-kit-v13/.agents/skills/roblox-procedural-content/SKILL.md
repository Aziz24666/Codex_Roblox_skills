---
name: roblox-procedural-content
description: Create bounded, deterministic procedural content and world-generation systems. Use for generated environments or content.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Procedural Content

Procedural generation must be reproducible, bounded, and explainable. Randomness is not a substitute for design constraints.

## Required design
- Define output type, world bounds, seed source, version, generation phases, constraints, and failure behavior.
- Choose whether generation runs at edit time, server runtime, or client presentation time. Never let clients authoritatively decide rewards, collision-critical geometry, or competitive outcomes.
- Use deterministic seeds and stable coordinate/chunk identifiers when clients or servers must agree.
- Separate layout generation, validation, instance construction, decoration, and cleanup.
- Bound part count, memory, CPU per frame, retry count, and concurrent jobs.
- Design chunk lifecycle: generate, validate, activate, stream, deactivate, and dispose.
- Add constraints for reachability, spawn safety, navigation, overlap, clearance, and content density.
- Provide a fixed seed mode for bug reproduction and a random seed mode for normal variation.

## Validation suite
Test known seeds, boundary seeds, empty/minimal dimensions, maximum supported dimensions, invalid configuration, overlapping features, unreachable objectives, chunk transitions, late joins, and repeated generation/cleanup. Store the seed and generator version in bug reports. Read `docs/PROCEDURAL_GENERATION_AND_WORLD_BUILDING.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
