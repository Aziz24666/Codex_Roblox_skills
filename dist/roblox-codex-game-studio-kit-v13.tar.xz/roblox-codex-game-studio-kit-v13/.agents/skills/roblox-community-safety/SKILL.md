---
name: roblox-community-safety
description: Design privacy-aware, age-appropriate community features, reporting flows, safe social defaults, and moderation-conscious experiences.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`.

# Roblox Community Safety

Use for social hubs, user-generated content, player reports, community tools, and privacy-sensitive features.

## Required workflow

1. Inventory user-generated surfaces such as names, signs, builds, profiles, and messages.
2. Use current platform filtering/moderation for applicable content; never build bypasses or hidden unfiltered display routes.
3. Design report, block, mute, privacy, and escalation flows according to current platform capabilities.
4. Minimize collected data; do not store private chat, credentials, sensitive data, or unnecessary profiles.
5. Enforce moderator roles server-side. Never trust client moderator flags.
6. Make moderation auditable, least-privilege, and reversible where appropriate.
7. Test filtered text, reporting, block/mute, permission spoofing, and moderation failure.
8. Verify current Roblox policy and mark uncertain interpretations for authoritative review.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`
- `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`
- `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`
