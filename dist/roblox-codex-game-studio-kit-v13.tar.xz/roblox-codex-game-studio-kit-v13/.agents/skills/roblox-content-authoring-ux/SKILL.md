---
name: roblox-content-authoring-ux
description: Design approachable Studio authoring interfaces that help creators configure and validate game content.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Content Authoring UX

Use plain labels, examples, inline validation, sensible defaults, grouping, clear errors, and explicit actions. Separate Save Definition, Preview, and Generate semantics. Show output path, source template, missing assets, and collision status. Make the form usable in compact docked and wide layouts. Read `docs/V9_EDITOR_UX_CHECKLIST.md`.
