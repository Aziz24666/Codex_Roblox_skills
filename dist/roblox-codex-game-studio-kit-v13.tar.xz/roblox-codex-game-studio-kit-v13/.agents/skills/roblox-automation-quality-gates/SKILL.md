---
name: roblox-automation-quality-gates
description: Roblox Automation Quality Gates.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Automation Quality Gates

Design validation as a layered pipeline: formatting/lint, strict type analysis, schema and generated-code checks, module-boundary checks, static API inventory, unit/contract tests, build/sync checks, Studio tests, multi-client/device/network tests, and staging smoke tests. Run only available checks and label each level truthfully. Fail fast on deterministic checks; preserve logs and artifacts. Do not call a static scan a security audit or a successful build a runtime test.
