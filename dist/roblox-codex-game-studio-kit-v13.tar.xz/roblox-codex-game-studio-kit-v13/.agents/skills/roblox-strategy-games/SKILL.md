---
name: roblox-strategy-games
description: Design turn-based and real-time strategy systems for Roblox, including action validation, turn/state flow, matchmaking, map rules.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Strategy Games — V6 Genre Specialist

## Design principles
- Define turn or tick ownership and legal action sets as explicit state-machine transitions.
- Make server truth canonical for match state, resources, victory conditions, cooldowns, and rankings.
- Separate public, private-to-player, and server-only information. Replicate only what each client is allowed to know.
- Use compact state snapshots plus versioned events where appropriate; define reconnect/resync behavior.
- Keep action ordering, timeout rules, pause behavior, surrender, tie-breaks, and disconnect outcomes explicit.

## Validation
Validate action schema, active match, player identity, turn owner, resource availability, unit/build limits, map bounds, cooldown, and legal state. The server recalculates outcomes; clients send intent, not authoritative results.

## Fairness and UX
Explain legal actions and game state, provide readable feedback, support accessible controls, and avoid misleading monetization or opaque competitive modifiers.

## QA
Test simultaneous action requests, duplicated request IDs, out-of-turn actions, disconnect/reconnect, late spectators, hidden-information leaks, timeout boundaries, and match-end races.

Read `docs/V6_GENRE_SYSTEMS_AND_BALANCE.md` and the remote-contract references.
