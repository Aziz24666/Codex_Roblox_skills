---
name: roblox-inventory-loadouts
description: Design server-authoritative inventory, equipment, item catalog, capacity, and loadout systems. Use for player item state.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Inventory and Loadouts — V7

## Mission
Keep item ownership and equipment rules consistent across client UI, server state, persistence, and game systems.

## Contract
Define item IDs, catalog version, stackability, capacity, slot types, equip restrictions, unique-item behavior, durability/charges if relevant, tradeability if relevant, and removal semantics. Keep definitions separate from per-player owned instances.

## Authority and integrity
- Server decides grants, spends, equips, unequips, drops, and capacity changes.
- Client sends an action request with stable item/slot identifiers, never a client-authored item definition or price.
- Validate ownership, catalog allowlist, state, capacity, slot compatibility, prerequisites, cooldown, and duplicate request IDs.
- Make grants/removals idempotent and auditable. Never let a UI-only state change become canonical ownership.

## Persistence
Use versioned compact records, safe migrations, bounded retries, and explicit handling for load failure. Never replace unknown/unavailable data with a fresh empty inventory automatically.

## UX
Show pending, success, rejected, and loading states. Prevent stale UI from implying an item was equipped when the server rejected it. Support touch/gamepad and accessible item labels.

## QA
Test full inventory, stale catalog, duplicate request, equip race, respawn, reconnect, load failure, migration, item removal, and simultaneous UI actions.

Read `docs/V7_INVENTORY_AND_LOADOUT_CONTRACTS.md`.
