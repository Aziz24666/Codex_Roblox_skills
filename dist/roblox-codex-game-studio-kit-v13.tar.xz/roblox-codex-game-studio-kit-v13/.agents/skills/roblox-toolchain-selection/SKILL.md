---
name: roblox-toolchain-selection
description: Roblox Toolchain Selection.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Toolchain Selection

Inspect the current project before selecting a workflow. Compare Studio-native, Script Sync, partially managed Rojo, and fully managed Rojo against the official workflow guide. Identify the source of truth separately for code, place content, UI, terrain, assets, and generated files. Start with the simplest workflow that preserves review, collaboration, build reproducibility, and the owner's current workflow. Pin external tool versions. Do not migrate without a reversible plan and approval for destructive changes.
