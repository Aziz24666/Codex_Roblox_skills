---
name: roblox-puzzle-adventure
description: Design puzzle/adventure state machines, clue systems, reset behavior, and progression gates. Use for puzzle gameplay.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Puzzle and Adventure Systems

Use for logic puzzles, exploration adventures, clue chains, interaction rooms, escape-room-like experiences, and cooperative environmental puzzles.

## Design process
1. State the intended player insight or skill being tested.
2. Ensure clue language, world composition, and interaction affordances point toward a fair solution.
3. Represent puzzle state explicitly and keep rules separate from presentation.
4. Define valid transitions, completion criteria, reset behavior, and checkpoint integration.
5. For shared puzzles, define whether state is per-player, per-party, or per-server.
6. Guard simultaneous interactions and duplicate completion requests.
7. Add progressive hints that help without accidentally revealing later content.
8. Test incorrect inputs, reset, late join, disconnect, and cooperative state consistency.

## Content quality
Make required objectives readable without relying on color or audio alone. Support reasonable hints and recovery from soft-locks. Use original story, text, characters, and environmental designs.

Read `docs/V4_CONTENT_AUTHORING_AND_VALIDATION.md`, `docs/V4_SESSION_CONCURRENCY_AND_RECOVERY.md`, `docs/WORLD_AND_LEVEL_DESIGN.md`, and `docs/V4_GENRE_ACCEPTANCE_MATRICES.md`.
