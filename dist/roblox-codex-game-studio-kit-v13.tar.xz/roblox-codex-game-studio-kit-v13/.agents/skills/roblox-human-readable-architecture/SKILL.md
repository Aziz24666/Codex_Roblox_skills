---
name: roblox-human-readable-architecture
description: Make generated architecture transparent to a project owner through diagrams, maps, extension guides, and change impact reports.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Human-Readable Architecture

Use after a new subsystem or refactor.

- Maintain a concise system map and module dependency map.
- Explain where to add a new NPC definition, behavior, gadget definition, editor field, or runtime capability.
- Keep naming consistent across config IDs, module paths, tags, and UI labels.
- Document ownership and execution context for each entrypoint.
- Generate change impact notes when public contracts or schema versions change.

Read `docs/V8_HUMAN_EXTENSION_GUIDE.md` and `docs/V8_MODULE_BOUNDARIES_AND_COMPOSITION.md`.
