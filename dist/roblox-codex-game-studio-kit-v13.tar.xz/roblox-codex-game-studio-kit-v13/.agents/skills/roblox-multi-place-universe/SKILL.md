---
name: roblox-multi-place-universe
description: Design multi-place Roblox experiences with place responsibilities, teleport transitions, shared data boundaries, cross-server coordination.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Multi-Place Universe Architecture — V6 Specialist

## Mission
Design a coherent experience across multiple places without creating accidental data silos or unsafe handoff assumptions.

## Discovery and design
1. Inventory universe/place IDs only from trusted project configuration or user-provided sources.
2. Build a place map: start place, hub, gameplay instances, private/reserved places, social areas, and test places.
3. Define each place's responsibility, ownership, audience, startup contract, supported client versions, and fallback route.
4. Decide which state is durable, temporary cross-server, server-local, or passed as a minimal transition hint.
5. Define teleport failure, retry, rejoin, party integrity, and user-facing recovery.

## Data boundaries
- Use durable cross-place player progress only where required and define concurrency rules.
- Use temporary shared coordination for queues/leases where appropriate; define expiry and reconciliation.
- Treat any client- or teleport-carried payload as untrusted input. Validate schema, size, version, ownership, expiry, and allowed values after arrival.
- Never rely on transition payload alone as the canonical source of currency, inventory, permission, purchase, or reward truth.
- Do not put secrets or private credentials in teleport payloads.

## Teleport contract
Specify source, destination, trigger, party membership, reserved-server policy, payload version, correlation ID, timeout, failure UX, retry limit, duplicate-arrival handling, and recovery destination. Verify exact APIs against current Creator Hub references before implementation.

## Testing
Test success, invalid/missing payload, full/closed destination, interrupted transition, rejoin, party changes, repeated requests, stale queue entries, and cross-place data consistency. Use separate test environments and test data.

Read `docs/V6_MULTI_PLACE_UNIVERSE_ARCHITECTURE.md` and `docs/V6_RELEASE_CHANNELS_AND_ROLLBACK.md`.
