---
name: roblox-localization
description: Build localization-ready Roblox UI and content with stable text keys, fallback behavior, locale QA, and layout resilience.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Localization

Use when an experience needs multiple languages, locale-aware UI, translated content, or localization readiness.

## Required workflow

1. Inventory player-visible text in UI, tutorials, prompts, names, errors, dialogue, and images.
2. Use stable semantic keys and a documented source-language catalog.
3. Define fallback for missing translations/keys and runtime lookup failure.
4. Plan for text expansion, RTL where supported, mixed scripts, plurals, dates/numbers, and font coverage.
5. Keep user-generated text separate and safely bounded.
6. Maintain translator context, placeholders, tone, and character limits.
7. Test long text, truncation, missing translations, button fit, RTL, and core screens.
8. Verify current platform localization APIs; do not invent methods.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_LOCALIZATION_ACCESSIBILITY.md`
- `docs/UI_UX_AND_ACCESSIBILITY.md`
- `docs/V5_CONTENT_PIPELINE_AND_ASSET_PROVENANCE.md`
