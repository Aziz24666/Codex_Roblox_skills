---
name: roblox-qa-performance
description: Plan and run Roblox tests, debug issues, review regressions, profile client/server performance, validate device coverage, inspect multiplayer.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox QA and Performance

Verification is evidence, not confidence. Distinguish static checks, automated tests, build checks, Studio playtests and production observations.

## Test workflow
1. Convert the feature brief into testable acceptance criteria.
2. Identify unit, integration, Studio runtime, multiplayer, device, persistence and regression tests.
3. Write normal, boundary, failure, concurrency and abuse cases.
4. Run formatting, lint, type analysis, project mapping and builds that are actually available.
5. Use Studio to test runtime behavior when possible; test multiple clients for shared state and remotes.
6. Test join/leave/respawn, late join, reconnect, full/empty states and failure paths as applicable.
7. Inspect output logs and record evidence.
8. Profile the slow or expensive path before optimizing. Change one hotspot at a time and compare before/after.
9. Re-run the focused suite and relevant regression suite.
10. Report all untested cases.

## Defect discipline
Classify severity by player impact, exploitability, data-loss risk and scope. Reproduce first. Fix root cause, add a regression test, then verify the fix. Do not hide errors with broad `pcall`, empty catches or log suppression.

## Performance discipline
Measure on representative device classes and real workloads. Look at frame time, memory, network/replication, physics, instance counts, script work and loading. Avoid premature micro-optimizations. Read current Creator Hub performance docs.

## Completion rule
Never claim "tested in Studio" unless Studio was actually launched and the relevant behavior was exercised. Never treat a successful static check as proof of runtime correctness.

## References
Read `docs/TEST_STRATEGY.md`, `docs/MULTIPLAYER_TEST_MATRIX.md`, `docs/PERFORMANCE_BUDGETS.md`, `docs/OBSERVABILITY.md`, and `docs/RELEASE_OPERATIONS.md`.
## V3 evidence-first QA protocol

Every test case has an ID, setup, action, expected result, actual result, environment, build/version, and evidence or log reference. Mark statuses as `PASS`, `FAIL`, `BLOCKED`, or `NOT RUN`; never infer pass from code inspection alone.

For Roblox features, select the correct test modes: solo client/server inspection, Server & Clients for replication and multiplayer, device simulation for screen/input variation, and network simulation for latency/jitter/loss sensitivity. Test Studio runtime paths separately from static checks and Rojo builds.

Prioritize critical user journeys, save/purchase integrity, permissions, simultaneous actions, late join, disconnect/reconnect, respawn, server shutdown, and regression. Profile before optimizing. Capture baseline and post-change measurements under comparable conditions. Keep a known-issues list with severity, reproduction steps, and owner.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.

## V12 runtime measurement
Use `docs/V12_RUNTIME_PERFORMANCE_LOOP.md`, `docs/V12_DEVICE_TIER_TEST_MATRIX.md`, and `docs/V12_PERFORMANCE_REGRESSION_POLICY.md`. Baseline first; profile server/client separately; optimize only evidenced bottlenecks.
