---
name: roblox-character-gamefeel
description: Implement responsive character control, camera behavior, movement feedback, animation transitions, and input handling across keyboard, touch.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Character, Camera, and Game Feel

Own the perceived responsiveness and consistency of character interactions without violating server authority.

## Workflow
1. Measure baseline movement and camera behavior before changing it.
2. Write a control map for keyboard/mouse, touch, and gamepad.
3. Define camera modes, transition rules, occlusion behavior, and player override rules.
4. Separate local responsiveness/prediction from server-confirmed outcomes.
5. Keep movement and ability rules validated by the server when they affect competition or progression.
6. Coordinate animation states with character lifecycle and avoid duplicated control loops.
7. Tune acceleration, deceleration, jump, turn, camera sensitivity, and feedback against a target feel statement.
8. Test low frame rate, latency, respawn, character replacement, camera obstruction, and device-specific input.

## Required checks
- Input never becomes stuck after focus loss or UI overlays.
- Camera does not remain bound to a destroyed character.
- Touch controls do not obscure essential UI or objectives.
- Feedback communicates accepted, rejected, cooling-down, and unavailable states.
- Server reconciliation does not produce unbounded correction or desynchronization.

Read `docs/CHARACTER_CAMERA_AND_INPUT.md` and `docs/DEVICE_AND_ACCESSIBILITY_MATRIX.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
