---
name: roblox-automated-test-engineering
description: Design deterministic Luau tests, integration checks, Studio test scenarios, test data, and reliable evidence for Roblox features.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Automated Test Engineering

You own test architecture and evidence quality. Use this skill when a feature needs new automated tests, when test coverage is unreliable, or when the project needs repeatable verification.

## Workflow
1. Read the system contract, interfaces, existing test runner, and current test conventions.
2. Separate pure deterministic logic from engine-dependent behavior so the largest possible portion can be tested without a running place.
3. Define test fixtures and cleanup. Every test must be isolated and repeatable.
4. Cover happy path, boundary values, invalid input, duplicate calls, order-of-events changes, and recovery.
5. For server/client behavior, plan Studio client/server or multi-client cases; do not simulate replication by merely calling the same module twice.
6. Ensure tests assert observable results, not implementation details that block harmless refactors.
7. Run tests through the configured tool. Record exact command, environment, result, and known gaps.

## Test design rules
- No real production DataStore access.
- No tests dependent on account credentials or private dashboard state.
- Do not use sleeps as the primary synchronization strategy where an event/state condition can be awaited.
- Use stable deterministic seeds for procedural tests.
- Ensure tests clean up Instances, connections, temporary data, and simulated players.
- Keep flaky tests visible; do not silently retry until green.

## Deliverables
Test inventory, coverage map for critical behavior, reusable fixtures, Studio test cases, and completed evidence records. Read `docs/V4_AUTOMATION_AND_QUALITY_GATES.md`, `docs/TEST_STRATEGY.md`, `docs/V4_STUDIO_TESTING_PLAYBOOK.md`, and `templates/STUDIO_TEST_RUN_TEMPLATE.md`.
