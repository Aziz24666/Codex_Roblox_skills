---
name: roblox-genre-blueprints
description: Translate a Roblox game genre into a focused core loop, feature sequence, systems map, and test plan without overbuilding generic mechanics.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Genre Blueprints

Use genre patterns as starting hypotheses, not formulas. Confirm the requested game fantasy and audience before applying a blueprint.

## Workflow
1. Identify the dominant player verb and short repeatable loop.
2. Choose one archetype or a deliberate hybrid, and explain what is borrowed from each.
3. Define first-session onboarding and a complete short-session outcome.
4. Identify progression and social interaction only where they reinforce the core loop.
5. Build a small playable slice before building broad content.
6. Design anti-grind and fair reward pacing; do not depend on manipulative retention or gambling-style paid randomness.
7. Map the core loop to world, UI, networking, persistence, and QA skills.

## Supported design patterns
Use the references for obstacle/course, simulator/collection, tycoon/building, round-based party, exploration/adventure, puzzle/co-op, racing/time-trial, social/role-play, and arena/objective experiences. Avoid copying a successful game's exact map, interface, branding, progression tables, or proprietary content.

Read `docs/GENRE_BLUEPRINTS.md` before writing a full feature roadmap.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
