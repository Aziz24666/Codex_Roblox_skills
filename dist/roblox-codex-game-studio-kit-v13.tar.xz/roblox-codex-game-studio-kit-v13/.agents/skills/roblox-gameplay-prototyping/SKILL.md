---
name: roblox-gameplay-prototyping
description: Rapidly prototype and evaluate Roblox gameplay mechanics using disposable grayboxes, measurable hypotheses, and vertical-slice decisions.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Gameplay Prototyping

Use this skill before committing to uncertain mechanics, controls, pacing, camera behavior, multiplayer interactions, or procedural systems.

## Prototype protocol
1. State the design question in one sentence.
2. Define observable success and failure signals before building.
3. Identify the cheapest representative test: graybox geometry, a single UI flow, a pure simulation, or a two-client Studio scenario.
4. Limit the prototype to one major uncertainty; do not build production architecture prematurely.
5. Make controls and feedback representative enough to evaluate the hypothesis.
6. Test with the intended input/device context when possible.
7. Capture observations, failure cases, and a clear keep/change/drop decision.
8. If retained, refactor into the project's real architecture; do not promote throwaway code unchanged by default.
9. Delete or isolate discarded prototype artifacts.

## Avoid
- polishing art before the interaction is validated;
- using a single successful run as proof of fairness;
- designing around one developer's reflexes or device;
- expanding the prototype into a hidden permanent subsystem;
- inventing test outcomes when no Studio session was run.

Read `docs/FEATURE_VERTICAL_SLICE_PLAYBOOK.md`, `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`, `docs/CHARACTER_CAMERA_AND_INPUT.md`, and the relevant genre blueprint.
