---
name: roblox-content-catalog
description: Structure and validate data-driven Roblox catalogs for items, quests, levels, waves, cosmetics, dialogue, and progression content with stable.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Content Catalog Engineering — V7

## Mission
Keep game content data-driven, validated, versioned, reviewable, and safely consumable by runtime systems.

## Catalog contract
Every entry needs a stable unique ID, schema version, type, required fields, explicit references, and a defined owner. Separate player-facing text from machine identifiers. Avoid using display names as keys.

## Validation
Check duplicate IDs, missing references, invalid enums, numeric bounds, empty required text, asset provenance, localization keys, dependency cycles where relevant, and unsupported schema versions. Validate cross-catalog references before runtime.

## Runtime
Load only approved catalog content. Do not let clients create canonical catalog entries. Keep catalogs immutable during a session unless there is a deliberate versioned hot-reload design. Define safe fallback for missing content without silently granting or deleting player data.

## Content operations
Review provenance, permission, quality, safety, performance cost, and rollback for every external asset. Preserve previous catalog versions needed for existing saved data.

Read `docs/V7_CONTENT_CATALOG_GOVERNANCE.md`.
