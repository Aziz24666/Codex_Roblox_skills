---
name: roblox-plugin-development
description: Create safe, maintainable Roblox Studio plugins and internal editor tooling.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Studio Plugin Development — V6 Specialist

## Mission
Build developer-facing Studio tools that are predictable, reversible, and respectful of the current project workflow.

## Before implementation
- Confirm the plugin is actually requested and identify whether it is personal/internal or intended for distribution.
- Verify current Plugin API signatures and lifecycle behavior in Creator Hub.
- Define permissions, filesystem/network behavior, data changes, supported Studio versions, and uninstall/reset path.
- Keep plugin-only code separate from runtime experience code.

## UX and safety
- Provide clear commands, visible status, preview/dry-run, confirmation for destructive actions, undo where possible, and error messages that identify recovery steps.
- Never collect or expose credentials, session cookies, API keys, or private user data.
- Do not silently rewrite place hierarchies, overwrite scripts, or publish assets.
- Treat third-party plugin packages as untrusted; inspect source/provenance and minimize dependencies.

## Architecture
Separate UI, command dispatch, validation, project adapters, and mutation services. Make actions idempotent where possible. Keep long-running work bounded and cancellable. Log only necessary diagnostic data.

## Verification
Test install/enable/disable/reload, empty selection, large selection, permission-denied cases, malformed input, undo/recovery, and Studio-version compatibility. Never report plugin runtime tests unless executed in Studio.

Read `docs/V6_PLUGIN_AND_TOOLING_GOVERNANCE.md`.
