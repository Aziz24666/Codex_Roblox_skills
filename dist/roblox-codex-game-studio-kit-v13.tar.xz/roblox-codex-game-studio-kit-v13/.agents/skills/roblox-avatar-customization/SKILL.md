---
name: roblox-avatar-customization
description: Implement player avatar customization, loadouts, appearance presets, cosmetic previews, ownership validation, persistence, and responsive UI.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Avatar Customization — V6 Specialist

## Mission
Build expressive, accessible customization while respecting avatar ownership, platform APIs, asset provenance, and player data integrity.

## Architecture
- Separate owned cosmetics, equipped cosmetics, preview state, avatar appearance, and entitlement checks.
- Keep authoritative ownership and saved loadout on the server.
- Treat client preview selections as untrusted intent; validate catalog IDs, allowed combinations, ownership, and policy constraints before applying.
- Keep preview changes isolated from saved profile state until explicit confirmation.
- Use versioned loadout schemas and safe migration/rollback.

## Content and safety
Use original or properly licensed assets. Inspect marketplace/catalog asset metadata and provenance. Avoid misleading purchase previews or claims about exclusivity. Do not load arbitrary user-supplied asset IDs into trusted runtime contexts without controls.

## UX
Support keyboard, touch, and gamepad; provide clear selected/equipped/owned states; design for varied screen sizes and longer localized names.

## QA
Test invalid IDs, unowned assets, conflicting accessories, save failure, duplicate requests, rapid equip/unequip, respawn, preview cancellation, and cross-place loadout consistency.

Read `docs/V6_CONTENT_AUTHORING_AND_ASSET_VALIDATION.md` and the data/economy skills.
