---
name: roblox-release-operations
description: Prepare Roblox experiences for release: versioning, release candidates, configuration review, regression gates, rollout checklists, rollback.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Release Operations

Prepare a reviewable release candidate. The user must explicitly authorize publishing and other live external actions.

## Release procedure
1. Confirm release scope, target place/environment and release owner.
2. Review milestone acceptance criteria and unresolved defects.
3. Freeze intended scope; classify any late change by risk.
4. Run static, build, automated, Studio, multiplayer and device checks applicable to the release.
5. Review security, permissions, DataStore schema, remote contracts, asset availability and experience configuration.
6. Verify privacy, age-appropriate content, policy constraints, purchase messaging and platform requirements using current official sources.
7. Prepare version notes, known issues, operational metrics and support/rollback plan.
8. Produce a local release checklist and explicit list of actions that require owner approval.
9. If approval is given for a specific external action, perform only that action and report its actual result. Do not infer wider permission.
10. After release (when authorized), compare observed behavior to expected behavior and document issues for the next patch.

## Rollback readiness
Document what can be reverted, what data migrations are reversible, and what changes are destructive or forward-only. Never promise rollback is safe until data/schema compatibility has been examined.

## References
Read `docs/RELEASE_OPERATIONS.md`, `docs/DATA_MIGRATIONS.md`, `docs/CI_AND_TOOLCHAIN.md`, `docs/TEST_STRATEGY.md`, and `docs/DOCUMENTATION_MAINTENANCE.md`.
## V3 release protocol

A release candidate must have a version identifier, scope summary, change list, test evidence, known-issue list, data compatibility statement, asset provenance check, permission/security review, performance snapshot, and rollback/mitigation plan.

Separate local build verification, Studio playtest, private test environment, staged availability, and public publishing. Publishing and Creator Dashboard operations are approval-gated. Never claim a publish, upload, or setting change happened unless the relevant tool returned success and the result was verified.

For live incidents, prioritize player safety and data integrity, stop risky changes, preserve logs, identify blast radius, use the approved mitigation path, and document a post-incident review. Never perform a destructive rollback of player data without an explicitly approved recovery plan.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
