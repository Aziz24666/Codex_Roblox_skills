---
name: roblox-runtime-observability
description: Add low-noise diagnostics and operational signals without exposing secrets or collecting sensitive player data.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Define the operational question before adding a log, metric, or event.
- Prefer bounded enums/counters over free-form player-provided strings.
- Never log secrets, credentials, tokens, contact details, or sensitive personal data.
- Keep debug-only diagnostics separate from production telemetry.
- Rate-limit noisy diagnostics and document how to disable them.

Read `docs/V12_RUNTIME_OBSERVABILITY.md` and `docs/V12_ANALYTICS_EVENT_GOVERNANCE.md`.
