---
name: roblox-asset-pipeline
description: Plan, source, create, import, organize, validate and document Roblox models, meshes, textures, images, audio, animations, packages and other.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Asset Pipeline

Keep assets safe, traceable, consistent and suitable for the intended experience. Code must not depend on an unverified asset ID.

## Asset workflow
1. Define asset purpose, dimensions/scale, visual style, target devices and budget.
2. Prefer original or properly licensed assets. Record creator/source, license or permission, moderation status and project use.
3. Use a stable naming convention and asset registry.
4. Validate dimensions, pivot, orientation, collision, material, texture resolution, animation/audio length and file size where applicable.
5. Organize assets by feature and replication need. Keep large or server-only content out of replicated containers until required.
6. Import through the intended Studio/tool workflow and inspect the result in the actual project.
7. Verify dependencies and fallback behavior if the asset is unavailable.
8. Record final asset identifiers only after they are confirmed by the project owner or actual tool output.

## Safety and ownership
Do not scrape or re-upload content without rights. Do not claim an asset is licensed based solely on its appearance or availability. Do not use copyrighted characters, logos, music or distinctive maps as direct substitutes for original work. Do not upload or replace live assets without explicit approval.

## References
Read `docs/ASSET_PIPELINE.md`, `docs/STREAMING_AND_WORLD_SCALE.md`, `docs/ANIMATION_AND_AUDIO.md`, and `docs/PERFORMANCE_BUDGETS.md`.
## V3 execution contract

1. Create an asset register before adding substantial content: stable name, purpose, source, creator/owner, permission status, format, dimensions/triangles where relevant, target location, and replacement plan.
2. Separate original project assets, Roblox-provided content, licensed third-party assets, and unverified references. Never pass unverified content into a release candidate.
3. Use consistent names and folder ownership. Avoid duplicate near-identical assets and unexplained numeric IDs.
4. Review imported models for unexpected Scripts, LocalScripts, ModuleScripts, remote objects, hidden instances, and suspicious external dependencies before use. Treat uploaded models as untrusted content.
5. Validate pivots, scale, collision geometry, attachments, rig compatibility, textures, animation references, and LOD suitability.
6. Keep large assets out of ReplicatedStorage unless clients genuinely need them immediately. Consider streaming and on-demand delivery.
7. Preserve source files and document any destructive optimization. Use a reversible export/import path where possible.

**Release gate:** every required asset is present, attributable, permitted for use, correctly mapped, and tested in the target place. A filename or ID alone is not proof of rights or availability.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
