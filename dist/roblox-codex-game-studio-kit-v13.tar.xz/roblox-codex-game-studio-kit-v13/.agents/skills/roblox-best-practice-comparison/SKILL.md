---
name: roblox-best-practice-comparison
description: Roblox Best-Practice Comparison.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Best-Practice Comparison

For non-trivial design choices, compare at least two credible approaches before selecting one.

Evaluate: player impact, correctness, complexity, module coupling, performance, replication, security, data integrity, platform compatibility, team workflow, migration cost, observability, and human editability.

Rank sources: current official Creator Hub/API docs; official Roblox release notes/announcements; upstream documentation for third-party tools; maintained high-quality community projects; community discussion as discovery only. Reject stale tutorials, copied snippets, AI summaries without source pages, and unmaintained libraries unless documenting a migration reason.

Select the simplest stable approach that meets requirements, not the newest or most abstract. Record rejected alternatives and the reason.
