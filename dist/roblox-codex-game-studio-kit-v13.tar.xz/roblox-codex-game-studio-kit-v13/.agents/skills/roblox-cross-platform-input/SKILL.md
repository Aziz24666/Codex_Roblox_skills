---
name: roblox-cross-platform-input
description: Implement and audit input abstraction, UI navigation, interaction prompts, camera behavior, and feature parity across Roblox touch.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Cross-Platform Input — V7

## Mission
Deliver the same intended player capabilities across input methods without assuming every device has a keyboard, pointer, or touch screen.

## Input architecture
Use action-oriented abstractions rather than scattering raw key names through gameplay. Define actions, bindings, context priority, cancellation, held/toggled behavior, and UI focus rules. Verify current Roblox Input Action System and ContextActionService APIs before implementation.

## Interaction UX
- Touch targets must be comfortably reachable and not overlap critical controls.
- Gamepad users must be able to reach menus, dialogs, inventory, and core actions without a mouse.
- Keyboard/mouse must expose clear focus and remapping assumptions.
- Provide contextual prompts that reflect the active input mode.
- Avoid double activation when UI and world input overlap.

## Verification
Test each action on touch, mouse/keyboard, and gamepad. Include input switching mid-session, modal UI, respawn, focus loss, orientation change, and simultaneous input. Studio emulation is useful but not a substitute for physical-device checks where they matter.

Read `docs/V7_CROSS_PLATFORM_INPUT_AND_UI_QA.md`.
