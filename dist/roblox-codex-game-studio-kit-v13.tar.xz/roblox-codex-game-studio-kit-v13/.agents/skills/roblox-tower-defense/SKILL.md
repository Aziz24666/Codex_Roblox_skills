---
name: roblox-tower-defense
description: Design wave-based strategy gameplay, placement rules, upgrades, co-op, and economy pacing. Use for tower-defense features.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Tower Defense — V6 Genre Specialist

## Core loop
Prepare → place/upgrade → survive wave → earn result → choose upgrade → face next challenge. Make the loop readable on desktop, touch, and gamepad.

## Systems
- Wave director with validated data-driven wave definitions and bounded spawn schedules.
- Path graph or waypoint system with explicit route versioning and NPC recovery.
- Placement preview client-side; placement validation, ownership, cost, range, and collision checks server-side.
- Target-selection rules, cooldowns, damage values, status effects, and rewards owned by server systems.
- Upgrade tree with explicit prices, caps, prerequisites, and reversible balance configuration.
- Co-op contribution rules that do not create duplicate payouts or reward exploits.

## Balance
Model wave difficulty, economy income, upgrade breakpoints, time-to-complete, failure rates, and new-player learning curve. Use simulations to narrow candidate values, then playtest. Never present simulated balance as observed player data.

## QA
Test placement races, insufficient currency, blocked placement, path edge cases, simultaneous targeting, wave skip voting, player disconnect, late join, server shutdown, and reward idempotency.

Read `docs/V6_GENRE_SYSTEMS_AND_BALANCE.md`.
