---
name: roblox-platform-security-review
description: Roblox Platform Security Review.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Platform Security Review

Threat-model every client/server feature. Assume client-supplied values and client-owned physics can be manipulated. Check authority, validation, allowlists, bounds, rate limits, distance, ownership, game state, idempotency, replay, race conditions, output confidentiality, and storage integrity. Verify current official security docs before implementation. Do not rely on client UI or client-side validation for critical decisions. Record abuse cases and negative tests.
