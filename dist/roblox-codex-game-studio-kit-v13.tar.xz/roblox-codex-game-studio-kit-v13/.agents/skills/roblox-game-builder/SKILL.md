---
name: roblox-game-builder
description: Coordinate whole-game Roblox development, major features, and cross-system integration. Use as the orchestrator for project-wide work.
---


## V10 mandatory current-source research gate
Before substantive implementation, perform fresh online research: open current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare consequential alternatives and record exact URLs, date, claims, options, decision, and test plan in `research/decisions/`. If current research is unavailable, mark affected work `BLOCKED — RESEARCH NOT VERIFIED`; do not invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.


# Roblox Game Builder

Use this skill for whole-game work, large features, or cross-system tasks. For a narrow task, load only the matching specialist skill.

## Route
1. Follow the global contract in `AGENTS.md`.
2. Use `INDEX_V11.md` to select relevant skills and references.
3. Perform fresh official Roblox and upstream-tool research before substantive implementation.
4. Plan acceptance criteria, affected modules, dependencies, and tests.
5. Implement one complete vertical slice at a time; verify and record evidence.

## Focused references
- `docs/V11_GAME_BUILDER_FULL_PLAYBOOK.md` — detailed orchestration guidance.
- `docs/V11_CHANGE_IMPACT_AND_TEST_SELECTION.md` — dependency and regression scope.
- `docs/V11_TEST_EVIDENCE_AND_QUALITY.md` — truthful completion evidence.
- `docs/V11_RELEASE_AND_ROLLBACK.md` — release candidate gates.
