#!/usr/bin/env python3
"""Validate starter Rojo mapping JSON and referenced source paths (not a Rojo build)."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
project_file = ROOT / "project-template" / "default.project.json"
try:
    data = json.loads(project_file.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"Project JSON invalid: {exc}")
    sys.exit(1)
if data.get("tree", {}).get("$className") != "DataModel":
    print("Project mapping does not define a DataModel root.")
    sys.exit(1)

missing = []
def walk(node, location="tree"):
    if isinstance(node, dict):
        if "$path" in node:
            target = ROOT / "project-template" / node["$path"]
            if not target.exists():
                missing.append(f"{location}: missing $path {node['$path']}")
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                walk(value, f"{location}.{key}")
    elif isinstance(node, list):
        for i, value in enumerate(node):
            walk(value, f"{location}[{i}]")
walk(data.get("tree", {}))
if missing:
    print("Starter project mapping has unresolved paths:")
    for item in missing:
        print(f" - {item}")
    sys.exit(1)
print("Starter project JSON and referenced source paths OK.")
print("This is not a real Rojo validation/build; run the project's pinned Rojo version separately.")
