#!/usr/bin/env python3
"""Read-only Roblox project inventory. Prints a Markdown audit; optionally writes --out."""
from pathlib import Path
import argparse
import json

SKIP_DIRS = {".git", "node_modules", "Packages", "_Index", "target", "build", "dist", ".cache"}
INTERESTING = {".luau", ".lua", ".json", ".toml", ".yml", ".yaml", ".md", ".rbxm", ".rbxmx", ".rbxl", ".rbxlx", ".png", ".jpg", ".jpeg", ".webp", ".ogg", ".mp3", ".wav", ".fbx", ".obj"}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".", help="Project root (default: current directory)")
    parser.add_argument("--out", help="Optional Markdown output path. Without it, print to stdout.")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        raise SystemExit(f"Not a directory: {root}")

    files = []
    for path in root.rglob("*"):
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        if path.is_file() and (path.suffix.lower() in INTERESTING or path.name in {"AGENTS.md", "default.project.json", "rokit.toml", "aftman.toml", "wally.toml", "wally.lock"}):
            try:
                size = path.stat().st_size
            except OSError:
                size = -1
            files.append((path, size))
    files.sort(key=lambda item: str(item[0]).lower())

    suffixes = {}
    for path, _ in files:
        suffixes[path.suffix.lower() or "[no extension]"] = suffixes.get(path.suffix.lower() or "[no extension]", 0) + 1

    def exists(name):
        return (root / name).exists()
    workflow = []
    if exists("default.project.json"):
        workflow.append("Rojo project mapping detected")
    if exists("rokit.toml"):
        workflow.append("Rokit toolchain manifest detected")
    if exists("aftman.toml"):
        workflow.append("Aftman toolchain manifest detected")
    if exists("wally.toml") or exists("wally.lock"):
        workflow.append("Wally package manifest/lockfile detected")
    if exists(".github/workflows"):
        workflow.append("GitHub Actions workflow directory detected")
    if not workflow:
        workflow.append("No common Rojo/toolchain/CI marker detected; inspect Studio-native or custom workflow")

    luau_files = [p for p, _ in files if p.suffix.lower() in {".luau", ".lua"}]
    docs = [p for p, _ in files if p.suffix.lower() == ".md"]
    lines = [f"# Read-only Project Audit: {root.name}", "", "## Detected workflow markers"]
    lines.extend(f"- {item}" for item in workflow)
    lines += ["", "## Inventory summary", f"- Relevant files: {len(files)}", f"- Luau/Lua files: {len(luau_files)}", f"- Markdown documents: {len(docs)}", "", "### File types"]
    lines.extend(f"- `{ext}`: {count}" for ext, count in sorted(suffixes.items()))
    lines += ["", "## Important project markers"]
    for marker in ["AGENTS.md", "README.md", "default.project.json", "rokit.toml", "aftman.toml", "wally.toml", "wally.lock", ".github/workflows", "tests", "test", "docs"]:
        lines.append(f"- {'Present' if exists(marker) else 'Not found'}: `{marker}`")
    lines += ["", "## Relevant file inventory"]
    for path, size in files:
        rel = path.relative_to(root).as_posix()
        lines.append(f"- `{rel}` ({size} bytes)")
    lines += ["", "## Important limitations", "- This inventory is read-only and does not parse place files or prove that assets are usable.", "- It does not identify all Studio-authored content or hidden dependencies.", "- Confirm Git status, project mapping, tool versions, and runtime behavior separately.", ""]
    report = "\n".join(lines)
    if args.out:
        destination = Path(args.out).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(report, encoding="utf-8")
        print(f"Audit written to {destination}")
    else:
        print(report)

if __name__ == "__main__":
    main()
