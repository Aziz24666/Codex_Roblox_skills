#!/usr/bin/env python3
"""Non-destructive structural validator for Roblox Codex Game Studio Kit V4."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
SKILLS = ROOT / ".agents" / "skills"
errors = []

for rel in ["AGENTS.md", "README.md", "INDEX.md", "CHANGELOG.md"]:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required root file: {rel}")

skill_dirs = sorted(p for p in SKILLS.iterdir() if p.is_dir()) if SKILLS.exists() else []
if len(skill_dirs) < 30:
    errors.append(f"Expected at least 30 skills; found {len(skill_dirs)}")

names = set()
for folder in skill_dirs:
    skill = folder / "SKILL.md"
    if not skill.is_file():
        errors.append(f"{folder.name}: missing SKILL.md")
        continue
    content = skill.read_text(encoding="utf-8")
    if not content.startswith("---\n"):
        errors.append(f"{folder.name}: missing YAML frontmatter")
        continue
    end = content.find("\n---\n", 4)
    if end < 0:
        errors.append(f"{folder.name}: unterminated YAML frontmatter")
        continue
    front = content[4:end]
    name_line = next((line.split(":", 1)[1].strip() for line in front.splitlines() if line.startswith("name:")), None)
    desc_line = next((line.split(":", 1)[1].strip() for line in front.splitlines() if line.startswith("description:")), None)
    if name_line != folder.name:
        errors.append(f"{folder.name}: frontmatter name does not match folder")
    if not desc_line:
        errors.append(f"{folder.name}: missing description")
    if name_line in names:
        errors.append(f"Duplicate skill name: {name_line}")
    names.add(name_line)

required_docs = [
    "docs/PRODUCTION_PIPELINE.md", "docs/AUTONOMOUS_EXECUTION_PROTOCOL.md",
    "docs/STUDIO_WORKFLOW_AND_TOOLING.md", "docs/SYSTEM_ARCHITECTURE_PLAYBOOK.md",
    "docs/FEATURE_VERTICAL_SLICE_PLAYBOOK.md", "docs/GENRE_BLUEPRINTS.md",
    "docs/API_AND_DEPENDENCY_VERIFICATION.md", "docs/MULTIPLAYER_SESSION_TESTING.md",
    "templates/GAME_BRIEF_TEMPLATE.md", "templates/FEATURE_TICKET_TEMPLATE.md",
    "prompts/00_PROJECT_RECONNAISSANCE.md", "prompts/39_V4_HANDOFF_AND_CONTINUATION.md",
    "docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md",
    "docs/V4_AUTOMATION_AND_QUALITY_GATES.md",
    "docs/V4_GENRE_PRODUCTION_PIPELINES.md",
    "tools/check_v4_package.py",
    "project-template/default.project.json",
]
for rel in required_docs:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing expected file: {rel}")

# Check all local Markdown links that look like relative paths. External links are ignored.
for md in ROOT.rglob("*.md"):
    if ".git" in md.parts:
        continue
    text = md.read_text(encoding="utf-8")
    for match in __import__("re").finditer(r"\[[^\]]+\]\(([^)]+)\)", text):
        target = match.group(1).split("#", 1)[0]
        if not target or "://" in target or target.startswith("mailto:") or target.startswith("#"):
            continue
        resolved = (md.parent / target).resolve()
        if not resolved.exists():
            errors.append(f"Broken local Markdown link in {md.relative_to(ROOT)}: {target}")

if errors:
    print("V4 kit check FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"V4 kit structure OK: {len(skill_dirs)} skills found.")
print(f"Markdown documents: {len(list(ROOT.rglob('*.md')))}")
print("This check does not compile Luau, build a place, or run Roblox Studio tests.")
