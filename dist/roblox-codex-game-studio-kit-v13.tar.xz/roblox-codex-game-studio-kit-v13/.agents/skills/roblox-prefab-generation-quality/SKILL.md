---
name: roblox-prefab-generation-quality
description: Build deterministic, collision-safe Roblox prefab generators with post-generation validation and provenance.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Prefab Generation Quality

Build from approved templates and allowlisted family handlers. Check definition, template, source selection, output collision, and target hierarchy before writes. Stamp schema/template/generator metadata. Verify hierarchy after generation. Refuse collisions by default; replacement requires a diff and explicit approval. Read `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md`.
