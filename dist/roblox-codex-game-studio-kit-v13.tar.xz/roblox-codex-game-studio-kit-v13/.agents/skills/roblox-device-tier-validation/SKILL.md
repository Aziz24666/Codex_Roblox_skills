---
name: roblox-device-tier-validation
description: Validate performance and usability across representative Roblox device classes.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Define realistic low/mid/high target tiers based on the actual audience.
- Separate emulator evidence from physical-device evidence.
- Run the same scenario, scene, and build across tiers.
- Record frame time, memory, join time, input mode, and visual defects.
- Fix the highest-impact tier-specific failure without degrading others.

Read `docs/V12_DEVICE_TIER_TEST_MATRIX.md`.
