---
name: roblox-asset-reference-authoring
description: Model, validate, and document Roblox asset references in reusable content definitions and Studio editors.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Asset Reference Authoring

Use typed asset fields with expected asset kind, required/optional state, and load/permission verification status. Syntax validation is not existence, moderation, ownership, permission, or compatibility verification. Keep asset resolution separate from definition parsing; never invent IDs or silently replace unavailable assets. Read `docs/V9_ASSET_REFERENCE_FIELDS.md`.
