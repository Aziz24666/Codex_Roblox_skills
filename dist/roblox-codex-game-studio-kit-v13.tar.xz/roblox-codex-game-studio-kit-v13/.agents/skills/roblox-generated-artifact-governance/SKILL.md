---
name: roblox-generated-artifact-governance
description: Make generated files deterministic, provenance-tracked, and safe to regenerate. Use when maintaining codegen, prefabs, schemas, or catalogs.
---


## V10 mandatory current-source research gate
Before substantive implementation, perform fresh online research: open current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare consequential alternatives and record exact URLs, date, claims, options, decision, and test plan in `research/decisions/`. If current research is unavailable, mark affected work `BLOCKED — RESEARCH NOT VERIFIED`; do not invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.


# Roblox Generated Artifact Governance

Use this skill only when its trigger matches the task. Keep the root skill small; load the linked playbook and relevant project files progressively.

## Workflow boundary
- Inspect the existing project before changing it.
- Research relevant Roblox APIs and upstream tools before implementation.
- Make the smallest reversible change that satisfies acceptance criteria.
- Run checks appropriate to the change and report what was not verified.

## Detailed playbook
Read `docs/V11_GENERATED_ARTIFACTS_AND_DRIFT.md`.
