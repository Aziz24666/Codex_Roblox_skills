---
name: roblox-config-schema-engineering
description: Create strongly typed, versioned, validated configuration contracts for reusable Roblox systems and content definitions.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Configuration Schema Engineering

Use whenever a feature has many instances or author-editable values.

- Define types and runtime validators together; Luau types do not validate decoded JSON or Studio-authored data at runtime.
- Require a schema version and stable definition ID.
- Validate types, bounds, enums, cross-field invariants, references, uniqueness, and unsupported keys.
- Apply defaults in one canonical normalizer; do not scatter fallback values across consumers.
- Distinguish missing, invalid, and intentionally empty values.
- Migrate old definitions using pure, deterministic migration functions.
- Never silently clamp a dangerous or semantically invalid value without reporting it.

Read `docs/V8_CONFIG_SCHEMA_AND_VALIDATION.md` and `docs/V8_CONFIG_MIGRATIONS.md`.
