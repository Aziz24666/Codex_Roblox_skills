---
name: roblox-npc-ai
description: Design and implement Roblox NPCs, non-player agents, state machines, patrols, social behaviors, pathfinding, obstacle handling, interaction.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox NPC AI and Navigation

Create predictable NPC behavior that degrades gracefully when navigation fails or world geometry changes.

## Procedure
1. Define the NPC's role and behaviors in player-visible terms.
2. Model behavior as explicit states and transitions (idle, observe, move, interact, recover, return, despawn—adapt to the design).
3. Define perception and decision inputs. Avoid scanning every object every frame.
4. Define movement ownership: server-controlled or client-presentational, based on gameplay consequence and network behavior.
5. Use Roblox pathfinding APIs only after verifying current signatures and limits. Plan for blocked paths, failed computations, moving targets and stale waypoints.
6. Recompute paths when meaningful conditions change, not on every frame.
7. Add stuck detection, bounded retries, fallback routes and a safe idle behavior.
8. Clean up connections, tasks, path state and spawned NPCs on despawn/server shutdown.
9. Test crowded geometry, narrow passages, streaming boundaries, player interference and low frame rates.

## Scalability
Use bounded update budgets, staggered work, distance/visibility-based update frequency and sensible NPC counts. Do not use a single expensive loop for every NPC. Avoid unbounded path recomputation and per-frame raycasts for large populations.

## Review
Check ownership, state transitions, stuck recovery, collision, replication, spawn/despawn, path failure, streaming behavior and player interaction validation.

## References
Read `docs/NPC_AI_AND_NAVIGATION.md`, `docs/LIFECYCLE_AND_CLEANUP.md`, `docs/PERFORMANCE_BUDGETS.md`, `docs/STREAMING_AND_WORLD_SCALE.md`, and `docs/TEST_STRATEGY.md`.
## V3 NPC implementation protocol

1. Define NPC purpose, allowed area, interaction contract, and player-facing affordances.
2. Model behavior as explicit states with entry, update, exit, and transition conditions.
3. Keep navigation, decision-making, animation, and interaction responsibilities separate.
4. Bound path requests and retries; add cooldowns and destination thresholds to prevent pathfinding thrash.
5. Handle blocked paths, unreachable targets, target removal, NPC destruction, player leave, and streaming boundaries.
6. Use a perception/update budget appropriate to the number of active NPCs. Stagger or reduce update work where safe.
7. Avoid trusting client-selected target or hit outcomes for consequential behavior.
8. Provide debug visibility for current state, target, path status, and last failure reason in development builds only.

Test multiple NPCs, crowded areas, obstacles, teleport/respawn, path failure, and server performance under expected population.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
