---
name: roblox-farming-crafting
description: Design Roblox farming, gathering, crafting, and production loops with deterministic rules, durable progression, and secure interactions.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Farming and Crafting

Use for planting, timed growth, gathering, recipes, crafting stations, and production chains.

## Required workflow

1. Map source → storage → transformation → sink.
2. Define item IDs, stack rules, recipe inputs/outputs, station requirements, capacity, and timing in data tables.
3. Validate plot/station ownership, proximity, materials, recipe allowlist, state, and cooldown on the server.
4. Never accept client yields, prices, elapsed growth, or inventory totals as truth.
5. Choose online/offline growth semantics deliberately and cap elapsed time.
6. Validate all recipe inputs before consuming; grant output exactly once.
7. Test repeated/concurrent crafting, insufficient items, full inventory, disconnect, and migration.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_GENRE_COMPENDIUM.md`
- `docs/ECONOMY_AND_REWARDS.md`
- `docs/DATA_MIGRATIONS.md`
