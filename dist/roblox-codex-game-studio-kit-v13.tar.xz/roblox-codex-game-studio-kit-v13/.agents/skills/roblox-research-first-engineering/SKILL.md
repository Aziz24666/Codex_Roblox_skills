---
name: roblox-research-first-engineering
description: Roblox Research-First Engineering.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Research-First Engineering

## Mission
Make current research the first engineering activity, not a post-hoc citation exercise.

## Procedure
1. Translate the task into platform concepts, APIs, toolchains, and risks.
2. Search current Creator Hub docs and exact API reference pages.
3. Search release notes/updates and official announcements for new, pending, deprecated, beta, or changed behavior.
4. Search upstream documentation for tools and reputable external sources for alternative patterns.
5. Compare viable options by correctness, maintainability, security, performance, complexity, and compatibility.
6. Create a structured V10 research decision record before implementation.
7. Prototype ambiguous/high-risk behavior in an isolated place.
8. Re-check references when scope or API usage changes.
9. Update record with implementation and test evidence.

Never treat cached context, an old skill, or a search snippet as current verification. If no live research capability exists, block the API-sensitive change and say exactly what could not be verified.


## V11 research integrity
Use `docs/V11_RESEARCH_SOURCE_QUALITY.md`. Open official Roblox docs and upstream tool docs; search independent alternatives when relevant; record exact URLs and accessed date. Research records are evidence snapshots, not permanent truth. Use `tools/v11_research_lint.py` to check record completeness.
