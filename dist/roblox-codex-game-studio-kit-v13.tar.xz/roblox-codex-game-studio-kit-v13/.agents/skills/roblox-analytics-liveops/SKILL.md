---
name: roblox-analytics-liveops
description: Design privacy-conscious gameplay telemetry, operational dashboards, live content configuration, event planning, and post-release learning loops.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Analytics and Live Operations

Use measurement to answer a specific product or reliability question. Do not collect more player data than the design requires.

## Measurement protocol
1. Write the question and decision that the metric will inform.
2. Define an event schema with stable name, version, trigger, required fields, and data owner.
3. Avoid chat content, credentials, precise personal identifiers, or unnecessary sensitive data.
4. Define session, funnel, completion, failure, economy, and reliability metrics only where applicable.
5. Distinguish measured evidence from estimates and sample bias.
6. Make telemetry low-cost, bounded, and safe when a logging destination is unavailable.
7. Document sampling, event volume, retention, access, and deletion considerations.

## Live operations
- Use versioned, validated configuration for events and content rotations.
- Define start/end time, audience, content, rewards, support plan, rollback, and fallback behavior.
- Keep live configuration server-validated and safe when absent or stale.
- Test event transitions with test configuration before changing production settings.
- Do not use deceptive urgency, coercive timers, or manipulative reward loops.

Read `docs/ANALYTICS_AND_LIVEOPS.md` and `docs/MONETIZATION_AND_PLAYER_TRUST.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.

## V12 analytics governance
Use `docs/V12_ANALYTICS_EVENT_GOVERNANCE.md` and `schemas/v12-analytics-event-catalog.schema.json`. Instrument only a defined product question, minimize event fields, and keep Studio validation distinct from published-server custom events.
