---
name: roblox-open-cloud-operations
description: Plan governed Roblox Open Cloud and Creator Dashboard automation.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Open Cloud Operations — V6 Specialist

## Mission
Prepare safe, auditable workflows around Roblox cloud APIs. This skill does not grant API access and does not authorize external mutations.

## Capability and permission discovery
- Inspect tools genuinely available in the current session. Do not assume an API client or connector exists.
- Identify the exact API, resource, environment, permission scope, and owner before any operation.
- Verify current official documentation and API version before designing requests.
- Keep development, staging, and production credentials distinct. Prefer least-privilege keys and managed secret stores.

## Approval boundaries
Always require explicit user approval before publishing, changing permissions, modifying production data, creating/deleting places, uploading or replacing public assets, changing Creator Dashboard settings, spending currency, or performing irreversible operations.

## Secret hygiene
Never request, echo, commit, log, or store `.ROBLOSECURITY`, cookies, API keys, passwords, or tokens in project files. Never ask the user to paste credentials into chat. Use an approved secret manager or user-configured environment, and verify that logs redact values.

## Change protocol
1. Prepare a dry-run plan with exact resources and intended before/after state.
2. Identify rollback and whether the operation is reversible.
3. Confirm test/staging target and approval.
4. Execute only through a documented, available tool.
5. Record response identifiers without recording secrets.
6. Verify resulting state and report partial failures honestly.

Read `docs/V6_OPEN_CLOUD_CHANGE_GOVERNANCE.md` and `docs/V6_RELEASE_CHANNELS_AND_ROLLBACK.md`.
