---
name: roblox-context-engineering
description: Keep Codex project context efficient and accurate.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Context Engineering for Roblox Projects — V7

## Mission
Give the agent enough verified context to act correctly without loading the entire knowledge base on every task. A larger prompt is not automatically a better prompt.

## Workflow
1. Read the root `AGENTS.md` and only the nested instructions that apply to changed paths.
2. Classify the task and identify the player outcome, affected systems, risk, and test level.
3. Use the skill router or `docs/V7_CONTEXT_MANAGEMENT_AND_SKILL_ROUTING.md` to select the smallest useful skill set.
4. Read each selected `SKILL.md`; then open only the reference sections linked for this task.
5. Inspect the actual source files, callers, tests, data contracts, and current diffs. Never treat docs as proof that code matches them.
6. Record version-sensitive assumptions and verify APIs against official current documentation.
7. Summarize only durable decisions, active tasks, blockers, and next steps in project status. Do not paste the whole conversation into repository files.

## Context budget rules
- Prefer 1 orchestrator + 1–4 specialists for ordinary tasks. Add security/data/QA specialties when their boundaries are touched.
- Do not activate every skill just because the project contains them.
- Prefer concise stable interfaces and exact file references over copying large code excerpts into prompts.
- Do not load prior-version documentation when a newer V7 document supersedes it unless historical comparison is needed.
- If instructions conflict, obey platform/system safety, repository-specific instructions, then the most specific applicable skill; report unresolved conflicts.

## Output
Return selected skills, source files inspected, assumptions verified, and the smallest next action. Keep the final explanation focused on observable delivered behavior and test evidence.

Read `docs/V7_CONTEXT_MANAGEMENT_AND_SKILL_ROUTING.md` and `docs/V7_OFFICIAL_REFERENCE_INDEX.md`.
