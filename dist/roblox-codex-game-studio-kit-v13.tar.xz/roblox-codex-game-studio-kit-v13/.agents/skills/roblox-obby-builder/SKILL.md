---
name: roblox-obby-builder
description: Design obstacle courses, checkpoints, stage progression, collision fairness, and feedback. Use for obby experiences.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Obby Builder

Use for obstacle courses, time trials, platforming stages, checkpoint systems, and parkour-style traversal.

## Build process
1. Define the movement verbs and camera behavior before building a long course.
2. Graybox a short sequence with varied but teachable obstacles.
3. Check visibility, landing surfaces, collision volumes, and player recovery.
4. Implement checkpoint IDs and progression order on the server.
5. Ensure reset/respawn and checkpoint activation have consistent state.
6. Add timing/leaderboards only with server-defined race rules and clear ties/disconnect handling.
7. Tune for keyboard/mouse, touch, and controller.
8. Test difficulty with repeated runs, not one successful developer attempt.
9. Audit skips, purchases, and difficulty for fairness and transparency.

## Safety and fairness
Do not create real-world dangerous challenge instructions. Keep the experience virtual and age-appropriate. Avoid making a purchase the only practical way past a deliberately unfair obstacle. Ensure the route is visually readable and recoverable after mistakes.

Read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`, `docs/CHARACTER_CAMERA_AND_INPUT.md`, `docs/WORLD_AND_LEVEL_DESIGN.md`, and `docs/V4_GENRE_ACCEPTANCE_MATRICES.md`.
