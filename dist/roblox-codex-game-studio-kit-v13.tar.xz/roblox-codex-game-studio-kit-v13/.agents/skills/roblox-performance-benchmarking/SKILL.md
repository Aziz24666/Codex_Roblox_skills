---
name: roblox-performance-benchmarking
description: Measure and set repeatable client, server, memory, physics, rendering, network, and loading budgets. Use for performance work.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Performance Benchmarking — V7

## Mission
Measure representative player journeys and regressions rather than optimize by intuition or a single desktop run.

## Baseline setup
- Define target device tiers and the player journey to measure.
- Pin place/build identifier, Studio/client version, server size, device profile, graphics settings, network profile, and test duration.
- Separate cold start from warm session and solo from multi-client measurements.
- Record p50/p95 or another clearly stated statistic where samples support it; never compare one-off measurements as if they were stable.

## Budgets
Track frame time/FPS, memory, instance count, script time, server heartbeat, network traffic, physics cost, load time, and streaming readiness as relevant. A budget needs metric, unit, scenario, threshold, sample size, and action when exceeded.

## Investigation
Use MicroProfiler and available Studio diagnostics. Find the dominant cost first; change one major factor at a time. Consider event-driven work, batching, pooling, streaming, asset sizes, replication volume, and device-specific visual settings.

## Evidence
Keep raw captures separate from summaries. Compare same scenario and environment; explain changes in build, device, Studio version, or network profile. A static source scan is not a runtime performance result.

Read `docs/V7_PERFORMANCE_BENCHMARKING.md`.

## V12 evidence contract
Use `docs/V12_MICROPROFILER_AND_SCRIPT_PROFILER.md` and `docs/V12_PERFORMANCE_BUDGETS.md`. Record repeatable environment metadata and avoid comparing non-equivalent captures.
