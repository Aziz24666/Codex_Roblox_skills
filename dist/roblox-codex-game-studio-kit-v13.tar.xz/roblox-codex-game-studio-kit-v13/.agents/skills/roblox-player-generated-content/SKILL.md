---
name: roblox-player-generated-content
description: Design safe, constrained player-generated content such as names, signs, room layouts, custom levels, and social creations with validation.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Player-Generated Content — V7

## Mission
Let players express creativity while minimizing abusive content, privacy exposure, exploit paths, and moderation burden.

## Scope and constraints
Define exactly what players can create, who can see it, how long it persists, whether it is shared, and what moderation/reporting process applies. Prefer constrained catalogs, templates, and safe structured choices when free-form content is unnecessary.

## Data and validation
Treat every client submission as untrusted. Validate schema, length, allowed values, ownership, rate, placement bounds, catalog IDs, and server state. Do not accept arbitrary code, executable content, unsafe asset IDs, or unrestricted URLs as player content. Keep content data separate from executable scripts.

## Safety and privacy
Do not build tools that evade moderation or conceal harmful content. Minimize personal data. Provide report/block/removal pathways where applicable and make content visibility controls clear. Follow current Roblox policies and age-appropriate design requirements.

## Testing
Test invalid payloads, repeated submissions, ownership violations, visibility rules, report flow, removal, persistence, moderation state, and client/server consistency.

Read `docs/V7_PLAYER_GENERATED_CONTENT_AND_SAFETY.md`.
