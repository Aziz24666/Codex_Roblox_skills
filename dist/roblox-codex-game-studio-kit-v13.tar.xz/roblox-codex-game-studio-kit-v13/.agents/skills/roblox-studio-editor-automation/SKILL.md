---
name: roblox-studio-editor-automation
description: Design safe Roblox Studio plugin editors that validate authoring data and generate consistent prefab structures.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Studio Editor Automation

Use for custom DockWidget plugins, content editors, validators, and prefab generators.

- Start with a written editor specification, fields, constraints, generated hierarchy, and undo expectations.
- Separate UI, validation, transformation, and instance generation modules.
- Never treat plugin form values as trusted; validate again before modifying the DataModel.
- Make generation deterministic and idempotent where possible.
- Generate only into a clearly named staging/output folder; do not overwrite an existing prefab without an explicit replace flow.
- Wrap mutations in Studio undo/recording support and provide clear errors.
- Do not upload assets, publish, or change permissions from an editor without explicit user action.
- Support preview/validate before generate and report every generated object.

Read `docs/V8_STUDIO_CONTENT_EDITOR_SPEC.md`, `docs/V8_PREFAB_GENERATION_PIPELINE.md`, and `studio-plugin/README.md`.
