---
name: roblox-studio-test-automation
description: Design and operate Roblox Studio scripted test workflows using only APIs and integrations that are actually available.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Studio Test Automation — V6 Specialist

## Mission
Create repeatable test coverage that exercises actual Roblox runtime behavior. Separate test planning, test harness code, Studio execution, and evidence collection. This skill does not imply Studio is controllable from the current Codex session.

## Capability discovery
1. Inspect the current Studio version and project workflow.
2. Inspect available plugins, Studio automation services, command-line tools, and connected integrations.
3. Verify current official Creator Hub documentation for `StudioTestService`, `StudioDeviceSimulatorService`, `VirtualInput`, and relevant API signatures before writing code that calls them.
4. Record whether the capability is `AVAILABLE`, `UNAVAILABLE`, `BETA_OR_VERSION_DEPENDENT`, or `NOT_VERIFIED`.
5. Never emulate an API with invented methods. Do not write a fake test adapter and report it as working.

## Test design
- Convert acceptance criteria into observable assertions.
- Prefer small, isolated tests for pure Luau logic; then integration tests for service boundaries; then Studio runtime tests.
- Build a matrix across client/server ownership, player count, join/leave, device profile, orientation, input, locale, and network quality where relevant.
- Exercise failure paths: invalid payload, timeout, disconnect, respawn, server shutdown, missing asset, failed persistence, and repeated request.
- Ensure tests clean up instances, connections, tasks, temporary data, and sessions even after assertion failures.

## Studio-only automation
The Creator Hub documents Studio-only scripted test facilities. Treat them as Studio capabilities, not APIs available to published gameplay. Confirm current documentation and Studio version before use. Device presets, multi-client simulation, and virtual input can support automation when available. Do not put Studio test-only services into production game code.

## Evidence contract
Every test run records: commit/build identifier, Studio version, tool versions, test entrypoint, client count, device profile, locale, network configuration, fixture/data environment, exact steps, expected and actual results, status, logs/artifact path, and timestamp.

## Stop conditions
- If Studio automation is unavailable, produce an executable manual test plan and mark Studio tests `BLOCKED` or `NOT RUN`.
- If an API signature is uncertain, stop implementation of that adapter until verified.
- Do not enable production DataStore access for test convenience.
- Do not publish a place just to run a test unless the user explicitly approves.

Read `docs/V6_STUDIO_AUTOMATION_AND_TEST_SERVICE.md`, `docs/V6_SIMULATION_TESTING_AND_DETERMINISM.md`, and `docs/V6_REQUIREMENTS_TRACEABILITY.md`.
