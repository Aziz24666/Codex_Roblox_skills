---
name: roblox-product-design
description: Define and improve Roblox game concepts, player fantasies, target audiences, core loops, onboarding, session design, progression.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Product Design

Translate the game idea into a small, testable experience before implementation. A polished loop beats a long list of disconnected features.

## Procedure
1. Extract the player's fantasy: what role does the player imagine inhabiting, and what satisfying action do they repeat?
2. Define the target audience and content boundaries. Keep the intended audience and Roblox experience rating in view.
3. Write the core loop as: **enter → understand goal → act → receive feedback/reward → choose next action**.
4. Define short-, medium- and long-term goals without relying on manipulative pressure or confusing reward systems.
5. Define session shape: first 30 seconds, first 3 minutes, a typical session, and a natural stopping point.
6. Define controls and readability for mouse/keyboard, touch and gamepad as appropriate.
7. Separate launch-critical features from future expansion. Estimate design and engineering risk.
8. Write measurable acceptance criteria and a playtest question for every major system.
9. Validate with a graybox prototype and revise based on observed player confusion, pacing and enjoyment.

## Required artifacts
For a new game, produce `GAME_BRIEF.md`, `CORE_LOOP.md`, a feature priority list, `ACCEPTANCE_CRITERIA.md`, and a short playtest plan. Use templates in `/templates`.

## Design quality checks
- Is the goal obvious within the first minute?
- Does each action produce clear feedback?
- Can a new player recover from a mistake?
- Are rewards understandable and proportionate?
- Can players make meaningful choices without needing an external guide?
- Does the loop remain interesting after repetition?
- Does multiplayer add value rather than simply add complexity?
- Are monetization and progression fair, transparent and age-appropriate?

## Avoid
Do not copy the distinctive identity of another game. Do not design gambling-like paid random rewards, pressure timers, misleading purchase prompts, pay-to-win progression, or systems that punish players for taking breaks. Do not claim a feature improves retention without playtest evidence.

## References
Read `docs/PRODUCT_SPEC.md`, `docs/CORE_LOOP_AND_PROGRESSION.md`, `docs/SCOPE_AND_RISK.md`, and `docs/UI_UX_AND_ACCESSIBILITY.md`.
## V3 product-design protocol

Create a one-page game brief first. Define player fantasy, core promise, audience and age appropriateness, first-session path, core loop, session length, social role, target devices, accessibility requirements, content boundaries, monetization assumptions, and measurable learning goals.

Use a prioritization model with player value, uncertainty, cost, dependencies, and risk. Prototype the largest uncertainty before building expensive content. For every milestone, write player-facing acceptance criteria and explicit exclusions. Keep retention design respectful: clear value, meaningful choice, transparent rewards, and no coercive timers, deceptive purchase prompts, or gambling-style paid randomness.

Validate design with a small playtest plan. Distinguish observed behavior from assumptions and avoid inventing player metrics when there is no telemetry or research evidence.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
