---
name: roblox-data-migration-operations
description: Plan and validate safe Roblox player-data schema migrations, backfills, compatibility windows, rollback, and recovery without risking.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Data Migration Operations — V7

## Mission
Change persisted player data without silent resets, lost progress, or accidental production impact.

## Required preflight
1. Identify the exact store, key schema, version range, affected population, and environment.
2. Capture current schema examples and define invariants that must remain true.
3. Write a pure, deterministic migration function with explicit input/output versions.
4. Test old, current, malformed, partial, maximum-size, and unknown-future-version records.
5. Define idempotency, retry limits, concurrency behavior, and a rollback or forward-repair plan.
6. Verify backup/restore capability using a safe non-production dataset.

## Non-negotiable safeguards
- Never enable Studio DataStore access to live production data for convenience.
- Never interpret load failure as a new player or overwrite data with defaults without a safe explicit design.
- Never run bulk mutation/backfill without scope, rate, monitoring, approval, and stop conditions.
- Preserve unknown fields when safe; do not drop data merely because the current model does not use it.
- Keep credentials out of code, chat, and logs.

## Execution
Prefer read-only inventory, dry-run counts, small canary batches, bounded concurrency, progress checkpoints, and post-write verification. Record before/after schema versions and non-sensitive operation IDs.

Read `docs/V7_DATA_MIGRATION_RUNBOOK.md` and `templates/V7_DATA_MIGRATION_PREFLIGHT.md`.
