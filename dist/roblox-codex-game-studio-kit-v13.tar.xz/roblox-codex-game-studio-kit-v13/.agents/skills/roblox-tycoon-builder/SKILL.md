---
name: roblox-tycoon-builder
description: Plan and implement tycoon-style Roblox building loops including plot ownership, placement, production, upgrades, progression, persistence.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Tycoon Builder

Use for plot-based builder/production games. Start from the genre pipeline; do not import a prebuilt framework unless the project already uses one and it is understood.

## Build order
1. Define one plot, one production object, one purchase, and one visible reward.
2. Implement server-owned plot claim/release and ownership checks.
3. Implement server-validated placement with plot bounds, collision/overlap rules, object caps, and catalog allowlists.
4. Implement production with bounded scheduling; do not create a loop for every machine if one scheduler can process active units.
5. Implement upgrades as explicit server-side configuration/state transitions.
6. Add UI that shows exact cost and outcome before purchase.
7. Add idempotent currency spending and reward grants.
8. Add profile persistence, reconnect, and owner-leaves behavior.
9. Test two players, simultaneous claims/purchases, invalid placement, duplicate requests, and profile failure.
10. Expand content only after the first plot loop is fun and stable.

## Core invariants
A player cannot operate another player's plot without permission. A purchase is charged at most once. Placement never exceeds server limits. Production does not continue after its ownership/lifecycle ends. A failed profile load must not produce an empty overwriting profile.

Read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`, `docs/ECONOMY_AND_REWARDS.md`, `docs/PERSISTENCE.md`, and `docs/V4_GENRE_ACCEPTANCE_MATRICES.md`.
