---
name: roblox-tagged-component-lifecycle
description: Build reusable CollectionService component binders with idempotent registration and complete cleanup.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Research the current CollectionService reference; prefer per-instance added/removed signals.
- Subscribe to additions/removals and enumerate existing tags at startup.
- Make attach idempotent so startup races cannot double-register an instance.
- Store each instance's cleanup function and release connections/resources on removal or shutdown.
- Avoid deprecated ItemAdded/ItemRemoved signals.
- Test tag added before startup, added after startup, removed, instance destroyed, and binder restarted.

Read `docs/V12_COLLECTIONSERVICE_LIFECYCLE.md` and `examples/v12/TaggedLifecycleBinder.lua`.
