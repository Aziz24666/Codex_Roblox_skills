---
name: roblox-performance-regression-testing
description: Detect performance regressions with comparable baselines and repeatable scenario captures.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Pin build identity, device tier, Studio/engine version, test scenario, and capture method.
- Compare equivalent captures and disclose noise/variance.
- Enforce project budgets with the V12 budget checker.
- Investigate regressions before changing thresholds.
- Attach raw evidence and before/after metrics to the change record.

Read `docs/V12_PERFORMANCE_REGRESSION_POLICY.md`.
