---
name: roblox-racing-vehicle
description: Design vehicle handling, race sessions, checkpoints, and verified results. Use for driving and race gameplay.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Racing and Vehicle Systems

Use for kart, car, hover, boat, or other non-weaponized vehicle experiences and timed courses.

## Build sequence
1. Prototype steering, acceleration, braking, camera, and collision feel with one vehicle.
2. Define input abstractions for keyboard, touch, and controller.
3. Decide ownership/replication assumptions for vehicle physics; verify the current Roblox APIs and security implications.
4. Define a race state machine: lobby, ready, countdown, active, finished, canceled.
5. Track checkpoint order and eligibility on the server. Never trust a client-reported finish time or completion flag.
6. Define reset, disconnect, timeout, tie, and server-shutdown behavior.
7. Build multi-client tests and run network simulation for latency-sensitive behavior.
8. Profile physics, replication, and map complexity on target device classes.

## Review invariants
Only eligible players can finish. Checkpoints cannot be skipped unless the design allows a verified shortcut. Duplicate finish messages do not alter results. A leaving player cannot leave ghost vehicle or race state. Results are consistent across clients.

Read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`, `docs/CHARACTER_CAMERA_AND_INPUT.md`, `docs/MULTIPLAYER_SESSION_TESTING.md`, and `docs/V4_GENRE_ACCEPTANCE_MATRICES.md`.
