---
name: roblox-simulator-collection
description: Build collection and incremental progression systems with server-owned rewards and upgrade pacing. Use for simulator loops.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Simulator and Collection Systems

Use for collection, incremental progression, pets/items as companions or cosmetics, upgrades, unlocks, and repeatable action loops.

## Build order
1. Define a satisfying action that works without a large economy.
2. Define exact reward calculation and keep it server-authoritative.
3. Create a stable catalog schema with unique IDs and content validation.
4. Add collection/inventory limits, equip rules, and clear UI states.
5. Add one upgrade with a visible effect and understandable cost.
6. Simulate progression pacing for new, typical, active, and returning player scenarios.
7. Persist profile changes safely and make reward grants idempotent.
8. Test duplicate requests, invalid item IDs, capacity overflow, reconnect, and server restart.

## Player-trust constraints
Do not add paid random rewards, gambling-like mechanics, deceptive scarcity, or misleading reward probabilities. Explain costs and effects. Keep free progression coherent and test for dominant strategies and progression cliffs.

Read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`, `docs/V4_PROGRESSION_BALANCING_AND_SIMULATION.md`, `docs/ECONOMY_AND_REWARDS.md`, and `docs/PERSISTENCE.md`.
