---
name: roblox-physics-simulation
description: Engineer Roblox physics, constraints, collision behavior, ownership, replication, and stable gameplay under latency.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Physics and Simulation — V6 Specialist

## Mission
Build understandable, stable physics interactions while keeping authoritative outcomes server-validated.

## Design checklist
- Classify every assembly as static, server-owned, client-owned by design, or ownership-transferred under explicit rules.
- Identify which simulation outcomes affect rewards, competition, damage-like game state, inventory, checkpoints, or shared world state. Those outcomes require server validation and anti-abuse constraints.
- Define collision groups, physical properties, constraints, mass distribution, assemblies, streaming behavior, and lifecycle.
- Bound velocity, force, torque, impulses, object count, interaction radius, and active simulation population where applicable.
- Avoid per-frame work when event-driven or lower-frequency logic is sufficient.

## Network ownership
Do not equate client-owned simulation with trusted game truth. Validate critical outcomes on the server using plausible movement envelopes, timing, proximity, state transitions, and independent server context. Tune validation to avoid punishing normal latency or legitimate physics variation.

## Stability
Use finite-number checks, NaN/infinity rejection, bounded deltas, safe fallback states, explicit collision filters, and cleanup on player/object removal. Avoid brittle exact-position equality for physics results; use tolerances and invariant checks.

## Verification
Measure client and server cost separately. Test under different frame rates and constrained network conditions where available. Verify ownership transitions, respawns, streaming in/out, collisions, and simultaneous interactions.

Read `docs/V6_PHYSICS_OWNERSHIP_AND_REPLICATION.md` and the existing performance/networking references.
