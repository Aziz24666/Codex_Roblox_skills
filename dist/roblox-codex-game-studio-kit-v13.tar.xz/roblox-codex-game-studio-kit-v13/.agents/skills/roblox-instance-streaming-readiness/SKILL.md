---
name: roblox-instance-streaming-readiness
description: Design client features to tolerate Workspace instances streaming in, out, and back; use for large worlds and streamed entities.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Research current Workspace streaming semantics and model streaming modes.
- Identify every client reference to Workspace descendants and classify its lifetime.
- Make lookups repeatable and rebind on re-entry; release local resources on stream-out.
- Avoid assuming `WaitForChild()` makes a distant instance permanently available.
- Do not set non-scriptable streaming properties from Luau.
- Test movement between distant regions, respawn, teleport, low-memory behavior, and re-entry.

Read `docs/V12_INSTANCE_STREAMING_CONTRACT.md` and `docs/V12_STREAMING_AWARE_COMPONENTS.md`.
