---
name: roblox-matchmaking-teleport
description: Design Roblox parties, matchmaking queues, reserved-server handoff, cross-server coordination, and TeleportService failure recovery.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Matchmaking and Teleport

Use whenever the experience creates parties, queues players, teleports between places, or coordinates across servers.

## Required workflow

1. Specify party membership, leader semantics, eligibility, privacy, capacity, match criteria, cancellation, and timeout.
2. Use MemoryStore for temporary expiring coordination and DataStores for durable records.
3. Give queue entries stable IDs, schema version, timestamps, expiry, and ownership/lease rules.
4. Treat messages as notifications, not sole truth; make handlers idempotent and re-check authoritative state.
5. Define teleport failure, bounded retry, fallback lobby, partial-party recovery, and rejoin.
6. Never assume a teleport request means every client arrived.
7. Keep reserved-server secrets server-side.
8. Test queue expiry, duplicate notifications, leader disconnect, partial failure, destination unavailable, and shutdown.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_MULTIPLAYER_SESSION_ARCHITECTURE.md`
- `docs/FAILURE_RECOVERY_AND_INCIDENTS.md`
- `docs/V5_REFERENCE_INDEX.md`
