---
name: roblox-player-support-triage
description: Triage player-facing reports, reproduce defects, assess impact, and coordinate incident follow-up. Use for bug reports.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Player Support and Incident Triage — V7

## Mission
Turn player reports and operational signals into reproducible, prioritized engineering work while protecting privacy.

## Intake
Capture issue category, approximate time window, place/build, device/input mode, locale, steps, expected/actual behavior, frequency, and whether data or purchases may be affected. Do not ask for passwords, cookies, account secrets, or unnecessary personal information.

## Severity
Prioritize data loss, account/security exposure, transaction integrity, broad join failures, exploit impact, and widespread crashes above cosmetic defects. Distinguish confirmed impact from an unverified report.

## Reproduction
Create a safe minimal scenario using test accounts and non-production data. Preserve relevant logs with secrets and personal data redacted. Link the report to an issue, owner, mitigation, and verification plan.

## Communication
Use factual, age-appropriate, non-blaming language. Do not promise restoration or compensation without evidence and authorized process. Do not contact players or change accounts unless explicitly authorized and permitted.

Read `docs/V7_PLAYER_SUPPORT_AND_INCIDENT_TRIAGE.md`.
