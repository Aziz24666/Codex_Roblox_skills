---
name: roblox-sports-games
description: Design Roblox sports and skill games with responsive controls, fair scoring, rounds, leaderboards, and cross-device input.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Sports Games

Use for sports-style experiences such as ball games, timed courses, team scoring, or skill challenges. Keep rules readable, controls accessible, and scores server-verified.

## Required workflow

1. Define rules, round duration, scoring, tie-breaks, teams, and valid attempts.
2. Prototype controls/camera on keyboard, touch, and gamepad before building a full arena.
3. Keep scores, checkpoints, results, and rewards server-owned; client prediction is presentation only.
4. Handle respawn, leave/rejoin, late join, simultaneous results, and round reset.
5. Test out-of-bounds actions, ties, latency, player dropouts, and different frame rates.
6. Use color-independent result cues and clear boundaries.
7. Report scoring reconciliation and real Studio evidence.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_GENRE_COMPENDIUM.md`
- `docs/CHARACTER_CAMERA_AND_INPUT.md`
- `docs/MULTIPLAYER_TEST_MATRIX.md`
