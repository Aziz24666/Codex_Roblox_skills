---
name: roblox-content-factory
description: Build reusable factories that turn validated content definitions and approved templates into consistent Roblox prefabs.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Content Factory

Use for NPC, companion, cosmetic, collectible, utility gadget, and interactive-prop authoring.

- Definitions describe intended content; templates define approved object hierarchy; the factory combines them.
- The factory must not invent asset IDs, copy untrusted scripts, or silently omit missing references.
- Keep source template, generated prefab, and runtime registry separate.
- Record schema version, definition ID, source template ID, and generation version on outputs.
- Use preview/dry-run, collision detection, deterministic names, and undo support.
- Generated objects remain inert until connected to an approved runtime system.

Read `docs/V8_CONTENT_FACTORY.md` and `docs/V8_PREFAB_GENERATION_PIPELINE.md`.
