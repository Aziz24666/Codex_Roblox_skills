---
name: roblox-component-system
description: Build lifecycle-safe reusable components attached to tagged Roblox instances, with explicit attach/detach contracts.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Component System

Use for behavior shared across many Models, Parts, or other Instances.

- Prefer one system observing a CollectionService tag over duplicating identical Scripts under every instance.
- Each component has `CanAttach`, `Attach`, and `Destroy`/`Detach` responsibilities.
- Attach is idempotent; detach disconnects every connection, cancels tasks, and releases references.
- Store the component instance/state in a registry keyed by the Instance; do not put mutable state in shared configuration.
- Read stable IDs from attributes, resolve definitions through a typed registry, and fail closed on unknown IDs.
- Handle already-tagged instances at startup and instances added/removed later.
- Keep server-owned gameplay components on the server; use separate presentation components on clients when needed.

Read `docs/V8_COMPONENT_LIFECYCLE.md` and `docs/V8_COLLECTIONSERVICE_REGISTRATION.md`.

## V12 lifecycle requirements
For tag-based registration, follow `docs/V12_COLLECTIONSERVICE_LIFECYCLE.md` and the sample `examples/v12/TaggedLifecycleBinder.lua`. Handle pre-existing tags, add/remove signals, idempotency, and cleanup.
