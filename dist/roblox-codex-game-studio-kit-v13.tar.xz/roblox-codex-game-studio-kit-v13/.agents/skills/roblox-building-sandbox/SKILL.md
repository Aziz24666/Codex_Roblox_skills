---
name: roblox-building-sandbox
description: Implement player-authored building systems with placement previews, server validation, ownership, quotas, and persistence.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Building Sandbox

Use for plot builders, decorators, editable player spaces, and grid/snap placement systems.

## Required workflow

1. Define permissions, plot bounds, reviewed catalog, transforms, rotation, snapping, collision, quotas, and deletion.
2. Use client previews for responsiveness; repeat all checks on the server.
3. Accept catalog IDs and bounded transform intent, not arbitrary asset paths or serialized Instance trees.
4. Validate ownership, allowlist, finite transforms, boundaries, overlap, cost, quota, and rate.
5. Use server-owned reviewed templates; never execute client-supplied modules.
6. Bound serialized size, object count, and nesting.
7. Persist compact versioned placement records.
8. Test simultaneous placement, plot transfer, deletion, rejoin, large builds, and streaming.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md`
- `docs/PROCEDURAL_GENERATION_AND_WORLD_BUILDING.md`
- `docs/STREAMING_AND_WORLD_SCALE.md`
