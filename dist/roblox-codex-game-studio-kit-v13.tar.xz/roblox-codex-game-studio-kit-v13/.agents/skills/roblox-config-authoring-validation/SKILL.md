---
name: roblox-config-authoring-validation
description: Create approachable data-authoring workflows with field metadata, defaults, validation feedback, and preview support.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Config Authoring and Validation

Use for forms, JSON editors, config catalogs, and content tools.

- Define field label, type, description, default, bounds, enum options, visibility conditions, and required status in one field schema.
- Generate UI from field metadata rather than hand-writing one-off forms for each content type.
- Keep parsing, validation, normalization, and serialization pure/testable.
- Display field-level errors and preserve the user's draft on failure.
- Distinguish warning from blocking error.
- Show previews and the exact generated hierarchy before committing changes.

Read `docs/V8_CONFIG_EDITOR_FIELD_MODEL.md` and `docs/V8_CONFIG_SCHEMA_AND_VALIDATION.md`.
