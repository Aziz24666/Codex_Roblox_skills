---
name: roblox-pets-companions
description: Build Roblox pet and companion systems including ownership, collection, following, inventory, cosmetic progression, and server-authoritative.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Pets and Companions

Use for companion followers, collection books, pet cosmetics, equip slots, or utility companions.

## Required workflow

1. Define stable companion IDs, ownership records, collection rules, equip limits, cosmetics, and presentation.
2. Separate definitions from player-owned data.
3. Keep ownership, equips, unlocks, boosts, and rewards server-authoritative.
4. Bound follower count and update cost; avoid one expensive per-frame loop per companion.
5. Define collision, catch-up, respawn, streaming, and cleanup on unequip/leave.
6. Persist with versioned schemas.
7. Test duplicate equip, full slots, missing assets, respawn, streaming gaps, and concurrent requests.
8. Disclose unlock conditions; avoid misleading random reward mechanics.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md`
- `docs/PERSISTENCE.md`
- `docs/ASSET_PIPELINE.md`
