---
name: roblox-competitive-ranking
description: Design fair, explainable competitive ratings, leaderboards, seasonal resets, placement matches, and anti-abuse validation for Roblox experiences.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Competitive Ranking — V6 Specialist

## Mission
Create understandable competitive progression that resists obvious manipulation and treats ranking calculations as server-owned outcomes.

## Design decisions
- Define rating model, placement period, uncertainty, inactivity, season boundaries, tie-breaks, decay (if any), and reset policy.
- Distinguish skill rating, visible rank tier, leaderboard score, and reward eligibility.
- Specify match eligibility, party restrictions, rematch handling, disconnect outcomes, and suspicious-match review.
- Store durable results with idempotent match IDs and explicit schema versions.

## Integrity
Clients never submit final score/rating deltas. The server verifies match completion and computes results from trusted match events. Prevent duplicate settlement and replay with stable match IDs. Separate display updates from durable writes.

## Fairness
Document ranking behavior to players. Avoid opaque pay-to-win rating multipliers, deceptive placement messaging, and rewards that encourage unhealthy play patterns.

## QA
Test ties, draw, repeated settlement, disconnect, server crash near settlement, party edge cases, stale leaderboard cache, season rollover, migration, and rollback.

Read `docs/V6_GENRE_SYSTEMS_AND_BALANCE.md` and `docs/V6_RUNTIME_OBSERVABILITY_AND_INCIDENT_RESPONSE.md`.
