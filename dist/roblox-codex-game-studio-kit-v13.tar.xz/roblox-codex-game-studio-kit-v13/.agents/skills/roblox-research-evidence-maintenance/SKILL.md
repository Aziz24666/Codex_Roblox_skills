---
name: roblox-research-evidence-maintenance
description: Roblox Research Evidence Maintenance.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Research Evidence Maintenance

Maintain research records alongside the systems they support. Index decisions by feature, API, module, and recheck trigger. On each new task re-open current sources; do not simply reuse old citations. Before a major release, recheck all API-sensitive decisions in the release scope. Record superseded decisions and update implementation notes when docs change. Keep references concise and actionable rather than creating a large link dump.
