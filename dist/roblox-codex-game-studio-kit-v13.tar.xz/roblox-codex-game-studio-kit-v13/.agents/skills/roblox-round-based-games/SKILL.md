---
name: roblox-round-based-games
description: Build round-based Roblox experiences with lobby flow, matchmaking handoff, countdowns, phases, scoring, player dropout, reconnect handling.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Round-Based Games — V7

## Mission
Implement match/session loops as explicit state machines with clear ownership, legal transitions, and recoverable failure behavior.

## State model
Define states such as `WaitingForPlayers`, `Intermission`, `Loading`, `InProgress`, `Resolving`, `Results`, and `Returning`. Use only the states needed by the game. Define allowed transitions and who may request each transition.

## Server authority
The server owns player membership, phase deadlines, score, objective state, match result, reward eligibility, and payout idempotency. Clients send intent and render replicated state. Do not accept client-submitted winners, score totals, timers, or rewards.

## Lifecycle
Handle late joins, leave/rejoin, disconnect, server shutdown, empty server, minimum-player failure, timeout, cancellation, and duplicate transition requests. Clean up round-scoped connections, NPCs, temporary objects, and timers on every exit path.

## Testing
Exercise every legal transition and representative illegal transitions. Test simultaneous last-player leave, result race, duplicate end requests, late join, disconnect during resolving, and retry/re-entry. Use an injected clock/random source for pure logic tests; verify actual runtime separately.

Read `docs/V7_ROUND_SESSION_STATE_MACHINES.md` and `docs/V7_REGRESSION_AND_TEST_EVIDENCE.md`.
