---
name: roblox-data-driven-npc-runtime
description: Implement one shared NPC movement and non-hostile behavior runtime configured by per-NPC data definitions.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Data-Driven NPC Runtime

Use for NPCs that wander, follow, patrol, guide players, idle at a service point, or act as companions.

- Do not clone a bespoke behavior Script into every NPC.
- Define `NPCDefinitionId` on each model; apply the `DataDrivenNPC` tag.
- One server bootstrap discovers tagged models and attaches the shared controller.
- Keep movement, behavior policy, animation presentation, and interaction separate.
- Behavior modules receive a narrow context and typed configuration. They do not reach into unrelated systems.
- Per-NPC state belongs to that controller instance. Definitions are read-only.
- Pathfinding is throttled, cancellable, and has unreachable/stuck fallbacks.
- Detach on model removal, death, respawn replacement, or streaming/lifecycle transitions as appropriate.

Use only non-hostile roles in this playbook. Read `docs/V8_SHARED_NPC_RUNTIME.md`, `docs/V8_REUSABLE_MOVEMENT_SYSTEM.md`, and `examples/v8/NPCDefinitions.lua`.
