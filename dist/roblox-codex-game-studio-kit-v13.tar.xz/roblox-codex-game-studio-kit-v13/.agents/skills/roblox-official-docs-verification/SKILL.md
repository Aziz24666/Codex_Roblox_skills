---
name: roblox-official-docs-verification
description: Roblox Official Documentation Verification.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Official Documentation Verification

Use this skill whenever Roblox APIs, Studio behavior, policy, release state, limits, security, or platform compatibility matter.

- Search Creator Hub topic docs and API reference separately.
- Verify exact class/member names and security context.
- Check whether the member is available in Studio, plugin security, client, server, or only specific test contexts.
- Check deprecation, beta, feature-flag, permission, rollout, and engine-version notes.
- Read examples and caveats; never rely on search snippets.
- Compare the doc page to current updates/release notes when a feature is new or recently changed.
- Record claims with exact source URL and access date.
- If documentation is ambiguous, isolate a minimal Studio spike and mark uncertainty until tested.
