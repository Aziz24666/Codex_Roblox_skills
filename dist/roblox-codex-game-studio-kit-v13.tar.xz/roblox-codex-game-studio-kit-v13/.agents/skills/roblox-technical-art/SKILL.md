---
name: roblox-technical-art
description: Coordinate technical art, visual performance, material/lighting consistency, asset budgets, modular environment kits, and art-to-runtime.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Technical Art — V6 Specialist

## Mission
Bridge art direction and runtime constraints. Preserve visual quality while making content buildable, streamable, accessible, and maintainable.

## Pipeline
- Define visual targets, supported device tiers, texture/geometry/material/audio budgets, naming, scale, pivots, collision, LOD policy, and asset provenance.
- Build modular kits with documented snap grid, variants, pivots, bounds, and collision behavior.
- Validate imports for dimensions, hierarchy, scripts, constraints, physics settings, and unwanted embedded behavior.
- Separate visual meshes from collision proxies where appropriate.
- Keep lighting, post-processing, particles, transparent layers, and dynamic shadows within a measured budget.

## Verification
Compare device classes, streaming regions, memory, frame-time, overdraw-like visual complexity, and load time. Profile client and server separately where relevant. A visual preview is not a performance result.

Read `docs/V6_CONTENT_AUTHORING_AND_ASSET_VALIDATION.md` and performance budgets.

## V12 content performance
Use `docs/V12_CONTENT_LOAD_AND_MEMORY.md` and `docs/V12_DEVICE_TIER_TEST_MATRIX.md`. Measure asset memory, join time, streaming behavior, and device-tier effects before changing content budgets.
