---
name: roblox-experience-onboarding
description: Design and implement first-session onboarding, tutorials, guided tasks, teachable moments, returning-player guidance, and skip/resume.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Experience Onboarding — V7

## Mission
Help new players understand the core loop and reach a meaningful first success without overwhelming them or blocking experienced players.

## Design sequence
1. Map the first 30 seconds, first 3 minutes, and first complete core loop.
2. Identify the minimum concepts required before the player can act.
3. Teach through safe contextual actions and visible feedback rather than long text walls.
4. Keep tutorials skippable where possible; support pause, resume, reconnect, respawn, and returning-player state.
5. Avoid teaching monetization before players understand the experience.

## Architecture
- Server owns durable tutorial milestones and rewards.
- Client owns presentation, prompts, highlights, and local input state.
- Represent tutorial progression as versioned, data-driven steps with stable IDs.
- Treat client step-completion signals as requests; validate prerequisites and reward eligibility on the server.
- Make completion idempotent so repeated signals do not duplicate rewards.
- Do not persist every transient UI state; persist only meaningful milestones.

## Accessibility and devices
Support touch, mouse/keyboard, and gamepad navigation. Avoid tiny targets, color-only instructions, flashing-only cues, and input assumptions. Localize strings and permit reduced-motion presentation.

## Verification
Test new, returning, skip, reconnect, respawn, alternate device, changed tutorial version, and mid-step disconnect paths. Verify that tutorial rewards cannot be claimed twice.

Read `docs/V7_PLAYER_JOURNEY_AND_ONBOARDING.md`.
