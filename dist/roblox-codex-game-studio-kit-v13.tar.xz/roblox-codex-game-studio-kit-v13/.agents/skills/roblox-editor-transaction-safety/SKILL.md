---
name: roblox-editor-transaction-safety
description: Make Studio plugin DataModel operations undoable, cancel-safe, and collision-aware.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Editor Transaction Safety

Perform all validation and dry-run checks before starting a recording. Use `ChangeHistoryService:TryBeginRecording()` before DataModel changes; commit after successful post-validation and cancel on failure. If recording cannot begin, make no changes. Ensure all created objects are within the transaction. Read `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md` and test undo/redo in Studio.
