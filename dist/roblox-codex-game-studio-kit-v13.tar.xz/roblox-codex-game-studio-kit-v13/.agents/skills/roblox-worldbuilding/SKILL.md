---
name: roblox-worldbuilding
description: Plan, graybox, build and optimize Roblox maps, levels, hubs, obstacle courses, tycoon spaces, social areas and interactive environments.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Worldbuilding

Create worlds that help players understand where to go, what matters and how spaces connect. Design for the camera, movement, interaction and device performance—not only a top-down image.

## World workflow
1. Extract the player loop and list the spaces it requires.
2. Create a world flow diagram: spawn, orientation point, main activity, reward/return path, optional spaces and social area.
3. Define scale, traversal time, sightlines, landmarks, safe zones and spawn safety.
4. Graybox with simple geometry before detailed props. Test camera, collision, jump/traversal and player density.
5. Use consistent spatial rules, modular kits and clear visual hierarchy.
6. Add interactive objects with server-side validation, meaningful prompts, clear affordances and fallback behavior.
7. Separate collision geometry from visual decoration where this helps performance or readability.
8. Plan streaming and client availability. Do not assume all Workspace content is present when a client first joins.
9. Add detail in layers: silhouette, primary materials, landmark shapes, lighting, props, particles and polish.
10. Profile on target device classes and inspect occlusion, overdraw, physics load, memory and replication costs.

## Level review
- Can a new player identify the next useful action from spawn?
- Are important paths readable without excessive arrows?
- Are jumps, platforms and interaction ranges consistent?
- Can mobile players see and reach important UI/world targets?
- Are spawn points safe and not inside geometry?
- Does each zone have a purpose and recognizable identity?
- Does the world avoid unnecessary high-detail repetition?

## Technical caution
World objects can stream in and out on clients. Client-side references to streamed Workspace objects must handle absence and reappearance. Keep persistent game state on the server/shared data model, not in the assumption that a specific client has a particular part loaded.

## References
Read `docs/WORLD_AND_LEVEL_DESIGN.md`, `docs/STREAMING_AND_WORLD_SCALE.md`, `docs/ASSET_PIPELINE.md`, and `docs/PERFORMANCE_BUDGETS.md`.
## V3 world production protocol

1. Turn the game brief into a spatial experience map: spawn, tutorial path, core activity, recovery route, social spaces, progression unlocks, and exit/return path.
2. Graybox scale, sightlines, navigation, landmarks, interaction spacing, and camera behavior before detailing.
3. Partition content into named zones/chunks with documented ownership and streaming assumptions.
4. Validate collision, spawn safety, vertical navigation, readability, lighting, and performance on target devices.
5. Keep client-needed assets lean; do not assume streamed Workspace instances exist immediately on clients.
6. Use original art direction and clear asset provenance. Avoid copied maps, branded UI, or unlicensed source material.
7. Add detail only after the graybox passes movement, objective clarity, and performance checks.

A map is not complete because it looks finished in an editor. It must support the intended loop, guide players, replicate correctly, stream predictably, and perform on target devices.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
