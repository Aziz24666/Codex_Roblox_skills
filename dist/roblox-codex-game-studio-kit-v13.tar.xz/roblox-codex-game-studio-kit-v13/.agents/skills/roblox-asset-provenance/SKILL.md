---
name: roblox-asset-provenance
description: Roblox Asset Provenance.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Asset Provenance

Before using an existing or inserted asset, record its asset ID, asset type, creator/owner where verifiable, source, permissions/experience availability, license/usage constraints where relevant, embedded scripts, dependencies, and actual load test. Asset ID syntax is not provenance or permission proof. Inspect inserted models and packages for scripts and unexpected descendants. Prefer owned, reviewed, reusable package assets. Never publish or upload without explicit permission.
