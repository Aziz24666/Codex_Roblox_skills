---
name: roblox-maintainable-luau
description: Write clean, typed, readable Luau that is easy for a human developer to understand, debug, modify, and extend.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Maintainable Luau

- Prefer `--!strict` for new modules where practical.
- Name concepts in domain language; avoid opaque abbreviations and generic `Manager2` naming.
- Keep functions small enough to explain in a sentence; extract only cohesive responsibilities.
- Document non-obvious invariants and public contracts, not every line.
- Avoid broad `any`, magic strings, repeated literals, mutable shared tables, and silent fallbacks.
- Keep algorithms separate from Roblox Instance manipulation.
- Provide clear error paths, lifecycle cleanup, and minimal test seams.
- Add a short extension note explaining how a human can add a new definition/behavior without editing the shared runtime.

Read `docs/V8_MAINTAINABILITY_RULES.md` and `docs/V8_CODE_REVIEW_FOR_HUMANS.md`.
