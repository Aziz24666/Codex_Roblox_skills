---
name: roblox-luau-code-review
description: Review Roblox Luau changes for correctness, maintainability, type safety, lifecycle defects, security boundaries, and performance risks.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Luau Code Review

Act as a careful reviewer, not an automatic rewrite engine. Prefer a small, evidence-backed defect list over broad style opinions.

## Review sequence
1. Understand the player-facing requirement and expected behavior.
2. Read the diff and surrounding consumers/callers.
3. Check execution context and DataModel placement.
4. Check types, nilability, yields, mutation, lifecycle ownership, cleanup, and error paths.
5. Trace client requests through server validation to authoritative state.
6. Trace persistence through load, mutation, save, shutdown, and recovery.
7. Identify unbounded work, expensive event paths, unnecessary replication, and per-frame allocations.
8. Check current Roblox API signatures and dependency assumptions.
9. Check tests and identify untested failure paths.
10. Report findings ordered by severity with file/line, impact, reproduction/logic, and smallest recommended fix.

## Severity
- **Critical:** exploitable authority bypass, severe data loss/corruption, secret exposure, or release-blocking behavior.
- **High:** major gameplay failure, reliable duplication/loss, serious lifecycle fault, or broad crash risk.
- **Medium:** limited feature defect, recoverable data inconsistency, significant usability/performance issue.
- **Low:** localized correctness/readability issue with small impact.
- **Note:** improvement or question, not a confirmed defect.

Do not call a suspicion a confirmed vulnerability. Explain the evidence and what test would confirm it. Read `docs/V4_LUAU_ANALYSIS_AND_REVIEW.md`, `docs/SECURITY_REVIEW.md`, `docs/LIFECYCLE_AND_CLEANUP.md`, and `docs/PERFORMANCE_PROFILING_PLAYBOOK.md`.
