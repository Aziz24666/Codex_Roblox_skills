---
name: roblox-content-template-authoring
description: Create versioned, approved source templates and deterministic prefab hierarchies for reusable Roblox content.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Content Template Authoring

Templates define hierarchy and required descendants; schemas define editable data. Give templates stable IDs and versions. Validate class types, required attachments, PrimaryPart expectations, asset slots, tags, and attributes. Preserve source templates and never silently mutate them during generation. Read `docs/V9_GENERATED_CONTENT_GOVERNANCE.md`.
