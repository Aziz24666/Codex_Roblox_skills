---
name: roblox-animation-audio
description: Integrate Roblox character and object animations, animation controllers, sound effects, music, ambience, spatial audio and synchronized.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Animation and Audio

Use animation and audio to clarify action, character, environment and state—not as decoration that obscures gameplay.

## Workflow
1. List the player action or state the asset communicates.
2. Identify whether playback is client-local, server-triggered, or replicated; choose the narrowest appropriate scope.
3. Check asset ownership, usage rights, moderation status and availability. Never invent asset IDs.
4. Define naming, grouping, priority, loop, fade, spatial behavior and cleanup.
5. Integrate with the feature's state machine so cancelled, interrupted and repeated actions behave cleanly.
6. Avoid playing multiple duplicate sounds due to replication or repeated events.
7. Test load failure, late join, respawn, device volume, distance falloff and repeated triggers.
8. Document externally sourced or user-provided assets in the asset register.

## Quality gates
- Animation does not desynchronize gameplay-critical hitboxes or state.
- Animation tracks and sound instances have an explicit lifecycle owner.
- Audio does not overwhelm narration, important prompts or accessibility cues.
- Missing or moderated assets fail gracefully.
- No unlicensed audio or copied character animation is silently introduced.

## References
Read `docs/ANIMATION_AND_AUDIO.md`, `docs/ASSET_PIPELINE.md`, `docs/LIFECYCLE_AND_CLEANUP.md`, and `docs/PERFORMANCE_BUDGETS.md`.
## V3 execution contract

### Before editing
1. Inventory animation and audio assets already used by the experience; preserve IDs, ownership notes, and authoring sources.
2. Identify the character rigs, animation controller/Animator ownership, supported devices, audio mix goals, and whether the content is original, licensed, or Roblox-provided.
3. Confirm every referenced asset exists and is usable in the target experience. Do not invent asset IDs or claim an upload succeeded.

### Implementation sequence
1. Define the player-visible intent and trigger conditions for each cue.
2. Specify lifecycle ownership: who loads, plays, stops, fades, and cleans up each track or sound.
3. Keep animation state transitions deterministic and avoid competing scripts controlling the same Animator or track.
4. Use semantic sound categories and a consistent volume/mix policy; avoid maximum-volume surprises and overlapping loops.
5. Handle missing, delayed, moderated, or unavailable assets gracefully.
6. Test join, respawn, character replacement, UI close, round transition, and player removal.

### Verification
- Confirm animation priority, loop state, fade behavior, and state transitions in Studio.
- Check audio spatialization, rolloff, volume, concurrency, and mobile performance.
- Verify that the cue is not duplicated by both server and client.
- Record the actual asset provenance and any permissions that remain unverified.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
