---
name: roblox-runtime-performance-profiling
description: Profile client and server workloads with Roblox tools; use when investigating frame time, CPU, memory, or stutter.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
1. Research current Creator Hub profiling documentation and available Studio/MCP tools.
2. Define a repeatable player scenario, warm-up, device tier, client count, and sample window.
3. Capture client and server separately with MicroProfiler/Developer Console or a verified Studio workflow.
4. Find the dominant measured cost before editing code.
5. Change one cause at a time, repeat the same scenario, and compare evidence.
6. Record limitations and avoid extrapolating Studio measurements to all live devices.

Read `docs/V12_RUNTIME_PERFORMANCE_LOOP.md` and `docs/V12_MICROPROFILER_AND_SCRIPT_PROFILER.md`.
