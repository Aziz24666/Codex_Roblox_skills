---
name: roblox-cutscene-cinematics
description: Build camera choreography, dialogue timing, transitions, and skippable cinematic flows. Use for in-game presentation.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Cutscenes and Cinematics — V6 Specialist

## Mission
Deliver clear, interruptible presentation without trapping players or coupling important gameplay state to a camera animation.

## Design
- Define whether each sequence is local-only presentation or synchronized match-critical state.
- Use server-authoritative state for rewards/objectives; let client camera and UI presentation remain client-side where safe.
- Establish a sequence state machine: idle, preparing, playing, skipped, interrupted, completed, cleanup.
- Define ownership of camera mode, input lock, UI visibility, audio, character anchoring, and focus target.
- Include skip/fast-forward behavior and recovery after respawn, disconnect, or character removal.

## Timing and compatibility
Use time-based interpolation rather than frame-count assumptions. Handle low frame rates, late asset loading, touch/gamepad skip controls, reduced motion preferences, subtitles, and localization expansion.

## Cleanup
Every sequence must restore camera, input, UI, character control, audio state, and temporary instances through one guaranteed cleanup path.

## Verification
Test skip at every phase, player respawn, overlapping requests, late asset load, character removal, low frame rate, mobile aspect ratios, and simultaneous multiplayer start.

Read `docs/V6_CINEMATICS_AND_PRESENTATION.md`.
