---
name: roblox-plugin-tooling
description: Implement maintainable Roblox Studio plugins with clean UI/controller/service separation and safe DataModel editing.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Plugin Tooling

Use when creating or extending Studio plugins.

- Keep plugin entrypoint small; pass the `plugin` capability explicitly to modules that need it.
- Separate widget construction, form state, validation, factories, and persistence.
- Use stable widget IDs and version stored plugin settings.
- Make selection assumptions explicit and revalidate selection at action time.
- Provide a dry-run and actionable validation errors.
- Keep plugin source free of credentials and external network dependencies unless the feature explicitly requires a reviewed service.
- Verify current Studio API signatures against Creator Hub.

Read `docs/V8_STUDIO_CONTENT_EDITOR_SPEC.md`, `docs/V8_PLUGIN_UNDO_AND_SAFETY.md`, and `studio-plugin/README.md`.
