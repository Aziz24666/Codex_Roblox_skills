---
name: roblox-feature-orchestration
description: Coordinate multi-system Roblox feature implementation across specialists, stable interfaces, dependency order, bounded parallel work.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Feature Orchestration — V7

## Mission
Coordinate specialists so a feature becomes one integrated player outcome, not several incompatible partial implementations.

## Before delegation
1. Define the player-visible outcome and non-goals.
2. Inspect the actual architecture and assign one integration owner.
3. Split work by system boundaries with explicit files, interfaces, dependencies, acceptance criteria, and test requirements.
4. Assign one owner per shared file. Parallelize only independent tasks.
5. Create a feature contract before parallel implementation.

## During work
- Keep work-in-progress small; finish or unblock active tasks before opening more.
- Require specialists to report changed files, public contracts, assumptions, tests actually run, blockers, and unresolved TODOs.
- Integrate early through real interfaces. Reject placeholder adapters that are not part of the final design.
- Resolve cross-system decisions centrally. Do not let multiple agents independently edit shared state or duplicate modules.

## Integration gates
Run contract checks, static checks, module integration tests, Studio scenarios, security/data review, and a final diff audit. Track partial results honestly; one completed specialist task does not mean the whole feature is complete.

Read `docs/V7_TEAM_WORKSTREAMS_AND_INTEGRATION.md` and `docs/V7_END_TO_END_FEATURE_FACTORY.md`.
