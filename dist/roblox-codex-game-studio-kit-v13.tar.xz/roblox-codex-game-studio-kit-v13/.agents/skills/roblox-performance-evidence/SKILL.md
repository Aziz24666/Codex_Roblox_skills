---
name: roblox-performance-evidence
description: Roblox Performance Evidence.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Performance Evidence

Do not optimize from intuition alone. Research current Creator Hub performance guidance, define budgets by device/server/player count, collect a baseline, identify the actual hotspot with Studio profiler/MicroProfiler or available observability, change one major factor, and compare under the same workload. Test low-end/mobile, memory, loading, networking, replication, physics, scripts, and long-running server behavior as applicable. Record raw measurements, conditions, confidence, and regression threshold.

## V12 baseline schema
Use `schemas/v12-performance-baseline.schema.json`, its example, and `tools/v12_perf_budget_check.py`. A budget check is a structured comparison, not a Studio profile.
