---
name: roblox-quest-content
description: Design and implement data-driven quests, objectives, dialogue, clues, rewards, and progression gates with stable IDs and server-authoritative.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Quest and Content Systems

Use this skill for objective chains, tutorial tasks, missions, collection goals, dialogue progression, clue delivery, and content catalogs.

## Design and implementation
1. Define player intent and how the objective is discovered.
2. Give each quest/objective a stable ID independent of its display name.
3. Define states such as locked, available, active, completed, claimed, and expired only when those states are needed.
4. Define prerequisites and a directed dependency graph; detect cycles and unreachable objectives.
5. Define progress events with narrow typed payloads. Server owns completion and rewards.
6. Make reward grants idempotent and auditable; repeated claim requests must not duplicate value.
7. Keep presentation text and asset references separate from authoritative requirements/rewards.
8. Add skip/reset/retry behavior only when its rules are clear.
9. Validate all content references and test late join, reconnect, duplicate events, and simultaneous progress.

## Content rules
Use original dialogue and avoid copying protected stories or characters. Keep content age-appropriate. Do not use manipulative streak pressure or paid random outcomes. Ensure critical objectives are readable and don't rely on audio alone.

Read `docs/V4_CONTENT_AUTHORING_AND_VALIDATION.md`, `docs/CORE_LOOP_AND_PROGRESSION.md`, `docs/V4_SESSION_CONCURRENCY_AND_RECOVERY.md`, and `templates/QUEST_SPEC_TEMPLATE.md`.
