---
name: roblox-party-minigames
description: Build Roblox party experiences with rotating minigames, lobbies, round state, fair scoring, rematches, and reliable cleanup.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Party Minigames

Use for short-round collections, social competitions, rotating challenges, and party lobbies.

## Required workflow

1. Define capacity, minimum players, countdown, selection, duration, scoring, ties, intermission, and disconnect policy.
2. Model lifecycle as explicit states with one transition owner.
3. Give minigames a narrow contract: prepare, start, join/leave, finish, cleanup, result.
4. Keep scores and winners server-side. Prevent round state/connections leaking into the next minigame.
5. Handle late join, empty rounds, single player, shutdown, load failure, and timeout.
6. Use bounded timers and one countdown source of truth.
7. Test multi-client, rapid leave/rejoin, simultaneous finish, ties, and cleanup.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_GENRE_COMPENDIUM.md`
- `docs/MULTIPLAYER_SESSION_TESTING.md`
- `docs/V5_TEST_AUTOMATION_STRATEGY.md`
