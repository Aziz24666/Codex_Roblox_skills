---
name: roblox-networking-security
description: Design, implement and audit Roblox client/server communication, remotes, replication, server-authoritative gameplay, request validation, rate.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Networking and Security

The server is authoritative for consequential shared state. Treat all client requests as untrusted—even if they originate from the game's own LocalScripts.

## Remote design procedure
1. Name the action and the minimum data the client must send.
2. Prefer intent-based requests (for example, request a known interaction) over client-supplied outcomes (for example, set currency to a number).
3. Define a typed payload contract: fields, types, bounds, allowed values, ownership and maximum size.
4. Validate player state, context, distance, cooldown, permission, object class/location and rate on the server.
5. Apply the action using server-owned data and configuration.
6. Return or replicate the result through a narrow response contract.
7. Rate-limit requests and clean limiter state when players leave.
8. Test malformed, repeated, stale, out-of-range and concurrent requests.

## Threat review
Inspect RemoteEvents, RemoteFunctions, ProximityPrompts, ClickDetectors, DragDetectors, client-owned physics and any other client-triggerable path. UI visibility, `Enabled`, activation distance and local cooldowns are not sufficient security controls. Verify current Creator Hub guidance for event-specific server behavior.

## Never implement
- Arbitrary server-side instance path or property mutation from client arguments.
- Arbitrary asset/code loading based on a client-supplied identifier.
- Remote admin consoles, hidden backdoors, credential collection or exploit code.
- Client-authoritative rewards, inventory, purchases, permissions, score or progression.

## Security review output
Provide a table of each client-triggerable action, payload, server checks, rate limit, state mutation, response and relevant test. Mark any unvalidated path as a blocker.

## References
Read `docs/SERVER_AUTHORITY.md`, `docs/REMOTE_CONTRACTS.md`, `docs/SECURITY_REVIEW.md`, `docs/PERSISTENCE.md` and current Creator Hub client/server security guidance.
## V3 threat-model protocol

For every client-triggered action, write a small contract: action, allowed caller, payload shape, maximum payload size, server preconditions, distance/ownership rules, cooldown/rate, expected cost, output, and failure result.

Validate in layers: type and structure; numeric finiteness and bounds; enum allowlist; instance class and ancestry; caller state and permissions; proximity and line of sight where relevant; cooldown and rate; then authoritative state transition. Reject arbitrary paths, arbitrary instance mutation, client-supplied prices/rewards, and unbounded arrays/strings.

Assume replicated UI properties, prompt enabled state, local cooldowns, client animations, and client-owned physics can be manipulated. Client validation improves usability but is never the authorization boundary. Treat ProximityPrompt, ClickDetector, and similar interaction events as untrusted client-triggered input too.

For high-impact features, add adversarial tests for malformed payloads, repeated activation, stale state, simultaneous requests, ownership spoofing, excessive distance, invalid numeric values, and disconnect during operation. Rate-limit before expensive work. Log rejected categories without flooding output or exposing private player data.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.


## V5 boundary evidence
For every consequential request, write a remote contract and adverse tests. Use `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md` and `docs/V5_TEST_AUTOMATION_STRATEGY.md`. Test malformed, oversized, non-finite, unauthorized, stale, repeated, and concurrent requests.
