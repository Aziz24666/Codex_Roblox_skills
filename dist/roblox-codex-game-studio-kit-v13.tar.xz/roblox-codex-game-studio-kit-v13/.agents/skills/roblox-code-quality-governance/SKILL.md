---
name: roblox-code-quality-governance
description: Roblox Code Quality Governance.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Code Quality Governance

Review code for responsibility clarity, strict typing, focused public APIs, dependency direction, state ownership, error paths, lifecycle cleanup, deterministic behavior, testability, and understandable names. Prefer simple functions and small modules. Avoid mega-modules, magic values, duplicated configuration, global mutable state, hidden dependencies, arbitrary dynamic `require`, swallowed errors, and over-engineering. A review must explain concrete maintenance risks and propose the smallest effective correction.
