---
name: roblox-memory-and-resource-lifecycle
description: Find and prevent memory growth from connections, instances, tasks, caches, and component state.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Establish a workload and memory baseline before investigating growth.
- Trace ownership and lifetime for connections, tasks, instances, caches, and per-entity state.
- Add cleanup at explicit lifecycle boundaries; do not rely on weak assumptions about garbage collection.
- Repeat the same scenario and compare memory after teardown/settling.
- Do not introduce pooling unless repeated profiling proves it beneficial.

Read `docs/V12_MEMORY_AND_RESOURCE_LIFECYCLE.md`.
