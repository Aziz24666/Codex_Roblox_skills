---
name: roblox-social-roleplay
description: Design social spaces and roleplay interactions with lifecycle, permissions, accessibility, and privacy. Use for social experiences.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Social and Roleplay Design

Use for hangouts, roleplay spaces, social hubs, parties, shared activities, and player-to-player interactions.

## Build process
1. Define the social fantasy without requiring players to reveal personal information.
2. Design a safe arrival, activity discovery, participation, exit, and reset loop.
3. Define roles/props/rooms as server-owned permissions and state.
4. Keep player identity and privacy data to the minimum required.
5. Use platform-supported chat and safety systems; do not pretend a custom chat UI or filter replaces Roblox moderation.
6. Add clear controls to leave, reset, mute/report through supported platform capabilities where applicable.
7. Test role changes, shared ownership, disconnects, late joins, and permission boundaries.
8. Confirm no UI or game system exposes private account data or enables harassment.

Do not create surveillance, doxxing, impersonation, coercive social mechanics, harassment tools, or mechanisms that evade platform safeguards. Check current Roblox policy and APIs before using social features.

Read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`, `docs/UI_UX_AND_ACCESSIBILITY.md`, `docs/V4_OFFICIAL_REFERENCE_INDEX.md`, and `docs/V4_GENRE_ACCEPTANCE_MATRICES.md`.
