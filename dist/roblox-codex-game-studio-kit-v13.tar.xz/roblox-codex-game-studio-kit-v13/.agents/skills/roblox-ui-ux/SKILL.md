---
name: roblox-ui-ux
description: Build Roblox interfaces, HUDs, menus, prompts, and responsive input. Use when player-facing UI or interaction changes.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox UI/UX

Build interfaces that are readable, responsive and driven by real game state. Never ship a decorative button that appears functional but does nothing.

## Workflow
1. List screens and the player task each screen supports.
2. Map the navigation hierarchy and identify how players open, close, return and recover.
3. Define screen states: loading, ready, empty, unavailable, error, confirmation and success.
4. Sketch hierarchy and priority. Keep primary action obvious and avoid clutter.
5. Define input behavior for supported devices; avoid keyboard-only assumptions.
6. Implement UI as reusable components only where reuse is real. Keep state ownership explicit.
7. Bind to a controlled client presentation model; server-authoritative state remains on server and is replicated safely.
8. Provide focus, selection, touch size, safe-area spacing, readable text and clear feedback.
9. Test at multiple aspect ratios and viewport sizes, with mouse, touch and gamepad if supported.
10. Verify every action, close path, empty state and error state.

## Interaction contract
A button should have a defined action, disabled condition, loading behavior, failure behavior and feedback. Purchases or reward actions require server confirmation; the UI must not display success merely because the user clicked. Avoid double submission and stale state.

## Accessibility and clarity
Use readable contrast, consistent naming, clear icon labels, non-color-only status cues, predictable navigation and concise copy. Prefer plain-language instructions. Support reduced visual clutter where feasible. Do not use flashing or intense effects as the only signal.

## References
Read `docs/UI_UX_AND_ACCESSIBILITY.md`, `docs/REMOTE_CONTRACTS.md`, `docs/CORE_LOOP_AND_PROGRESSION.md`, and `docs/TEST_STRATEGY.md`.
## V3 UI delivery protocol

For each screen, define purpose, entry/exit, priority, keyboard/controller/touch navigation, focus order, loading/empty/error states, safe-area behavior, and responsive layout rules. Separate view state from authoritative game state. A client UI may request an action but must wait for the server's accepted result before presenting a consequential success state.

Build reusable visual tokens for spacing, typography, color, corner/radius, motion, and semantic states. Keep text concise and localizable. Do not rely on color alone; provide readable contrast, clear focus/selection states, and reduced-motion alternatives where appropriate.

Test common aspect ratios, small screens, touch controls, controller navigation, keyboard focus, text scaling where applicable, and overlays such as chat/system UI. Confirm that every visible control works or is clearly disabled with an explanation.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
