---
name: roblox-regression-engineering
description: Create regression suites, fixtures, runtime scenarios, failure-path tests, and evidence. Use for regression strategy.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V7_REGRESSION_AND_TEST_EVIDENCE.md`.

# Regression Test Engineering — V7

## Mission
Prevent previously working player behavior from silently breaking as systems evolve.

## Suite design
Organize tests by pure logic, module contracts, service integration, Studio runtime, client/server, multi-client, device/network, and release smoke tests. Keep stable fast checks separate from expensive environment-dependent tests.

## Test quality
- Assert externally meaningful behavior, not private implementation details.
- Use deterministic fixtures and isolated test data.
- Cover success, boundary, invalid input, concurrency, timeout, disconnect, retry, and cleanup paths.
- Avoid relying on real production services or mutable player data.
- Make tests independent and repeatable; clean up all resources.

## Regression mapping
Every important requirement maps to one or more tests. Every failed test links to a reproducible issue. Flaky tests are quarantined with an owner and repair deadline, not silently ignored.

## Evidence
Record build identifier, tool versions, test environment, command/entrypoint, expected/actual behavior, status, logs, and artifact path. Distinguish tests authored from tests executed.

Read `docs/V7_REGRESSION_AND_TEST_EVIDENCE.md` and `templates/V7_REGRESSION_PLAN_TEMPLATE.md`.
