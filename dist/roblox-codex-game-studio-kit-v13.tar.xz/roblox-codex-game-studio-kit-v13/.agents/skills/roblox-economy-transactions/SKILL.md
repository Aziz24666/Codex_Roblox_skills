---
name: roblox-economy-transactions
description: Design transparent Roblox game economies and server-side transaction fulfillment, including idempotent purchase receipts and recovery.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Economy and Transactions

Use for currency, rewards, shops, developer-product receipts, purchase fulfillment, inventory, and economic integrity.

## Required workflow

1. Define each currency/item source, sink, owner, cap, price, eligibility, and reason code.
2. Keep prices, balances, grants, and purchase fulfillment server-owned.
3. Model each transaction with a unique ID, product, player, state, and result.
4. Make grants idempotent and persist fulfillment evidence safely.
5. Verify the current MarketplaceService receipt API before coding; do not mix handler styles without a migration plan.
6. Handle missing player, data failure, unknown product, duplicate/concurrent callback, and server shutdown.
7. Disclose costs and benefits; avoid gambling, fake scarcity, deceptive urgency, or misleading prompts.
8. Use isolated test products/data. Do not spend Robux or publish without explicit approval.

## Required outputs

- Feature brief, assumptions, and non-goals.
- Client/server/shared/persistent ownership map.
- Player-observable acceptance criteria.
- Negative-case and regression test matrix.
- Handoff with files, evidence, blockers, and untested items.

## Mandatory constraints

- Use Luau and current Roblox APIs; verify unfamiliar signatures in official Creator Hub docs.
- Prefer `--!strict` for new modules.
- Keep consequential state and authorization on the server. Treat client input as untrusted.
- Design for accessibility, privacy, fairness, and age-appropriate play.
- No gambling, manipulative purchase flows, harassment tooling, or unlicensed/copyrighted content.
- Ask before publishing, public uploads, spending Robux, permission changes, or production-data operations.
- Static checks are not Studio runtime verification.

## Read when relevant

- `docs/V5_ECONOMY_AND_TRANSACTION_INTEGRITY.md`
- `docs/ECONOMY_AND_REWARDS.md`
- `docs/PERSISTENCE.md`
- `docs/MONETIZATION_AND_PLAYER_TRUST.md`
