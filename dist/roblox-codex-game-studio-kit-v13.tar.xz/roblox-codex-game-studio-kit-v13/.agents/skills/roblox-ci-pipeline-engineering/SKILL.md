---
name: roblox-ci-pipeline-engineering
description: Design pull-request and main-branch quality workflows. Use when adding or changing CI.
---

# Roblox Ci Pipeline Engineering

Use this skill only for its named workflow. Follow the global rules in `AGENTS.md`; perform fresh research for platform/tool claims.

## Mandatory current-source research gate
Before substantive implementation, research current official Roblox Creator Hub/API references and relevant upstream tool documentation. Record exact URLs, access date, claims, alternatives, decision, and verification plan in `research/decisions/`. If a critical claim cannot be verified, mark it `BLOCKED — RESEARCH NOT VERIFIED`.

## Focused reference
- `docs/V13_AUTOMATED_QUALITY_PIPELINE.md`
- `INDEX_V13.md` for routing.
