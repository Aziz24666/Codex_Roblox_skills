---
name: roblox-gameplay-systems
description: Design and implement Roblox gameplay mechanics, objectives, rounds, interactions, collectibles, upgrades, movement challenges, crafting.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Gameplay Systems

Build gameplay that is legible, responsive and consistent. Keep the player experience and authoritative state aligned.

## Feature procedure
1. State the player goal and why the mechanic supports the core loop.
2. Define states, transitions, triggers, cooldowns, constraints, failure behavior and reset behavior.
3. Define the owning service/module and the server/client split.
4. Define interaction affordances and feedback before implementation.
5. Implement a small prototype with graybox visuals.
6. Validate edge cases: simultaneous inputs, repeated triggers, character death, reset, late join, leaving mid-action and invalid state.
7. Tune timing and values through documented configuration rather than scattered literals.
8. Add tests and acceptance criteria; playtest the loop in Studio.

## State-machine discipline
Use explicit states when behavior has modes (for example, lobby, active, completed, cooldown). Document valid transitions. Reject invalid transitions on the server. Ensure only one authority advances global state. Avoid boolean combinations that allow impossible states.

## Feedback discipline
Provide immediate, readable feedback for success, failure, progress and disabled actions. Pair sound, animation, world feedback and UI intentionally; avoid redundant effects or sensory overload. Keep core information visible on small screens.

## Balancing discipline
Use a configuration table with units and meaningful names. Record assumptions and the target experience. Change one major variable at a time during tuning. Do not claim balance from intuition alone; use playtest observations and, where appropriate, aggregated telemetry.

## Security
Every interaction that changes rewards, inventory, ownership, score, progression or match outcome must be validated by the server. A proximity prompt or client-side cooldown is not proof of legitimacy.

## References
Read `docs/CORE_LOOP_AND_PROGRESSION.md`, `docs/MODULE_CONTRACTS.md`, `docs/SERVER_AUTHORITY.md`, and `docs/TEST_STRATEGY.md`.
## V3 feature implementation protocol

For each mechanic, specify: player goal, entry point, controls, server-owned state, client feedback, valid transitions, cancellation, cooldown, edge cases, and completion condition.

1. Write a state diagram before adding multiple interacting states.
2. Define a typed public API and the single owner of each piece of state.
3. Separate input capture, intent request, authoritative rules, state mutation, and presentation.
4. Define deterministic outcomes for simultaneous requests and race conditions.
5. Add interruption handling for death, respawn, leaving, round end, UI closure, and character replacement.
6. Add telemetry only where it answers a defined product question and does not collect unnecessary personal data.
7. Verify the full player flow, negative paths, server/client disagreement, and repeat activation.

Do not ship a button that only changes its own visual state while the underlying system is absent. Mark prototypes as prototypes and keep them out of release scope.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
