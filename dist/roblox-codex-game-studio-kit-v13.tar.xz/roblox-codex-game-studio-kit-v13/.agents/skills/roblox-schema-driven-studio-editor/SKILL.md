---
name: roblox-schema-driven-studio-editor
description: Design extensible Roblox Studio editors whose panels and forms are generated from declarative content schemas.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Schema-Driven Studio Editor

Use when a game needs repeatable authoring workflows for many content variants. Read `docs/V9_SCHEMA_DRIVEN_EDITOR_ARCHITECTURE.md`, `docs/V9_SCHEMA_CATALOG_CONTRACT.md`, and `docs/V9_EXTENSION_GUIDE.md`.

- Define families and fields as data; do not hand-code a new form per family.
- Keep schema, UI, validation, preview, template resolution, generator, and runtime separate.
- Use a small allowlisted field-control registry.
- Make preview read-only and generation explicit.
- Check source selection, output collision, final hierarchy, provenance, and undo transaction.
- Do not claim asset references work based on string syntax alone.
- Demonstrate two definitions through the same generated form and family handler.
