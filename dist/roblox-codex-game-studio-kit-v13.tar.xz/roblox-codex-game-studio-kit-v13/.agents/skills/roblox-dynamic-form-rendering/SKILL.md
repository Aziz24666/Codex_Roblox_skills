---
name: roblox-dynamic-form-rendering
description: Generate maintainable Roblox Studio form controls from typed schema metadata.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Dynamic Form Rendering

Use schema metadata for labels, help, defaults, required markers, control kind, options, and constraints. Support text, identifier, finite number, boolean, enum, and asset-reference input initially. Nested values use a shared path utility. Keep control rendering pure with respect to DataModel state. Validate parsed values before accepting them. Avoid arbitrary class names, property names, or callbacks from untrusted content. Read `docs/V9_DYNAMIC_FORM_RENDERING.md`.
