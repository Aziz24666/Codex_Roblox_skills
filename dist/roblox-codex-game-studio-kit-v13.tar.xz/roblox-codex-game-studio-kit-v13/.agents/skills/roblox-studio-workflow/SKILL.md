---
name: roblox-studio-workflow
description: Choose and operate the project’s actual Roblox Studio workflow: Studio-native editing, Rojo sync/build, Script Sync, plugins, available MCP.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Studio Workflow and Tooling

You own the boundary between Codex's file environment and Roblox Studio. Never assume an integration exists because a document mentions it.

## 1. Discover the actual workflow
- Inspect project manifests, Rojo mappings, toolchain lock/config files, Studio plugins, Script Sync setup, CI, and repository conventions.
- Classify the project as Studio-native, Rojo-managed, Script Sync, mixed, or unknown.
- Detect installed command-line tools by running safe version/help checks. Record the exact executable path and version when available.
- Inspect available connected tools/integrations. Only use capabilities that are actually exposed in the current session.
- If the workflow is unknown, preserve the current project and request no migration by default.

## 2. Select the least disruptive workflow
- Studio-native: edit only files that are intentionally source-controlled; guide the user through Studio-only edits when file access is unavailable.
- Rojo: inspect `default.project.json`, source paths, sourcemap/build commands, and the project's pinned tool versions before editing.
- Script Sync or mixed: identify authoritative ownership per script/folder. Never create competing copies of a script in two sources of truth.
- Studio plugin/MCP: inspect tool descriptions and permissions. Use only supported operations, report limitations, and confirm before destructive Studio actions.

## 3. Safe synchronization
1. Check Git status and save a baseline.
2. Verify mappings and target DataModel paths.
3. Edit one small slice.
4. Run the project's pinned validation/build command if available.
5. Sync or open in Studio only through a real available mechanism.
6. Inspect Studio Output and Explorer, then test the affected behavior.
7. Confirm that Studio-authored changes have not been overwritten.

## 4. Capability truth table
For every task, separate: `file-editable`, `CLI-verifiable`, `Studio-verifiable`, `multi-client-verifiable`, `publishable`. A capability is true only when the relevant tool exists and actually succeeded. Do not claim visual editor manipulation, runtime testing, uploads, or publishing from file edits alone.

## 5. Required deliverable
Record workflow classification, available tool versions, commands used, mapping risks, Studio-only steps, actual sync/build status, and the next manual action if needed. Read `docs/STUDIO_WORKFLOW_AND_TOOLING.md` and `docs/API_AND_DEPENDENCY_VERIFICATION.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.


## V5 verification truth
Use `docs/V5_TEST_AUTOMATION_STRATEGY.md`. A mapping check is not a Rojo build, and a Rojo build is not a Studio runtime test. Record tool version, test mode, client count, device/network configuration, and actual results.


## V6 scripted Studio test capabilities
Creator Hub documents Studio-only services for programmatic multiplayer simulation, device simulation, and virtual input. Their availability and signatures are version-sensitive. Discover and verify them before use; never put Studio-only testing APIs into published gameplay code. Read `docs/V6_STUDIO_AUTOMATION_AND_TEST_SERVICE.md` and use `$roblox-studio-test-automation`.
