---
name: roblox-content-loading-optimization
description: Improve join time and asset loading using measured content dependencies and streaming-aware design.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Measure cold and warm join/load scenarios separately.
- Inventory required-at-spawn versus optional/later content.
- Defer nonessential presentation/content when player experience permits.
- Validate references, failed loads, fallback behavior, and device memory impact.
- Evaluate instance streaming for large Workspace content using current docs.

Read `docs/V12_CONTENT_LOAD_AND_MEMORY.md`.
