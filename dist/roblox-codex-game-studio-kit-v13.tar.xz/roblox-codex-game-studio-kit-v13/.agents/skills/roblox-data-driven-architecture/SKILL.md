---
name: roblox-data-driven-architecture
description: Design configuration-first Roblox systems where shared behavior is driven by validated definitions and per-instance runtime state.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Data-Driven Architecture

Use when multiple entities share behavior but differ by values, assets, states, or feature flags.

## Required model
Separate four layers:
1. **Definitions**: versioned, validated, mostly immutable data keyed by stable IDs.
2. **Shared systems**: reusable behavior modules with typed public contracts.
3. **Instance state**: mutable state owned by one runtime instance; never stored in a shared definition.
4. **Adapters/editors**: Studio tooling and thin runtime adapters that create or connect configured instances.

## Procedure
1. Inventory duplicated scripts and identify behavior that is genuinely common.
2. Group differences into data fields; keep true behavioral differences behind named strategies/components.
3. Design a versioned schema, defaults, bounds, asset-reference rules, and migration policy.
4. Build one shared runtime and one registry/resolver.
5. Attach behavior through tags/attributes or explicit composition; avoid copying scripts into every model.
6. Keep configuration read-only at runtime; deep-copy only mutable per-instance defaults.
7. Add authoring, validation, diagnostics, and tests before scaling content.
8. Verify one basic, one heavily configured, one malformed, and many simultaneous instances.

## Boundaries
Do not turn every property into data. Keep algorithms in code, tunable differences in data, and exceptional mechanics in explicit modules. Avoid one giant generic framework or stringly typed magic keys.

## References
Read `docs/V8_DATA_DRIVEN_ARCHITECTURE.md`, `docs/V8_MODULE_BOUNDARIES_AND_COMPOSITION.md`, `docs/V8_CONFIG_SCHEMA_AND_VALIDATION.md`, and `docs/V8_MAINTAINABILITY_RULES.md`.

## V12 streaming-aware definitions
Use `docs/V12_STREAMING_AWARE_COMPONENTS.md`. Keep definitions independent of transient Workspace instances; resolve streamed references at the point of use and tolerate stream-out/re-entry.
