---
name: roblox-prefab-governance
description: Govern template versions, generated prefab metadata, asset references, diffs, and safe regeneration.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md`.

# Prefab Governance

- Give each template a stable ID and version.
- Mark generated prefabs with definition ID, schema version, template ID/version, and generator version.
- Never overwrite hand-edited output silently; detect drift and offer diff/replace/skip.
- Keep authored overrides separate from generated baseline values.
- Validate hierarchy and required descendants after generation.
- Record generation reports and content provenance.

Read `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md` and `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md`.
