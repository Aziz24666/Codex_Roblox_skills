---
name: roblox-generated-content-diff
description: Detect drift between generated prefabs and their template/definition baseline before updates.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Generated Content Diff

Separate generated base fields from hand-authored overrides. Record definition/template/generator versions. Compare stable hierarchy and managed properties. Detect missing, added, changed, and user-owned descendants. Default to skip/side-by-side; never overwrite hand edits. Read `docs/V9_GENERATED_CONTENT_GOVERNANCE.md`.
