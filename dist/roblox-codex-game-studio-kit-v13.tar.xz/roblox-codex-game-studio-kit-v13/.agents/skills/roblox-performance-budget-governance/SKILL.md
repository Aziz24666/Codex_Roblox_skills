---
name: roblox-performance-budget-governance
description: Define measurable per-project performance targets and enforce evidence-based regression budgets.
---

## Mandatory current-source research gate
Before substantive implementation, perform fresh online research. Open the current official Roblox Creator Hub/API references, check relevant platform updates/deprecations/permissions, and consult upstream tool docs where applicable. Compare viable approaches when the decision is consequential. Record exact URLs, access date, claims, alternatives, decision, and test plan in `research/decisions/`. If current research is unavailable, mark the affected work `BLOCKED — RESEARCH NOT VERIFIED`; never invent sources. See `docs/V10_RESEARCH_FIRST_STANDARD.md` and `docs/V12_RESEARCH_SNAPSHOT.md`.

## Workflow
- Define device tiers and player scenarios; budgets are project targets, not platform guarantees.
- Store metric name, unit, limit, source, environment, and review date in versioned data.
- Use `tools/v12_perf_budget_check.py` to compare structured captures with budgets.
- Reject missing metrics and incomparable test environments.
- Change budgets only with evidence and an explicit rationale.

Read `docs/V12_PERFORMANCE_BUDGETS.md` and `schemas/v12-performance-baseline.schema.json`.
