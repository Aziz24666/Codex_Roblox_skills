---
name: roblox-studio-mcp-integration
description: Roblox Studio MCP Integration.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Studio MCP Integration

Discover whether the official built-in Roblox Studio MCP server is enabled and connected to the active Codex client. Re-read the current Creator Hub MCP instructions before configuration. Enumerate connected Studio sessions and target the correct studio/place explicitly. Use MCP for DataModel inspection, script edits, Luau execution, asset authoring, and playtests only when those tools are actually exposed. Treat all write-capable actions as high-impact: inspect first, use narrow edits, verify after, keep source-control diffs, and ask before destructive, publishing, credential, production-data, or permission operations. If MCP is unavailable, use the known source-of-truth workflow and report that Studio runtime actions are unavailable.
