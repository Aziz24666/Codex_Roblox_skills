---
name: roblox-data-progression
description: Implement Roblox player profiles, DataStore persistence, inventory, currency, achievements, quests, upgrades, rewards, progression and fair.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Data and Progression

Treat saved player data as a long-lived contract. Design for failed requests, retries, old schemas, concurrent sessions and player departure.

## Data workflow
1. Identify data that truly needs persistence versus session-only state.
2. Define a versioned schema with defaults, allowed ranges and ownership.
3. Establish one server-side profile/data owner; avoid many systems independently writing overlapping profile fields.
4. Design load, validation, migration, save, retry, shutdown and player-removal behavior.
5. Use update-safe operations appropriate to the chosen data model. Verify current DataStore limits and API signatures from Creator Hub.
6. Handle partial failures without inventing success or overwriting good data with defaults.
7. Test against a separate test experience/configuration; do not use production data for experiments.
8. Add migration tests for current and previous schema versions.

## Progression rules
- Make rewards, costs and unlock requirements deterministic and explainable.
- Keep server authority over balances, inventory and ownership.
- Use integer/fixed-point representation where fractional rounding would create inconsistencies; document units.
- Prevent duplicate reward grants with idempotent transaction identifiers or state transitions where appropriate.
- Never trust client-reported price, reward amount, ownership or completion.
- Keep purchase UI honest: pending is not success; success requires a verified server/platform result.

## Player fairness
Avoid gambling-like mechanics, paid random outcomes, misleading scarcity, manipulative pressure, or systems designed to punish breaks. Make progression understandable and avoid confusing monetization.

## References
Read `docs/PERSISTENCE.md`, `docs/DATA_MIGRATIONS.md`, `docs/ECONOMY_AND_REWARDS.md`, `docs/SERVER_AUTHORITY.md`, and `docs/TEST_STRATEGY.md`.
## V3 execution contract

### Profile lifecycle
Model explicit states such as `Loading`, `Ready`, `Saving`, `Closing`, and `Unavailable`. Do not allow reward, purchase, inventory, or progression mutations before a profile is ready. Define what the player sees when data cannot load; never silently create a fresh profile over an unknown existing profile.

### Data workflow
1. Define a typed, versioned schema with defaults and validation.
2. Define key naming, request budgeting, save cadence, retries, lock ownership, shutdown behavior, and recovery procedures.
3. Choose DataStoreService for durable records and MemoryStoreService only for temporary cross-server coordination or short-lived state.
4. Serialize plain supported data only. Enforce size, key, numeric, UTF-8, and table-shape limits.
5. Make rewards and purchase grants idempotent. A repeated request must not duplicate value.
6. Test interrupted writes, concurrent servers, duplicate receipts, profile load failure, and schema migration.

### Economy controls
The server calculates balances, prices, rewards, inventory ownership, and transaction outcomes. Clients may display a proposed action but cannot authoritatively set a price, balance, item count, or reward. Keep economy tuning in documented configuration and provide sinks/sources analysis before changing it.

### Release gate
Test against isolated test data. Never enable Studio API access against production records for routine testing. Require a migration plan, compatibility check, and rollback/restore strategy for schema changes.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.


## V5 integrity rules
Use `docs/V5_ECONOMY_AND_TRANSACTION_INTEGRITY.md` for grants and `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md` for schemas. Treat duplicate callbacks and uncertain writes as normal failure cases. Keep durable data in DataStores and temporary coordination in MemoryStores.
