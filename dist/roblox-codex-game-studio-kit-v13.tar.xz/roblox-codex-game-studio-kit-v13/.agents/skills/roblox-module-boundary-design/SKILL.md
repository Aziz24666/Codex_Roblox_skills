---
name: roblox-module-boundary-design
description: Design clear Luau module boundaries, one-way dependencies, public contracts, and extension points.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Module Boundary Design

Use during architecture, refactoring, and code review.

Each module must document purpose, owner, execution side, dependencies, public API, lifecycle, error behavior, and test seam.

- Prefer cohesive modules with one reason to change.
- Use one-way dependency flow; avoid cyclic `require` graphs.
- Keep pure calculations separate from engine-facing adapters.
- Inject collaborators for complex or stateful systems; avoid hidden global service locators.
- Expose narrow interfaces rather than mutable implementation tables.
- Avoid both micro-module fragmentation and giant manager modules.

Read `docs/V8_MODULE_BOUNDARIES_AND_COMPOSITION.md` and `docs/V8_MAINTAINABILITY_RULES.md`.
