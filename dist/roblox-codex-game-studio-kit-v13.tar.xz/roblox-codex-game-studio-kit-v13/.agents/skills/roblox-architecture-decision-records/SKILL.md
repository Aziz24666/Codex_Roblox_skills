---
name: roblox-architecture-decision-records
description: Roblox Architecture Decision Records.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Architecture Decision Records

Create a concise decision record for meaningful architecture, data, plugin, toolchain, networking, persistence, editor, and performance choices. Include problem, constraints, sources, options, trade-offs, chosen option, consequences, migration/rollback, implementation scope, tests, date, and recheck triggers. Keep one decision per record. Supersede old decisions rather than silently editing history.
