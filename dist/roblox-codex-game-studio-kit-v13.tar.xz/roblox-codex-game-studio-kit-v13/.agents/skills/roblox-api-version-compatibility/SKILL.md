---
name: roblox-api-version-compatibility
description: Roblox API Version Compatibility.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox API Version Compatibility

Before using or upgrading an API/tool: inspect official docs, release notes, API status, security context, rollout state, known limitations, and relevant platform support. Record minimum tested Studio version where available. Avoid beta APIs unless the task needs them and the owner accepts rollout risk. Add an isolated compatibility test for uncertain members. Re-run the compatibility check before release and after relevant Studio updates.
