---
name: roblox-system-architecture
description: Design maintainable Roblox systems: service ownership, DataModel placement, module boundaries, dependency direction, lifecycle, interfaces.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox System Architecture

Design only as much architecture as the current game needs. Favor clear ownership and easy change over speculative frameworks.

## Architecture sequence
1. Identify player-visible features and runtime actors.
2. Partition domains (round/session, interaction, inventory, progression, NPCs, UI, world, social, settings) only where the project needs them.
3. Assign authoritative ownership: server, client presentation, shared pure logic/configuration, or external Roblox service.
4. Map each domain to DataModel locations and module responsibilities.
5. Define public interfaces, events, data schemas, errors, and lifecycle owners.
6. Draw dependency direction. Avoid cycles and hidden service locators.
7. Identify persistence boundaries, remote boundaries, streaming boundaries, and cleanup boundaries.
8. Record decisions with alternatives and migration cost.

## Required architecture artifacts
- DataModel map showing runtime side and replication visibility.
- Service/module responsibility table.
- Dependency diagram or concise text graph.
- Remote contract table.
- Data schema/version map.
- Lifecycle table for create/start/stop/cleanup.
- Decision records for consequential choices.

## Rules
- Server owns consequential game state.
- Shared modules must not accidentally contain secrets or server-only authority.
- Modules should expose narrow APIs, not mutable internal tables.
- Use composition for feature variation; avoid inheritance-like metatable forests.
- Prefer deterministic pure functions for calculations and transformations.
- Do not place every system in a generic `Manager` or `Utils` bucket.
- Introduce abstractions only after at least two real use cases or a clearly measured need.

## Validation
Trace a representative player action from input to server validation to state mutation to replication/UI feedback. Confirm there is one owner for each state transition and a defined failure path. Read `docs/SYSTEM_ARCHITECTURE_PLAYBOOK.md` and `docs/FEATURE_VERTICAL_SLICE_PLAYBOOK.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.
