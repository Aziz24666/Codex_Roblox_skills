---
name: roblox-luau-engineering
description: Design, write, review, debug and refactor professional Roblox Luau code.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Luau Engineering

Write code that is understandable, typed where practical, modular, lifecycle-safe and aligned with actual Roblox APIs.

## Before coding
- Inspect neighboring scripts and project conventions.
- Confirm the file's intended DataModel location and execution context.
- Identify consumers, public interfaces, lifecycle owner, failure modes and test seam.
- Verify uncertain or version-sensitive APIs against the current Creator Hub reference.

## Implementation procedure
1. Write the module's single responsibility and public contract.
2. Define types for configuration, state and public methods. Use `--!strict` where practical.
3. Separate pure calculations from Roblox Instance and service interaction.
4. Use dependency injection or explicit constructors when a module needs collaborators; avoid hidden service locators when they make tests or ownership unclear.
5. Give every connection, task, instance and temporary object a clear owner and cleanup path.
6. Handle `WaitForChild` and asynchronous readiness deliberately. Avoid infinite startup waits without a documented reason.
7. Use bounded loops and event-driven changes. Do not poll continuously when an event or state transition is available.
8. Handle errors at meaningful boundaries; include actionable context without flooding output or exposing secrets.
9. Add tests for deterministic logic and a Studio test plan for engine behavior.
10. Review readability, allocations, dependencies, nilability, concurrency and cleanup.

## Code standards
- Prefer descriptive names and small functions with explicit inputs/outputs.
- Avoid broad `any`, untyped public modules, magic strings/numbers and shared mutable tables.
- Validate external values at the boundary; internal invariants should be explicit.
- Avoid cyclic `require` relationships.
- Do not hide expensive work in module top-level initialization.
- Use Roblox task scheduling APIs intentionally; do not copy deprecated or outdated patterns without checking docs.
- Do not invent API signatures. Verify uncertain APIs.

## Required review
For each modified module, answer: who owns it, who calls it, what can fail, what cleans it up, what runs on client/server, and how it is tested.

## References
Read `docs/LUAU_ENGINEERING.md`, `docs/MODULE_CONTRACTS.md`, `docs/LIFECYCLE_AND_CLEANUP.md`, `docs/ERROR_HANDLING.md`, and any relevant subsystem reference.
## V3 engineering protocol

- Start new modules with `--!strict` where practical. If strict typing is deferred, record the reason and contain the untyped boundary.
- Define exported types for public tables, constructors, callbacks, and result values. Avoid broad `any` and repeated casts that hide uncertain contracts.
- Use dependency injection or explicit service modules for testable logic; do not build a framework to solve a one-module problem.
- Keep module top-level code cheap and deterministic. Avoid yielding, creating world instances, or connecting long-lived events during `require` unless the module's contract explicitly requires it.
- Use `task` APIs rather than legacy `wait`, `spawn`, or `delay`; still bound loops and cancel work on lifecycle end.
- Make cleanup explicit with a single owner for connections, tasks, instances, and temporary state.
- Prefer clear table shapes, early validation, narrow function responsibilities, and descriptive error messages.
- Inspect actual API signatures in current Creator Hub or Studio autocomplete before using unfamiliar or recently changed APIs.

**Review checklist:** types, nilability, module cycles, yield points, memory lifetime, event cleanup, error paths, performance hot paths, and API version assumptions.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.


## V5 system contracts
Use `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md` for ownership/interfaces, `docs/V5_CODE_REVIEW_CHECKLIST.md` for reviews, and `docs/V5_TOOLCHAIN_AND_REPRODUCIBILITY.md` before changing tool versions. Prefer strict Luau for new modules and verify engine APIs against current Creator Hub references.
