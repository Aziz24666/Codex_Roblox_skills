---
name: roblox-accessibility-device
description: Review and implement accessible, readable, responsive Roblox experiences across screen sizes, touch, keyboard, controller, and supported.
---

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Accessibility and Device Compatibility

Accessibility is a design and QA requirement, not a final visual polish task.

## Workflow
1. List target devices, aspect ratios, input methods, and primary play contexts.
2. Define readable text hierarchy, contrast, non-color state indicators, focus order, and safe-area behavior.
3. Ensure essential tasks are possible with the supported input modes.
4. Add clear selection/focus/disabled/error states.
5. Avoid relying only on audio, color, rapid reaction, tiny targets, or precise pointer motion for core information.
6. Offer reduced-motion or less intense presentation when the experience uses strong screen motion or repeated flashes.
7. Keep UI responsive under localization and longer text.
8. Test real device behavior where available; label emulator checks separately.

## Release matrix
Cover small phone portrait, large phone, tablet, desktop, controller/TV where supported, and relevant orientation changes. Test chat/system overlays, safe areas, touch reach, controller focus, and UI scaling. Read `docs/DEVICE_AND_ACCESSIBILITY_MATRIX.md` and `docs/UI_UX_AND_ACCESSIBILITY.md`.


## V4 execution contract

For meaningful changes, use `docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md`. Select the smallest complete player-visible slice, define acceptance criteria and failure paths, and record actual verification status. Apply `docs/V4_AUTOMATION_AND_QUALITY_GATES.md` to avoid overstating checks. When a task is genre-specific, route to the corresponding V4 genre skill and read `docs/V4_GENRE_PRODUCTION_PIPELINES.md`.

## V12 device performance matrix
Use `docs/V12_DEVICE_TIER_TEST_MATRIX.md`; verify device form factor and performance tiers separately from input/accessibility checks.
