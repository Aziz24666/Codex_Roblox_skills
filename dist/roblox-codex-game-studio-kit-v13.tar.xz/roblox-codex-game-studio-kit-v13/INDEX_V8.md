# Roblox Codex Game Studio Kit — V8 Index

V8 focuses on **modular, data-driven, maintainable development**. It preserves V1–V7 and adds a configuration-first architecture, reusable NPC runtime, schema-driven authoring, prefab generation, and human-readable extension practices.

## Start here
1. `AGENTS.md` — V8 operating contract.
2. `README.md` — installation and capabilities.
3. `docs/V8_DATA_DRIVEN_ARCHITECTURE.md` — the core model.
4. `docs/V8_MODULE_BOUNDARIES_AND_COMPOSITION.md` — clean code boundaries.
5. `docs/V8_SHARED_NPC_RUNTIME.md` — one runtime for many NPC definitions.
6. `docs/V8_STUDIO_CONTENT_EDITOR_SPEC.md` — editor design.
7. `docs/V8_CONTENT_FACTORY.md` — data-to-prefab pipeline.
8. `docs/V8_HUMAN_EXTENSION_GUIDE.md` — how the owner extends the project.

## Total skills
The package contains 75 skill folders including the preserved V1–V7 set.

## New skills
- `roblox-data-driven-architecture`
- `roblox-component-system`
- `roblox-data-driven-npc-runtime`
- `roblox-config-schema-engineering`
- `roblox-studio-editor-automation`
- `roblox-content-factory`
- `roblox-plugin-tooling`
- `roblox-module-boundary-design`
- `roblox-maintainable-luau`
- `roblox-config-authoring-validation`
- `roblox-prefab-governance`
- `roblox-human-readable-architecture`

## Core example layouts
- `project-template/src/shared/Config/` — definitions, types, registry, validation.
- `project-template/src/server/Components/` — shared reusable systems.
- `project-template/src/server/Bootstrap/` — tagged-instance registration.
- `examples/v8/` — Luau reference patterns and sample definitions.
- `studio-plugin/` — Studio plugin source and setup notes.
- `schemas/v8-*.schema.json` — machine-readable definition contracts.

## New tools
- `tools/v8_config_lint.py`
- `tools/v8_definition_diff.py`
- `tools/v8_prefab_manifest_lint.py`
- `tools/v8_module_boundary_audit.py`
- `tools/v8_plugin_source_check.py`

## Safe authoring scope
V8 includes an editor/factory example for non-combat utility gadgets, interactive props, cosmetics, and NPC prefabs. It does not include a weapon-specific editor. Generated prefabs are inert content until an approved runtime system consumes their data.

## Progressive disclosure
Do not load all 75 skills for every task. Start with the V7 context routing skill, then add `roblox-data-driven-architecture` and only the relevant specialist skills. Read deep references on demand.
