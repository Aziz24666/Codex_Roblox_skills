# V7 Project Starter Guide

1. Keep the project's existing source-of-truth workflow. Do not convert Studio-native projects to Rojo automatically.
2. Inspect `default.project.json`, `universe.manifest.json`, `src/`, tests, and `TOOLCHAIN.md` before editing.
3. Start from the root `AGENTS.md`; select only relevant `.agents/skills/` using `docs/V7_SKILL_ROUTING_MATRIX.md`.
4. Define one small playable vertical slice and its feature contract.
5. Run static validation and actual Studio checks where available; label blocked runtime checks honestly.
6. Keep secrets and production data out of the repository and test fixtures.

See `README.md`, `docs/V7_END_TO_END_FEATURE_FACTORY.md`, and `docs/V7_DEFINITION_OF_DONE_AND_RELEASE_GATE.md`.
