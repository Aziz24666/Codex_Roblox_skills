# Optional Roblox File-First Starter

This is a minimal Rojo-oriented starter for a new project. It is not a finished game and is not intended to replace an existing Studio-native project.

## Contents
- `default.project.json`: minimal DataModel mapping.
- `src/shared`: shared types/config/constants only; do not place secrets here.
- `src/server`: server bootstrap and server-only systems.
- `src/client`: client bootstrap and presentation systems.

## Use
1. Confirm the project is intended to use a file-first workflow.
2. Install and pin a trusted Rojo/toolchain version using current official instructions.
3. Inspect the project's mapping and preserve Studio-authored content.
4. Build to a local file and inspect it before connecting Studio.
5. Use the Studio Rojo plugin for sync; verify the correct place is open.

Rojo is community-maintained, not Roblox-maintained. Verify version-specific commands and mappings against current Rojo and Creator Hub documentation.
