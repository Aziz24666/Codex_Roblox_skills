# V8 modular project template

This is a reference layout, not an automatic migration. Review and map it to the project's actual Rojo/Studio source of truth.

- `src/shared/Config`: versioned content definitions, types, registry, validation.
- `src/server/Components`: reusable component and behavior modules.
- `src/server/Bootstrap`: one registration point for tagged instances.
- `src/client`: client-only presentation and input adapters as the project grows.

The NPC example is a starting point. It demonstrates separation and extension points but still needs a project-specific follow-target resolver, full pathfinding/obstacle recovery, animation binding, and Studio test suite before production use. The starter scheduler and waypoint route resolver are intentionally minimal examples. The bootstrap filters to live Workspace descendants so prefabs staged in ServerStorage are not activated until placed in the world.
