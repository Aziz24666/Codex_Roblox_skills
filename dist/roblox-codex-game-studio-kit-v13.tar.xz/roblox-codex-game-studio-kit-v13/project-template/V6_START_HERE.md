# V6 Project Starter

1. Read the root `AGENTS.md` and inspect the actual project before editing.
2. Keep the current project source of truth. Do not migrate Studio-native projects to Rojo by default.
3. Use `universe.manifest.json` only as a planning inventory; never guess or fabricate place IDs.
4. Define product requirements, architecture, risk, task graph, acceptance criteria, and test matrix before implementing substantial systems.
5. Start with one vertical slice and a small testable feature.
6. Use the V6 traceability matrix to link requirements to executed evidence.
7. Distinguish static checks, builds, Studio solo tests, multi-client tests, device emulation, network simulation, and physical-device validation.
8. Ask before production publish, live data access/migration, public asset upload, permissions, or destructive changes.

Useful first command (from package/project root):

```bash
python tools/project_doctor.py . --out docs/PROJECT_AUDIT.md
python tools/skill_pack_doctor.py .
python tools/place_manifest_lint.py universe.manifest.json --repo-root .
```

When running from the extracted kit root instead of a copied project-template, use `python tools/place_manifest_lint.py project-template/universe.manifest.json --repo-root project-template`. This template is a starter/reference, not a prebuilt game. Verify the paths against your project layout.
