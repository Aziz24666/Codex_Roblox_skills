# Toolchain record

Record project-pinned tool versions and commands here. The starter does not assume Rojo, Rokit, Wally, Lune, Selene, StyLua, or Studio automation are installed.

| Tool | Version | Pin file | Purpose | Verified date |
|---|---|---|---|---|
