# Client source

Place input, UI presentation, camera, audio/visual feedback, and local prediction here. Treat client state as presentation or a request; the server confirms consequential outcomes.
