--!strict

-- Keep client startup focused on input, UI and presentation. The server remains
-- authoritative for progression, inventory, rewards and shared game outcomes.

print("[Client] Experience bootstrap started")
