# Integration Test Location

Document integration adapters, setup, and teardown. Studio tests need a runbook with build ID, test mode, client count, and actual result. A plan is not a completed test.
