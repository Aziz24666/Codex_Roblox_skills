# Test source

Place pure-logic tests, test fixtures, and documented Studio test scenarios here. Do not point test scripts at production data.
