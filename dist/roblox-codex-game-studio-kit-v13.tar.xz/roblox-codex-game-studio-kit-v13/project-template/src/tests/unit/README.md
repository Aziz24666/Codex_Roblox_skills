# Unit Test Location

Place deterministic rule/state tests here using the framework already pinned by the project. Do not add a new test dependency without evaluation. Keep data isolated; never connect unit tests to production DataStores or purchase flows.
