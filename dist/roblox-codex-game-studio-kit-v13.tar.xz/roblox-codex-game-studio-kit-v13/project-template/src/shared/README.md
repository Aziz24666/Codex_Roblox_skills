# Shared source

Place pure shared types, deterministic calculations, and configuration here. Shared does not mean trusted: anything replicated to clients must be safe for clients to inspect. Never store secrets or server authority here.
