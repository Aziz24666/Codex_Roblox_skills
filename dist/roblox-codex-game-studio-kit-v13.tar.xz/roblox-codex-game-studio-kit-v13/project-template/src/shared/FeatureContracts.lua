--!strict
-- Example shared types/configuration only. Do not place server secrets or authoritative state here.

export type ActionRequest = {
    actionId: string,
    targetId: string?,
}

export type ActionResult = {
    ok: boolean,
    code: string,
}

local FeatureContracts = {}

FeatureContracts.ActionCodes = {
    Accepted = "Accepted",
    InvalidRequest = "InvalidRequest",
    NotReady = "NotReady",
    NotAllowed = "NotAllowed",
    TooManyRequests = "TooManyRequests",
} :: {[string]: string}

return FeatureContracts
