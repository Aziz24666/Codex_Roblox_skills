--!strict

export type Result<T> = {
    ok: boolean,
    value: T?,
    reason: string?,
}

return {}
