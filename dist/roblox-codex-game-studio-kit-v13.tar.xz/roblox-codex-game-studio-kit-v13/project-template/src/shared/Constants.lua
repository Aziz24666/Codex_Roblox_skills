--!strict

local Constants = {
    RemoteFolderName = "Remotes",
}

return table.freeze(Constants)
