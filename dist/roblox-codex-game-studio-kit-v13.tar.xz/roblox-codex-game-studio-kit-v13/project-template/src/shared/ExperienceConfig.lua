--!strict
-- Public configuration only. Never place secrets or authoritative reward values here.

local ExperienceConfig = {
    ExperienceName = "Roblox Experience",
    Version = "0.1.0-dev",
    Debug = false,
}

return table.freeze(ExperienceConfig)
