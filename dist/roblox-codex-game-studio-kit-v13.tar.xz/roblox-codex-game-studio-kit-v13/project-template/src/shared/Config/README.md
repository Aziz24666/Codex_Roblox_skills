# Configuration modules

Keep definitions data-only and immutable. Do not add service calls, event connections, or runtime state here. Add schemas and validation when a definition family grows beyond a tiny local prototype. Runtime systems should resolve stable IDs rather than requiring a copied config script under every entity.
