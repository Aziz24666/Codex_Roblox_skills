--!strict

local VALID_BEHAVIORS: {[string]: boolean} = {
    Wander = true,
    Follow = true,
    Patrol = true,
    Guide = true,
    VendorIdle = true,
}

local Validator = {}

function Validator.Validate(definition: any): (boolean, {string})
    local issues: {string} = {}
    if type(definition) ~= "table" then
        return false, {"Definition must be a table"}
    end
    if definition.schemaVersion ~= 1 then
        table.insert(issues, "Unsupported schemaVersion")
    end
    if type(definition.id) ~= "string" or definition.id == "" then
        table.insert(issues, "id must be a non-empty string")
    end
    if type(definition.displayName) ~= "string" or definition.displayName == "" then
        table.insert(issues, "displayName must be a non-empty string")
    end
    if type(definition.behavior) ~= "string" or VALID_BEHAVIORS[definition.behavior] ~= true then
        table.insert(issues, "behavior is not a supported behavior key")
    end
    local movement = definition.movement
    if type(movement) ~= "table" then
        table.insert(issues, "movement must be a table")
    else
        local bounds = {
            walkSpeed = {0, 24},
            arrivalRadius = {0.5, 30},
            turnResponsiveness = {0, 1},
            repathInterval = {0.5, 15},
            stuckTimeout = {1, 60},
            maxPathRetries = {0, 8},
        }
        for key, range in pairs(bounds) do
            local value = movement[key]
            local isInvalidNumber = type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge
            local isInvalidInteger = key == "maxPathRetries" and type(value) == "number" and value % 1 ~= 0
            if isInvalidNumber or (type(value) == "number" and (value < range[1] or value > range[2])) or isInvalidInteger then
                table.insert(issues, string.format("movement.%s must be a valid number within %s..%s", key, range[1], range[2]))
            end
        end
    end
    return #issues == 0, issues
end

return table.freeze(Validator)
