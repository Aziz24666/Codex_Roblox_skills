--!strict

export type MovementConfig = {
    walkSpeed: number,
    jumpPower: number?,
    arrivalRadius: number,
    turnResponsiveness: number,
    repathInterval: number,
    stuckTimeout: number,
    maxPathRetries: number,
}

export type FollowConfig = {followOffsetX: number, followOffsetZ: number, stopDistance: number}
export type PatrolConfig = {routeId: string, pauseAtWaypointSeconds: number}
export type WanderConfig = {radius: number, chooseDestinationInterval: number}
export type IdleConfig = {}
export type BehaviorConfig = FollowConfig | PatrolConfig | WanderConfig | IdleConfig

export type NPCDefinition = {
    schemaVersion: number,
    id: string,
    displayName: string,
    behavior: "Wander" | "Follow" | "Patrol" | "Guide" | "VendorIdle",
    movement: MovementConfig,
    behaviorConfig: BehaviorConfig,
    presentation: {[string]: string},
}

export type ValidationIssue = {
    code: string,
    path: string,
    message: string,
    severity: "error" | "warning",
}

export type ValidationResult<T> = {
    ok: boolean,
    value: T?,
    issues: {ValidationIssue},
}

return {}
