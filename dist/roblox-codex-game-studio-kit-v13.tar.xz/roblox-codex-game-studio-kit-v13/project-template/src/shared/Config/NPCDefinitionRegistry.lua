--!strict

local Definitions = require(script.Parent.NPCDefinitions)

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Registry = {}

local function deepFreeze(value)
    if type(value) ~= "table" or table.isfrozen(value) then return value end
    for _, child in pairs(value) do deepFreeze(child) end
    return table.freeze(value)
end

function Registry.Get(id: string)
    local definition = Definitions[id]
    if definition ~= nil then
        return definition, nil
    end

    local generatedRoot = ReplicatedStorage:FindFirstChild("V8Definitions")
    local generatedFolder = generatedRoot and generatedRoot:FindFirstChild("NPCs")
    local generatedModule = generatedFolder and generatedFolder:FindFirstChild(id)
    if generatedModule and generatedModule:IsA("ModuleScript") then
        local ok, generatedDefinition = pcall(require, generatedModule)
        if ok and type(generatedDefinition) == "table" then
            return deepFreeze(generatedDefinition), nil
        end
        return nil, string.format("Generated NPC definition '%s' failed to load", id)
    end

    return nil, string.format("Unknown NPC definition '%s'", id)
end

function Registry.GetAll()
    return Definitions
end

return table.freeze(Registry)
