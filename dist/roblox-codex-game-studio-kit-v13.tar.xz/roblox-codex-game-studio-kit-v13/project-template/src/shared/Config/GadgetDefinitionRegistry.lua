--!strict

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Definitions = require(script.Parent.GadgetDefinitions)
local Registry = {}

function Registry.Get(id: string)
    local definition = Definitions[id]
    if definition ~= nil then return definition, nil end
    local root = ReplicatedStorage:FindFirstChild("V8Definitions")
    local folder = root and root:FindFirstChild("Gadgets")
    local module = folder and folder:FindFirstChild(id)
    if module and module:IsA("ModuleScript") then
        local ok, generated = pcall(require, module)
        if ok and type(generated) == "table" then return deepFreeze(generated), nil end
        return nil, string.format("Generated gadget definition '%s' failed to load", id)
    end
    return nil, string.format("Unknown gadget definition '%s'", id)
end

return table.freeze(Registry)
