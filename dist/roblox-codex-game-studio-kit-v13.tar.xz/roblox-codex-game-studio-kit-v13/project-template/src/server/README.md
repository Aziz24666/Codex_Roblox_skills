# Server source

Place server-authoritative orchestration and gameplay rules here. Validate all client-triggered actions and keep persistence, rewards, permissions, and consequential state on the server.
