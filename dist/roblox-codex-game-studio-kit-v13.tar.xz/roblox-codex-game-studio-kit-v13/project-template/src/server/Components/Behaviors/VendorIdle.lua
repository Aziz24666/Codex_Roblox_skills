--!strict
-- Idle/social service point behavior; it does not implement transaction authority.

local VendorIdle = {}

function VendorIdle.Create(context)
    local movement = context.movement
    local destroyed = false
    local controller = {}
    function controller:Step()
        if destroyed then return end
        movement:Stop()
    end
    function controller:Destroy()
        destroyed = true
    end
    return controller
end

return VendorIdle
