--!strict
-- A simple, non-hostile follow policy. The controller passes a validated context.

local Follow = {}

function Follow.Create(context)
    local movement = context.movement
    local config = context.definition.behaviorConfig
    local destroyed = false

    local controller = {}
    function controller:Step()
        if destroyed then return end
        local followTarget = context.getFollowTarget()
        if followTarget == nil then
            movement:Stop()
            return
        end
        local targetRoot = followTarget:FindFirstChild("HumanoidRootPart")
        if targetRoot == nil or not targetRoot:IsA("BasePart") then
            movement:Stop()
            return
        end
        local offset = Vector3.new(config.followOffsetX or 3, 0, config.followOffsetZ or 4)
        local destination = targetRoot.Position + targetRoot.CFrame:VectorToWorldSpace(offset)
        movement:SetDestination(destination)
    end
    function controller:Destroy()
        destroyed = true
    end
    return controller
end

return Follow
