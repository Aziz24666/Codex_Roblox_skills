--!strict
-- Reads a pre-authored waypoint route supplied by the composition root.

local Patrol = {}

function Patrol.Create(context)
    local movement = context.movement
    local resolveRoute = context.routeResolver
    local config = context.definition.behaviorConfig
    local waypoints = resolveRoute(config.routeId)
    local index = 1
    local destroyed = false
    local controller = {}
    function controller:Step()
        if destroyed then return end
        if type(waypoints) ~= "table" or #waypoints == 0 then
            movement:Stop()
            return
        end
        local point = waypoints[index]
        if (context.model:GetPivot().Position - point).Magnitude <= context.definition.movement.arrivalRadius then
            index = (index % #waypoints) + 1
            point = waypoints[index]
        end
        movement:SetDestination(point)
    end
    function controller:Destroy() destroyed = true end
    return controller
end

return Patrol
