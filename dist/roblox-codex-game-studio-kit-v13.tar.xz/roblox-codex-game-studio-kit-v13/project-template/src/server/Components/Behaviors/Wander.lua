--!strict
-- Simple bounded wandering around the NPC's spawn position.

local Wander = {}

function Wander.Create(context)
    local movement = context.movement
    local origin = context.model:GetPivot().Position
    local config = context.definition.behaviorConfig
    local radius = math.clamp(config.radius or 18, 2, 80)
    local interval = math.clamp(config.chooseDestinationInterval or 5, 1, 30)
    local nextChoiceAt = 0
    local destroyed = false
    local controller = {}
    function controller:Step()
        if destroyed then return end
        if os.clock() < nextChoiceAt then return end
        nextChoiceAt = os.clock() + interval
        local angle = math.random() * math.pi * 2
        local distance = math.random() * radius
        local destination = origin + Vector3.new(math.cos(angle) * distance, 0, math.sin(angle) * distance)
        movement:SetDestination(destination)
    end
    function controller:Destroy() destroyed = true end
    return controller
end

return Wander
