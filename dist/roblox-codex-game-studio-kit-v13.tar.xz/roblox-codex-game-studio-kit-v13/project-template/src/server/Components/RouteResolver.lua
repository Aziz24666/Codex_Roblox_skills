--!strict
-- Resolves named waypoint folders under Workspace/NPCRoutes.

local Workspace = game:GetService("Workspace")
local RouteResolver = {}

function RouteResolver.GetRoute(routeId: string): {Vector3}?
    local routeRoot = Workspace:FindFirstChild("NPCRoutes")
    local routeFolder = routeRoot and routeRoot:FindFirstChild(routeId)
    if routeFolder == nil then return nil end
    local points = {}
    for _, child in ipairs(routeFolder:GetChildren()) do
        if child:IsA("BasePart") then
            local index = child:GetAttribute("WaypointIndex")
            if type(index) == "number" then
                table.insert(points, {index = index, position = child.Position})
            end
        end
    end
    table.sort(points, function(a, b) return a.index < b.index end)
    local result = {}
    for _, point in ipairs(points) do table.insert(result, point.position) end
    return result
end

return table.freeze(RouteResolver)
