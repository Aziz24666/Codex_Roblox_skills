--!strict

local MovementController = require(script.Parent.MovementController)
local BehaviorRegistry = require(script.Parent.BehaviorRegistry)

local NPCController = {}
NPCController.__index = NPCController

function NPCController.new(model: Model, definition, dependencies)
    local movement = MovementController.new(model, definition.movement)
    local context = {
        model = model,
        definition = definition,
        movement = movement,
        -- Inject these project-specific resolvers; no hidden global lookup is used.
        getFollowTarget = dependencies and dependencies.getFollowTarget or function() return nil end,
        routeResolver = dependencies and dependencies.routeResolver or function() return nil end,
    }
    local behavior, reason = BehaviorRegistry.Create(definition.behavior, context)
    if behavior == nil then
        movement:Destroy()
        return nil, reason
    end
    local self = setmetatable({
        _model = model,
        _definition = definition,
        _movement = movement,
        _behavior = behavior,
        _destroyed = false,
    }, NPCController)
    return self, nil
end

function NPCController:Step()
    if self._destroyed then return end
    self._behavior:Step()
end

function NPCController:Destroy()
    if self._destroyed then return end
    self._destroyed = true
    self._behavior:Destroy()
    self._movement:Destroy()
end

return NPCController
