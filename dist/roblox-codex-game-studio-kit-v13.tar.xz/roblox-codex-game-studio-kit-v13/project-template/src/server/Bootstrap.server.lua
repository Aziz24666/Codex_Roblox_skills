--!strict

-- Keep bootstrap intentionally small. Compose server systems here once their
-- contracts and lifecycle are defined. Do not perform production data changes
-- or publish operations from bootstrap code.

print("[Server] Experience bootstrap started")
