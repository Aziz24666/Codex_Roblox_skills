# V5 Starter Project

Reference layout only—not a migration target. Do not copy over an existing game. First classify the source of truth as Studio-native, Rojo, Script Sync, or mixed.

1. Review project instructions and toolchain.
2. Adopt only the docs/templates needed.
3. Define one player loop and one vertical slice.
4. Define contracts and schemas before network/persistence work.
5. Treat local utilities as advisory.
6. Open in Studio and run relevant tests.

Suggested folders: `src/client` for presentation/input; `src/server` for authority/persistence adapters; `src/shared` for types/rules/contracts; `src/tests` for tests; `docs` for design/status/evidence. Follow existing conventions where they differ.
