# Runtime Quality Standard (V12)

For every significant release candidate, maintain:
- A current performance baseline for defined scenarios and target device tiers.
- A project-specific budget file with rationale and owners.
- A streaming/lifecycle review for client-side Workspace-dependent code.
- Cleanup ownership for long-lived connections, tasks, Instances, and caches.
- A minimal, privacy-reviewed analytics catalog when custom events are needed.
- Regression evidence for performance-sensitive changes.

The framework's Python tools validate files and structured evidence. They do not create Studio performance captures or prove runtime behavior.
