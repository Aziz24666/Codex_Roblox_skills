# V11 Project Engineering Workflow

## Per-feature cycle
1. Clarify player outcome and acceptance criteria.
2. Inspect only relevant project boundaries and current tests.
3. Research current official Roblox docs and upstream tool docs before technical decisions.
4. Record decision sources, alternatives, and limitations.
5. Map module dependencies and identify the smallest vertical slice.
6. Implement through explicit contracts and data definitions.
7. Run static/unit/integration/Studio checks proportionate to the change.
8. Review generated drift, security boundaries, lifecycle cleanup, and human readability.
9. Update evidence and docs before marking complete.

## Recommended local validation
From the project root, run the V11 kit's skill audit and unit tests when those files have been copied into the project. Use the repo's pinned Luau tools and build workflow; do not install or upgrade tools without reviewing upstream documentation.

## Change ownership
Do not edit generated outputs by hand. Find their canonical schema/template and generator first. Do not migrate the project's source of truth simply to match this template.
