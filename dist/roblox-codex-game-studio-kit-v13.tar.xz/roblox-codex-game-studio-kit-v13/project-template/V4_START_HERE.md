# V4 Starter Project Notes

This is a small Rojo-oriented starter map for learning and scaffolding. It is not a complete game. Before using it, inspect the pinned Rojo version and run the actual Rojo build command. Do not assume the mapping is valid because the bundled JSON parser accepts it.

## Suggested first slice

1. Create one spawn and readable graybox area in Studio.
2. Add one player-facing action with a clear objective.
3. Put shared types/constants in `src/shared`.
4. Put server-owned rules and state in `src/server`.
5. Put input and presentation in `src/client`.
6. Add a deterministic test for the pure logic.
7. Add a Studio test plan for engine-dependent behavior.

## Before expansion

Add system modules only after their owner, interface, lifecycle, and tests are understood. Keep production persistence isolated until the schema and recovery design are reviewed.
