# Code of Conduct

We want participation in this project to be respectful, constructive, and welcoming.

Examples of expected behavior:
- Be respectful and assume good faith.
- Give actionable feedback about code and documentation, not personal attacks.
- Respect privacy; do not post another person's personal information, credentials, or private game data.
- Keep discussions appropriate for a broad developer community.

Harassment, discrimination, threats, doxxing, and deliberate disruption are not acceptable. Maintainers may edit or remove contributions that violate these expectations and may restrict participation when necessary.

For conduct concerns, contact the maintainer privately through the contact method on the GitHub profile.
