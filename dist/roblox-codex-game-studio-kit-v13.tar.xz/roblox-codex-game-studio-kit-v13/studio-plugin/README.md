# V9 Schema Studio Plugin

This is a modular source project for a local Roblox Studio plugin. It is not a signed or published plugin. Source is split into modules for maintainability; do not combine it into a single giant script.

## Modules
- `SchemaCatalog.lua` — family and field metadata (declarative only).
- `FieldPath.lua` — shared nested path access.
- `TemplateResolver.lua` — resolves approved source/template requirements for each family.
- `SchemaValidator.lua` — pure field/schema validation.
- `DynamicFormRenderer.lua` — generated controls.
- `PreviewRenderer.lua` — read-only ViewportFrame preview.
- `DefinitionSerializer.lua` — safe deterministic ModuleScript output.
- `PrefabFactory.lua` — allowlisted family output handlers, provenance, and collision checks.
- `EditorApp.lua` — toolbar, dock widget, draft state, actions, and transaction orchestration.

## Build with Rojo
From this directory:
```bash
rojo build default.project.json -o V9SchemaStudioPlugin.rbxmx
```
The output is a model for local installation. This package does not bundle Rojo.

## Manual assembly
Create a plugin Script named `SchemaStudio` and a child Folder named `Modules`. Add one ModuleScript per file from `src/Modules` with the exact file stem as the ModuleScript name. Copy `src/init.server.lua` to the plugin Script's Source. Keep modules under the Script as required by the `require(script.Parent...)` paths.

## Test checklist
Use a disposable place. Validate each family, preview, generate, inspect output, undo and redo. Test wrong selection, bad values, collision, and generation failure cancellation. Do not install in a production project until the test matrix passes.

## Current starter behavior
- Dynamic schema-generated forms for six content families.
- Number, boolean, enum, text, identifier, and asset ID controls.
- Read-only viewport preview of selected source or a proxy for simple prop families.
- NPC/Companion generation from selected Humanoid Model.
- Cosmetic generation from selected Accessory.
- Simple inert prefab generation for WorldProp, InteractiveProp, and UtilityGadget.
- Definition ModuleScript, generated-content manifest, and prefab provenance attributes/tags.
- Selected source clones are sanitized by removing Script, LocalScript, and ModuleScript descendants; runtime behavior belongs in shared game systems.
- No-overwrite collision checks and ChangeHistoryService transaction.

## Important
Asset ID validation is syntax-only. The source has not been compiled or run in Studio in this environment. Review API compatibility in your Studio version. The sample does not create executable gameplay scripts from field values; a reviewed runtime system must interpret definitions.
