--!strict
local TemplateResolver = require(script.Parent:WaitForChild("TemplateResolver"))
local PreviewRenderer = {}

local function clearWorld(world: WorldModel)
    for _, child in ipairs(world:GetChildren()) do child:Destroy() end
end

local function makeProxy(data: {[string]: any}): Model
    local model = Instance.new("Model")
    model.Name = tostring(data.displayName or data.id or "Preview")
    local part = Instance.new("Part")
    part.Name = "PreviewRoot"
    part.Size = Vector3.new(2, 2, 2)
    part.Anchored = true
    part.CanCollide = false
    part.Color = Color3.fromRGB(86, 139, 190)
    part.Parent = model
    model.PrimaryPart = part
    local visual = data.visual or {}
    local meshId = visual.meshAssetId or ""
    if meshId ~= "" then
        local mesh = Instance.new("SpecialMesh")
        mesh.MeshType = Enum.MeshType.FileMesh
        mesh.MeshId = meshId
        mesh.TextureId = visual.textureAssetId or ""
        local scale = visual.scale or 1
        mesh.Scale = Vector3.new(scale, scale, scale)
        mesh.Parent = part
    end
    return model
end

local function frameCamera(viewport: ViewportFrame, model: Model)
    local camera = viewport.CurrentCamera
    if camera == nil then
        camera = Instance.new("Camera")
        camera.Parent = viewport
        viewport.CurrentCamera = camera
    end
    local boxCFrame, boxSize = model:GetBoundingBox()
    local largest = math.max(boxSize.X, boxSize.Y, boxSize.Z, 2)
    local distance = largest * 2.5
    camera.CFrame = CFrame.lookAt(boxCFrame.Position + Vector3.new(distance, distance * 0.65, distance), boxCFrame.Position)
end

function PreviewRenderer.Render(viewport: ViewportFrame, family: any, data: {[string]: any}, selectedSource: Instance?)
    local world = viewport:FindFirstChildOfClass("WorldModel")
    if world == nil then
        world = Instance.new("WorldModel")
        world.Parent = viewport
    end
    clearWorld(world)
    local previewModel: Model? = nil
    if (family.sourceRequirement == "HumanoidModel" or family.sourceRequirement == "Accessory") and selectedSource ~= nil then
        if selectedSource:IsA("Model") then
            local clone = TemplateResolver.CloneSanitized(selectedSource)
            previewModel = clone :: Model
        elseif selectedSource:IsA("Accessory") then
            previewModel = Instance.new("Model")
            local accessoryClone = TemplateResolver.CloneSanitized(selectedSource)
            local accessory = accessoryClone :: Accessory
            accessory.Parent = previewModel
            local handle = accessory:FindFirstChild("Handle")
            if handle and handle:IsA("BasePart") then
                previewModel.PrimaryPart = handle
            end
        end
    end
    if previewModel == nil then previewModel = makeProxy(data) end
    previewModel.Parent = world
    frameCamera(viewport, previewModel)
end

return PreviewRenderer
