--!strict
-- Resolves and sanitizes approved source selections before preview or generation.
local TemplateResolver = {}

function TemplateResolver.Resolve(family: any, selected: {Instance}): (Instance?, string)
    if family.sourceRequirement == "None" then
        return nil, "No external source required"
    end
    for _, candidate in ipairs(selected) do
        if family.sourceRequirement == "HumanoidModel" and candidate:IsA("Model") then
            if candidate:FindFirstChildOfClass("Humanoid") == nil then
                return nil, "Selected Model must contain a Humanoid"
            end
            if not candidate.Archivable then
                return nil, "Selected Model must have Archivable enabled"
            end
            return candidate, candidate:GetFullName()
        elseif family.sourceRequirement == "Accessory" and candidate:IsA("Accessory") then
            local handle = candidate:FindFirstChild("Handle")
            if handle == nil or not handle:IsA("BasePart") then
                return nil, "Selected Accessory must contain a BasePart named Handle"
            end
            if not candidate.Archivable then
                return nil, "Selected Accessory must have Archivable enabled"
            end
            return candidate, candidate:GetFullName()
        end
    end
    return nil, "Select a compatible source " .. tostring(family.sourceRequirement)
end

function TemplateResolver.CloneSanitized(source: Instance): (Instance, number)
    local clone = source:Clone()
    local removed = 0
    -- Runtime behavior belongs to shared systems, not copied template scripts.
    for _, descendant in ipairs(clone:GetDescendants()) do
        if descendant:IsA("Script") or descendant:IsA("LocalScript") or descendant:IsA("ModuleScript") then
            descendant:Destroy()
            removed += 1
        end
    end
    return clone, removed
end

return TemplateResolver
