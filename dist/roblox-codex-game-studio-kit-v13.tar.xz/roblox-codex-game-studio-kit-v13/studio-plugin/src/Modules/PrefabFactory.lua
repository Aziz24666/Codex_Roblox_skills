--!strict
local CollectionService = game:GetService("CollectionService")
local ServerStorage = game:GetService("ServerStorage")
local Selection = game:GetService("Selection")
local HttpService = game:GetService("HttpService")
local TemplateResolver = require(script.Parent:WaitForChild("TemplateResolver"))
local FieldPath = require(script.Parent:WaitForChild("FieldPath"))
local DefinitionSerializer = require(script.Parent:WaitForChild("DefinitionSerializer"))

local PrefabFactory = {}
PrefabFactory.GeneratorId = "V9SchemaStudioPrefabFactory"
PrefabFactory.GeneratorVersion = "1.0.0"

local function ensureFolder(parent: Instance, name: string): Folder
    local existing = parent:FindFirstChild(name)
    if existing then
        assert(existing:IsA("Folder"), string.format("Expected Folder at %s/%s", parent:GetFullName(), name))
        return existing
    end
    local folder = Instance.new("Folder")
    folder.Name = name
    folder.Parent = parent
    return folder
end

local function createAssetReference(parent: Instance, className: string, name: string, assetId: string)
    if assetId == "" then return end
    local reference = Instance.new(className)
    reference.Name = name
    if className == "Sound" then
        (reference :: Sound).SoundId = assetId
    elseif className == "Animation" then
        (reference :: Animation).AnimationId = assetId
    end
    reference.Parent = parent
end

local function attachPresentation(root: Instance, data: {[string]: any})
    local presentation = Instance.new("Folder")
    presentation.Name = "PresentationReferences"
    presentation.Parent = root
    local audio = data.audio or {}
    local audioFolder = Instance.new("Folder")
    audioFolder.Name = "Audio"
    audioFolder.Parent = presentation
    createAssetReference(audioFolder, "Sound", "Equip", audio.equipSoundAssetId or "")
    createAssetReference(audioFolder, "Sound", "Use", audio.useSoundAssetId or "")
    createAssetReference(audioFolder, "Sound", "Spawn", audio.spawnSoundAssetId or "")
    local useSound = audio.useSoundAssetId or ""
    createAssetReference(audioFolder, "Sound", "Interaction", useSound)

    local animations = Instance.new("Folder")
    animations.Name = "Animations"
    animations.Parent = presentation
    local anims = data.presentation or {}
    createAssetReference(animations, "Animation", "Idle", anims.idleAnimationAssetId or "")
    createAssetReference(animations, "Animation", "Walk", anims.walkAnimationAssetId or "")
    createAssetReference(animations, "Animation", "Follow", anims.followAnimationAssetId or "")
end

local function addMesh(handle: BasePart, visual: {[string]: any})
    local meshId = visual.meshAssetId or ""
    if meshId == "" then return end
    local mesh = Instance.new("SpecialMesh")
    mesh.MeshType = Enum.MeshType.FileMesh
    mesh.MeshId = meshId
    mesh.TextureId = visual.textureAssetId or ""
    local scale = visual.scale or 1
    mesh.Scale = Vector3.new(scale, scale, scale)
    mesh.Parent = handle
end

local function makeWorldObject(family: any, data: {[string]: any}): Instance
    if family.id == "UtilityGadget" then
        local tool = Instance.new("Tool")
        tool.Name = data.displayName
        tool.RequiresHandle = true
        tool.CanBeDropped = false
        local handle = Instance.new("Part")
        handle.Name = "Handle"
        handle.Size = Vector3.new(1, 1, 1) * (data.visual.scale or 1)
        handle.CanCollide = false
        handle.Anchored = false
        addMesh(handle, data.visual or {})
        handle.Parent = tool
        attachPresentation(tool, data)
        return tool
    end

    local model = Instance.new("Model")
    model.Name = data.displayName
    local root = Instance.new("Part")
    root.Name = "Root"
    root.Size = Vector3.new(2, 2, 2) * ((data.visual and data.visual.scale) or 1)
    root.Anchored = true
    root.CanCollide = not (data.world and data.world.nonCollidable == true)
    root.Parent = model
    model.PrimaryPart = root
    addMesh(root, data.visual or {})
    attachPresentation(model, data)
    return model
end

local function validateSource(family: any, selected: {Instance}): Instance?
    local source, message = TemplateResolver.Resolve(family, selected)
    if source == nil and family.sourceRequirement ~= "None" then
        error(message)
    end
    return source
end

local function setMetadata(root: Instance, family: any, data: {[string]: any})
    root:SetAttribute("V9GeneratedContent", true)
    root:SetAttribute("ContentFamily", family.id)
    root:SetAttribute("DefinitionId", data.id)
    root:SetAttribute("DefinitionSchemaVersion", family.schemaVersion)
    root:SetAttribute("TemplateId", family.templateId)
    root:SetAttribute("TemplateVersion", family.templateVersion)
    root:SetAttribute("GeneratorId", PrefabFactory.GeneratorId)
    root:SetAttribute("GeneratorVersion", PrefabFactory.GeneratorVersion)
    CollectionService:AddTag(root, "V9GeneratedContent")
    CollectionService:AddTag(root, "V9Content_" .. family.id)
end

local function findOutputNames(family: any, definitionId: string)
    local base = ensureFolder(ServerStorage, "V9GeneratedContent")
    local prefabs = ensureFolder(base, "Prefabs")
    local familyPrefabs = ensureFolder(prefabs, family.id)
    local definitions = ensureFolder(base, "Definitions")
    local familyDefinitions = ensureFolder(definitions, family.id)
    local prefabName = definitionId .. "_Prefab"
    assert(familyPrefabs:FindFirstChild(prefabName) == nil, "Prefab collision: " .. prefabName .. ". Existing content was not changed.")
    assert(familyDefinitions:FindFirstChild(definitionId) == nil, "Definition collision: " .. definitionId .. ". Existing content was not changed.")
    return familyPrefabs, familyDefinitions, prefabName
end

function PrefabFactory.ValidateSource(family: any, selected: {Instance}): (boolean, string)
    local ok, result = pcall(function() return validateSource(family, selected) end)
    if ok then return true, if result then result:GetFullName() else "No external source required" end
    return false, tostring(result)
end

function PrefabFactory.CanGenerate(family: any, data: {[string]: any}): (boolean, string)
    local base = ServerStorage:FindFirstChild("V9GeneratedContent")
    local prefabs = base and base:FindFirstChild("Prefabs")
    local familyPrefabs = prefabs and prefabs:FindFirstChild(family.id)
    local definitions = base and base:FindFirstChild("Definitions")
    local familyDefinitions = definitions and definitions:FindFirstChild(family.id)
    local prefabCollision = familyPrefabs ~= nil and familyPrefabs:FindFirstChild(data.id .. "_Prefab") ~= nil
    local definitionCollision = familyDefinitions ~= nil and familyDefinitions:FindFirstChild(data.id) ~= nil
    if prefabCollision or definitionCollision then
        return false, "Output collision detected. Existing content will not be overwritten; change the ID or inspect the existing output."
    end
    return true, "No output collision detected."
end

function PrefabFactory.BuildPreviewPlan(family: any, data: {[string]: any}, selected: {Instance}): string
    local sourceOk, sourceMessage = PrefabFactory.ValidateSource(family, selected)
    if not sourceOk then return "Source check failed: " .. sourceMessage end
    local canGenerate, collisionMessage = PrefabFactory.CanGenerate(family, data)
    local prefabRoot = "ServerStorage/V9GeneratedContent/Prefabs/" .. family.id .. "/" .. data.id .. "_Prefab"
    local definitionRoot = "ServerStorage/V9GeneratedContent/Definitions/" .. family.id .. "/" .. data.id
    local unverifiedAssets = 0
    for _, field in ipairs(family.fields) do
        if field.kind == "assetId" then
            local reference = FieldPath.Get(data, field.path) or ""
            if reference ~= "" then unverifiedAssets += 1 end
        end
    end
    return table.concat({
        "READ-ONLY PREVIEW — no DataModel changes",
        "Family: " .. family.label .. " (" .. family.id .. ")",
        "Definition: " .. data.id .. " / schema " .. tostring(family.schemaVersion),
        "Source: " .. sourceMessage,
        "Template: " .. family.templateId .. " v" .. tostring(family.templateVersion),
        "Prefab output: " .. prefabRoot,
        "Definition output: " .. definitionRoot,
        "Output check: " .. collisionMessage,
        "Asset references with syntax only (not verified): " .. tostring(unverifiedAssets),
        "Generator: " .. PrefabFactory.GeneratorId .. " v" .. PrefabFactory.GeneratorVersion,
        "Existing output is never overwritten."
    }, "\n")
end

function PrefabFactory.Generate(family: any, data: {[string]: any}, selected: {Instance}): (Instance, string, string)
    local source = validateSource(family, selected)
    local prefabFolder, definitionFolder, prefabName = findOutputNames(family, data.id)
    local prefab: Instance
    local removedExecutableScripts = 0
    if source ~= nil then
        local clone, removedCount = TemplateResolver.CloneSanitized(source)
        prefab = clone
        removedExecutableScripts = removedCount
        prefab.Name = prefabName
    else
        prefab = makeWorldObject(family, data)
        prefab.Name = prefabName
    end
    setMetadata(prefab, family, data)
    local definitionModule = Instance.new("ModuleScript")
    definitionModule.Name = data.id
    definitionModule.Source = DefinitionSerializer.ToModuleSource(data, family.id, PrefabFactory.GeneratorVersion)

    -- Parent only after all local construction has succeeded; caller wraps these writes in a Studio recording.
    definitionModule.Parent = definitionFolder
    prefab.Parent = prefabFolder
    local verify = prefab:FindFirstChild("Handle", true) or prefab:FindFirstChild("HumanoidRootPart", true) or prefab:FindFirstChild("Root", true)
    if family.outputKind == "WorldProp" or family.outputKind == "InteractiveProp" or family.outputKind == "UtilityGadget" then
        assert(verify ~= nil, "Generated prefab is missing its required root/handle")
    elseif family.sourceRequirement == "HumanoidModel" then
        assert(prefab:IsA("Model") and prefab:FindFirstChildOfClass("Humanoid") ~= nil, "Generated character prefab lost its Humanoid")
    elseif family.sourceRequirement == "Accessory" then
        assert(prefab:IsA("Accessory") and prefab:FindFirstChild("Handle") ~= nil, "Generated cosmetic prefab lost its Handle")
    end

    local assetReferences = {}
    for _, field in ipairs(family.fields) do
        if field.kind == "assetId" then
            local reference = FieldPath.Get(data, field.path) or ""
            table.insert(assetReferences, {
                path = field.path,
                kind = field.assetKind or "Unknown",
                referenceStatus = if reference == "" then "EMPTY_OPTIONAL" else "FORMAT_VALID_UNVERIFIED",
            })
        end
    end
    local manifest = {
        family = family.id,
        definitionId = data.id,
        definitionSchemaVersion = family.schemaVersion,
        templateId = family.templateId,
        templateVersion = family.templateVersion,
        generatorId = PrefabFactory.GeneratorId,
        generatorVersion = PrefabFactory.GeneratorVersion,
        outputPath = prefab:GetFullName(),
        definitionPath = definitionModule:GetFullName(),
        status = "GENERATED",
        removedExecutableScripts = removedExecutableScripts,
        assetReferences = assetReferences,
    }
    local manifestValue = Instance.new("StringValue")
    manifestValue.Name = "V9GenerationManifest"
    manifestValue.Value = HttpService:JSONEncode(manifest)
    manifestValue.Parent = prefab
    Selection:Set({prefab})
    return prefab, prefab:GetFullName(), definitionModule:GetFullName()
end

return PrefabFactory
