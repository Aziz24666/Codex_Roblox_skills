--!strict
local FieldPath = {}

local function split(path: string): {string}
    local parts = {}
    for segment in string.gmatch(path, "[^%.]+") do
        table.insert(parts, segment)
    end
    return parts
end

function FieldPath.Get(root: {[string]: any}, path: string): any
    local current: any = root
    for _, segment in ipairs(split(path)) do
        if type(current) ~= "table" then return nil end
        current = current[segment]
    end
    return current
end

function FieldPath.Set(root: {[string]: any}, path: string, value: any)
    local parts = split(path)
    assert(#parts > 0, "Field path cannot be empty")
    local current = root
    for index = 1, #parts - 1 do
        local segment = parts[index]
        if type(current[segment]) ~= "table" then
            current[segment] = {}
        end
        current = current[segment]
    end
    current[parts[#parts]] = value
end

return FieldPath
