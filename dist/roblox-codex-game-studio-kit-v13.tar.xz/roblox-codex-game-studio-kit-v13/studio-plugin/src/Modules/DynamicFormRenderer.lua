--!strict
local FieldPath = require(script.Parent:WaitForChild("FieldPath"))
local DynamicFormRenderer = {}

local COLORS = {
    panel = Color3.fromRGB(38, 40, 46),
    field = Color3.fromRGB(49, 52, 60),
    text = Color3.fromRGB(232, 235, 240),
    muted = Color3.fromRGB(165, 172, 184),
    accent = Color3.fromRGB(64, 112, 170),
}

local function make(className: string, properties: {[string]: any}, parent: Instance): Instance
    local object = Instance.new(className)
    for key, value in pairs(properties) do
        (object :: any)[key] = value
    end
    object.Parent = parent
    return object
end

local function addCorner(object: Instance)
    make("UICorner", {CornerRadius = UDim.new(0, 5)}, object)
end

local function createLabel(parent: Instance, text: string, height: number, color: Color3?): TextLabel
    return make("TextLabel", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, height),
        Font = Enum.Font.SourceSans,
        Text = text,
        TextColor3 = color or COLORS.text,
        TextSize = 14,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextWrapped = true,
    }, parent) :: TextLabel
end

local function createInput(parent: Instance, text: string, placeholder: string): TextBox
    local input = make("TextBox", {
        BackgroundColor3 = COLORS.field,
        ClearTextOnFocus = false,
        Font = Enum.Font.Code,
        Size = UDim2.new(1, 0, 0, 30),
        Text = text,
        PlaceholderText = placeholder,
        TextColor3 = COLORS.text,
        PlaceholderColor3 = COLORS.muted,
        TextSize = 13,
        TextXAlignment = Enum.TextXAlignment.Left,
    }, parent) :: TextBox
    addCorner(input)
    return input
end

function DynamicFormRenderer.Render(parent: ScrollingFrame, family: any, draft: {[string]: any}, onChanged: (string, any) -> ())
    for _, child in ipairs(parent:GetChildren()) do
        if child ~= parent:FindFirstChildOfClass("UIListLayout") and child:IsA("GuiObject") then
            child:Destroy()
        end
    end
    local layout = parent:FindFirstChildOfClass("UIListLayout")
    if not layout then
        layout = make("UIListLayout", {Padding = UDim.new(0, 9), SortOrder = Enum.SortOrder.LayoutOrder}, parent)
    end
    local currentSection = ""
    for index, field in ipairs(family.fields) do
        if field.section ~= nil and field.section ~= currentSection then
            currentSection = field.section
            local section = createLabel(parent, string.upper(currentSection), 22, COLORS.muted)
            section.LayoutOrder = index * 10 - 1
        end
        local row = make("Frame", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -8, 0, 58),
            LayoutOrder = index * 10,
        }, parent) :: Frame
        local currentValue = FieldPath.Get(draft, field.path)
        local valueText = if currentValue == nil then "" else tostring(currentValue)
        local labelText = field.label .. (field.required and "  *" or "")
        createLabel(row, labelText, 20, COLORS.text)
        if field.kind == "boolean" then
            local toggle = make("TextButton", {
                BackgroundColor3 = COLORS.accent,
                Position = UDim2.fromOffset(0, 23),
                Size = UDim2.new(1, 0, 0, 30),
                Font = Enum.Font.SourceSansSemibold,
                Text = if currentValue == true then "ON" else "OFF",
                TextColor3 = COLORS.text,
                TextSize = 14,
            }, row) :: TextButton
            addCorner(toggle)
            toggle.Activated:Connect(function()
                local nextValue = not (currentValue == true)
                currentValue = nextValue
                toggle.Text = if nextValue then "ON" else "OFF"
                onChanged(field.path, nextValue)
            end)
        elseif field.kind == "enum" then
            local options = field.options or {}
            local enumButton = make("TextButton", {
                BackgroundColor3 = COLORS.field,
                Position = UDim2.fromOffset(0, 23),
                Size = UDim2.new(1, 0, 0, 30),
                Font = Enum.Font.SourceSans,
                Text = valueText .. "   ▾  (click to cycle)",
                TextColor3 = COLORS.text,
                TextSize = 13,
            }, row) :: TextButton
            addCorner(enumButton)
            enumButton.Activated:Connect(function()
                if #options == 0 then return end
                local currentIndex = table.find(options, currentValue) or 0
                local nextIndex = currentIndex % #options + 1
                currentValue = options[nextIndex]
                enumButton.Text = tostring(currentValue) .. "   ▾  (click to cycle)"
                onChanged(field.path, currentValue)
            end)
        else
            local placeholder = if field.kind == "assetId" then "Paste " .. tostring(field.assetKind or "asset") .. " ID or rbxassetid://... (syntax only)" else "Enter " .. field.kind
            local input = createInput(row, valueText, placeholder)
            input.Position = UDim2.fromOffset(0, 23)
            input.FocusLost:Connect(function()
                local nextValue: any = input.Text
                if field.kind == "number" then
                    nextValue = tonumber(input.Text)
                    if nextValue == nil then
                        input.Text = valueText
                        return
                    end
                elseif field.kind == "assetId" and string.match(input.Text, "^%d+$") then
                    nextValue = "rbxassetid://" .. input.Text
                    input.Text = nextValue
                end
                valueText = input.Text
                currentValue = nextValue
                onChanged(field.path, nextValue)
            end)
        end
        if field.help and field.help ~= "" then
            local help = createLabel(row, field.help, 18, COLORS.muted)
            help.Position = UDim2.fromOffset(0, 53)
            help.Size = UDim2.new(1, 0, 0, 18)
        end
    end
    parent.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 8)
    layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        parent.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 8)
    end)
end

return DynamicFormRenderer
