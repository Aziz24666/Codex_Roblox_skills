--!strict
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local Selection = game:GetService("Selection")
local SchemaValidator = require(script.Parent:WaitForChild("SchemaValidator"))
local DynamicFormRenderer = require(script.Parent:WaitForChild("DynamicFormRenderer"))
local PreviewRenderer = require(script.Parent:WaitForChild("PreviewRenderer"))
local PrefabFactory = require(script.Parent:WaitForChild("PrefabFactory"))
local EditorApp = {}
EditorApp.__index = EditorApp

local function make(className: string, properties: {[string]: any}, parent: Instance): Instance
    local object = Instance.new(className)
    for key, value in pairs(properties) do (object :: any)[key] = value end
    object.Parent = parent
    return object
end

local function addCorner(object: Instance)
    make("UICorner", {CornerRadius = UDim.new(0, 6)}, object)
end

local function addButton(parent: Instance, label: string, color: Color3, position: UDim2, size: UDim2): TextButton
    local button = make("TextButton", {
        BackgroundColor3 = color,
        Position = position,
        Size = size,
        Font = Enum.Font.SourceSansSemibold,
        Text = label,
        TextColor3 = Color3.fromRGB(245, 247, 250),
        TextSize = 14,
        AutoButtonColor = true,
    }, parent) :: TextButton
    addCorner(button)
    return button
end

function EditorApp.new(pluginObject: Plugin, catalog: any)
    local self = setmetatable({}, EditorApp)
    self._plugin = pluginObject
    self._catalog = catalog
    self._family = catalog.families[1]
    self._draft = catalog.CreateDefault(self._family.id)
    self._previewIsCurrent = false
    self._previewSource = nil
    self._canGenerate = false
    return self
end

function EditorApp:_setStatus(message: string, isError: boolean?)
    self._status.Text = message
    self._status.TextColor3 = if isError then Color3.fromRGB(255, 150, 135) else Color3.fromRGB(190, 215, 245)
end

function EditorApp:_renderFamilyTabs()
    for _, child in ipairs(self._tabs:GetChildren()) do
        if child:IsA("TextButton") then child:Destroy() end
    end
    local count = #self._catalog.families
    local columns = 3
    for index, family in ipairs(self._catalog.families) do
        local row = math.floor((index - 1) / columns)
        local column = (index - 1) % columns
        local button = addButton(
            self._tabs,
            family.label,
            if family.id == self._family.id then Color3.fromRGB(67, 111, 166) else Color3.fromRGB(53, 57, 65),
            UDim2.new(column / columns, 3, 0, row * 30),
            UDim2.new(1 / columns, -6, 0, 27)
        )
        button.Activated:Connect(function()
            self._family = family
            self._draft = self._catalog.CreateDefault(family.id)
            self._previewIsCurrent = false
            self._previewSource = nil
            self._canGenerate = false
            self:_renderFamilyTabs()
            self:_renderFields()
            self:_setStatus("Loaded defaults for " .. family.label .. ". Select a source object if the family requires one.")
        end)
    end
    self._tabs.Size = UDim2.new(1, 0, 0, math.ceil(count / columns) * 30)
end

function EditorApp:_renderFields()
    DynamicFormRenderer.Render(self._fields, self._family, self._draft, function(path: string, value: any)
        require(script.Parent:WaitForChild("FieldPath")).Set(self._draft, path, value)
        self._previewIsCurrent = false
        self._previewSource = nil
        self._canGenerate = false
        self:_setStatus("Draft changed. Preview is outdated; validate and preview again.")
    end)
end

function EditorApp:_selectedSource(): Instance?
    for _, item in ipairs(Selection:Get()) do
        if item:IsA("Model") or item:IsA("Accessory") then return item end
    end
    return nil
end

function EditorApp:_refreshPreview()
    local issues = SchemaValidator.Validate(self._family, self._draft)
    if #issues > 0 then
        self:_setStatus(table.concat(issues, "\n"), true)
        self._previewIsCurrent = false
        return false
    end
    local selected = Selection:Get()
    local sourceOk, sourceMessage = PrefabFactory.ValidateSource(self._family, selected)
    if not sourceOk then
        self:_setStatus(sourceMessage, true)
        self._previewIsCurrent = false
        return false
    end
    PreviewRenderer.Render(self._viewport, self._family, self._draft, self:_selectedSource())
    self._previewText.Text = PrefabFactory.BuildPreviewPlan(self._family, self._draft, selected)
    self._previewSource = self:_selectedSource()
    self._previewIsCurrent = true
    local canGenerate, collisionMessage = PrefabFactory.CanGenerate(self._family, self._draft)
    self._canGenerate = canGenerate
    if canGenerate then
        self:_setStatus("Preview current. No DataModel changes were made. " .. collisionMessage)
    else
        self:_setStatus("Preview current, but generation is blocked. " .. collisionMessage, true)
    end
    return true
end

function EditorApp:_generate()
    local issues = SchemaValidator.Validate(self._family, self._draft)
    if #issues > 0 then
        self:_setStatus(table.concat(issues, "\n"), true)
        return
    end
    if not self._previewIsCurrent then
        self:_setStatus("Preview is missing or outdated. Run Preview before Generate.", true)
        return
    end
    local selected = Selection:Get()
    if self._previewSource ~= self:_selectedSource() then
        self._previewIsCurrent = false
        self._canGenerate = false
        self:_setStatus("Source selection changed after preview. Preview again before Generate.", true)
        return
    end
    local canGenerate, collisionMessage = PrefabFactory.CanGenerate(self._family, self._draft)
    if not canGenerate or not self._canGenerate then
        self:_setStatus(collisionMessage, true)
        return
    end
    local definitionSnapshot = table.clone(self._draft)
    local recordingId = ChangeHistoryService:TryBeginRecording(
        "V9Generate" .. self._family.id,
        "Generate " .. self._family.label .. " " .. tostring(definitionSnapshot.id)
    )
    if recordingId == nil then
        self:_setStatus("Studio could not start an undo recording. No changes were made. Retry outside playtest and ensure no previous recording is open.", true)
        return
    end
    local ok, prefabOrError, prefabPath, definitionPath = pcall(function()
        return PrefabFactory.Generate(self._family, definitionSnapshot, selected)
    end)
    if ok then
        local finishOk, finishError = pcall(function()
            ChangeHistoryService:FinishRecording(recordingId, Enum.FinishRecordingOperation.Commit)
        end)
        if not finishOk then
            pcall(function()
                ChangeHistoryService:FinishRecording(recordingId, Enum.FinishRecordingOperation.Cancel)
            end)
            self:_setStatus("Prefab generation returned, but finishing the Studio recording failed: " .. tostring(finishError) .. ". Cancellation was attempted; inspect the DataModel before continuing.", true)
            return
        end
        self:_setStatus("Generated successfully.\nPrefab: " .. tostring(prefabPath) .. "\nDefinition: " .. tostring(definitionPath) .. "\nUndo is available in Studio.")
        self._previewIsCurrent = false
        self._previewSource = nil
        self._canGenerate = false
    else
        pcall(function()
            ChangeHistoryService:FinishRecording(recordingId, Enum.FinishRecordingOperation.Cancel)
        end)
        self:_setStatus("Generation failed; Studio recording cancellation was requested.\n" .. tostring(prefabOrError), true)
    end
end

function EditorApp:Mount()
    local toolbar = self._plugin:CreateToolbar("V9 Schema Studio")
    local toolbarButton = toolbar:CreateButton("OpenV9SchemaStudio", "Open schema-generated content editor", "")
    local widgetInfo = DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Right, false, false, 620, 760, 440, 520)
    local widget = self._plugin:CreateDockWidgetPluginGuiAsync("V9SchemaStudioWidget", widgetInfo)
    widget.Title = "V9 Schema Studio"
    self._widget = widget

    local root = make("Frame", {BackgroundColor3 = Color3.fromRGB(33, 36, 42), Size = UDim2.fromScale(1, 1)}, widget)
    make("UIPadding", {PaddingTop = UDim.new(0, 10), PaddingBottom = UDim.new(0, 10), PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 10)}, root)
    make("UIListLayout", {Padding = UDim.new(0, 7), SortOrder = Enum.SortOrder.LayoutOrder}, root)
    make("TextLabel", {BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 28), Font = Enum.Font.SourceSansBold, Text = "Schema-driven content authoring", TextColor3 = Color3.fromRGB(240, 242, 246), TextSize = 18, TextXAlignment = Enum.TextXAlignment.Left, LayoutOrder = 1}, root)
    local tabs = make("Frame", {BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 60), LayoutOrder = 2}, root) :: Frame
    self._tabs = tabs
    local previewFrame = make("Frame", {BackgroundColor3 = Color3.fromRGB(44, 47, 54), Size = UDim2.new(1, 0, 0, 190), LayoutOrder = 3}, root)
    addCorner(previewFrame)
    self._viewport = make("ViewportFrame", {BackgroundColor3 = Color3.fromRGB(28, 31, 36), Position = UDim2.fromOffset(6, 6), Size = UDim2.new(0.48, -9, 1, -12), Ambient = Color3.fromRGB(180, 180, 180), LightColor = Color3.fromRGB(255, 255, 255), LightDirection = Vector3.new(-1, -1, -1)}, previewFrame) :: ViewportFrame
    addCorner(self._viewport)
    self._previewText = make("TextLabel", {BackgroundTransparency = 1, Position = UDim2.new(0.5, 2, 0, 7), Size = UDim2.new(0.5, -10, 1, -14), Font = Enum.Font.Code, Text = "Preview has not been generated.", TextColor3 = Color3.fromRGB(210, 214, 222), TextSize = 11, TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top}, previewFrame) :: TextLabel
    local fieldTitle = make("TextLabel", {BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 22), Font = Enum.Font.SourceSansSemibold, Text = "Definition fields", TextColor3 = Color3.fromRGB(230, 234, 240), TextSize = 15, TextXAlignment = Enum.TextXAlignment.Left, LayoutOrder = 4}, root)
    local fields = make("ScrollingFrame", {BackgroundColor3 = Color3.fromRGB(39, 42, 49), BorderSizePixel = 0, Size = UDim2.new(1, 0, 0, 265), CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, ScrollBarThickness = 8, LayoutOrder = 5}, root) :: ScrollingFrame
    addCorner(fields)
    self._fields = fields
    make("UIPadding", {PaddingTop = UDim.new(0, 8), PaddingBottom = UDim.new(0, 8), PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8)}, fields)
    local buttons = make("Frame", {BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 36), LayoutOrder = 6}, root)
    local validate = addButton(buttons, "Validate", Color3.fromRGB(67, 93, 127), UDim2.new(0, 0, 0, 0), UDim2.new(0.24, -4, 1, 0))
    local preview = addButton(buttons, "Preview", Color3.fromRGB(67, 93, 127), UDim2.new(0.25, 0, 0, 0), UDim2.new(0.24, -4, 1, 0))
    local reset = addButton(buttons, "Reset", Color3.fromRGB(79, 83, 91), UDim2.new(0.5, 0, 0, 0), UDim2.new(0.24, -4, 1, 0))
    local generate = addButton(buttons, "Generate", Color3.fromRGB(54, 119, 83), UDim2.new(0.75, 0, 0, 0), UDim2.new(0.25, 0, 1, 0))
    self._status = make("TextLabel", {BackgroundColor3 = Color3.fromRGB(42, 45, 52), Size = UDim2.new(1, 0, 0, 76), Font = Enum.Font.SourceSans, Text = "Ready. Choose a family, edit its data, validate, preview, then generate.", TextColor3 = Color3.fromRGB(190, 215, 245), TextSize = 13, TextWrapped = true, TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Center, LayoutOrder = 7}, root) :: TextLabel
    addCorner(self._status)

    self:_renderFamilyTabs()
    self:_renderFields()
    validate.Activated:Connect(function()
        local issues = SchemaValidator.Validate(self._family, self._draft)
        if #issues == 0 then self:_setStatus("Validation passed. No DataModel changes were made.") else self:_setStatus(table.concat(issues, "\n"), true) end
    end)
    preview.Activated:Connect(function() self:_refreshPreview() end)
    reset.Activated:Connect(function()
        self._draft = self._catalog.CreateDefault(self._family.id)
        self._previewIsCurrent = false
        self._previewSource = nil
        self._canGenerate = false
        self:_renderFields()
        self:_setStatus("Defaults restored. Preview is outdated.")
    end)
    generate.Activated:Connect(function() self:_generate() end)
    toolbarButton.Click:Connect(function() widget.Enabled = not widget.Enabled end)
    widget:BindToClose(function() self._previewIsCurrent = false end)
end

return EditorApp
