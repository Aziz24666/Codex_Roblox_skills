--!strict
local FieldPath = require(script.Parent:WaitForChild("FieldPath"))
local SchemaValidator = {}

local function isFinite(value: number): boolean
    return value == value and value > -math.huge and value < math.huge
end

local function isIdentifier(value: any): boolean
    return type(value) == "string"
        and #value >= 2 and #value <= 48
        and string.match(value, "^[A-Za-z][A-Za-z0-9_%-]*$") ~= nil
end

local function canonicalAssetId(value: any): boolean
    if value == "" then return true end
    if type(value) ~= "string" then return false end
    return string.match(value, "^rbxassetid://%d+$") ~= nil
        or string.match(value, "^%d+$") ~= nil
end

function SchemaValidator.Validate(family: any, definition: {[string]: any}): {string}
    local issues = {}
    if type(definition) ~= "table" then return {"Definition must be a table"} end
    if definition.schemaVersion ~= family.schemaVersion then
        table.insert(issues, "schemaVersion does not match the selected family")
    end
    if definition.family ~= family.id then
        table.insert(issues, "family does not match selected editor tab")
    end

    for _, field in ipairs(family.fields) do
        local value = FieldPath.Get(definition, field.path)
        local kind = field.kind
        local valid = true
        if value == nil then
            valid = field.required ~= true
        elseif kind == "identifier" then
            valid = isIdentifier(value)
        elseif kind == "text" then
            valid = type(value) == "string"
                and #value <= (field.maxLength or 240)
                and (field.required ~= true or #value > 0)
        elseif kind == "number" then
            valid = type(value) == "number" and isFinite(value)
            if valid and field.min ~= nil then valid = value >= field.min end
            if valid and field.max ~= nil then valid = value <= field.max end
        elseif kind == "boolean" then
            valid = type(value) == "boolean"
        elseif kind == "enum" then
            valid = type(value) == "string" and table.find(field.options or {}, value) ~= nil
        elseif kind == "assetId" then
            valid = canonicalAssetId(value)
        else
            valid = false
        end
        if not valid then
            table.insert(issues, string.format("%s has an invalid value for field kind %s", field.path, kind))
        end
    end

    local definitionId = definition.id
    if not isIdentifier(definitionId) then
        table.insert(issues, "id must be a 2-48 character stable identifier")
    end
    local displayName = definition.displayName
    if type(displayName) ~= "string" or #displayName < 1 or #displayName > 48 then
        table.insert(issues, "displayName must be 1-48 characters")
    end
    return issues
end

function SchemaValidator.NormalizeAssetId(value: string): string
    if value == "" then return "" end
    if string.match(value, "^%d+$") then return "rbxassetid://" .. value end
    return value
end

return SchemaValidator
