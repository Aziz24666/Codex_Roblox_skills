--!strict
-- V9 Schema Studio Plugin entrypoint. This Script must run in Studio plugin context.
local modules = script:WaitForChild("Modules")
local SchemaCatalog = require(modules:WaitForChild("SchemaCatalog"))
local EditorApp = require(modules:WaitForChild("EditorApp"))
local app = EditorApp.new(plugin, SchemaCatalog)
app:Mount()
