# Legacy V8 Plugin Notice

`ContentFactoryPlugin.lua` is retained from V8 for historical comparison. Use the modular `src/` plugin tree for V9 work. Do not install both simultaneously; they write different output roots and expose overlapping authoring concepts.
