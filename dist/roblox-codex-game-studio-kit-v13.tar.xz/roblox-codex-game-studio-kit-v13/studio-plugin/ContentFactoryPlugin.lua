--!strict
-- V8 Content Factory plugin source example.
-- Scope: tagged NPC prefabs and non-combat utility gadgets/interactive props.
-- Install/test in a disposable Studio place before use in a real project.

local ChangeHistoryService = game:GetService("ChangeHistoryService")
local CollectionService = game:GetService("CollectionService")
local HttpService = game:GetService("HttpService")
local Selection = game:GetService("Selection")
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local TOOLBAR = plugin:CreateToolbar("V8 Content Factory")
local OPEN_BUTTON = TOOLBAR:CreateButton("OpenV8Factory", "Open V8 content factory", "")
local WIDGET_INFO = DockWidgetPluginGuiInfo.new(
    Enum.InitialDockState.Right,
    false,
    false,
    460,
    620,
    360,
    420
)
local WIDGET = plugin:CreateDockWidgetPluginGuiAsync("V8ContentFactoryWidget", WIDGET_INFO)
WIDGET.Title = "V8 Content Factory"

local ALLOWED_UTILITY_KINDS = {
    IlluminateArea = true,
    PlaySoundCue = true,
    ShowWaypointMarker = true,
    OpenJournal = true,
    CapturePhoto = true,
    CollectNearbyTokens = true,
}

local function make(className: string, props: {[string]: any}, parent: Instance): Instance
    local object = Instance.new(className)
    for key, value in pairs(props) do
        (object :: any)[key] = value
    end
    object.Parent = parent
    return object
end

local function addCorner(parent: Instance)
    make("UICorner", {CornerRadius = UDim.new(0, 6)}, parent)
end

local function createLabel(parent: Instance, text: string, height: number?): TextLabel
    local label = make("TextLabel", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, height or 28),
        Font = Enum.Font.SourceSans,
        Text = text,
        TextColor3 = Color3.fromRGB(230, 230, 230),
        TextSize = 15,
        TextXAlignment = Enum.TextXAlignment.Left,
    }, parent) :: TextLabel
    return label
end

local function createButton(parent: Instance, text: string): TextButton
    local button = make("TextButton", {
        Size = UDim2.new(1, 0, 0, 34),
        BackgroundColor3 = Color3.fromRGB(54, 104, 160),
        Font = Enum.Font.SourceSansSemibold,
        Text = text,
        TextColor3 = Color3.new(1, 1, 1),
        TextSize = 15,
        AutoButtonColor = true,
    }, parent) :: TextButton
    addCorner(button)
    return button
end

local root = make("Frame", {
    BackgroundColor3 = Color3.fromRGB(35, 38, 44),
    Size = UDim2.fromScale(1, 1),
}, WIDGET) :: Frame
local padding = make("UIPadding", {
    PaddingTop = UDim.new(0, 12), PaddingBottom = UDim.new(0, 12),
    PaddingLeft = UDim.new(0, 12), PaddingRight = UDim.new(0, 12),
}, root)
local layout = make("UIListLayout", {
    Padding = UDim.new(0, 8),
    SortOrder = Enum.SortOrder.LayoutOrder,
}, root)

createLabel(root, "Choose a content family, paste a JSON definition, validate, then generate.", 42)
createLabel(root, "Content type: NPC or Gadget", 22)
local kindBox = make("TextBox", {
    Size = UDim2.new(1, 0, 0, 32),
    BackgroundColor3 = Color3.fromRGB(50, 54, 62),
    ClearTextOnFocus = false,
    Font = Enum.Font.Code,
    Text = "NPC",
    TextColor3 = Color3.new(1, 1, 1),
    TextSize = 14,
}, root) :: TextBox
addCorner(kindBox)
createLabel(root, "Definition JSON", 22)
local jsonBox = make("TextBox", {
    Size = UDim2.new(1, 0, 0, 300),
    BackgroundColor3 = Color3.fromRGB(25, 28, 33),
    ClearTextOnFocus = false,
    Font = Enum.Font.Code,
    MultiLine = true,
    Text = '{\n  "schemaVersion": 1,\n  "id": "TrailLantern",\n  "displayName": "Trail Lantern",\n  "utilityKind": "IlluminateArea",\n  "interaction": { "interactionRadius": 12, "cooldownSeconds": 0.5 },\n  "visual": { "meshAssetId": "", "textureAssetId": "", "iconAssetId": "", "scale": 1 },\n  "audio": { "equipSoundAssetId": "", "useSoundAssetId": "", "volume": 0.7 },\n  "animation": { "equipAnimationAssetId": "", "useAnimationAssetId": "" },\n  "utilityConfig": { "durationSeconds": 8, "intensity": 0.75 }\n}',
    TextColor3 = Color3.fromRGB(230, 230, 230),
    TextSize = 13,
    TextXAlignment = Enum.TextXAlignment.Left,
    TextYAlignment = Enum.TextYAlignment.Top,
}, root) :: TextBox
addCorner(jsonBox)
local status = createLabel(root, "Ready. NPC generation requires a selected rig Model.", 52)
status.TextWrapped = true
local validateButton = createButton(root, "Validate Definition")
local previewButton = createButton(root, "Preview Prefab Plan")
local generateButton = createButton(root, "Generate Prefab")

local function isAssetRef(value: any): boolean
    return value == "" or (type(value) == "string" and string.match(value, "^rbxassetid://%d+$") ~= nil)
end

local function validId(value: any): boolean
    return type(value) == "string" and string.match(value, "^[%w_%-]+$") ~= nil and #value >= 2 and #value <= 48
end

local function validateNpc(data: any): {string}
    local issues = {}
    if type(data) ~= "table" then return {"Definition must be an object"} end
    if data.schemaVersion ~= 1 then table.insert(issues, "schemaVersion must be 1") end
    if not validId(data.id) then table.insert(issues, "id must be 2-48 letters/numbers/underscore/hyphen") end
    if type(data.displayName) ~= "string" or #data.displayName < 1 or #data.displayName > 48 then
        table.insert(issues, "displayName must be 1-48 characters")
    end
    local allowed = {Wander = true, Follow = true, Patrol = true, Guide = true, VendorIdle = true}
    if not allowed[data.behavior] then table.insert(issues, "behavior is not in the supported non-hostile behavior list") end
    if type(data.movement) ~= "table" then
        table.insert(issues, "movement object is required")
    else
        local limits = {walkSpeed = {0, 24}, arrivalRadius = {0.5, 30}, repathInterval = {0.5, 15}, stuckTimeout = {1, 60}, maxPathRetries = {0, 8}}
        for key, range in pairs(limits) do
            local value = data.movement[key]
            if type(value) ~= "number" or value < range[1] or value > range[2] then
                table.insert(issues, string.format("movement.%s must be within %s..%s", key, range[1], range[2]))
            end
        end
    end
    return issues
end

local function validateGadget(data: any): {string}
    local issues = {}
    if type(data) ~= "table" then return {"Definition must be an object"} end
    if data.schemaVersion ~= 1 then table.insert(issues, "schemaVersion must be 1") end
    if not validId(data.id) then table.insert(issues, "id must be 2-48 letters/numbers/underscore/hyphen") end
    if type(data.displayName) ~= "string" or #data.displayName < 1 or #data.displayName > 48 then
        table.insert(issues, "displayName must be 1-48 characters")
    end
    if not ALLOWED_UTILITY_KINDS[data.utilityKind] then table.insert(issues, "utilityKind is not an allowed utility action") end
    if type(data.interaction) ~= "table" then
        table.insert(issues, "interaction object is required")
    else
        local radius = data.interaction.interactionRadius
        local cooldown = data.interaction.cooldownSeconds
        if type(radius) ~= "number" or radius < 1 or radius > 40 then table.insert(issues, "interactionRadius must be 1..40") end
        if type(cooldown) ~= "number" or cooldown < 0 or cooldown > 120 then table.insert(issues, "cooldownSeconds must be 0..120") end
    end
    for groupName, keys in pairs({
        visual = {"meshAssetId", "textureAssetId", "iconAssetId"},
        audio = {"equipSoundAssetId", "useSoundAssetId"},
        animation = {"equipAnimationAssetId", "useAnimationAssetId"},
    }) do
        local group = data[groupName] or {}
        if type(group) ~= "table" then
            table.insert(issues, groupName .. " must be an object")
        else
            for _, key in ipairs(keys) do
                if not isAssetRef(group[key] or "") then
                    table.insert(issues, groupName .. "." .. key .. " must be empty or rbxassetid://digits")
                end
            end
        end
    end
    local scale = data.visual and data.visual.scale or 1
    if type(scale) ~= "number" or scale < 0.1 or scale > 5 then table.insert(issues, "visual.scale must be 0.1..5") end
    local volume = data.audio and data.audio.volume or 0.7
    if type(volume) ~= "number" or volume < 0 or volume > 1 then table.insert(issues, "audio.volume must be 0..1") end
    return issues
end

local function parseAndValidate()
    local ok, data = pcall(function() return HttpService:JSONDecode(jsonBox.Text) end)
    if not ok then return nil, {"JSON parse failed: " .. tostring(data)} end
    local kind = string.lower(string.gsub(kindBox.Text, "%s+", ""))
    local issues
    if kind == "npc" then
        issues = validateNpc(data)
    elseif kind == "gadget" then
        issues = validateGadget(data)
    else
        issues = {"Content type must be NPC or Gadget"}
    end
    return data, issues
end

local function ensureFolder(parent: Instance, name: string): Folder
    local existing = parent:FindFirstChild(name)
    if existing and existing:IsA("Folder") then return existing end
    local folder = Instance.new("Folder")
    folder.Name = name
    folder.Parent = parent
    return folder
end

local function toLuau(value: any, depth: number?): string
    local level = depth or 0
    local indent = string.rep("    ", level)
    local childIndent = string.rep("    ", level + 1)
    if type(value) == "string" then return string.format("%q", value) end
    if type(value) == "number" then
        assert(value == value and value > -math.huge and value < math.huge, "Non-finite number")
        return tostring(value)
    end
    if type(value) == "boolean" then return tostring(value) end
    if type(value) ~= "table" then error("Unsupported config value type: " .. typeof(value)) end
    local keys = {}
    for key in pairs(value) do table.insert(keys, key) end
    table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
    local parts = {"{"}
    for _, key in ipairs(keys) do
        local encodedKey
        if type(key) == "number" then encodedKey = "[" .. tostring(key) .. "]"
        else encodedKey = "[" .. string.format("%q", tostring(key)) .. "]" end
        table.insert(parts, "\n" .. childIndent .. encodedKey .. " = " .. toLuau(value[key], level + 1) .. ",")
    end
    if #keys > 0 then table.insert(parts, "\n" .. indent) end
    table.insert(parts, "}")
    return table.concat(parts)
end

local function writeDefinition(folder: Folder, data: any)
    local existing = folder:FindFirstChild(data.id)
    if existing then error("Definition already exists: " .. data.id .. ". Rename or use a separate explicit replace workflow.") end
    local module = Instance.new("ModuleScript")
    module.Name = data.id
    module.Source = "--!strict\n-- Generated by V8 Content Factory. Edit through the definition editor or review this module.\nreturn " .. toLuau(data)
    module.Parent = folder
end

local function runUndoable(name: string, callback: () -> ())
    local recordingId = ChangeHistoryService:TryBeginRecording(name)
    if recordingId == nil then
        error("Studio could not start an undo recording. No changes were made; close any unfinished plugin recording and retry outside playtest.")
    end
    local ok, err = pcall(callback)
    if recordingId then
        local operation = if ok then Enum.FinishRecordingOperation.Commit else Enum.FinishRecordingOperation.Cancel
        ChangeHistoryService:FinishRecording(recordingId, operation)
    end
    if not ok then error(err) end
end

local function generateNpc(data: any)
    local selected = Selection:Get()
    local sourceModel = nil
    for _, item in ipairs(selected) do
        if item:IsA("Model") then sourceModel = item; break end
    end
    assert(sourceModel ~= nil, "Select one approved NPC rig Model before generating an NPC prefab")
    assert(sourceModel:FindFirstChildOfClass("Humanoid") ~= nil, "Selected Model must contain a Humanoid")
    assert(sourceModel.Archivable, "Selected rig Model must have Archivable enabled")
    runUndoable("Generate NPC prefab " .. data.id, function()
        local output = ensureFolder(ensureFolder(ServerStorage, "V8GeneratedPrefabs"), "NPCs")
        assert(output:FindFirstChild(data.id .. "_Prefab") == nil, "Prefab already exists; no overwrite performed")
        local definitions = ensureFolder(ensureFolder(ReplicatedStorage, "V8Definitions"), "NPCs")
        writeDefinition(definitions, data)
        local clone = sourceModel:Clone()
        clone.Name = data.id .. "_Prefab"
        clone:SetAttribute("NPCDefinitionId", data.id)
        clone:SetAttribute("DefinitionSchemaVersion", data.schemaVersion)
        clone:SetAttribute("GeneratedBy", "V8ContentFactory")
        CollectionService:AddTag(clone, "DataDrivenNPC")
        clone.Parent = output
        Selection:Set({clone})
    end)
end

local function addAsset(parent: Instance, className: string, name: string, id: string)
    if id == nil or id == "" then return end
    local object = Instance.new(className)
    object.Name = name
    if className == "Sound" then (object :: Sound).SoundId = id end
    if className == "Animation" then (object :: Animation).AnimationId = id end
    object.Parent = parent
end

local function generateGadget(data: any)
    runUndoable("Generate utility gadget " .. data.id, function()
        local output = ensureFolder(ensureFolder(ServerStorage, "V8GeneratedPrefabs"), "Gadgets")
        assert(output:FindFirstChild(data.id) == nil, "Prefab already exists; no overwrite performed")
        local definitions = ensureFolder(ensureFolder(ReplicatedStorage, "V8Definitions"), "Gadgets")
        writeDefinition(definitions, data)
        local tool = Instance.new("Tool")
        tool.Name = data.displayName
        tool.RequiresHandle = true
        tool.CanBeDropped = false
        tool:SetAttribute("GadgetDefinitionId", data.id)
        tool:SetAttribute("DefinitionSchemaVersion", data.schemaVersion)
        tool:SetAttribute("UtilityKind", data.utilityKind)
        tool:SetAttribute("InteractionRadius", data.interaction.interactionRadius)
        tool:SetAttribute("CooldownSeconds", data.interaction.cooldownSeconds)
        tool:SetAttribute("GeneratedBy", "V8ContentFactory")

        local handle = Instance.new("Part")
        handle.Name = "Handle"
        handle.Size = Vector3.new(1, 1, 1) * (data.visual and data.visual.scale or 1)
        handle.Anchored = false
        handle.CanCollide = false
        handle.Parent = tool
        local meshId = data.visual and data.visual.meshAssetId or ""
        if meshId ~= "" then
            local mesh = Instance.new("SpecialMesh")
            mesh.MeshType = Enum.MeshType.FileMesh
            mesh.MeshId = meshId
            mesh.TextureId = data.visual.textureAssetId or ""
            mesh.Parent = handle
        end
        local presentation = Instance.new("Folder")
        presentation.Name = "Presentation"
        presentation.Parent = tool
        local audioFolder = Instance.new("Folder")
        audioFolder.Name = "Audio"
        audioFolder.Parent = presentation
        local animationFolder = Instance.new("Folder")
        animationFolder.Name = "Animations"
        animationFolder.Parent = presentation
        local audio = data.audio or {}
        addAsset(audioFolder, "Sound", "Equip", audio.equipSoundAssetId or "")
        addAsset(audioFolder, "Sound", "Use", audio.useSoundAssetId or "")
        local animations = data.animation or {}
        addAsset(animationFolder, "Animation", "Equip", animations.equipAnimationAssetId or "")
        addAsset(animationFolder, "Animation", "Use", animations.useAnimationAssetId or "")
        tool.Parent = output
        Selection:Set({tool})
    end)
end

previewButton.Activated:Connect(function()
    local data, issues = parseAndValidate()
    if data == nil or #issues > 0 then
        status.Text = table.concat(issues, "\n")
        status.TextColor3 = Color3.fromRGB(255, 150, 130)
        return
    end
    local kind = string.lower(string.gsub(kindBox.Text, "%s+", ""))
    if kind == "npc" then
        local selectedModelName = "<select rig>"
        for _, selected in ipairs(Selection:Get()) do
            if selected:IsA("Model") then selectedModelName = selected.Name; break end
        end
        status.Text = string.format(
            "PREVIEW (no changes): clone selected rig Model '%s'; tag DataDrivenNPC; set NPCDefinitionId=%s; output ServerStorage/V8GeneratedPrefabs/NPCs/%s_Prefab.",
            selectedModelName, data.id, data.id
        )
    else
        local visual = data.visual or {}
        local audio = data.audio or {}
        local animation = data.animation or {}
        status.Text = string.format(
            "PREVIEW (no changes): create Tool '%s' with Handle%s, %s optional sound refs, %s optional animation refs, and definition %s; output ServerStorage/V8GeneratedPrefabs/Gadgets/%s.",
            data.displayName,
            ((visual.meshAssetId or "") ~= "" and " + SpecialMesh") or "",
            ((audio.equipSoundAssetId or "") ~= "" and 1 or 0) + ((audio.useSoundAssetId or "") ~= "" and 1 or 0),
            ((animation.equipAnimationAssetId or "") ~= "" and 1 or 0) + ((animation.useAnimationAssetId or "") ~= "" and 1 or 0),
            data.id, data.id
        )
    end
    status.TextColor3 = Color3.fromRGB(180, 210, 255)
end)

validateButton.Activated:Connect(function()
    local _, issues = parseAndValidate()
    if #issues == 0 then
        status.Text = "Validation passed. No DataModel changes were made."
        status.TextColor3 = Color3.fromRGB(120, 220, 140)
    else
        status.Text = table.concat(issues, "\n")
        status.TextColor3 = Color3.fromRGB(255, 150, 130)
    end
end)

generateButton.Activated:Connect(function()
    local data, issues = parseAndValidate()
    if data == nil or #issues > 0 then
        status.Text = table.concat(issues, "\n")
        status.TextColor3 = Color3.fromRGB(255, 150, 130)
        return
    end
    local ok, err = pcall(function()
        local kind = string.lower(string.gsub(kindBox.Text, "%s+", ""))
        if kind == "npc" then generateNpc(data) else generateGadget(data) end
    end)
    if ok then
        status.Text = "Generated " .. data.id .. ". Prefab is in ServerStorage/V8GeneratedPrefabs; its definition is in ReplicatedStorage/V8Definitions."
        status.TextColor3 = Color3.fromRGB(120, 220, 140)
    else
        status.Text = "Generation failed: " .. tostring(err)
        status.TextColor3 = Color3.fromRGB(255, 150, 130)
    end
end)

OPEN_BUTTON.Click:Connect(function()
    WIDGET.Enabled = not WIDGET.Enabled
end)
