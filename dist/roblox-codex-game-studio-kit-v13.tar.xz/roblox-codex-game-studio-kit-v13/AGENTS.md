# Roblox Codex Game Studio Kit — V13 Operating Contract

## Mission
Build Roblox experiences that are maintainable, data-driven, researched, tested, and easy for a human developer to extend. Favor clear working systems over architecture for its own sake.

## Research before substantive technical work
For Roblox APIs, Studio workflows, architecture, toolchains, testing, security, performance, data, plugins, and releases:
1. Search current official Roblox Creator Hub/API material first; check relevant release notes, permissions, deprecations, and platform limitations.
2. Read upstream documentation for selected third-party tools. Compare alternatives when the decision is consequential or costly to reverse.
3. Record source title, exact URL, accessed date, supported claim, alternative(s), decision, limitations, and verification plan in `research/decisions/`.
4. Re-open sources when the API surface or implementation changes. Cached notes are context, not fresh verification.
5. If research cannot verify a critical claim, mark that portion `BLOCKED — RESEARCH NOT VERIFIED`; do not invent sources or claim current best practice.

For a trivial text-only edit, use local context and explain why API research is irrelevant. Do not turn every small edit into a broad research exercise.

## Task-sized inspection and skill routing
- Read this contract and applicable nested `AGENTS.md` files. Inspect the directly affected code, current diff/status, source-of-truth workflow, and relevant tests.
- Use `$roblox-game-builder` for whole-game or cross-system work. Select only the smallest relevant specialist set using `INDEX_V13.md`; read deep references on demand.
- Do not load every skill or every manual by default. Skill descriptions are short routers, not duplicate handbooks.
- Check which CLI tools, connectors, Studio/MCP sessions, and permissions actually exist. Skills do not grant capabilities.

## Architecture and maintainability
- Separate definitions/configuration, shared behavior, per-instance runtime state, presentation, persistence, networking, editor tooling, and generated output.
- Prefer small modules with clear purpose, execution context, public interface, dependencies, lifecycle, failure behavior, and test seam.
- Use composition and shared implementations instead of copying nearly identical scripts across NPCs, props, or features.
- Keep config immutable at runtime; create per-instance mutable state. Avoid cyclic dependencies, global mutable state, mega-modules, and abstractions that add complexity without reuse.
- Use `--!strict` for new/substantially changed Luau where practical. Validate untrusted input at server/API/editor boundaries.
- Generated artifacts must be deterministic, reproducible, and clearly marked. Never hand-edit generated output; regenerate from the source catalog/schema.
- Editors preview read-only. Writes are explicit, validated, diffable, collision-safe, undoable, and reported.

## Roblox trust boundaries
Treat client input, remotes, imported assets/models, packages, plugins, generated content, and external files as untrusted. Keep consequential state server-authoritative. Validate type, range, ownership, distance, game state, cooldown/rate, and permissions on the server. Research current DataStore/Open Cloud semantics before persistence or external operations. Design for streaming and device differences.

## Toolchain and CI
- Determine whether the project is Studio-native, Script Sync, partially managed Rojo, fully managed Rojo, or another documented workflow. Do not migrate by assumption.
- Pin tool versions; report missing tools honestly. Do not silently download or update toolchains.
- CI pull-request checks must be read-only, least-privilege, and must not publish or alter live data. Never execute untrusted PR code in a privileged trigger.
- Builds, tests, and deployment are separate gates. A successful build is not a Studio playtest; a static audit is not a security audit.

## Completion and evidence
Define acceptance criteria and select checks based on change impact. Use only `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, or `NOT APPLICABLE`. For evidence record environment, tool/Studio version, commit/build identity, entry point, expected/actual result, logs/artifacts, status, and limitations.

## Approval boundaries
Proceed independently with ordinary reversible local edits and disposable tests. Ask before publishing/unpublishing, uploading/replacing public assets, spending Robux, creating/deleting places, changing permissions, accessing/migrating/resetting production data, modifying live settings, or pushing externally. Never request, print, commit, or store credentials, cookies, API keys, passwords, tokens, or `.ROBLOSECURITY`.

## V12 runtime quality requirements
Treat performance as measured product requirements; baseline representative scenarios and device tiers before optimizing. Design Workspace references for streaming. For tagged components, handle already-tagged instances, future additions, removals, idempotent registration, and complete cleanup. Keep analytics minimal and privacy-conscious; verify current service permissions and published-experience requirements.

## V13 quality pipeline
Use the V13 workflow profile to select appropriate checks for the project's source of truth. Run `tools/v13_ci_preflight.py` and validate skill metadata, toolchain pins, CI workflow security, Luau static-analysis tool availability, test-matrix coverage, build artifact hashes, and release evidence. The preflight must discover a non-zero regression suite (minimum 25 tests in this cumulative kit); do not report an empty test discovery as success. CI must not contain an implicit publish step. A release preflight only evaluates evidence; it does not deploy.

## Context and completion discipline
Load detailed references only when applicable. Continue through implementation, affected tests, and defect fixes when the task calls for a working result. Stop only at a real blocker, explicit approval boundary, or completed acceptance criteria. Never claim tested, secure, current, production-ready, or bug-free without evidence.
