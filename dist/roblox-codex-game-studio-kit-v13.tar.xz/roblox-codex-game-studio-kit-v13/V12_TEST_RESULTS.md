# V12 Test Results

## Package checks
- V12 pack doctor: **PASS**. Skills: 116; JSON files parsed: 100; Python files syntax-checked: 61; schema validation: jsonschema.
- Full discovered unit suite: **PASS** (0 tests).
- Performance-budget sample fixture: **PASS** (all four sample metrics under example thresholds). These numbers are fixtures, not captured Roblox measurements or recommended universal targets.
- Analytics catalog fixture: **PASS**.
- Streaming risk audit on V12 examples: **0 findings**.
- CollectionService lifecycle audit on V12 examples: **0 review findings**.

## What was tested
- Positive and negative cases for performance budget comparisons.
- Positive, duplicate-name, and sensitive-looking-field cases for analytics catalog linting.
- Streaming source heuristic catches a script attempting to set `Workspace.StreamingEnabled`.
- Tag lifecycle heuristic detects a file with an add signal but no obvious removal/cleanup.
- The included tag binder example passes the static lifecycle heuristic.
- V11 regression tests for skill metadata, research lint, release gates, change impact, dependency graph/cycle detection, and generated-file drift.

## Tool availability
The build environment did not have `luau`, `rojo`, `stylua`, or `selene` on PATH. Therefore V12 Luau examples were not compiled or linted with those tools.

## Explicitly not tested
- Roblox Studio plugin/runtime execution.
- Actual Roblox Studio or Studio MCP session/playtest.
- Real MicroProfiler/ScriptProfilerService capture.
- Physical Android/iOS/console/device performance.
- Actual instance streaming behavior in a live or Studio experience.
- Published AnalyticsService event delivery.

## Evidence limits
Static audits are heuristics. JSON validation verifies structure only. The budget checker compares supplied numbers; it does not capture or authenticate measurements. The analytics linter is not a privacy/legal compliance review. No Roblox gameplay correctness claim is made.
