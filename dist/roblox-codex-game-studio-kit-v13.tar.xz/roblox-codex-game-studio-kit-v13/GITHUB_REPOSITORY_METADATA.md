# GitHub repository metadata

Repository owner: `Aziz24666`

Repository name: `roblox-codex-game-studio-kit`

Visibility: Public

Description:

> Research-first Roblox game-development toolkit for Codex: modular Luau systems, data-driven NPCs, schema-driven Studio editors, prefab factories, testing, and CI.

Suggested topics:

`roblox`, `roblox-studio`, `luau`, `codex`, `game-development`, `data-driven-architecture`, `studio-plugin`, `github-actions`, `testing`, `modular-architecture`

The description and topics are prepared for the GitHub About panel. They still need to be applied after the repository is created.
