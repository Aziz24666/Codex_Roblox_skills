#!/usr/bin/env python3
"""Generate a readable index of research decision records."""
from __future__ import annotations
import argparse, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',default='research/decisions')
    ap.add_argument('--out',default='research/RESEARCH_INDEX.md')
    args=ap.parse_args(); root=Path(args.root); rows=[]
    for p in sorted(root.glob('*.json')):
        try: d=json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: rows.append((p.name,'INVALID',str(e),'—',p.name,'—')); continue
        sources=d.get('sources',[])
        domains=', '.join(sorted({s.get('domain','') for s in sources if isinstance(s,dict)}))
        rows.append((d.get('recordId',p.stem),d.get('status','UNKNOWN'),d.get('task',''),domains,p.name,d.get('researchedAt','—')))
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    lines=['# Research Decision Index','', 'Records are evidence snapshots. Re-open current sources on every new task; this index is not a currency guarantee.','', '| Record | Date | Status | Task | Source domains | File |','|---|---|---|---|---|---|']
    for row in rows: lines.append(f'| `{row[0]}` | {row[5]} | {row[1]} | {row[2]} | {row[3]} | `{row[4]}` |')
    out.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Indexed {len(rows)} record(s) to {out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
