#!/usr/bin/env python3
"""Generate a test-plan matrix from JSON feature records; does not run tests."""
import argparse,json
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--input',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    try: data=json.loads(Path(args.input).read_text(encoding='utf-8'))
    except Exception as e: print(f'FAIL: {e}'); return 1
    features=data.get('features') if isinstance(data,dict) else None
    if not isinstance(features,list) or not features: print('FAIL: expected non-empty features array'); return 1
    lines=['# Generated Test Matrix','','> Planning aid only; no test has been executed.','','| Feature | Category | Suggested levels | Scenarios | Status |','|---|---|---|---|---|']
    for item in features:
        if not isinstance(item,dict) or not item.get('name'): print('FAIL: every feature needs a name'); return 1
        category=str(item.get('category','general')).lower(); levels=['STATIC','UNIT','INTEGRATION','STUDIO_SOLO']; scenarios=['happy path','invalid input','failure/recovery']
        if category in {'network','multiplayer','social','matchmaking'}: levels += ['CLIENT_SERVER','MULTI_CLIENT','NETWORK']; scenarios += ['duplicate/concurrent','leave/rejoin','late join']
        if category in {'data','economy','purchase','persistence'}: levels += ['INTEGRATION']; scenarios += ['load/save failure','duplicate operation','isolated migration/recovery']
        if category in {'ui','input','accessibility','localization'}: levels += ['DEVICE']; scenarios += ['narrow/wide layout','touch/gamepad/keyboard','text expansion/focus']
        if category in {'world','procedural','streaming'}: levels += ['DEVICE','NETWORK']; scenarios += ['streaming in/out','missing asset fallback','budget limits']
        row='| {} | {} | {} | {} | NOT RUN |'.format(item['name'],category,', '.join(dict.fromkeys(levels)),', '.join(scenarios)); lines.append(row)
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text('\n'.join(lines)+'\n',encoding='utf-8'); print(f'Wrote {out} for {len(features)} features; plan only.'); return 0
if __name__=='__main__': raise SystemExit(main())
