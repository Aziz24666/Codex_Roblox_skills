#!/usr/bin/env python3
"""Compare a structured performance capture with project-specific budgets.

This tool does not capture performance or verify the authenticity/comparability of the evidence.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

REQUIRED_CAPTURE = {"experience", "buildId", "place", "capturedAt", "environment", "deviceTier", "scenario", "durationSeconds", "evidence"}
ALLOWED_ENV = {"Studio", "published-staging", "published-production", "physical-device"}

def evaluate(baseline: dict, budget: dict) -> dict:
    errors, warnings, results = [], [], []
    if baseline.get("schemaVersion") != 1: errors.append("baseline schemaVersion must be 1")
    if budget.get("schemaVersion") != 1: errors.append("budget schemaVersion must be 1")
    capture = baseline.get("capture")
    metrics = baseline.get("metrics")
    budgets = budget.get("budgets")
    if not isinstance(capture, dict): errors.append("baseline.capture must be an object"); capture = {}
    if not isinstance(metrics, dict): errors.append("baseline.metrics must be an object"); metrics = {}
    if not isinstance(budgets, dict): errors.append("budget.budgets must be an object"); budgets = {}
    missing = sorted(REQUIRED_CAPTURE - set(capture))
    if missing: errors.append("missing capture fields: " + ", ".join(missing))
    if capture.get("environment") not in ALLOWED_ENV: errors.append("unsupported or missing capture.environment")
    if capture.get("environment") == "Studio" and any("published" in str(capture.get(k, "")).lower() for k in ("evidence",)):
        warnings.append("Studio capture references a published environment; verify the evidence path")
    if not isinstance(capture.get("evidence"), list) or not capture.get("evidence"):
        errors.append("capture.evidence must be a non-empty list")
    if not isinstance(capture.get("durationSeconds"), (int, float)) or capture.get("durationSeconds", 0) <= 0:
        errors.append("capture.durationSeconds must be positive")
    if not isinstance(metrics, dict) or not metrics: errors.append("baseline.metrics must contain at least one metric")
    for name, spec in budgets.items():
        if not isinstance(spec, dict):
            errors.append(f"budget {name}: must be an object"); continue
        if name not in metrics:
            results.append({"metric": name, "status": "BLOCKED", "reason": "metric missing from baseline"})
            continue
        value = metrics[name]
        limit = spec.get("max")
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0:
            errors.append(f"metric {name}: baseline value must be a non-negative number"); continue
        if not isinstance(limit, (int, float)) or isinstance(limit, bool) or limit < 0:
            errors.append(f"budget {name}: max must be a non-negative number"); continue
        passed = value <= limit
        results.append({"metric": name, "value": value, "max": limit, "unit": spec.get("unit", ""), "status": "PASS" if passed else ("FAIL" if spec.get("severity", "fail") == "fail" else "WARN")})
    extra = sorted(set(metrics) - set(budgets))
    if extra: warnings.append("metrics without configured budgets: " + ", ".join(extra))
    ok = not errors and all(x["status"] in {"PASS", "WARN"} for x in results)
    return {"ok": ok, "status": "PASS" if ok else "FAIL", "errors": errors, "warnings": warnings, "results": results,
            "limitation": "Compares supplied values only; does not capture, authenticate, or prove that measurements are comparable."}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("baseline", type=Path); ap.add_argument("budget", type=Path); ap.add_argument("--output", type=Path); args = ap.parse_args()
    try: result = evaluate(json.loads(args.baseline.read_text()), json.loads(args.budget.read_text()))
    except Exception as exc: print(json.dumps({"ok":False,"error":str(exc)}, indent=2)); raise SystemExit(2)
    out = json.dumps(result, indent=2); print(out)
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(out + "\n", encoding="utf-8")
    raise SystemExit(0 if result["ok"] else 1)
if __name__ == "__main__": main()
