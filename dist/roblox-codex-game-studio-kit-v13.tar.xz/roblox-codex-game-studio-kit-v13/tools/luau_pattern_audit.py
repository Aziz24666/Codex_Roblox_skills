#!/usr/bin/env python3
"""Heuristic Luau text scanner. Findings require human review; absence proves nothing."""
from pathlib import Path
import argparse, re, sys

RULES = [
    ('LEGACY_WAIT', re.compile(r'\bwait\s*\('), 'Review legacy wait(); consider task.wait or event-driven flow.'),
    ('LEGACY_SPAWN', re.compile(r'\bspawn\s*\('), 'Review legacy spawn(); consider task APIs and lifecycle ownership.'),
    ('LEGACY_DELAY', re.compile(r'\bdelay\s*\('), 'Review legacy delay(); consider task.delay and cancellation.'),
    ('BROAD_ANY', re.compile(r'\bany\b'), 'Review broad any usage; narrow the boundary and document why.'),
    ('TODO_MARKER', re.compile(r'\bTODO\b|\bFIXME\b'), 'Confirm this marker is intentional and tracked.'),
    ('PRINT_CALL', re.compile(r'\bprint\s*\('), 'Review whether this debug print should be removed or gated.'),
]
SKIP = {'.git', 'node_modules', 'Packages', '_Index', 'target', 'build', 'dist', '.cache', '__pycache__'}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('path', nargs='?', default='src')
    ap.add_argument('--strict', action='store_true', help='Exit 1 if any findings are produced')
    args = ap.parse_args()
    root = Path(args.path)
    if not root.exists(): raise SystemExit(f'Path does not exist: {root}')
    files = [root] if root.is_file() else [p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.lua', '.luau'} and not any(x in SKIP for x in p.parts)]
    findings = 0
    for file in sorted(files):
        try: lines = file.read_text(encoding='utf-8').splitlines()
        except (UnicodeDecodeError, OSError): continue
        for number, line in enumerate(lines, 1):
            for code, pattern, hint in RULES:
                if pattern.search(line):
                    print(f'{file}:{number}: [{code}] {hint}')
                    findings += 1
    print(f'\nScanned {len(files)} Luau/Lua file(s); {findings} heuristic finding(s).')
    print('This is not a Luau parser, type checker, security audit, or proof of correctness.')
    if args.strict and findings: raise SystemExit(1)

if __name__ == '__main__': main()
