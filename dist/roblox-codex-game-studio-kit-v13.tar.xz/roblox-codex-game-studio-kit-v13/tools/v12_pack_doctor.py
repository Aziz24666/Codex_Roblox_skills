#!/usr/bin/env python3
"""Validate V12 skills, JSON examples, Python syntax, links, and key docs."""
from __future__ import annotations
import argparse, json, re, py_compile, sys
from pathlib import Path

def run(root: Path) -> dict:
    errors=[]; warnings=[]; counts={}
    skill_files=sorted((root/'.agents/skills').glob('*/SKILL.md'))
    counts['skills']=len(skill_files); names=set()
    for p in skill_files:
        text=p.read_text(encoding='utf-8',errors='replace')
        m=re.match(r'^---\n(.*?)\n---\n',text,re.S)
        if not m: errors.append(f'{p}: missing frontmatter'); continue
        nm=re.search(r'^name:\s*(.+)$',m.group(1),re.M); ds=re.search(r'^description:\s*(.*)$',m.group(1),re.M)
        if not nm or not ds: errors.append(f'{p}: missing name/description'); continue
        name=nm.group(1).strip().strip("\"'")
        if name in names: errors.append(f'duplicate skill: {name}')
        names.add(name)
        if len(ds.group(1).strip().strip("\"'"))>160: warnings.append(f'{name}: long description')
        if 'V10 mandatory current-source research gate' not in text and 'Mandatory current-source research gate' not in text: errors.append(f'{p}: missing mandatory research gate')
        for ref in re.findall(r'`((?:docs|templates|schemas|prompts|examples)/[^`]+)`',text):
            if not (root/ref).exists(): errors.append(f'{p}: missing reference {ref}')
    counts['jsonFiles']=0
    for p in root.rglob('*.json'):
        if any(x in p.parts for x in {'.git','__pycache__','node_modules'}): continue
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'{p}: invalid JSON: {e}')
        counts['jsonFiles']+=1
    counts['pythonFiles']=0
    for p in root.rglob('*.py'):
        if any(x in p.parts for x in {'.git','__pycache__','node_modules'}): continue
        try: py_compile.compile(str(p),doraise=True)
        except Exception as e: errors.append(f'{p}: Python compile error: {e}')
        counts['pythonFiles']+=1
    try:
        import jsonschema
        for example in sorted((root/'schemas/examples').glob('v12-*.example.json')):
            stem=example.name.replace('.example.json','.schema.json')
            schema=root/'schemas'/stem
            if not schema.exists(): errors.append(f'{example}: missing schema {schema.name}'); continue
            try: jsonschema.validate(json.loads(example.read_text()),json.loads(schema.read_text()))
            except Exception as e: errors.append(f'{example}: schema failure: {e}')
        counts['schemaValidation']='jsonschema'
    except ImportError:
        warnings.append('jsonschema not installed; V12 example checks are syntax-only')
        counts['schemaValidation']='not-installed'
    # Check V12 Markdown inline paths (relative to project root)
    for p in list((root/'docs').glob('V12_*.md'))+list((root/'prompts').glob('V12_*.md')):
        text=p.read_text(encoding='utf-8')
        for ref in re.findall(r'`((?:docs|templates|schemas|prompts|examples|tools)/[^`]+)`',text):
            if not (root/ref).exists(): errors.append(f'{p}: missing path reference {ref}')
    for required in ['AGENTS.md','README.md','INDEX_V12.md','V12_TEST_RESULTS.md','PACKAGE_INVENTORY.md','V12_SHA256SUMS.txt']:
        if not (root/required).exists(): errors.append(f'missing required file {required}')
    counts['files']=sum(1 for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    return {'ok':not errors,'counts':counts,'errors':errors,'warnings':warnings}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',type=Path,nargs='?',default=Path('.')); ap.add_argument('--output',type=Path); a=ap.parse_args(); result=run(a.root); out=json.dumps(result,indent=2); print(out)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(out+'\n',encoding='utf-8')
    raise SystemExit(0 if result['ok'] else 1)
if __name__=='__main__': main()
