#!/usr/bin/env python3
"""Check example content definitions for duplicate IDs and family mismatches."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--root',default='examples/v9/definitions'); a=p.parse_args()
root=Path(a.root); ids=set(); errors=[]; count=0
for path in sorted(root.rglob('*.json')):
 try: data=json.loads(path.read_text(encoding='utf-8'))
 except Exception as e: errors.append(f'{path}: {e}'); continue
 count+=1; key=(data.get('family'),data.get('id'))
 if key in ids: errors.append(f'{path}: duplicate family/id {key}')
 ids.add(key)
 if not data.get('family') or not data.get('id'): errors.append(f'{path}: missing family or id')
 if data.get('schemaVersion') != 1: errors.append(f'{path}: example schemaVersion must be 1')
if errors: print('\n'.join('ERROR '+e for e in errors)); raise SystemExit(1)
print(f'PASS: {count} definitions; no duplicate family/ID pairs')
