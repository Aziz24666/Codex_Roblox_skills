#!/usr/bin/env python3
"""Lint required asset provenance CSV fields and duplicate internal IDs."""
import argparse,csv
from pathlib import Path
REQUIRED={'internal_id','asset_type','source','permission_evidence','status'}
STATUSES={'PROPOSED','REVIEWED','APPROVED','REJECTED','RETIRED'}
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('csv_file',nargs='?',default='docs/ASSET_REGISTER.csv'); args=ap.parse_args(); path=Path(args.csv_file)
    if not path.is_file(): print(f'NOT APPLICABLE: {path} not found'); return 0
    with path.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f); missing=REQUIRED-set(reader.fieldnames or [])
        if missing: print('FAIL: missing columns '+', '.join(sorted(missing))); return 1
        rows=list(reader)
    errors=[]; seen=set()
    for n,row in enumerate(rows,2):
        key=(row.get('internal_id') or '').strip()
        if not key: errors.append(f'line {n}: empty internal_id')
        elif key in seen: errors.append(f'line {n}: duplicate internal_id {key}')
        seen.add(key)
        for field in ('asset_type','source','permission_evidence'):
            if not (row.get(field) or '').strip(): errors.append(f'line {n}: empty {field}')
        status=(row.get('status') or '').strip().upper()
        if status not in STATUSES: errors.append(f'line {n}: invalid status {status!r}')
    print(f'Rows checked: {len(rows)}')
    for e in errors: print('FAIL:',e)
    if errors: return 1
    print('PASS: required fields and duplicate IDs only; permission and asset content are not verified.')
    return 0
if __name__=='__main__': raise SystemExit(main())
