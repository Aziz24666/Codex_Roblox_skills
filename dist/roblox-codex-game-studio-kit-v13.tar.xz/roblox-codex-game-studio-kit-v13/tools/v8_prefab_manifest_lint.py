#!/usr/bin/env python3
"""Check a simple generated-prefab manifest for required provenance and hierarchy entries."""
import argparse,json
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('file'); a=ap.parse_args()
    try: d=json.loads(Path(a.file).read_text(encoding='utf-8'))
    except Exception as e: print('FAIL: JSON parse:',e); return 1
    required=['schemaVersion','componentId','tag','definitionAttribute','owner','executionSide','components']
    errors=[f'missing {k}' for k in required if k not in d]
    if d.get('schemaVersion') != 1: errors.append('schemaVersion must be 1')
    if d.get('executionSide') not in {'Server','Client','Shared'}: errors.append('executionSide invalid')
    if not isinstance(d.get('components'),list): errors.append('components must be array')
    if errors:
        for e in errors: print('FAIL:',e)
        return 1
    print('PASS: manifest structure valid; no Studio DataModel hierarchy was inspected')
    return 0
if __name__=='__main__': raise SystemExit(main())
