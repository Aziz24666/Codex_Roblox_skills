#!/usr/bin/env python3
"""Run safe local package checks; no network, secrets, Studio writes, or deployment."""
from pathlib import Path
import argparse,json,subprocess,sys,re

def run(root: Path):
    commands=[('skill-frontmatter',[sys.executable,str(root/'tools/v13_skill_frontmatter_audit.py'),str(root)]),
              ('package-doctor',[sys.executable,str(root/'tools/v13_pack_doctor.py'),str(root)]),
              ('unit-tests',[sys.executable,'-m','unittest','discover','-s',str(root/'tools/tests'),'-p','test_*.py','-v']),
              ('workflow-security',[sys.executable,str(root/'tools/v13_github_actions_security_audit.py'),str(root/'.github/workflows')]),
              ('workflow-profile',[sys.executable,str(root/'tools/v13_workflow_profile_lint.py'),str(root/'examples/v13/workflow-profile.json')]),
              ('test-matrix',[sys.executable,str(root/'tools/v13_test_matrix_lint.py'),str(root/'examples/v13/test-matrix.json')]),
              ('toolchain-lock',[sys.executable,str(root/'tools/v13_toolchain_lock_audit.py'),str(root/'examples/v13/rokit.toml')]),
              ('luau-toolchain-discovery',[sys.executable,str(root/'tools/v13_luau_toolchain_report.py')])]
    results=[]; ok=True
    for name,cmd in commands:
        r=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
        output=r.stdout+'\n'+r.stderr
        if name=='unit-tests':
            m=re.search(r'Ran (\d+) tests?',output); count=int(m.group(1)) if m else 0
            if count<25 and r.returncode==0: r.returncode=1; output+='\nERROR: expected at least 25 discovered tests; found '+str(count)
        results.append({'name':name,'status':'PASS' if r.returncode==0 else 'FAIL','returncode':r.returncode,'output':output[-5000:]})
        ok &= r.returncode==0
    return {'ok':bool(ok),'checks':results,'networkUsed':False,'deploymentPerformed':False}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',nargs='?',type=Path,default=Path('.')); a=ap.parse_args(); r=run(a.root.resolve()); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
