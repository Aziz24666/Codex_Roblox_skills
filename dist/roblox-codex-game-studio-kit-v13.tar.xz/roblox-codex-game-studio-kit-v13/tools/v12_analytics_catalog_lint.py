#!/usr/bin/env python3
"""Validate a minimal, privacy-conscious custom-event catalog."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

FORBIDDEN_TOKENS = {"userid","username","email","phone","phonenumber","ipaddress","ip","deviceid","address","preciselocation","realname","password","token","health","birthdate","dob","accountid","robloxid"}

def lint(catalog: dict) -> dict:
    errors=[]; warnings=[]
    if catalog.get("schemaVersion") != 1: errors.append("schemaVersion must be 1")
    if not isinstance(catalog.get("purpose"),str) or len(catalog.get("purpose","")) < 8: errors.append("purpose must explain the catalog's purpose")
    events=catalog.get("events")
    if not isinstance(events,list): errors.append("events must be an array"); events=[]
    if len(events)>100: errors.append("event count exceeds current documented custom-event maximum of 100; re-check current docs before implementation")
    names=set()
    for i,event in enumerate(events):
        if not isinstance(event,dict): errors.append(f"events[{i}] must be an object"); continue
        name=event.get("name")
        if not isinstance(name,str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{1,63}",name): errors.append(f"events[{i}].name has invalid format")
        elif name in names: errors.append(f"duplicate event name: {name}")
        else: names.add(name)
        if event.get("kind") not in {"counter","value"}: errors.append(f"events[{i}].kind must be counter or value")
        if not isinstance(event.get("question"),str) or len(event.get("question",""))<8: errors.append(f"events[{i}].question must state a meaningful product question")
        fields=event.get("fields",[])
        if not isinstance(fields,list) or any(not isinstance(f,str) for f in fields): errors.append(f"events[{i}].fields must be an array of strings"); continue
        normalized=[re.sub(r"[^a-z0-9]","",f.lower()) for f in fields]
        for field,norm in zip(fields,normalized):
            if norm in FORBIDDEN_TOKENS or any(token in norm for token in ("email","phone","password","token","preciselocation","ipaddress","realname")):
                errors.append(f"events[{i}] contains a prohibited/sensitive-looking field name: {field}")
        if len(set(fields)) != len(fields): errors.append(f"events[{i}].fields contains duplicate names")
        if len(fields)>8: warnings.append(f"events[{i}] has many fields; verify each one is necessary")
    return {"ok":not errors,"eventCount":len(events),"errors":errors,"warnings":warnings,"limitation":"Static catalog lint only; not a privacy/legal review and does not verify server-side implementation or actual event delivery."}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("catalog",type=Path); ap.add_argument("--output",type=Path); a=ap.parse_args(); result=lint(json.loads(a.catalog.read_text())); out=json.dumps(result,indent=2); print(out)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(out+"\n",encoding="utf-8")
    raise SystemExit(0 if result["ok"] else 1)
if __name__=="__main__": main()
