#!/usr/bin/env python3
"""Check research decision records for traceable sources, dates, alternatives, and decisions."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
REQUIRED={"id","title","accessedDate","task","queries","sources","alternatives","decision","limitations","verificationPlan"}
def lint(path):
    d=json.loads(path.read_text(encoding="utf-8")); errors=[]; warnings=[]
    for k in sorted(REQUIRED-set(d)): errors.append(f"missing field: {k}")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}",str(d.get("accessedDate",""))): errors.append("accessedDate must use YYYY-MM-DD")
    sources=d.get("sources",[])
    if not sources: errors.append("at least one source is required")
    if not any("create.roblox.com" in str(s.get("domain", "")) or "roblox.com" in str(s.get("domain", "")) for s in sources): errors.append("at least one official Roblox source is required for Roblox platform decisions")
    for i,s in enumerate(sources):
        if not s.get("url","").startswith("https://"): errors.append(f"source[{i}] URL must be https")
        if not s.get("title") or not s.get("claims"): errors.append(f"source[{i}] needs title and claims")
    if len(d.get("alternatives",[]))<2: warnings.append("fewer than two alternatives; justify why comparison is unnecessary for narrow lookups")
    if not d.get("verificationPlan"): errors.append("verificationPlan cannot be empty")
    return {"path":str(path),"errors":errors,"warnings":warnings,"ok":not errors}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("path",type=Path); a=ap.parse_args(); files=[a.path] if a.path.is_file() else sorted(a.path.glob("*.json")); results=[lint(p) for p in files]; print(json.dumps(results,indent=2)); raise SystemExit(1 if any(not r['ok'] for r in results) else 0)
if __name__=="__main__": main()
