#!/usr/bin/env python3
"""Validate Codex SKILL.md frontmatter without external YAML dependencies."""
from pathlib import Path
import argparse, json, re

def audit(root: Path) -> dict:
    errors=[]; warnings=[]; skills=sorted((root/'.agents/skills').glob('*/SKILL.md')); names=set()
    for p in skills:
        text=p.read_text(encoding='utf-8',errors='replace')
        m=re.match(r'^---\n(.*?)\n---\n',text,re.S)
        if not m:
            errors.append(f'{p}: missing or malformed YAML frontmatter'); continue
        block=m.group(1)
        if re.search(r'^\s*(#{1,6}\s|```)',block,re.M): errors.append(f'{p}: Markdown body appears inside YAML frontmatter')
        fields={}
        for line in block.splitlines():
            if not line.strip() or line.lstrip().startswith('#'): continue
            if ':' not in line: errors.append(f'{p}: invalid frontmatter line {line!r}'); continue
            key,value=line.split(':',1); key=key.strip(); value=value.strip().strip('"\'')
            if key in fields: errors.append(f'{p}: duplicate key {key}')
            fields[key]=value
        if set(fields)!={'name','description'}: errors.append(f'{p}: expected exactly name and description fields, got {sorted(fields)}')
        name=fields.get('name',''); desc=fields.get('description','')
        if name != p.parent.name: errors.append(f'{p}: name does not match directory {p.parent.name}')
        if name in names: errors.append(f'{p}: duplicate skill name {name}')
        names.add(name)
        if not desc: errors.append(f'{p}: empty description')
        if len(desc)>160: errors.append(f'{p}: description exceeds 160 characters ({len(desc)})')
        body=text[m.end():]
        if not re.search(r'(?:docs|templates|schemas|prompts|examples)/[A-Za-z0-9_./-]+', body): warnings.append(f'{p}: no progressive-disclosure reference path')
    return {'ok':not errors,'count':len(skills),'errors':errors,'warnings':warnings}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',nargs='?',type=Path,default=Path('.')); a=ap.parse_args()
    result=audit(a.root); print(json.dumps(result,indent=2)); raise SystemExit(0 if result['ok'] else 1)
if __name__=='__main__': main()
