#!/usr/bin/env python3
"""Heuristic presence check for V8 Studio plugin safety affordances."""
import argparse
from pathlib import Path
REQUIRED=['CreateToolbar','CreateDockWidgetPluginGuiAsync','JSONDecode','Validate','Preview','Generate','ServerStorage','DataDrivenNPC','NPCDefinitionId','ChangeHistoryService','recordingId == nil']
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('file'); a=ap.parse_args(); p=Path(a.file)
    if not p.is_file(): print('FAIL: plugin source not found'); return 2
    text=p.read_text(encoding='utf-8'); missing=[x for x in REQUIRED if x not in text]
    for token in REQUIRED: print(('PASS' if token not in missing else 'WARN')+f': token {token}')
    if missing: print('WARN: heuristic tokens missing:',', '.join(missing)); return 1
    print('PASS: expected affordance tokens present; plugin compilation and Studio execution not tested')
    return 0
if __name__=='__main__': raise SystemExit(main())
