#!/usr/bin/env python3
"""Validate V8 JSON content definition examples using the standard library."""
import argparse, json, math, re, sys
from pathlib import Path
ASSET = re.compile(r"^(|rbxassetid://[0-9]+)$")
def fail(msg): print("FAIL:", msg); return 1
def load(path):
    try: return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as e: raise ValueError(f"cannot parse JSON: {e}")
def finite_number(v): return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def check_npc(d):
    issues=[]
    for k in ("schemaVersion","id","displayName","behavior","movement"):
        if k not in d: issues.append(f"missing {k}")
    if d.get("schemaVersion") != 1: issues.append("schemaVersion must be 1")
    if not isinstance(d.get("id"),str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,47}",d.get("id","")): issues.append("id format invalid")
    if d.get("behavior") not in {"Wander","Follow","Patrol","Guide","VendorIdle"}: issues.append("unsupported behavior")
    m=d.get("movement")
    if not isinstance(m,dict): issues.append("movement must be an object")
    else:
        limits={"walkSpeed":(0,24),"arrivalRadius":(.5,30),"turnResponsiveness":(0,1),"repathInterval":(.5,15),"stuckTimeout":(1,60),"maxPathRetries":(0,8)}
        for k,(lo,hi) in limits.items():
            v=m.get(k)
            if not finite_number(v) or not lo <= v <= hi: issues.append(f"movement.{k} must be within {lo}..{hi}")
    return issues
def check_gadget(d):
    issues=[]
    for k in ("schemaVersion","id","displayName","utilityKind","interaction"):
        if k not in d: issues.append(f"missing {k}")
    if d.get("schemaVersion") != 1: issues.append("schemaVersion must be 1")
    if d.get("utilityKind") not in {"IlluminateArea","PlaySoundCue","ShowWaypointMarker","OpenJournal","CapturePhoto","CollectNearbyTokens"}: issues.append("unsupported non-combat utilityKind")
    inter=d.get("interaction")
    if not isinstance(inter,dict): issues.append("interaction must be object")
    else:
        for k,lo,hi in (("interactionRadius",1,40),("cooldownSeconds",0,120)):
            v=inter.get(k)
            if not finite_number(v) or not lo <= v <= hi: issues.append(f"interaction.{k} must be within {lo}..{hi}")
    for group,keys in {"visual":["meshAssetId","textureAssetId","iconAssetId"],"audio":["equipSoundAssetId","useSoundAssetId"],"animation":["equipAnimationAssetId","useAnimationAssetId"]}.items():
        values=d.get(group,{})
        if not isinstance(values,dict): issues.append(f"{group} must be object"); continue
        for k in keys:
            v=values.get(k,"")
            if not isinstance(v,str) or not ASSET.fullmatch(v): issues.append(f"{group}.{k} must be empty or rbxassetid:// followed by digits")
    return issues
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("file"); ap.add_argument("--kind",choices=["npc","gadget"],required=True); a=ap.parse_args()
    try: d=load(a.file)
    except ValueError as e: return fail(str(e))
    if not isinstance(d,dict): return fail("top level must be object")
    issues=check_npc(d) if a.kind=="npc" else check_gadget(d)
    if issues:
        for i in issues: print("FAIL:",i)
        return 1
    print(f"PASS: {a.kind} definition structure and basic bounds validated; asset existence/permissions and Studio behavior not tested")
    return 0
if __name__=="__main__": raise SystemExit(main())
