#!/usr/bin/env python3
"""Check V10 package structure, skill metadata, mandatory research gates, and local Markdown links."""
from __future__ import annotations
import argparse, re
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',default='.')
    args=ap.parse_args(); root=Path(args.root).resolve(); issues=[]
    required=['AGENTS.md','README.md','INDEX_V10.md','docs/V10_RESEARCH_FIRST_STANDARD.md','schemas/v10-research-decision.schema.json','tools/v10_research_record_lint.py','studio-plugin/README.md']
    for rel in required:
        if not (root/rel).exists(): issues.append(f'missing required path: {rel}')
    skills=list((root/'.agents/skills').glob('*/SKILL.md'))
    for p in skills:
        content=p.read_text(encoding='utf-8',errors='replace')
        if not content.startswith('---\n') or '\nname:' not in content or '\ndescription:' not in content or '\n---\n' not in content:
            issues.append(f'invalid skill frontmatter: {p.relative_to(root)}')
        if 'V10 mandatory current-source research gate' not in content:
            issues.append(f'skill missing mandatory V10 research gate: {p.relative_to(root)}')
    for p in root.rglob('*'):
        if p.is_dir() and (p.name=='__pycache__' or p.name=='.git'): issues.append(f'unwanted directory: {p.relative_to(root)}')
        if p.is_file() and p.suffix=='.pyc': issues.append(f'unwanted bytecode: {p.relative_to(root)}')
    link_re=re.compile(r'\[[^\]]+\]\(([^)]+)\)')
    for p in root.rglob('*.md'):
        txt=p.read_text(encoding='utf-8',errors='replace')
        for target in link_re.findall(txt):
            target=target.strip().split('#',1)[0]
            if not target or '://' in target or target.startswith('mailto:') or target.startswith('/'):
                continue
            dest=(p.parent/target).resolve()
            try: dest.relative_to(root)
            except ValueError: continue
            if not dest.exists(): issues.append(f'broken local Markdown link: {p.relative_to(root)} -> {target}')
    print(f'Skills: {len(skills)}')
    if issues:
        print(f'FAIL: {len(issues)} issue(s)')
        for issue in issues: print(' - '+issue)
        return 1
    print('PASS: V10 package structure and mandatory research gates are valid')
    return 0
if __name__=='__main__': raise SystemExit(main())
