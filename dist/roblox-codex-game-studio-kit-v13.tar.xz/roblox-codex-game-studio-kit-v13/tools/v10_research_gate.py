#!/usr/bin/env python3
"""Ensure a V10 research record explicitly covers changed files before implementation."""
from __future__ import annotations
import argparse, json, fnmatch
from pathlib import Path
from datetime import date

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--record',required=True)
    ap.add_argument('--changed-file',action='append',default=[])
    ap.add_argument('--require-current',action='store_true')
    args=ap.parse_args()
    try: data=json.loads(Path(args.record).read_text(encoding='utf-8'))
    except Exception as exc: print(f'FAIL: cannot read record: {exc}'); return 2
    scopes=data.get('scopeFiles',[])
    missing=[]
    for item in args.changed_file:
        normalized=item.replace('\\','/')
        if not any(fnmatch.fnmatch(normalized, pattern.replace('\\','/')) for pattern in scopes): missing.append(item)
    if missing:
        print('FAIL: research record does not cover changed files:')
        for item in missing: print(f'  - {item}')
        return 1
    if args.require_current and data.get('researchedAt') != date.today().isoformat():
        print(f"FAIL: research record is not current; expected {date.today().isoformat()}")
        return 1
    if data.get('status') not in {'RESEARCHED','NEEDS_SPIKE'}:
        print(f"FAIL: record status is {data.get('status')}; implementation is not cleared")
        return 1
    if not data.get('chosenApproach') or not data.get('sources'):
        print('FAIL: missing chosen approach or source evidence')
        return 1
    print(f"PASS: research record {data.get('recordId')} covers {len(args.changed_file)} changed file(s)")
    return 0
if __name__=='__main__': raise SystemExit(main())
