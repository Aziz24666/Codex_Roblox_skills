#!/usr/bin/env python3
"""Compare two JSON remote-contract inventories for API surface changes."""
import argparse, json, sys
from pathlib import Path
def load(path):
    d=json.loads(Path(path).read_text(encoding='utf-8')); arr=d.get('remotes')
    if not isinstance(arr,list): raise ValueError(f'{path}: remotes must be an array')
    out={}
    for item in arr:
        name=item.get('name')
        if not name: raise ValueError(f'{path}: remote with missing name')
        if name in out: raise ValueError(f'{path}: duplicate remote {name}')
        out[name]=item
    return out
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('before'); ap.add_argument('after'); args=ap.parse_args()
    try: a,b=load(args.before),load(args.after)
    except Exception as e: print('ERROR',e); return 2
    added=sorted(set(b)-set(a)); removed=sorted(set(a)-set(b)); changed=sorted(k for k in set(a)&set(b) if a[k]!=b[k])
    print('Added:',', '.join(added) or 'none'); print('Removed:',', '.join(removed) or 'none'); print('Changed:',', '.join(changed) or 'none')
    if removed: print('REVIEW Removed remote contracts may break clients or deployed places.')
    if changed: print('REVIEW Changed payload/direction/owner contracts require compatibility review and versioning.')
    print('NOTE This is a structural diff, not a security review or runtime compatibility proof.')
    return 0
if __name__=='__main__': sys.exit(main())
