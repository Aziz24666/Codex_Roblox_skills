# V9 tool reference

Run from the package root. `jsonschema` is required for the JSON Schema validation utilities.

| Tool | Purpose |
|---|---|
| `v9_schema_catalog_lint.py` | Checks family IDs, output/source allowlists, field kinds, defaults, ranges, enum options, and nested path conflicts. |
| `v9_generate_lua_catalog.py` | Generates the plugin ModuleScript from the canonical JSON family catalog. |
| `v9_definition_validate.py --all` | Validates example definition JSON against the V9 definition schema. |
| `v9_plugin_source_check.py` | Static contract checks for plugin modules; not a Luau compiler. |
| `v9_generated_manifest_lint.py` | Validates a generated-content manifest fixture. |
| `v9_editor_field_reference.py` | Produces a Markdown field reference from the catalog. |
| `v9_content_registry_lint.py` | Checks duplicate IDs and required family metadata in definition examples. |

Run the negative-case regression suite with `python tools/tests/test_v9_negative_cases.py`.
