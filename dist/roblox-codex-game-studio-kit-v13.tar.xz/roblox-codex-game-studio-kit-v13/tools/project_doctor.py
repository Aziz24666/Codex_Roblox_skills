#!/usr/bin/env python3
"""Read-only structural health audit for a Roblox project. Not a Luau parser."""
from pathlib import Path
import argparse, json, re, sys

SKIP = {'.git', 'node_modules', 'Packages', '_Index', 'target', 'build', 'dist', '.cache', '.venv', '__pycache__'}
EXTS = {'.luau', '.lua', '.json', '.toml', '.yml', '.yaml', '.md', '.rbxm', '.rbxmx', '.rbxl', '.rbxlx', '.png', '.jpg', '.jpeg', '.webp', '.ogg', '.mp3', '.wav', '.fbx', '.obj'}
MARKERS = ['AGENTS.md', 'default.project.json', 'rokit.toml', 'aftman.toml', 'wally.toml', 'wally.lock', '.github/workflows', 'tests', 'test', 'docs']

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('root', nargs='?', default='.')
    ap.add_argument('--out')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        raise SystemExit(f'Not a directory: {root}')
    files = []
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if any(part in SKIP for part in rel.parts):
            continue
        if p.is_file() and (p.suffix.lower() in EXTS or p.name in {'AGENTS.md', 'default.project.json'}):
            try: files.append((rel.as_posix(), p.stat().st_size))
            except OSError: files.append((rel.as_posix(), -1))
    files.sort(key=lambda x: x[0].lower())
    types = {}
    for name, _ in files:
        ext = Path(name).suffix.lower() or '[no extension]'
        types[ext] = types.get(ext, 0) + 1
    markers = {m: (root / m).exists() for m in MARKERS}
    workflow = []
    if markers['default.project.json']: workflow.append('Rojo project mapping marker detected')
    if markers['rokit.toml']: workflow.append('Rokit manifest detected')
    if markers['aftman.toml']: workflow.append('Aftman manifest detected')
    if markers['wally.toml'] or markers['wally.lock']: workflow.append('Wally manifest/lock detected')
    if markers['.github/workflows']: workflow.append('GitHub Actions workflows detected')
    if not workflow: workflow.append('No common Rojo/toolchain/CI marker detected; inspect Studio-native/custom workflow')
    luau = [n for n, _ in files if Path(n).suffix.lower() in {'.lua', '.luau'}]
    lines = [f'# Project Doctor Report: {root.name}', '', '## Detected workflow', *[f'- {x}' for x in workflow], '', '## Summary', f'- Relevant files: {len(files)}', f'- Luau/Lua source files: {len(luau)}', '', '## Markers']
    lines.extend(f'- {"Present" if value else "Not found"}: `{name}`' for name, value in markers.items())
    lines += ['', '## File types']
    lines.extend(f'- `{k}`: {v}' for k, v in sorted(types.items()))
    lines += ['', '## Inventory']
    lines.extend(f'- `{name}` ({size} bytes)' for name, size in files)
    lines += ['', '## Limitations', '- Read-only; does not modify files.', '- Does not parse Roblox place files, understand the full DataModel, compile Luau, or prove runtime behavior.', '- Does not inspect file contents for secrets; use approved secret scanning separately.', '- Verify Git status, project mapping, tool versions, Studio behavior, and asset provenance independently.', '']
    report = '\n'.join(lines)
    if args.out:
        out = Path(args.out).resolve(); out.parent.mkdir(parents=True, exist_ok=True); out.write_text(report, encoding='utf-8'); print(f'Wrote {out}')
    else: print(report)

if __name__ == '__main__': main()
