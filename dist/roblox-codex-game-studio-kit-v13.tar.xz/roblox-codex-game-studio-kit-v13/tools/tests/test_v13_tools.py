from pathlib import Path
import importlib.util, json, tempfile, unittest
ROOT=Path(__file__).resolve().parents[2]
def load(name):
    p=ROOT/'tools'/f'{name}.py'; spec=importlib.util.spec_from_file_location(name,p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
class V13Tests(unittest.TestCase):
    def test_skill_frontmatter_all_valid(self): self.assertTrue(load('v13_skill_frontmatter_audit').audit(ROOT)['ok'])
    def test_v13_package_doctor(self): self.assertTrue(load('v13_pack_doctor').run(ROOT)['ok'])
    def test_skill_frontmatter_rejects_heading_in_yaml(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d); p=r/'.agents/skills/x'; p.mkdir(parents=True); (p/'SKILL.md').write_text('---\nname: x\ndescription: valid\n## heading\n---\nbody')
            self.assertFalse(load('v13_skill_frontmatter_audit').audit(r)['ok'])
    def test_workflow_profile_example(self):
        d=json.loads((ROOT/'examples/v13/workflow-profile.json').read_text()); self.assertTrue(load('v13_workflow_profile_lint').lint(d)['ok'])
    def test_workflow_profile_hybrid_requires_multiple_owners(self):
        d=json.loads((ROOT/'examples/v13/workflow-profile.json').read_text()); d['sourceOfTruth']='hybrid'; d['ownership']={k:'git' for k in d['ownership']}; self.assertFalse(load('v13_workflow_profile_lint').lint(d)['ok'])
    def test_toolchain_pin_example(self): self.assertTrue(load('v13_toolchain_lock_audit').audit(ROOT/'examples/v13/rokit.toml')['ok'])
    def test_toolchain_rejects_floating(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rokit.toml'; p.write_text('[tools]\nrojo = "rojo-rbx/rojo@latest"\n'); self.assertFalse(load('v13_toolchain_lock_audit').audit(p)['ok'])
    def test_actions_security_workflow_passes(self): self.assertTrue(load('v13_github_actions_security_audit').audit(ROOT/'.github/workflows')['ok'])
    def test_actions_security_rejects_tag_pin_and_privileged_pr(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.yml'; p.write_text('on:\n  pull_request_target:\njobs:\n  x:\n    steps:\n      - uses: actions/checkout@v7\n'); r=load('v13_github_actions_security_audit').audit(p); self.assertFalse(r['ok']); self.assertGreaterEqual(r['findingCount'],2)
    def test_artifact_manifest_detects_drift(self):
        mod=load('v13_artifact_manifest')
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'out'; root.mkdir(); (root/'a.txt').write_text('one'); manifest=root.parent/'manifest.json'; manifest.write_text(json.dumps(mod.create(root,manifest))); self.assertTrue(mod.verify(root,manifest)['ok']); (root/'a.txt').write_text('two'); self.assertFalse(mod.verify(root,manifest)['ok'])
    def test_test_matrix_positive(self): d=json.loads((ROOT/'examples/v13/test-matrix.json').read_text()); self.assertTrue(load('v13_test_matrix_lint').lint(d)['ok'])
    def test_test_matrix_rejects_missing_critical_test(self): d=json.loads((ROOT/'examples/v13/test-matrix.json').read_text()); d['features'][0]['tests']=[]; self.assertFalse(load('v13_test_matrix_lint').lint(d)['ok'])
    def test_release_preflight_never_deploys(self):
        d=json.loads((ROOT/'examples/v13/release-candidate.json').read_text()); self.assertFalse(load('v13_release_preflight').evaluate(d)['eligible']); d['target']='staging'; d['checks']=[{'id':k,'status':'PASS','evidence':'evidence/'+k+'.txt'} for k in ['unit-tests','static-analysis','build']]; self.assertTrue(load('v13_release_preflight').evaluate(d)['eligible'])
if __name__=='__main__': unittest.main()
