#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
VALID=ROOT/'examples/v10/research/v10-research-decision-record.json'
LINTER=ROOT/'tools/v10_research_record_lint.py'
GATE=ROOT/'tools/v10_research_gate.py'

def run(*args): return subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,text=True,capture_output=True)

def main():
    good=run(LINTER,VALID)
    assert good.returncode==0, good.stdout+good.stderr
    data=json.loads(VALID.read_text())
    data['sources']=[s for s in data['sources'] if s['domain']=='rojo.space']
    with tempfile.TemporaryDirectory() as td:
        bad=Path(td)/'bad.json'; bad.write_text(json.dumps(data))
        result=run(LINTER,bad)
        assert result.returncode!=0 and 'official Roblox source' in result.stdout
    gate_ok=run(GATE,'--record',VALID,'--changed-file','AGENTS.md')
    assert gate_ok.returncode==0, gate_ok.stdout+gate_ok.stderr
    gate_bad=run(GATE,'--record',VALID,'--changed-file','src/NotCovered.lua')
    assert gate_bad.returncode!=0 and 'does not cover' in gate_bad.stdout
    print('PASS: V10 research record positive/negative and file-scope gate tests')
if __name__=='__main__': main()
