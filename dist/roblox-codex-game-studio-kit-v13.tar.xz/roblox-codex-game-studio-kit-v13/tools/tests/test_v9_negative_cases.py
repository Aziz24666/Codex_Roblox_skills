#!/usr/bin/env python3
"""Small negative-case regression tests for V9 package validators."""
from pathlib import Path
import json, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[2]
PY=sys.executable
def run(args):
    return subprocess.run(args,cwd=ROOT,text=True,capture_output=True)

# Duplicate family IDs must be rejected.
catalog=json.loads((ROOT/'examples/v9/catalog.json').read_text())
catalog['families'].append(dict(catalog['families'][0]))
with tempfile.TemporaryDirectory() as td:
    bad=Path(td)/'bad-catalog.json'; bad.write_text(json.dumps(catalog))
    result=run([PY,str(ROOT/'tools/v9_schema_catalog_lint.py'),'--catalog',str(bad)])
    assert result.returncode != 0, 'duplicate family IDs were not rejected'

# Invalid enum definition must fail JSON Schema validation.
with tempfile.TemporaryDirectory() as td:
    bad=Path(td)/'bad-definition.json'
    bad.write_text(json.dumps({'schemaVersion':1,'family':'NPC','id':'BadNPC','displayName':'Bad NPC'}))
    result=run([PY,str(ROOT/'tools/v9_definition_validate.py'),str(bad)])
    assert result.returncode != 0, 'missing NPC fields were not rejected'

# Invalid manifest status must be rejected.
manifest=json.loads((ROOT/'schemas/examples/v9-generated-content-manifest.example.json').read_text())
manifest['status']='OVERWRITE_PRODUCTION'
with tempfile.TemporaryDirectory() as td:
    bad=Path(td)/'bad-manifest.json'; bad.write_text(json.dumps(manifest))
    # Validator CLI uses the package's schema and a path relative to cwd; run a direct schema check here.
    try:
        import jsonschema
    except ImportError:
        raise SystemExit('jsonschema dependency missing')
    schema=json.loads((ROOT/'schemas/v9-generated-content-manifest.schema.json').read_text())
    errors=list(jsonschema.Draft202012Validator(schema).iter_errors(manifest))
    assert errors, 'invalid manifest status was not rejected'
print('PASS: duplicate family, missing required definition fields, and invalid manifest status were rejected')
