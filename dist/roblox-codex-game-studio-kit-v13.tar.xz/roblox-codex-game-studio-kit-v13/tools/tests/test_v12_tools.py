from __future__ import annotations
import importlib.util, json, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def load(name):
    path=ROOT/'tools'/f'{name}.py'
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(module); return module

class V12Tests(unittest.TestCase):
    def test_performance_budget_pass(self):
        baseline=json.loads((ROOT/'schemas/examples/v12-performance-baseline.example.json').read_text())
        budget=json.loads((ROOT/'schemas/examples/v12-performance-budget.example.json').read_text())
        self.assertTrue(load('v12_perf_budget_check').evaluate(baseline,budget)['ok'])
    def test_performance_budget_fail(self):
        baseline=json.loads((ROOT/'schemas/examples/v12-performance-baseline.example.json').read_text())
        budget=json.loads((ROOT/'schemas/examples/v12-performance-budget.example.json').read_text())
        baseline['metrics']['clientFrameTimeP95Ms']=999
        self.assertFalse(load('v12_perf_budget_check').evaluate(baseline,budget)['ok'])
    def test_analytics_catalog_pass(self):
        cat=json.loads((ROOT/'schemas/examples/v12-analytics-event-catalog.example.json').read_text())
        self.assertTrue(load('v12_analytics_catalog_lint').lint(cat)['ok'])
    def test_analytics_rejects_sensitive_field(self):
        cat=json.loads((ROOT/'schemas/examples/v12-analytics-event-catalog.example.json').read_text())
        cat['events'][0]['fields'].append('emailAddress')
        self.assertFalse(load('v12_analytics_catalog_lint').lint(cat)['ok'])
    def test_analytics_rejects_duplicate_name(self):
        cat=json.loads((ROOT/'schemas/examples/v12-analytics-event-catalog.example.json').read_text())
        cat['events'].append(dict(cat['events'][0]))
        self.assertFalse(load('v12_analytics_catalog_lint').lint(cat)['ok'])
    def test_streaming_audit_flags_script_property(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'Test.client.lua').write_text('workspace.StreamingEnabled = true\n')
            self.assertEqual(load('v12_streaming_risk_audit').scan(root)['findingCount'],1)
    def test_tag_lifecycle_audit_flags_incomplete(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'Binder.lua').write_text('CollectionService:GetInstanceAddedSignal("A"):Connect(function() end)\n')
            result=load('v12_tag_lifecycle_audit').audit(root)
            self.assertEqual(result['reviewCount'],1)
    def test_tag_lifecycle_audit_example_has_no_flags(self):
        result=load('v12_tag_lifecycle_audit').audit(ROOT/'examples/v12')
        self.assertEqual(result['reviewCount'],0,result)
    def test_v12_pack_doctor(self):
        result=load('v12_pack_doctor').run(ROOT)
        self.assertTrue(result['ok'],result['errors'])
        self.assertGreaterEqual(result['counts']['skills'],115)

if __name__=='__main__': unittest.main()
