from __future__ import annotations
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def load(name: str):
    path = ROOT / "tools" / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


class V11ToolTests(unittest.TestCase):
    def test_skill_audit(self):
        result = load("v11_skill_audit").audit(ROOT)
        self.assertTrue(result["ok"], result["errors"])
        self.assertGreaterEqual(result["skillCount"], 100)
        self.assertFalse(result["warnings"], result["warnings"])

    def test_research_lint(self):
        result = load("v11_research_lint").lint(ROOT / "research/decisions/V11_CONTEXT_AND_STUDIO_WORKFLOW.json")
        self.assertTrue(result["ok"], result["errors"])

    def test_release_gate_pass_and_fail(self):
        module = load("v11_release_gate")
        manifest = {
            "candidate": "0.1",
            "researchCurrent": True,
            "checks": [{"name": "schema", "status": "PASS", "evidence": "logs/schema.txt"}],
            "studioEvidenceRequired": True,
            "studioEvidence": ["studio-test-01"],
            "migrationRecovery": "Not applicable",
            "knownIssues": [],
            "rollback": "Revert candidate",
            "approvalState": "NOT REQUIRED",
        }
        self.assertTrue(module.evaluate(manifest)["ok"])
        manifest["checks"][0]["status"] = "FAIL"
        self.assertFalse(module.evaluate(manifest)["ok"])
        manifest["checks"][0]["status"] = "PASS"
        manifest["checks"][0]["evidence"] = "logs/schema.txt"
        manifest["studioEvidence"] = []
        self.assertFalse(module.evaluate(manifest)["ok"])

    def test_impact_transitive(self):
        module = load("v11_change_impact")
        graph = {
            "reverseDependencies": {"A": ["B"], "B": ["C"]},
            "nodes": [{"id": "A"}, {"id": "B"}, {"id": "C"}],
            "unresolved": [],
        }
        result = module.impact(graph, ["A"])
        self.assertEqual(result["dependentModules"], ["B", "C"])

    def test_relative_require_graph(self):
        module = load("v11_luau_require_graph")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "A.lua").write_text("local B = require(script.Parent.B)\nreturn B\n", encoding="utf-8")
            (root / "B.lua").write_text("return {}\n", encoding="utf-8")
            result = module.graph(root)
            a_node = next(node for node in result["nodes"] if node["id"] == "A")
            self.assertEqual(a_node["dependencies"], ["B"])
            self.assertEqual(result["cycles"], [])

    def test_dependency_cycle_detected(self):
        module = load("v11_luau_require_graph")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "A.lua").write_text("local B = require(script.Parent.B)\n", encoding="utf-8")
            (root / "B.lua").write_text("local A = require(script.Parent.A)\n", encoding="utf-8")
            result = module.graph(root)
            self.assertTrue(result["cycles"], result)

    def test_generated_drift_pass_and_fail(self):
        module = load("v11_generated_drift")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "generated.txt"
            target.write_text("stable output", encoding="utf-8")
            import hashlib
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            manifest = {"artifacts": [{"path": "generated.txt", "sha256": digest}]}
            self.assertTrue(module.check(root, manifest)["ok"])
            target.write_text("changed output", encoding="utf-8")
            self.assertFalse(module.check(root, manifest)["ok"])


if __name__ == "__main__":
    unittest.main()
