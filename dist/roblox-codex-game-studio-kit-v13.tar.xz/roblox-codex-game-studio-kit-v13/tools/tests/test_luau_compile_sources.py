from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from tools.compile_luau_sources import compile_sources, discover_sources

class CompileLuauSourcesTests(unittest.TestCase):
    def test_discovers_lua_and_luau_but_skips_caches(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.lua").write_text("return 1")
            (root / "b.luau").write_text("return 2")
            cache = root / "__pycache__"
            cache.mkdir()
            (cache / "c.lua").write_text("bad")
            self.assertEqual([p.name for p in discover_sources(root)], ["a.lua", "b.luau"])

    def test_missing_compiler_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.luau").write_text("return 1")
            with patch("tools.compile_luau_sources.shutil.which", return_value=None):
                result = compile_sources(root, "not-installed")
            self.assertFalse(result["ok"])

    def test_minimum_source_guard_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.luau").write_text("return 1")
            result = compile_sources(root, "/bin/true", min_files=2)
            self.assertFalse(result["ok"])

    def test_compiler_failure_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.luau").write_text("return 1")
            result = compile_sources(root, "/bin/false")
            self.assertFalse(result["ok"])
            self.assertEqual(result["compiled"], 0)
            self.assertEqual(result["failed"][0]["file"], "a.luau")

    def test_compiler_success_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.luau").write_text("return 1")
            result = compile_sources(root, "/bin/true")
            self.assertTrue(result["ok"])
            self.assertEqual(result["compiled"], 1)

if __name__ == "__main__":
    unittest.main()
