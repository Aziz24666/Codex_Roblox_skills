#!/usr/bin/env python3
"""Create/verify deterministic SHA-256 manifests for build output directories."""
from pathlib import Path
import argparse,hashlib,json,sys
EXCLUDE={'.git','__pycache__','.pytest_cache','node_modules'}
def entries(root: Path, manifest: Path|None=None):
    out=[]
    for p in sorted(root.rglob('*')):
        if any(part in EXCLUDE for part in p.parts) or not p.is_file(): continue
        if p.is_symlink(): raise ValueError(f'symlink not allowed in artifact manifest: {p}')
        if manifest and p.resolve()==manifest.resolve(): continue
        rel=p.relative_to(root).as_posix(); data=p.read_bytes()
        out.append({'path':rel,'sizeBytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return out
def create(root: Path, output: Path):
    root=root.resolve(); output=output.resolve()
    return {'schemaVersion':1,'algorithm':'sha256','files':entries(root,output)}
def verify(root: Path, manifest_path: Path):
    expected=json.loads(manifest_path.read_text(encoding='utf-8'))
    if expected.get('schemaVersion')!=1 or expected.get('algorithm')!='sha256': return {'ok':False,'errors':['unsupported manifest format']}
    actual=entries(root,manifest_path); exp=expected.get('files',[]); em={x.get('path'):x for x in exp}; am={x['path']:x for x in actual}; errors=[]
    for rel in sorted(set(em)-set(am)): errors.append(f'missing artifact: {rel}')
    for rel in sorted(set(am)-set(em)): errors.append(f'unexpected artifact: {rel}')
    for rel in sorted(set(am)&set(em)):
        if am[rel]!=em[rel]: errors.append(f'artifact changed: {rel}')
    return {'ok':not errors,'filesVerified':len(set(am)&set(em)),'errors':errors}
def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    c=sub.add_parser('create'); c.add_argument('root',type=Path); c.add_argument('output',type=Path)
    v=sub.add_parser('verify'); v.add_argument('root',type=Path); v.add_argument('manifest',type=Path)
    a=ap.parse_args()
    if a.cmd=='create':
        data=create(a.root,a.output); a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'ok':True,'files':len(data['files']),'output':str(a.output)},indent=2)); return
    r=verify(a.root,a.manifest); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
