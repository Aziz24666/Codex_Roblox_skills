#!/usr/bin/env python3
"""Check generated artifact hashes from a manifest without overwriting or regenerating files."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
def check(root,manifest):
    rows=[]
    for item in manifest.get("artifacts",[]):
        p=root/item["path"]
        if not p.is_file(): rows.append({"path":item["path"],"status":"MISSING"}); continue
        got=hashlib.sha256(p.read_bytes()).hexdigest(); expected=item.get("sha256")
        rows.append({"path":item["path"],"status":"PASS" if got==expected else "DRIFT","expected":expected,"actual":got})
    return {"ok":all(r['status']=='PASS' for r in rows),"artifacts":rows,"note":"This verifies recorded hashes only; it does not regenerate outputs."}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("root",type=Path); ap.add_argument("manifest",type=Path); a=ap.parse_args(); r=check(a.root,json.loads(a.manifest.read_text())); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=="__main__": main()
