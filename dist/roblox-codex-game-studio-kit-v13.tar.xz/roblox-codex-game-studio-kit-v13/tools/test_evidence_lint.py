#!/usr/bin/env python3
"""Check a Markdown test report for minimum evidence fields; does not validate truth."""
from pathlib import Path
import argparse, re, sys

REQUIRED = ['build', 'environment', 'setup', 'steps', 'expected result', 'actual result', 'status']
VALID = {'PASS', 'FAIL', 'BLOCKED', 'NOT RUN', 'NOT APPLICABLE'}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('report')
    args = ap.parse_args()
    path = Path(args.report)
    if not path.is_file(): raise SystemExit(f'Not a file: {path}')
    text = path.read_text(encoding='utf-8')
    lower = text.lower()
    missing = [x for x in REQUIRED if x not in lower]
    statuses = {m.upper() for m in re.findall(r'\b(PASS|FAIL|BLOCKED|NOT RUN|NOT APPLICABLE)\b', text, re.I)}
    if missing: print('Missing evidence labels: ' + ', '.join(missing))
    if not statuses: print('No recognized status found.')
    else: print('Recognized statuses: ' + ', '.join(sorted(statuses)))
    if missing or not statuses: raise SystemExit(1)
    print('Evidence fields are structurally present. This does not verify that tests actually ran or that results are truthful.')

if __name__ == '__main__': main()
