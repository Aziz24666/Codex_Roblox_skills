#!/usr/bin/env python3
"""Compare a benchmark JSON file with explicit max budgets."""
import argparse,json,math
from pathlib import Path
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("file");a=p.parse_args();d=json.loads(Path(a.file).read_text(encoding="utf-8"));e=[];rows=[]
 metrics=d.get("metrics",[])
 if not metrics: e.append("metrics must contain at least one measured value")
 for m in metrics:
  try:v=float(m["value"]);limit=float(m["max"])
  except (KeyError,TypeError,ValueError):e.append(f"{m.get('name','unknown')}: value/max must be numeric");continue
  if not math.isfinite(v) or not math.isfinite(limit):
   e.append(f"{m.get('name','unknown')}: value/max must be finite numbers");continue
  status="PASS" if v<=limit else "FAIL"
  rows.append((m.get("name"),v,limit,m.get("unit"),status))
 for name,v,lim,unit,status in rows:print(f"{status}: {name} {v:g} {unit} <= {lim:g} {unit}")
 for x in e:print("FAIL:",x)
 if e:return 1
 if any(r[-1]=="FAIL" for r in rows):return 1
 print("PASS: recorded metric values are within declared limits; measurement quality/environment were not verified")
 return 0
if __name__=="__main__":raise SystemExit(main())
