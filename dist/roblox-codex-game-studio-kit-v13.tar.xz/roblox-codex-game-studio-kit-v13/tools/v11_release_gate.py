#!/usr/bin/env python3
"""Evaluate a release evidence manifest; this gate never publishes or mutates Roblox resources."""
from __future__ import annotations
import argparse,json
from pathlib import Path
ALLOWED={"PASS","FAIL","BLOCKED","NOT RUN","NOT APPLICABLE"}
REQUIRED=["candidate","researchCurrent","checks","studioEvidenceRequired","studioEvidence","migrationRecovery","knownIssues","rollback","approvalState"]
def evaluate(d):
    errors=[]; warnings=[]
    for k in REQUIRED:
        if k not in d: errors.append(f"missing {k}")
    if d.get("researchCurrent") is not True: errors.append("researchCurrent must be true")
    checks=d.get("checks",[])
    for i,c in enumerate(checks):
        if c.get("status") not in ALLOWED: errors.append(f"check[{i}] invalid status")
        if c.get("status") in {"FAIL","BLOCKED","NOT RUN"}: errors.append(f"check[{i}] is {c.get('status')}")
        if c.get("status")=="PASS" and not c.get("evidence"): errors.append(f"check[{i}] PASS requires evidence")
    if d.get("studioEvidenceRequired") is True and not d.get("studioEvidence"): errors.append("Studio evidence is required but missing")
    if d.get("studioEvidenceRequired") is False and not d.get("studioEvidenceNotRequiredReason"): errors.append("explain why Studio evidence is not required")
    if not d.get("migrationRecovery"): errors.append("migrationRecovery must describe a plan or state not applicable")
    if not d.get("rollback"): errors.append("rollback plan is required")
    if d.get("approvalState") not in {"NOT REQUIRED","APPROVED","PENDING"}: errors.append("invalid approvalState")
    if d.get("approvalState")=="PENDING": errors.append("required approval is still pending")
    return {"ok":not errors,"errors":errors,"warnings":warnings,"action":"READY FOR HUMAN RELEASE REVIEW" if not errors else "NOT READY"}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("manifest",type=Path); a=ap.parse_args(); r=evaluate(json.loads(a.manifest.read_text(encoding="utf-8"))); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=="__main__": main()
