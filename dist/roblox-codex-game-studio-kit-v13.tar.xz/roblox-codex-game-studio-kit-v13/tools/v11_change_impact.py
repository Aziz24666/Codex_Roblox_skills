#!/usr/bin/env python3
"""Estimate transitive reverse dependencies for changed module IDs using a V11 require graph."""
from __future__ import annotations
import argparse,json
from pathlib import Path
def impact(graph,changed):
    reverse=graph.get("reverseDependencies",{}); known={n["id"] for n in graph.get("nodes",[])}; queue=list(changed); impacted=set(); unknown=[]
    for c in changed:
        if c not in known: unknown.append(c)
    while queue:
        item=queue.pop(0)
        for dep in reverse.get(item,[]):
            if dep not in impacted and dep not in changed: impacted.add(dep); queue.append(dep)
    return {"changed":changed,"unknownChangedIds":unknown,"dependentModules":sorted(impacted),"manualReviewRequired":bool(graph.get("unresolved")),"limitations":graph.get("limitations",[])}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("graph",type=Path); ap.add_argument("changed",nargs="+"); args=ap.parse_args(); g=json.loads(args.graph.read_text()); r=impact(g,args.changed); print(json.dumps(r,indent=2))
if __name__=="__main__": main()
