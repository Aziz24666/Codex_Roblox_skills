#!/usr/bin/env python3
"""Validate V4 package structure, skill metadata, local Markdown links, and Python syntax."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
errors = []
for name in ['AGENTS.md','README.md','INDEX.md','CHANGELOG.md','PACKAGE_INVENTORY.md']:
    if not (ROOT / name).is_file(): errors.append(f'Missing root file: {name}')
skills = sorted((ROOT / '.agents/skills').glob('*/SKILL.md'))
if len(skills) < 30: errors.append(f'Expected at least 30 skills; found {len(skills)}')
names = set()
for path in skills:
    text = path.read_text(encoding='utf-8')
    if not text.startswith('---\n'): errors.append(f'{path}: missing YAML frontmatter'); continue
    end = text.find('\n---\n', 4)
    if end < 0: errors.append(f'{path}: unterminated frontmatter'); continue
    front = text[4:end]
    name = next((x.split(':',1)[1].strip() for x in front.splitlines() if x.startswith('name:')), '')
    desc = next((x.split(':',1)[1].strip() for x in front.splitlines() if x.startswith('description:')), '')
    if name != path.parent.name: errors.append(f'{path}: name must match folder')
    if not desc: errors.append(f'{path}: missing description')
    if name in names: errors.append(f'duplicate skill name: {name}')
    names.add(name)
required = ['docs/V4_AUTONOMOUS_FEATURE_EXECUTION_LOOP.md','docs/V4_AUTOMATION_AND_QUALITY_GATES.md','docs/V4_GENRE_PRODUCTION_PIPELINES.md','docs/V4_STUDIO_TESTING_PLAYBOOK.md','prompts/39_V4_HANDOFF_AND_CONTINUATION.md','templates/DEFINITION_OF_DONE_TEMPLATE.md','tools/project_doctor.py','tools/luau_pattern_audit.py','tools/test_evidence_lint.py','tools/file_manifest.py','examples/luau-patterns/RemoteRequestValidation.server.luau','project-template/default.project.json']
for rel in required:
    if not (ROOT / rel).is_file(): errors.append(f'Missing required file: {rel}')
for md in ROOT.rglob('*.md'):
    try: text = md.read_text(encoding='utf-8')
    except Exception as exc: errors.append(f'Cannot read {md}: {exc}'); continue
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', text):
        t = target.split('#',1)[0]
        if not t or '://' in t or t.startswith(('mailto:', '#')): continue
        if not (md.parent / t).resolve().exists(): errors.append(f'Broken link {md.relative_to(ROOT)} -> {t}')
for py in ROOT.rglob('*.py'):
    try: compile(py.read_text(encoding='utf-8'), str(py), 'exec')
    except (SyntaxError, UnicodeDecodeError) as exc: errors.append(f'Python syntax error {py}: {exc}')
if errors:
    print('V4 PACKAGE CHECK FAILED')
    for e in errors: print(' - ' + e)
    raise SystemExit(1)
print(f'V4 package structure OK: {len(skills)} skills, {len(list(ROOT.rglob("*.md")))} Markdown files.')
print('Python utilities compile. Local Markdown links resolve.')
print('This check does not compile Luau, build Rojo, execute Studio, or prove gameplay/security.')
