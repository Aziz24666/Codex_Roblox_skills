#!/usr/bin/env python3
"""Heuristic audit for CollectionService tag registration lifecycle coverage."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

def audit(root: Path) -> dict:
    rows=[]
    for p in sorted(list(root.rglob("*.lua"))+list(root.rglob("*.luau"))):
        if any(x in p.parts for x in {".git","node_modules","__pycache__"}): continue
        text=p.read_text(encoding="utf-8",errors="replace")
        if "CollectionService" not in text: continue
        added=bool(re.search(r"GetInstanceAddedSignal\s*\(",text))
        removed=bool(re.search(r"GetInstanceRemovedSignal\s*\(",text))
        initial=bool(re.search(r"GetTagged\s*\(",text))
        cleanup=bool(re.search(r"Disconnect\s*\(|:Destroy\s*\(|cleanup|Cleanup|Stop\s*\(",text))
        findings=[]
        if added and not removed: findings.append("added signal found without a removed-signal reference")
        if added and not initial: findings.append("added signal found without an initial GetTagged pass")
        if added and not cleanup: findings.append("tag-driven file has no obvious cleanup marker")
        if findings: rows.append({"file":str(p.relative_to(root)),"findings":findings,"confidence":"review-needed"})
    return {"ok":True,"reviewCount":len(rows),"files":rows,"limitation":"Text heuristics can miss indirect cleanup or report false positives; review ownership and runtime behavior manually."}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("root",type=Path); ap.add_argument("--output",type=Path); a=ap.parse_args(); result=audit(a.root); out=json.dumps(result,indent=2); print(out)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(out+"\n",encoding="utf-8")
if __name__=="__main__": main()
