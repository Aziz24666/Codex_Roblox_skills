#!/usr/bin/env python3
"""Evaluate release evidence only. Never publishes, writes Roblox data, or calls Open Cloud."""
import argparse,json
from pathlib import Path
REQUIRED={'unit-tests','static-analysis','build'}
def evaluate(data):
    errors=[]; checks=data.get('checks',[]); by={c.get('id'):c for c in checks}
    if data.get('deploymentPerformed') is not False: errors.append('preflight document must declare deploymentPerformed=false')
    if not data.get('sourceRevision') or len(data.get('sourceRevision',''))!=40: errors.append('sourceRevision must be a 40-character commit hash')
    for cid in REQUIRED:
        if cid not in by: errors.append(f'missing required check {cid}')
        elif by[cid].get('status')!='PASS': errors.append(f'required check {cid} is not PASS')
        elif not by[cid].get('evidence'): errors.append(f'required check {cid} lacks evidence path')
    if data.get('target')=='production':
        approval=data.get('manualApproval',{})
        if not approval.get('approved') or not approval.get('approver') or not approval.get('approvedAt'): errors.append('production candidate requires explicit manual approval metadata')
        if not data.get('migrationPlan') or not data.get('rollbackPlan'): errors.append('production candidate requires migration and rollback plans')
    return {'eligible':not errors,'deploymentPerformed':False,'errors':errors,'note':'This is evidence preflight only; no deployment is performed.'}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('candidate',type=Path); a=ap.parse_args(); r=evaluate(json.loads(a.candidate.read_text())); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['eligible'] else 1)
if __name__=='__main__': main()
