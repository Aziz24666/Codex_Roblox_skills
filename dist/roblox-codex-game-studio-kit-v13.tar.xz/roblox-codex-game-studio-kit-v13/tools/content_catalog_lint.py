#!/usr/bin/env python3
"""Validate basic structure and cross-reference IDs in a JSON content catalog."""
import argparse,json,re
from pathlib import Path
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("file");a=p.parse_args();d=json.loads(Path(a.file).read_text(encoding="utf-8"));items=d.get("items",[]);e=[];ids=set()
 for i,x in enumerate(items):
  iid=x.get("id") if isinstance(x,dict) else None
  if not isinstance(iid,str) or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{1,63}",iid):e.append(f"items[{i}]: invalid id {iid!r}");continue
  if iid in ids:e.append(f"duplicate id: {iid}")
  ids.add(iid)
  for key in ("kind","availability"):
   if not x.get(key):e.append(f"{iid}: missing {key}")
  if x.get("availability") not in ("ACTIVE","DISABLED","RETIRED"):e.append(f"{iid}: unsupported availability")
 for i,x in enumerate(items):
  for ref in x.get("references",[]) if isinstance(x,dict) else []:
   if ref not in ids:e.append(f"items[{i}]: missing referenced id {ref}")
 print(f"Catalog items: {len(items)}")
 for x in e:print("FAIL:",x)
 if e:return 1
 print("PASS: catalog structure and local references only; no asset permissions or gameplay behavior verified")
 return 0
if __name__=="__main__":raise SystemExit(main())
