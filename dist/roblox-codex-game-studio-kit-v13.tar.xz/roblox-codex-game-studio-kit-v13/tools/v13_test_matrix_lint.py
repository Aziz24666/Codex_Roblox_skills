#!/usr/bin/env python3
"""Verify that priority features reference defined tests and no test IDs collide."""
import argparse,json
from pathlib import Path
def lint(data):
    errors=[]; tests=data.get('tests',[]); features=data.get('features',[]); ids=[t.get('id') for t in tests]
    if len(ids)!=len(set(ids)): errors.append('duplicate test IDs')
    known={x for x in ids if isinstance(x,str)}
    for t in tests:
        if t.get('status')=='PASS' and not t.get('evidence'): errors.append(f"passing test {t.get('id')} has no evidence")
    for f in features:
        refs=f.get('tests',[])
        if f.get('priority') in {'P0','P1'} and not refs: errors.append(f"critical feature {f.get('id')} has no tests")
        for ref in refs:
            if ref not in known: errors.append(f"feature {f.get('id')} references unknown test {ref}")
    return {'ok':not errors,'featureCount':len(features),'testCount':len(tests),'errors':errors}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('matrix',type=Path); a=ap.parse_args(); r=lint(json.loads(a.matrix.read_text())); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
