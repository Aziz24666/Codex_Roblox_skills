#!/usr/bin/env python3
"""Heuristic scanner for source patterns that deserve streaming review."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

PATTERNS = [
    ("workspace_streaming_property_in_script", re.compile(r"(?:Workspace|workspace)\.StreamingEnabled\s*="), "StreamingEnabled is a Studio property; do not set it from a script."),
    ("workspace_waitforchild", re.compile(r"(?:Workspace|workspace)\s*:\s*WaitForChild\s*\("), "Check whether this Workspace target can stream out or never stream in on the client."),
    ("persistent_model_mode", re.compile(r"ModelStreamingMode\s*=\s*Enum\.ModelStreamingMode\.Persistent"), "Persistent model usage needs a documented reason and memory/replication review."),
]

def scan(root: Path) -> dict:
    findings=[]
    for path in sorted(list(root.rglob("*.lua")) + list(root.rglob("*.luau"))):
        if any(part in {".git", "node_modules", "__pycache__"} for part in path.parts): continue
        try: lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError: continue
        for line_no, line in enumerate(lines, 1):
            stripped=line.strip()
            if stripped.startswith("--"): continue
            for key, pattern, message in PATTERNS:
                if pattern.search(line): findings.append({"file":str(path.relative_to(root)),"line":line_no,"rule":key,"message":message,"confidence":"review-needed"})
    return {"ok":True,"findingCount":len(findings),"findings":findings,"limitation":"Heuristic source scan only; absence of findings is not proof of streaming correctness."}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("root",type=Path); ap.add_argument("--output",type=Path); a=ap.parse_args(); result=scan(a.root); out=json.dumps(result,indent=2); print(out)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(out+"\n",encoding="utf-8")
if __name__=="__main__": main()
