#!/usr/bin/env python3
"""Heuristic maintainability audit for Luau modules; findings require human review."""
from __future__ import annotations
import argparse, re
from pathlib import Path

PATTERNS=[
 ('warning','heartbeat-loop',re.compile(r'RunService\s*\.\s*Heartbeat\s*:\s*Connect|RunService\s*\.\s*Heartbeat\s*\.\s*Connect'), 'Review high-frequency work; measure before optimizing.'),
 ('warning','unbounded-loop',re.compile(r'while\s+true\s+do'), 'Confirm there is a bounded wait, cancellation, and cleanup path.'),
 ('warning','dynamic-require',re.compile(r'require\s*\(\s*(?:\d+|[A-Za-z_][A-Za-z0-9_]*\s*\[)'), 'Review dynamic module loading and trust boundary.'),
 ('info','remote-handler',re.compile(r'OnServerEvent\s*:\s*Connect'), 'Review server-side type, bounds, ownership, state, distance, and rate validation.'),
 ('info','datastore-call',re.compile(r'(?:GetAsync|SetAsync|UpdateAsync|IncrementAsync)\s*\('), 'Review current DataStore guidance, concurrency, retry order, and error outcomes.'),
]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',default='.')
    ap.add_argument('--max-lines',type=int,default=500)
    ap.add_argument('--out',default='artifacts/V10_ARCHITECTURE_AUDIT.md')
    args=ap.parse_args(); root=Path(args.root).resolve(); findings=[]; count=0
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in {'.lua','.luau'}: continue
        if any(x in p.parts for x in {'.git','node_modules','target','build','dist','__pycache__'}): continue
        try: content=p.read_text(encoding='utf-8')
        except Exception: continue
        count+=1; rel=str(p.relative_to(root)).replace('\\','/'); lines=content.splitlines()
        if len(lines)>args.max_lines: findings.append(('warning','large-module',rel,1,f'{len(lines)} lines; consider splitting by responsibility only if cohesion is poor.'))
        if not content.lstrip().startswith('--!strict') and p.suffix.lower()=='.lua':
            findings.append(('info','no-strict-directive',rel,1,'Consider --!strict for new or substantially modified modules; verify incrementally.'))
        for severity,code,pattern,message in PATTERNS:
            for i,line in enumerate(lines,1):
                if pattern.search(line): findings.append((severity,code,rel,i,message))
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    text=['# V10 Architecture Quality Audit','',f'- Files scanned: {count}',f'- Findings: {len(findings)}','', '| Severity | Finding | File | Line | Review guidance |','|---|---|---|---:|---|']
    text += [f'| {s.upper()} | `{c}` | `{f}` | {ln} | {m} |' for s,c,f,ln,m in findings]
    text += ['', '## Limitations','', '- Heuristic scan only; it can produce false positives and miss real issues.', '- It does not parse Luau, resolve types, understand control flow, or prove security/performance defects.', '- Treat findings as review prompts, not automatic defects or a release certification.']
    out.write_text('\n'.join(text)+'\n',encoding='utf-8')
    print(f'Scanned {count} Luau file(s); {len(findings)} review finding(s). Wrote {out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
