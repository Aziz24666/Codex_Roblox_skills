#!/usr/bin/env python3
"""Report available Luau/Roblox CLI tools without installing or updating anything."""
import argparse,json,shutil,subprocess
TOOLS=['luau','luau-analyze','stylua','selene','rojo','rokit','lune']
def report():
    rows=[]
    for name in TOOLS:
        path=shutil.which(name)
        if not path: rows.append({'tool':name,'status':'MISSING','path':None,'version':None}); continue
        version=None
        for flag in ('--version','-V','version'):
            try:
                r=subprocess.run([path,flag],capture_output=True,text=True,timeout=4)
                out=(r.stdout+' '+r.stderr).strip()
                if out: version=out.splitlines()[0][:200]; break
            except Exception: pass
        rows.append({'tool':name,'status':'AVAILABLE','path':path,'version':version})
    return {'tools':rows,'note':'Inspection only. No installation, download, upgrade, or project mutation performed.'}
def main():
    argparse.ArgumentParser().parse_args(); print(json.dumps(report(),indent=2))
if __name__=='__main__': main()
