#!/usr/bin/env python3
"""Validate V9 definition JSON examples using the V9 definition JSON Schema."""
import argparse, json, sys
from pathlib import Path
try:
 from jsonschema import Draft202012Validator
except ImportError:
 Draft202012Validator=None
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(); p.add_argument('--all',action='store_true'); p.add_argument('paths',nargs='*'); a=p.parse_args()
 schema=json.loads((ROOT/'schemas/v9-content-definition.schema.json').read_text(encoding='utf-8'))
 if Draft202012Validator is None:
  print('BLOCKED: install jsonschema to run full schema validation'); return 2
 files=[]
 if a.all: files=sorted((ROOT/'examples/v9/definitions').glob('*.json'))
 files += [Path(x) if Path(x).is_absolute() else Path.cwd()/x for x in a.paths]
 if not files: p.error('provide JSON paths or --all')
 validator=Draft202012Validator(schema); errors=[]
 for file in files:
  try: data=json.loads(file.read_text(encoding='utf-8'))
  except Exception as e: errors.append(f'{file}: JSON parse: {e}'); continue
  for issue in validator.iter_errors(data): errors.append(f'{file}: {list(issue.path)}: {issue.message}')
 if errors:
  print('\n'.join('ERROR '+x for x in errors)); return 1
 print(f'PASS: {len(files)} definitions validated')
 return 0
if __name__=='__main__': raise SystemExit(main())
