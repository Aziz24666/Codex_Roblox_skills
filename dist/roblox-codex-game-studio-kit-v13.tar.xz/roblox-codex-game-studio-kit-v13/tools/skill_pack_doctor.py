#!/usr/bin/env python3
"""Check basic .agents/skills layout and SKILL.md name/description frontmatter."""
import argparse, re
from pathlib import Path
NAME = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
def parse(text):
    if not text.startswith('---\n'): return None, 'missing opening frontmatter'
    end = text.find('\n---\n', 4)
    if end < 0: return None, 'missing closing frontmatter'
    values = {}
    for line in text[4:end].splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        if ':' not in line: return None, f'invalid line: {line}'
        key, value = line.split(':', 1); values[key.strip()] = value.strip().strip('"\'')
    return values, None
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('root',nargs='?',default='.'); args=ap.parse_args()
    skills=Path(args.root).resolve()/'.agents'/'skills'
    if not skills.is_dir(): print('FAIL: .agents/skills not found'); return 2
    errors=[]; warnings=[]; count=0
    for folder in sorted(p for p in skills.iterdir() if p.is_dir()):
        count+=1; file=folder/'SKILL.md'
        if not file.is_file(): errors.append(f'{folder.name}: missing SKILL.md'); continue
        raw=file.read_text(encoding='utf-8'); meta,err=parse(raw)
        if err: errors.append(f'{folder.name}: {err}'); continue
        name=meta.get('name',''); desc=meta.get('description','')
        if not NAME.fullmatch(name): errors.append(f'{folder.name}: invalid name {name!r}')
        if name != folder.name: errors.append(f'{folder.name}: frontmatter name mismatch {name!r}')
        if len(desc)<20: errors.append(f'{folder.name}: description too short')
        if len(raw.splitlines())>600: warnings.append(f'{folder.name}: long SKILL.md; consider references')
    print(f'Skills checked: {count}')
    for w in warnings: print('WARN:',w)
    for e in errors: print('FAIL:',e)
    if errors: return 1
    print('PASS: basic skill metadata/layout only; Codex runtime behavior not tested')
    return 0
if __name__=='__main__': raise SystemExit(main())
