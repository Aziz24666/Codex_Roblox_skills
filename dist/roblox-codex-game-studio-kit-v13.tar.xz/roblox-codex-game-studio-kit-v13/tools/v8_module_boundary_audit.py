#!/usr/bin/env python3
"""Heuristic scan for Luau require sites and obvious layer-boundary smells."""
import argparse,re
from pathlib import Path
REQUIRE=re.compile(r'require\s*\(?\s*([\w.:/]+)')
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('root'); ap.add_argument('--out'); a=ap.parse_args(); root=Path(a.root)
    if not root.exists(): print('FAIL: root not found'); return 2
    lines=['# V8 Module Boundary Audit','',f'Root: `{root}`','', '> Heuristic only. Dynamic requires and Roblox DataModel paths may not be resolved accurately.','']
    count=0; warnings=[]
    for p in sorted(root.rglob('*.lua')):
        if any(x in p.parts for x in ('.git','node_modules')): continue
        text=p.read_text(encoding='utf-8',errors='replace'); count+=1
        req=REQUIRE.findall(text)
        lines += [f'## `{p}`',f'- require sites: {len(req)}']
        lines += [f'  - `{r}`' for r in req]
        if 'Workspace' in text and ('shared' in [x.lower() for x in p.parts] or 'Config' in p.parts):
            warnings.append(f'{p}: shared/config path mentions Workspace; inspect execution-side boundary')
        if 'GetService("RunService")' in text and 'Config' in p.parts:
            warnings.append(f'{p}: config module appears to access RunService; inspect side effects')
        lines.append('')
    lines += ['## Warnings'] + ([f'- {w}' for w in warnings] if warnings else ['- No heuristic warnings found.'])
    report='\n'.join(lines)
    if a.out: Path(a.out).parent.mkdir(parents=True, exist_ok=True); Path(a.out).write_text(report+'\n',encoding='utf-8')
    else: print(report)
    print(f'\nScanned {count} Luau files. Review findings manually; this is not a compiler or dependency resolver.')
    return 0
if __name__=='__main__': raise SystemExit(main())
