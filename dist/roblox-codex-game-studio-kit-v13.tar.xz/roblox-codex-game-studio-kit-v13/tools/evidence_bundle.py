#!/usr/bin/env python3
"""Create a Markdown report and validate evidence paths in a test-evidence JSON bundle."""
import argparse,json
from pathlib import Path
STATUSES={"PASS","FAIL","BLOCKED","NOT RUN","NOT APPLICABLE"}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("file");p.add_argument("--out",default="TEST_EVIDENCE_REPORT.md");a=p.parse_args();src=Path(a.file).resolve();d=json.loads(src.read_text(encoding="utf-8"));tests=d.get("tests",[]);errors=[];rows=[]
 for i,t in enumerate(tests):
  tid=t.get("id",f"row-{i}");status=t.get("status")
  if status not in STATUSES:errors.append(f"{tid}: invalid status {status!r}")
  if status in ("BLOCKED","NOT RUN") and not t.get("reason"):errors.append(f"{tid}: blocked/not-run status requires a reason")
  ep=t.get("evidence_path")
  exists=bool(ep and (src.parent/ep).exists())
  if status in ("PASS","FAIL") and not exists:errors.append(f"{tid}: executed status requires an existing evidence_path")
  for k in ("environment","command","expected","actual"):
   if status in ("PASS","FAIL") and not t.get(k):errors.append(f"{tid}: executed status requires {k}")
  rows.append(f"| {tid} | {status} | {t.get('environment','')} | {ep or ''} | {'yes' if exists else 'no'} |")
 out=["# Test Evidence Bundle", "", f"Source: `{src.name}`", "", "| Test | Status | Environment | Evidence path | Exists |", "|---|---|---|---|---|", *rows, "", "## Validation", *([f"- FAIL: {e}" for e in errors] or ["- PASS: evidence bundle structure and local path existence only."]), "", "This report does not independently prove that a test actually executed or that its result is correct."]
 Path(a.out).parent.mkdir(parents=True, exist_ok=True)
 Path(a.out).write_text("\n".join(out)+"\n",encoding="utf-8")
 print(f"Tests: {len(tests)}; errors: {len(errors)}; report: {a.out}")
 for e in errors:print("FAIL:",e)
 return 1 if errors else 0
if __name__=="__main__":raise SystemExit(main())
