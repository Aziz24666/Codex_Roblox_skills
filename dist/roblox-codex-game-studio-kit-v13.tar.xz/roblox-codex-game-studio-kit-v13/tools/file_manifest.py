#!/usr/bin/env python3
"""Create or verify a SHA-256 file manifest for local handoff integrity."""
from pathlib import Path
import argparse, hashlib, sys

SKIP = {'.git', 'node_modules', '__pycache__', '.venv'}

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='command', required=True)
    c = sub.add_parser('create'); c.add_argument('root'); c.add_argument('--out', required=True)
    v = sub.add_parser('verify'); v.add_argument('root'); v.add_argument('manifest')
    args = ap.parse_args(); root = Path(args.root).resolve()
    if not root.is_dir(): raise SystemExit(f'Not a directory: {root}')
    if args.command == 'create':
        out = Path(args.out).resolve()
        rows = []
        for p in sorted(root.rglob('*')):
            if not p.is_file() or any(x in SKIP for x in p.relative_to(root).parts) or p.resolve() == out: continue
            rows.append(f'{digest(p)}  {p.relative_to(root).as_posix()}')
        out.parent.mkdir(parents=True, exist_ok=True); out.write_text('\n'.join(rows) + '\n', encoding='utf-8')
        print(f'Wrote {len(rows)} entries to {out}')
    else:
        manifest = Path(args.manifest)
        errors = []
        for line in manifest.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            try: expected, rel = line.split('  ', 1)
            except ValueError: errors.append(f'Malformed row: {line}'); continue
            target = (root / rel).resolve()
            try: target.relative_to(root)
            except ValueError: errors.append(f'Path escapes root: {rel}'); continue
            if not target.is_file(): errors.append(f'Missing: {rel}')
            elif digest(target) != expected: errors.append(f'Hash mismatch: {rel}')
        if errors:
            print('\n'.join(errors)); raise SystemExit(1)
        print('All listed files match their SHA-256 hashes. Files added after manifest creation are not detected.')

if __name__ == '__main__': main()
