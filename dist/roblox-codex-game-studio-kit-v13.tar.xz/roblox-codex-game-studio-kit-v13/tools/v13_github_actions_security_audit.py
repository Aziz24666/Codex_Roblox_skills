#!/usr/bin/env python3
"""Heuristic GitHub Actions audit. This is not a complete workflow security proof."""
from pathlib import Path
import argparse,json,re
SHA=re.compile(r'^[0-9a-fA-F]{40}$')
def audit(path: Path):
    files=[path] if path.is_file() else sorted([*path.glob('*.yml'),*path.glob('*.yaml')])
    findings=[]; inspected=0
    for file in files:
        text=file.read_text(encoding='utf-8',errors='replace'); inspected+=1
        try:
            import yaml
            yaml.load(text, Loader=yaml.BaseLoader)
        except ImportError:
            findings.append({'file':str(file),'severity':'REVIEW','message':'PyYAML unavailable; YAML syntax parse was not performed'})
        except Exception as exc:
            findings.append({'file':str(file),'severity':'HIGH','message':f'YAML syntax parse failed: {exc}'})
        low=text.lower()
        if re.search(r'^\s*pull_request_target\s*:',text,re.M): findings.append({'file':str(file),'severity':'HIGH','message':'pull_request_target requires a dedicated privileged-workflow review'})
        if not re.search(r'^\s*permissions\s*:',text,re.M): findings.append({'file':str(file),'severity':'HIGH','message':'missing explicit top-level permissions block'})
        if 'secrets.' in low and re.search(r'^\s*pull_request\s*:',text,re.M): findings.append({'file':str(file),'severity':'REVIEW','message':'secret reference in pull_request workflow; verify fork and same-repo threat model'})
        for line_no,line in enumerate(text.splitlines(),1):
            m=re.search(r'\buses:\s*([^\s#]+)',line)
            if m:
                ref=m.group(1).rsplit('@',1)[-1]
                if not SHA.fullmatch(ref): findings.append({'file':str(file),'line':line_no,'severity':'HIGH','message':f'action is not pinned to a full 40-character SHA: {m.group(1)}'})
        if re.search(r'github\.event\.(issue|pull_request)\.(title|body)',text) and re.search(r'^\s*run\s*:',text,re.M):
            findings.append({'file':str(file),'severity':'REVIEW','message':'review untrusted event text for shell interpolation/script injection'})
        if 'actions/checkout@' in text and 'persist-credentials: false' not in text:
            findings.append({'file':str(file),'severity':'REVIEW','message':'consider persist-credentials: false when checkout credentials are not needed'})
    errors=[x for x in findings if x['severity']=='HIGH']
    return {'ok':not errors,'filesInspected':inspected,'findingCount':len(findings),'findings':findings,'note':'Heuristic review only; not CodeQL or a complete security assessment.'}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path',type=Path); a=ap.parse_args(); r=audit(a.path); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
