#!/usr/bin/env python3
"""Check required fields and acceptance/test links in a V7 feature spec."""
import argparse,json
from pathlib import Path
REQ=["id","title","player_outcome","scope","non_goals","acceptance_criteria","test_plan"]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("file");a=p.parse_args();d=json.loads(Path(a.file).read_text(encoding="utf-8"));e=[]
 for k in REQ:
  if k not in d or d[k] in (None,"") or d[k]==[]:e.append(f"missing/empty: {k}")
 ac=d.get("acceptance_criteria",[]);tests=d.get("test_plan",[]);tids={x.get("id") for x in tests if isinstance(x,dict)}
 for i,x in enumerate(ac):
  if not isinstance(x,dict) or not x.get("id") or not x.get("description"):e.append(f"acceptance_criteria[{i}] needs id and description")
  elif not set(x.get("test_ids",[])).issubset(tids):e.append(f"{x['id']}: references unknown test id")
 print(f"Acceptance criteria: {len(ac)}; tests: {len(tests)}")
 for x in e:print("FAIL:",x)
 if e:return 1
 print("PASS: required feature-spec fields and trace links only; no behavior verified")
 return 0
if __name__=="__main__":raise SystemExit(main())
