#!/usr/bin/env python3
"""Validate V10 research decision records. This checks record quality, not source truth."""
from __future__ import annotations
import argparse, json
from datetime import date
from pathlib import Path

OFFICIAL_TYPES = {"official_roblox_docs", "official_api_reference", "official_roblox_release_notes", "official_roblox_announcement"}

def lint(path: Path, require_today: bool = False):
    issues=[]
    try: data=json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc: return [f"{path}: invalid JSON: {exc}"]
    required=["recordId","recordType","task","decisionType","researchedAt","scopeFiles","queries","sources","apiSurface","approachesCompared","chosenApproach","decisionRationale","constraints","assumptions","verificationPlan","recheckTriggers","status"]
    for key in required:
        if key not in data: issues.append(f"missing required field: {key}")
    for key in ("recordId","task","chosenApproach","decisionRationale"):
        if not isinstance(data.get(key),str) or not data[key].strip(): issues.append(f"{key} must be a non-empty string")
    if data.get("recordType") not in ("task","baseline-example"):
        issues.append("recordType must be task or baseline-example")
    try:
        researched=date.fromisoformat(data.get("researchedAt",""))
        if require_today and researched != date.today(): issues.append(f"researchedAt must be today's date ({date.today().isoformat()})")
    except Exception: issues.append("researchedAt must be YYYY-MM-DD")
    for key in ("scopeFiles","queries","sources","verificationPlan","recheckTriggers"):
        if not isinstance(data.get(key),list) or not data[key]: issues.append(f"{key} must be a non-empty array")
    sources=data.get("sources",[])
    if isinstance(sources,list):
        if len(sources)<2: issues.append("at least two sources are required for an online comparison")
        domains=set(); has_official=False; fresh=False
        for i,s in enumerate(sources):
            if not isinstance(s,dict): issues.append(f"sources[{i}] must be an object"); continue
            for k in ("title","url","domain","sourceType","accessedAt","claim","limitations"):
                if not isinstance(s.get(k),str) or not s[k].strip(): issues.append(f"sources[{i}].{k} must be non-empty")
            if not str(s.get("url","")).startswith("https://"): issues.append(f"sources[{i}].url must use https")
            domains.add(s.get("domain",""))
            if s.get("sourceType") in OFFICIAL_TYPES: has_official=True
            if s.get("accessedAt")==data.get("researchedAt"): fresh=True
            try: date.fromisoformat(s.get("accessedAt",""))
            except Exception: issues.append(f"sources[{i}].accessedAt must be YYYY-MM-DD")
        if len(domains)<2: issues.append("sources must cover at least two distinct domains when comparing approaches")
        if not has_official: issues.append("at least one source must be an official Roblox source")
        if not fresh: issues.append("at least one source must have been accessed on researchedAt")
    dtype=data.get("decisionType")
    options=data.get("approachesCompared",[])
    if dtype in {"architecture","tooling","pattern","security","performance","plugin"} and (not isinstance(options,list) or len(options)<2):
        issues.append(f"decisionType {dtype} requires at least two compared approaches")
    if data.get("status") not in {"RESEARCHED","NEEDS_SPIKE","BLOCKED","SUPERSEDED"}: issues.append("invalid status")
    return issues

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("records",nargs="+",help="JSON research records")
    ap.add_argument("--require-today",action="store_true",help="Require researchedAt to match the current date")
    args=ap.parse_args(); failures=0
    for name in args.records:
        path=Path(name); issues=lint(path,args.require_today)
        if issues:
            failures+=1; print(f"FAIL {path}")
            for issue in issues: print(f"  - {issue}")
        else: print(f"PASS {path}")
    return 1 if failures else 0
if __name__=="__main__": raise SystemExit(main())
