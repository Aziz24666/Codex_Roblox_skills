#!/usr/bin/env python3
"""Audit rokit.toml exact pins. Missing lock file is reported as not applicable."""
import argparse,json,re,tomllib
from pathlib import Path
FLOATING={'latest','master','main','stable','*','head'}
def audit(path: Path):
    if not path.exists(): return {'status':'NOT APPLICABLE','ok':True,'tools':[],'errors':[]}
    data=tomllib.loads(path.read_text(encoding='utf-8')); tools=data.get('tools',{}); errors=[]; rows=[]
    if not isinstance(tools,dict) or not tools: errors.append('rokit.toml [tools] table is empty or invalid')
    for name,spec in tools.items():
        value=str(spec); version=value.rsplit('@',1)[-1]
        if version.lower() in FLOATING or not re.search(r'\d+\.\d+\.\d+',version): errors.append(f'{name}: not pinned to an exact version: {value}')
        rows.append({'name':name,'value':value})
    return {'status':'PASS' if not errors else 'FAIL','ok':not errors,'tools':rows,'errors':errors}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path',nargs='?',type=Path,default=Path('rokit.toml')); a=ap.parse_args(); r=audit(a.path); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
