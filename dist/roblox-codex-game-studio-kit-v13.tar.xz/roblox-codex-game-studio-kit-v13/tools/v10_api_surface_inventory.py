#!/usr/bin/env python3
"""Heuristically inventory direct Roblox service lookups and likely API calls in Luau files."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from datetime import datetime, timezone

SERVICE_RE=re.compile(r'game\s*:\s*GetService\s*\(\s*["\']([A-Za-z0-9_]+)["\']\s*\)')
CALL_RE=re.compile(r'([A-Za-z_][A-Za-z0-9_\.:]*)\s*:\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(')
DOCS={
 'DataStoreService':'https://create.roblox.com/docs/cloud-services/data-stores',
 'CollectionService':'https://create.roblox.com/docs/reference/engine/classes/CollectionService',
 'RunService':'https://create.roblox.com/docs/reference/engine/classes/RunService',
 'Players':'https://create.roblox.com/docs/reference/engine/classes/Players',
 'HttpService':'https://create.roblox.com/docs/reference/engine/classes/HttpService',
 'TweenService':'https://create.roblox.com/docs/reference/engine/classes/TweenService',
 'PathfindingService':'https://create.roblox.com/docs/reference/engine/classes/PathfindingService',
 'MarketplaceService':'https://create.roblox.com/docs/reference/engine/classes/MarketplaceService',
 'StudioTestService':'https://create.roblox.com/docs/reference/engine/classes/StudioTestService',
 'ChangeHistoryService':'https://create.roblox.com/docs/reference/engine/classes/ChangeHistoryService'
}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',default='.')
    ap.add_argument('--out',default='artifacts/V10_API_SURFACE_INVENTORY.md')
    args=ap.parse_args(); root=Path(args.root).resolve(); files=[]; members=[]; services=set()
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in {'.lua','.luau'}: continue
        if any(x in p.parts for x in {'.git','node_modules','target','build','dist','__pycache__'}): continue
        files.append(p)
        try: lines=p.read_text(encoding='utf-8').splitlines()
        except Exception: continue
        for lineno,line in enumerate(lines,1):
            services.update(SERVICE_RE.findall(line))
            for match in CALL_RE.finditer(line):
                expr=f'{match.group(1)}:{match.group(2)}()'
                if match.group(2) not in {'Connect','WaitForChild','FindFirstChild','GetService'}:
                    members.append({'file':str(p.relative_to(root)).replace('\\','/'),'line':lineno,'expression':expr})
    out={'generatedAt':datetime.now(timezone.utc).isoformat(),'projectRoot':str(root),'filesScanned':len(files),'services':sorted(services),'members':members,'limitations':['Heuristic text scan only; does not resolve types, aliases, inheritance, dynamic requires, or APIs called through variables.','A listed service/member is not automatically incorrect or outdated. Open current Creator Hub references for every relevant API before implementation.','This inventory is not a Luau parser, compiler, or security audit.']}
    output=Path(args.out); output.parent.mkdir(parents=True,exist_ok=True)
    if output.suffix.lower()=='.json': output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    else:
        text=['# V10 API Surface Inventory','',f"- Generated: {out['generatedAt']}",f"- Files scanned: {len(files)}",'', '## Services', '']
        text += [f'- `{s}` — {DOCS.get(s,"Search current Creator Hub API reference")}' for s in sorted(services)] or ['- None detected']
        text += ['', '## Likely API calls','', '| File | Line | Expression |','|---|---:|---|']
        text += [f"| `{m['file']}` | {m['line']} | `{m['expression']}` |" for m in members[:1000]]
        text += ['', '## Limitations'] + [f'- {x}' for x in out['limitations']]
        output.write_text('\n'.join(text)+'\n',encoding='utf-8')
    print(f"Scanned {len(files)} Luau file(s); found {len(services)} service(s), {len(members)} likely member calls. Wrote {output}")
    return 0
if __name__=='__main__': raise SystemExit(main())
