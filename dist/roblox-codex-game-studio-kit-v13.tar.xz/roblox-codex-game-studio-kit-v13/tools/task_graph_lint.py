#!/usr/bin/env python3
"""Validate task IDs, dependencies, statuses, and cycles in a V7 task graph."""
import argparse, json
from pathlib import Path
VALID = {"TODO", "READY", "IN_PROGRESS", "BLOCKED", "DONE"}
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("file"); a=p.parse_args()
    data=json.loads(Path(a.file).read_text(encoding="utf-8")); tasks=data.get("tasks",[])
    errors=[]; ids={}
    for i,t in enumerate(tasks):
        tid=t.get("id")
        if not isinstance(tid,str) or not tid: errors.append(f"tasks[{i}]: missing id"); continue
        if tid in ids: errors.append(f"duplicate task id: {tid}")
        ids[tid]=t
        if t.get("status") not in VALID: errors.append(f"{tid}: invalid status {t.get('status')!r}")
    graph={k:list(v.get("depends_on",[])) for k,v in ids.items()}
    for tid,deps in graph.items():
        for dep in deps:
            if dep not in ids: errors.append(f"{tid}: unknown dependency {dep}")
    visiting=set(); visited=set()
    def visit(node, trail):
        if node in visiting: errors.append("dependency cycle: " + " -> ".join(trail+[node])); return
        if node in visited: return
        visiting.add(node)
        for dep in graph.get(node,[]):
            if dep in graph: visit(dep, trail+[node])
        visiting.remove(node); visited.add(node)
    for node in graph: visit(node,[])
    print(f"Tasks checked: {len(tasks)}")
    for e in errors: print("FAIL:",e)
    if errors: return 1
    print("PASS: local task graph structure only; no task completion or project correctness inferred")
    return 0
if __name__ == "__main__": raise SystemExit(main())
