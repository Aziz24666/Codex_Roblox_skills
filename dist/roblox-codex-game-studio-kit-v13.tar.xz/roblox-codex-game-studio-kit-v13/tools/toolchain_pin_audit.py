#!/usr/bin/env python3
"""Advisory scan for toolchain manifest files and obvious unpinned versions."""
import argparse, re, sys
from pathlib import Path
FILES=['rokit.toml','wally.toml','aftman.toml','default.project.json','package.json']
PATTERNS=[(re.compile(r'(?i)(?:latest|\*|\^|~)'), 'floating or broad version selector'),(re.compile(r'(?i)(?:main|master|head)'), 'branch-like selector; confirm immutable pin is intended')]
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('root',nargs='?',default='.'); args=ap.parse_args(); root=Path(args.root)
    found=0; findings=[]
    for rel in FILES:
        p=root/rel
        if not p.is_file(): continue
        found+=1
        try: lines=p.read_text(encoding='utf-8').splitlines()
        except UnicodeDecodeError: findings.append(f'{rel}: not UTF-8; skipped'); continue
        for n,line in enumerate(lines,1):
            s=line.strip()
            if not s or s.startswith('#') or s.startswith('//'): continue
            for rx,label in PATTERNS:
                if rx.search(s): findings.append(f'{rel}:{n}: {label}: {s[:160]}'); break
    print(f'Manifests inspected: {found} | Advisory findings: {len(findings)}')
    for f in findings: print('REVIEW',f)
    print('NOTE Heuristic only: pinning policy depends on the package manager and team workflow; this does not resolve or install dependencies.')
    return 0
if __name__=='__main__': sys.exit(main())
