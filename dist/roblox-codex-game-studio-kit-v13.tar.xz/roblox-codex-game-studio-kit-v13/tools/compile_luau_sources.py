#!/usr/bin/env python3
"""Compile every Lua/Luau source file using the official luau-compile CLI.

This validates syntax/bytecode compilation only. It does not provide Roblox
Studio globals, type declarations, runtime services, or gameplay verification.
"""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

EXCLUDED_PARTS = {".git", "__pycache__", "node_modules", ".venv"}


def discover_sources(root: Path) -> list[Path]:
    files = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".lua", ".luau"}:
            continue
        if any(part in EXCLUDED_PARTS for part in path.relative_to(root).parts):
            continue
        files.append(path)
    return sorted(files)


def compile_sources(root: Path, compiler: str, min_files: int = 1, timeout: int = 30) -> dict:
    compiler_path = shutil.which(compiler) if not Path(compiler).is_file() else str(Path(compiler))
    if not compiler_path:
        return {"ok": False, "compiled": 0, "failed": [], "error": f"Luau compiler not found: {compiler}"}
    sources = discover_sources(root)
    if len(sources) < min_files:
        return {"ok": False, "compiled": 0, "failed": [], "error": f"Expected at least {min_files} Lua/Luau sources; found {len(sources)}"}
    failures = []
    for path in sources:
        try:
            proc = subprocess.run([compiler_path, str(path)], cwd=root, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            failures.append({"file": str(path.relative_to(root)), "error": f"Timed out after {timeout}s"})
            continue
        except OSError as exc:
            failures.append({"file": str(path.relative_to(root)), "error": str(exc)})
            continue
        if proc.returncode != 0:
            output = (proc.stdout + "\n" + proc.stderr).strip()
            failures.append({"file": str(path.relative_to(root)), "returncode": proc.returncode, "output": output[-4000:]})
    return {"ok": not failures, "compiler": compiler_path, "discovered": len(sources), "compiled": len(sources) - len(failures), "failed": failures,
            "scope": "Syntax/bytecode compilation only; not Roblox Studio type-checking or runtime testing."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--compiler", default="luau-compile")
    parser.add_argument("--min-files", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()
    report = compile_sources(args.root.resolve(), args.compiler, args.min_files, args.timeout)
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
