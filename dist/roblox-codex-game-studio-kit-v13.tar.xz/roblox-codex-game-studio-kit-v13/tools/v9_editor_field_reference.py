#!/usr/bin/env python3
"""Generate a human-readable field reference from the V9 schema catalog."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--catalog',default='examples/v9/catalog.json'); p.add_argument('--output',default='artifacts/V9_EDITOR_FIELDS.md'); a=p.parse_args()
catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8'))
lines=['# V9 Editor Field Reference','', 'Generated from the schema catalog. This is a documentation artifact, not runtime validation evidence.','']
for family in catalog['families']:
 lines += [f"## {family['label']} (`{family['id']}`)", '', family['description'], '', '| Field path | Label | Kind | Default | Constraints/options |', '|---|---|---|---|---|']
 for f in family['fields']:
  constraints=[]
  for k in ('min','max','maxLength','assetKind','options'):
   if k in f: constraints.append(f'{k}={f[k]}')
  lines.append(f"| `{f['path']}` | {f['label']} | `{f['kind']}` | `{f['default']}` | {'; '.join(constraints)} |")
 lines.append('')
out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text('\n'.join(lines),encoding='utf-8')
print(f'Wrote {out}')
