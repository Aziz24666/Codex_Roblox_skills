#!/usr/bin/env python3
"""Inventory literal and dynamic-looking Luau require() call sites; not a full dependency resolver."""
import argparse,re
from pathlib import Path
PAT=re.compile(r"\brequire\s*\((.*?)\)",re.S)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("root",nargs="?",default="src");p.add_argument("--out",default="MODULE_REQUIRE_INVENTORY.md");a=p.parse_args();root=Path(a.root);rows=[]
 for f in sorted(root.rglob("*.lua")):
  text=f.read_text(encoding="utf-8",errors="replace")
  for m in PAT.finditer(text):
   expr=" ".join(m.group(1).split());line=text.count("\n",0,m.start())+1
   classification="LITERAL_OR_STATIC_EXPRESSION" if re.fullmatch(r"[\w.\[\]'\" ]+",expr) else "DYNAMIC_OR_COMPLEX"
   rows.append((str(f),line,classification,expr[:180]))
 lines=["# Luau require() Inventory","",f"Root: `{root}`","", "This is a source-text inventory, not a complete or authoritative runtime dependency graph. It may miss dynamic module resolution and may include commented examples.","", "| File | Line | Class | Expression |","|---|---:|---|---|"]
 lines += ["| `{}` | {} | {} | `{}` |".format(f,n,c,e.replace('|','\\|')) for f,n,c,e in rows]
 Path(a.out).parent.mkdir(parents=True, exist_ok=True)
 Path(a.out).write_text("\n".join(lines)+"\n",encoding="utf-8");print(f"require() sites inventoried: {len(rows)}; report: {a.out}");return 0
if __name__=="__main__":raise SystemExit(main())
