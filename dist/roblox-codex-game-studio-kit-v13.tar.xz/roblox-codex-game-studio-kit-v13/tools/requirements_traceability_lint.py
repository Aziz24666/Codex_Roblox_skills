#!/usr/bin/env python3
"""Validate a requirement-to-test-evidence CSV. Heuristic coverage check only."""
import argparse, csv, sys
from pathlib import Path
REQUIRED = ['requirement_id','feature_id','system_id','acceptance_id','test_id','evidence_id','coverage_status','notes']
VALID = {'COVERED','PLANNED','BLOCKED','GAP','NOT APPLICABLE'}
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('csv_file'); ap.add_argument('--strict',action='store_true'); args=ap.parse_args()
    p=Path(args.csv_file)
    try:
        with p.open(newline='',encoding='utf-8-sig') as f:
            reader=csv.DictReader(f); missing=[x for x in REQUIRED if x not in (reader.fieldnames or [])]
            if missing: print('ERROR missing columns:', ', '.join(missing)); return 2
            rows=list(reader)
    except OSError as e: print('ERROR',e); return 2
    errors=[]; seen=set()
    for n,row in enumerate(rows,2):
        rid=(row.get('requirement_id') or '').strip(); status=(row.get('coverage_status') or '').strip().upper()
        if not rid: errors.append(f'line {n}: missing requirement_id')
        elif rid in seen: errors.append(f'line {n}: duplicate requirement_id {rid}')
        seen.add(rid)
        if status not in VALID: errors.append(f'line {n}: invalid coverage_status {status!r}')
        if status=='COVERED' and not (row.get('test_id') or '').strip(): errors.append(f'line {n}: COVERED without test_id')
        if status=='COVERED' and not (row.get('evidence_id') or '').strip(): errors.append(f'line {n}: COVERED without evidence_id')
        if status=='NOT APPLICABLE' and not (row.get('notes') or '').strip(): errors.append(f'line {n}: NOT APPLICABLE needs reason in notes')
    gaps=[(r.get('requirement_id'),r.get('coverage_status')) for r in rows if (r.get('coverage_status') or '').strip().upper() in {'GAP','BLOCKED','PLANNED'}]
    print(f'Rows: {len(rows)} | Errors: {len(errors)} | Open coverage: {len(gaps)}')
    for e in errors: print('ERROR',e)
    for rid,status in gaps: print(f'OPEN {rid}: {status}')
    if errors or (args.strict and gaps): return 1
    return 0
if __name__=='__main__': sys.exit(main())
