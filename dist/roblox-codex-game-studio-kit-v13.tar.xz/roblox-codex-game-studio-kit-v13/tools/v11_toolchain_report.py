#!/usr/bin/env python3
"""Report available Roblox/Luau project tools; never installs or upgrades anything."""
from __future__ import annotations
import argparse,json,shutil,subprocess
from pathlib import Path
COMMANDS={"git":["--version"],"rojo":["--version"],"luau-analyze":["--version"],"luau":["--version"],"selene":["--version"],"stylua":["--version"],"wally":["--version"],"aftman":["--version"],"rokit":["--version"]}
def report():
    out=[]
    for name,args in COMMANDS.items():
        exe=shutil.which(name)
        row={"tool":name,"available":bool(exe),"path":exe}
        if exe:
            try:
                p=subprocess.run([exe,*args],capture_output=True,text=True,timeout=3,check=False)
                row["versionOutput"]=(p.stdout or p.stderr).strip()[:300]; row["exitCode"]=p.returncode
            except Exception as e: row["versionError"]=type(e).__name__
        out.append(row)
    return {"tools":out,"note":"Presence is not proof of project compatibility. Verify upstream docs and project pins before use."}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--output",type=Path); a=ap.parse_args(); r=report(); s=json.dumps(r,indent=2); print(s)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(s+"\n")
if __name__=="__main__": main()
