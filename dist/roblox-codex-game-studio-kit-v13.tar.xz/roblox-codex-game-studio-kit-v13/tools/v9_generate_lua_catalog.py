#!/usr/bin/env python3
"""Generate the plugin's Luau SchemaCatalog module from the JSON source catalog."""
import argparse
import json
from pathlib import Path


def lua_literal(value, depth=0):
    pad = "    " * depth
    if value is None:
        return "nil"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        if not value:
            return "{}"
        body = "\n".join(("    " * (depth + 1)) + lua_literal(item, depth + 1) + "," for item in value)
        return "{\n" + body + "\n" + pad + "}"
    if isinstance(value, dict):
        if not value:
            return "{}"
        body = []
        for key, item in value.items():
            body.append(("    " * (depth + 1)) + "[" + json.dumps(str(key), ensure_ascii=False) + "] = " + lua_literal(item, depth + 1) + ",")
        return "{\n" + "\n".join(body) + "\n" + pad + "}"
    raise TypeError(f"Unsupported catalog value: {type(value).__name__}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", default="examples/v9/catalog.json")
    parser.add_argument("--output", default="studio-plugin/src/Modules/SchemaCatalog.lua")
    args = parser.parse_args()
    catalog = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
    source = """--!strict
-- GENERATED FILE. Source of truth: examples/v9/catalog.json.
-- Run tools/v9_generate_lua_catalog.py after editing the JSON catalog.
local FieldPath = require(script.Parent:WaitForChild("FieldPath"))
local Catalog = """ + lua_literal(catalog) + """

function Catalog.GetFamily(familyId: string): any
    for _, family in ipairs(Catalog.families) do
        if family.id == familyId then return family end
    end
    return nil
end

function Catalog.CreateDefault(familyId: string): {[string]: any}
    local family = Catalog.GetFamily(familyId)
    assert(family ~= nil, "Unknown content family: " .. familyId)
    local definition: {[string]: any} = {
        schemaVersion = family.schemaVersion,
        family = family.id,
    }
    for _, field in ipairs(family.fields) do
        FieldPath.Set(definition, field.path, field.default)
    end
    return definition
end

return Catalog
"""
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(source, encoding="utf-8")
    print(f"Generated {output} from {args.catalog}")


if __name__ == "__main__":
    main()
