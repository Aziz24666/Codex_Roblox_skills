#!/usr/bin/env python3
"""Validate a planning manifest for a multi-place Roblox universe."""
import argparse, json, sys
from pathlib import Path
ROLES={'start','hub','match','instance','social','test','other'}
ENVS={'development','staging','production'}
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('manifest'); ap.add_argument('--repo-root',default='.'); args=ap.parse_args()
    try: data=json.loads(Path(args.manifest).read_text(encoding='utf-8'))
    except Exception as e: print('ERROR cannot read JSON:',e); return 2
    errs=[]
    if not isinstance(data,dict): print('ERROR manifest root must be an object'); return 2
    if data.get('schemaVersion') != 1: errs.append('schemaVersion must be 1')
    if not isinstance(data.get('universeName'),str) or not data.get('universeName').strip(): errs.append('universeName must be a non-empty string')
    places=data.get('places')
    if not isinstance(places,list) or not places: errs.append('places must be a non-empty array'); places=[]
    names=set(); ids=set(); starts=0
    for i,p in enumerate(places):
        if not isinstance(p,dict): errs.append(f'places[{i}] must be an object'); continue
        name=p.get('name'); role=p.get('role'); env=p.get('environment'); src=p.get('sourcePath'); pid=p.get('placeId')
        if not isinstance(name,str) or not name.strip(): errs.append(f'places[{i}] missing name')
        elif name in names: errs.append(f'duplicate place name: {name}')
        else: names.add(name)
        if role not in ROLES: errs.append(f'{name}: invalid role {role!r}')
        if role=='start': starts+=1
        if env not in ENVS: errs.append(f'{name}: invalid environment {env!r}')
        if pid is not None and (not isinstance(pid,int) or pid<=0): errs.append(f'{name}: placeId must be positive integer or null')
        if isinstance(pid,int):
            if pid in ids: errs.append(f'{name}: duplicate placeId {pid}')
            ids.add(pid)
        if not isinstance(src,str) or not src.strip(): errs.append(f'{name}: missing sourcePath')
        elif not (Path(args.repo_root)/src).exists(): errs.append(f'{name}: sourcePath does not exist: {src}')
    if starts>1: errs.append('more than one start place declared; confirm this is intentional')
    print(f'Places: {len(places)} | Unique names: {len(names)} | Errors: {len(errs)}')
    for e in errs: print('ERROR',e)
    print('NOTE This validates the planning manifest only; it does not verify Creator Dashboard place IDs or runtime teleports.')
    return 1 if errs else 0
if __name__=='__main__': sys.exit(main())
