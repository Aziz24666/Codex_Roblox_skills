#!/usr/bin/env python3
"""Heuristic static graph for simple Luau require(script.Parent.X) expressions; dynamic requires are not resolved."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
PATTERNS=[re.compile(r"require\s*\(\s*script((?:\s*\.\s*(?:Parent|[A-Za-z_][A-Za-z0-9_]*))+)\s*\)"), re.compile(r"require\s*\(\s*game:GetService\(\s*['\"](\w+)['\"]\s*\)([^)]*)\)\s*")]
def graph(root: Path):
    files=sorted(root.rglob("*.lua")); known={p.relative_to(root).with_suffix("").as_posix():p for p in files}; nodes=[]; unresolved=[]
    for p in files:
        rel=p.relative_to(root); text=p.read_text(encoding="utf-8",errors="replace"); deps=[]
        for m in PATTERNS[0].finditer(text):
            parts=re.findall(r"\.\s*([A-Za-z_][A-Za-z0-9_]*|Parent)",m.group(1)); cur=p
            ok=True
            for part in parts:
                if part=="Parent": cur=cur.parent
                else: cur=cur/part
            candidates=[cur.with_suffix(".lua"),cur/"init.lua"]
            found=next((c for c in candidates if c.exists()),None)
            if found: deps.append(found.relative_to(root).with_suffix("").as_posix())
            else: unresolved.append({"source":rel.as_posix(),"expression":m.group(0),"reason":"relative target not found by heuristic"})
        # Service-qualified requires are listed as unresolved rather than guessed from DataModel mappings.
        for m in PATTERNS[1].finditer(text): unresolved.append({"source":rel.as_posix(),"expression":m.group(0),"reason":"service/DataModel require needs project mapping"})
        nodes.append({"path":rel.as_posix(),"id":rel.with_suffix("").as_posix(),"dependencies":sorted(set(deps))})
    reverse={n["id"]:[] for n in nodes}
    for n in nodes:
        for dep in n["dependencies"]: reverse.setdefault(dep,[]).append(n["id"])
    # DFS cycle detection over the resolved subset of the graph.
    adjacency={n["id"]:n["dependencies"] for n in nodes}; visiting=set(); visited=set(); cycles=[]; stack=[]
    def visit(node):
        if node in visiting:
            try: i=stack.index(node); cycle=stack[i:]+[node]
            except ValueError: cycle=[node,node]
            if cycle not in cycles: cycles.append(cycle)
            return
        if node in visited: return
        visiting.add(node); stack.append(node)
        for dep in adjacency.get(node,[]):
            if dep in adjacency: visit(dep)
        stack.pop(); visiting.remove(node); visited.add(node)
    for node in adjacency: visit(node)
    return {"root":str(root.resolve()),"nodeCount":len(nodes),"nodes":nodes,"reverseDependencies":reverse,"unresolved":unresolved,"cycles":cycles,"limitations":["Static heuristic only","Does not resolve dynamic require, service/DataModel mappings, package aliases, dependency injection, CollectionService registrations, attributes, or generated paths"]}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("source",type=Path); ap.add_argument("--output",type=Path,required=True); args=ap.parse_args(); result=graph(args.source); args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8"); print(f"nodes={result['nodeCount']} unresolved={len(result['unresolved'])} output={args.output}")
if __name__=="__main__": main()
