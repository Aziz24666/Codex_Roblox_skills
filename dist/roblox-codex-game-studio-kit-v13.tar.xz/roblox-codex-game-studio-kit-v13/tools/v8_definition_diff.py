#!/usr/bin/env python3
"""Show added/removed/changed config paths between two JSON definitions."""
import argparse,json
from pathlib import Path
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def walk(a,b,path=''):
    out=[]
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            p=f"{path}.{k}" if path else k
            if k not in a: out.append(("ADDED",p,None,b[k]))
            elif k not in b: out.append(("REMOVED",p,a[k],None))
            else: out += walk(a[k],b[k],p)
    elif isinstance(a,list) and isinstance(b,list):
        if a != b: out.append(("CHANGED",path,a,b))
    elif a != b: out.append(("CHANGED",path,a,b))
    return out
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('before'); ap.add_argument('after'); a=ap.parse_args()
    changes=walk(load(a.before),load(a.after))
    if not changes: print('No changes'); return 0
    for kind,path,old,new in changes: print(f"{kind:7} {path}: {old!r} -> {new!r}")
    print(f"Total paths changed: {len(changes)}. Review semantic compatibility manually; this is not a migration classifier.")
    return 0
if __name__=='__main__': raise SystemExit(main())
