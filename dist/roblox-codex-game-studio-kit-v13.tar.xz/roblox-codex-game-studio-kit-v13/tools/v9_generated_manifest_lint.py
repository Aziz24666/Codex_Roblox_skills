#!/usr/bin/env python3
"""Validate V9 generation manifest example."""
import argparse,json,sys
from pathlib import Path
try: from jsonschema import Draft202012Validator
except ImportError: Draft202012Validator=None
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(); p.add_argument('--example',default='schemas/examples/v9-generated-content-manifest.example.json'); a=p.parse_args()
 if Draft202012Validator is None: print('BLOCKED: jsonschema is required'); return 2
 schema=json.loads((ROOT/'schemas/v9-generated-content-manifest.schema.json').read_text())
 data=json.loads((ROOT/a.example).read_text())
 errors=list(Draft202012Validator(schema).iter_errors(data))
 if errors: print('\n'.join('ERROR '+e.message for e in errors)); return 1
 print('PASS: generated-content manifest example is valid'); return 0
if __name__=='__main__': raise SystemExit(main())
