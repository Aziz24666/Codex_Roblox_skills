#!/usr/bin/env python3
"""Check JSON syntax and existence of $path entries in a Rojo mapping; not a Rojo build."""
import argparse, json
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('project',nargs='?',default='default.project.json'); args=ap.parse_args()
    path=Path(args.project).resolve()
    if not path.is_file(): print(f'NOT APPLICABLE: {path} not found'); return 0
    try: data=json.loads(path.read_text(encoding='utf-8'))
    except Exception as e: print(f'FAIL: invalid JSON: {e}'); return 1
    found=[]; missing=[]; root=path.parent
    def walk(node,where='$'):
        if isinstance(node,dict):
            rel=node.get('$path')
            if isinstance(rel,str):
                (found if (root/rel).exists() else missing).append((where,rel))
            for key,value in node.items():
                if key!='$path': walk(value,f'{where}.{key}')
        elif isinstance(node,list):
            for i,value in enumerate(node): walk(value,f'{where}[{i}]')
    walk(data); print(f'JSON PASS | mapped paths found: {len(found)} | missing: {len(missing)}')
    for where,rel in missing: print(f'FAIL: {where} -> {rel}')
    print('NOTE: no Rojo schema validation, sourcemap generation, or build was performed.')
    return 1 if missing else 0
if __name__=='__main__': raise SystemExit(main())
