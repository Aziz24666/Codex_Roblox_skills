#!/usr/bin/env python3
"""Validate a release manifest and guard against unapproved production mutations."""
import argparse, json, sys
from pathlib import Path
MUTATING={'publish','rollback','metadata-change'}
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('manifest'); ap.add_argument('--repo-root',default='.'); args=ap.parse_args()
    try: d=json.loads(Path(args.manifest).read_text(encoding='utf-8'))
    except Exception as e: print('ERROR cannot read JSON:',e); return 2
    errs=[]
    for k in ('releaseVersion','sourceCommit','channel','action','targets','explicitApproval'):
        if k not in d: errs.append(f'missing {k}')
    if d.get('channel') not in {'development','staging','production'}: errs.append('invalid channel')
    if d.get('action') not in {'build','publish','rollback','metadata-change'}: errs.append('invalid action')
    targets=d.get('targets') if isinstance(d.get('targets'),list) else []
    if not targets: errs.append('targets must be a non-empty array')
    target_envs=set()
    for i,t in enumerate(targets):
        if not isinstance(t,dict): errs.append(f'targets[{i}] must be object'); continue
        if not t.get('placeName'): errs.append(f'targets[{i}] missing placeName')
        env=t.get('environment')
        if env not in {'development','staging','production'}: errs.append(f'targets[{i}] invalid environment')
        target_envs.add(env)
        pid=t.get('placeId')
        if pid is not None and (not isinstance(pid,int) or pid<=0): errs.append(f'targets[{i}] placeId invalid')
    production = d.get('channel')=='production' or 'production' in target_envs
    mutating = d.get('action') in MUTATING
    approval=d.get('explicitApproval') if isinstance(d.get('explicitApproval'),dict) else {}
    if (production or mutating) and approval.get('required') is not True: errs.append('production or mutating action must set explicitApproval.required=true')
    if approval.get('required') is True and not approval.get('reference'): errs.append('approval reference missing')
    if d.get('action')=='publish' and not production: errs.append('publish action must explicitly target production only after approval')
    print(f"Channel: {d.get('channel')} | Action: {d.get('action')} | Targets: {len(targets)} | Errors: {len(errs)}")
    for e in errs: print('ERROR',e)
    print('NOTE Linting does not publish, authenticate, verify target ownership, or validate rollback safety.')
    return 1 if errs else 0
if __name__=='__main__': sys.exit(main())
