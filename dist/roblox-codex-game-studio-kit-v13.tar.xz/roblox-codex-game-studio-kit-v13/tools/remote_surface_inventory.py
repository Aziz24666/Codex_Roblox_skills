#!/usr/bin/env python3
"""Heuristically inventory remote/client-triggerable surfaces in Luau/Lua files."""
import argparse, re
from pathlib import Path
PATTERNS={
 'OnServerEvent':r'\.OnServerEvent\b','OnServerInvoke':r'\.OnServerInvoke\b',
 'FireServer':r'\.FireServer\s*\(','InvokeServer':r'\.InvokeServer\s*\(',
 'ProximityPrompt':r'\.Triggered\b','ClickDetector':r'\.MouseClick\b','Touched':r'\.Touched\b',
 'RemoteCreation':r'Instance\.new\s*\(\s*["\']Remote(?:Event|Function)["\']'
}
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('root',nargs='?',default='src'); ap.add_argument('--out'); args=ap.parse_args()
    root=Path(args.root)
    if not root.exists(): print(f'NOT APPLICABLE: {root} not found'); return 0
    rows=[]; file_count=0
    compiled={k:re.compile(v) for k,v in PATTERNS.items()}
    for file in sorted(root.rglob('*')):
        if file.suffix.lower() not in {'.lua','.luau'}: continue
        file_count+=1
        try: lines=file.read_text(encoding='utf-8',errors='replace').splitlines()
        except OSError: continue
        for number,line in enumerate(lines,1):
            for label,pattern in compiled.items():
                if pattern.search(line): rows.append((file,number,label,line.strip()[:160]))
    output=['# Remote and Interaction Surface Inventory','',f'Files scanned: {file_count}',f'Pattern matches: {len(rows)}','',
      '> Heuristic inventory only. Dynamic code may be missed and false positives may occur. This is not a security audit.','',
      '| File | Line | Pattern | Excerpt |','|---|---:|---|---|']
    for file,line,label,excerpt in rows:
        output.append('| `{}` | {} | `{}` | `{}` |'.format(file,line,label,excerpt.replace('|','\\|')))
    text='\n'.join(output)+'\n'
    if args.out:
        out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(text,encoding='utf-8'); print(f'Wrote {out}; {len(rows)} matches')
    else: print(text,end='')
    return 0
if __name__=='__main__': raise SystemExit(main())
