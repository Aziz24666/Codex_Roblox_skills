#!/usr/bin/env python3
"""Validate workflow-profile decisions; does not migrate or sync projects."""
import argparse,json
from pathlib import Path
ALLOWED={'studio-native','script-sync','partially-managed-rojo','fully-managed-rojo','hybrid'}
def lint(data):
    errors=[]; source=data.get('sourceOfTruth')
    if data.get('schemaVersion')!=1: errors.append('schemaVersion must be 1')
    if source not in ALLOWED: errors.append(f'unsupported sourceOfTruth: {source!r}')
    ownership=data.get('ownership',{})
    if not isinstance(ownership,dict) or not ownership: errors.append('ownership must map content areas to a source')
    else:
        for key,value in ownership.items():
            if value not in {'git','roblox-studio','external-catalog','generated'}: errors.append(f'ownership[{key}] has invalid value {value!r}')
    if source=='fully-managed-rojo' and not data.get('projectFile'): errors.append('fully-managed-rojo requires projectFile')
    ci=data.get('ci',{})
    if ci.get('pullRequest') not in {'read-only','disabled'}: errors.append('CI pullRequest must be read-only or disabled')
    if ci.get('deployment')!='separate-approved-workflow': errors.append('deployment must be separate-approved-workflow')
    if source=='hybrid' and len(set(ownership.values()))<2: errors.append('hybrid profile must actually define multiple ownership sources')
    return {'ok':not errors,'errors':errors,'sourceOfTruth':source}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('profile',type=Path); a=ap.parse_args(); r=lint(json.loads(a.profile.read_text())); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
