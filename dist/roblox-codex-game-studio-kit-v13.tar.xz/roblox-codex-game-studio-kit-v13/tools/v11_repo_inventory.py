#!/usr/bin/env python3
"""Inventory a Roblox repo by extension and directory; skips common build/cache dirs and never reads file contents."""
from __future__ import annotations
import argparse, json
from collections import Counter
from pathlib import Path
SKIP={".git",".venv","venv","node_modules","__pycache__",".mypy_cache",".pytest_cache","build","dist"}
SENSITIVE_NAMES={".env",".env.local",".roblosecurity","credentials.json","secrets.json"}
def inventory(root: Path):
    ext=Counter(); dirs=Counter(); files=[]; sensitive=[]
    for p in root.rglob("*"):
        if not p.is_file() or any(part in SKIP for part in p.parts): continue
        rel=p.relative_to(root); files.append(str(rel)); ext[p.suffix.lower() or "[no extension]"]+=1; dirs[str(rel.parent)]+=1
        if p.name.lower() in SENSITIVE_NAMES or p.name.lower().endswith((".pem",".p12",".key")): sensitive.append(str(rel))
    return {"root":str(root.resolve()),"fileCount":len(files),"byExtension":dict(ext.most_common()),"byDirectory":dict(dirs.most_common()),"sensitiveNameWarnings":sensitive,"files":sorted(files)}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("project",type=Path); ap.add_argument("--output",type=Path); args=ap.parse_args(); result=inventory(args.project)
    data=json.dumps(result,indent=2); print(data)
    if args.output: args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(data+"\n",encoding="utf-8")
if __name__=="__main__": main()
