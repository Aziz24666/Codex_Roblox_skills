#!/usr/bin/env python3
"""Suggest matching installed skills by name/description. Heuristic routing only."""
import argparse,re
from pathlib import Path
def tokens(s):return set(re.findall(r"[a-z0-9]+",s.lower()))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("query");p.add_argument("--root",default=".");p.add_argument("--limit",type=int,default=8);a=p.parse_args();base=Path(a.root)/".agents"/"skills";q=tokens(a.query);scores=[]
 for f in base.glob("*/SKILL.md"):
  text=f.read_text(encoding="utf-8");desc=next((x.split(":",1)[1].strip() for x in text.splitlines() if x.startswith("description:")),"");name=f.parent.name
  name_tokens=tokens(name.replace("roblox-",""));desc_tokens=tokens(desc);score=3*len(q&name_tokens)+len(q&desc_tokens)
  if score:scores.append((score,name,desc))
 for score,name,desc in sorted(scores,reverse=True)[:max(1,a.limit)]:print(f"{score:>3}  ${name} — {desc}")
 print("\nHeuristic suggestions only. Read the selected SKILL.md and confirm relevance; do not activate every result.")
 return 0
if __name__=="__main__":raise SystemExit(main())
