#!/usr/bin/env python3
"""Validate V9 family catalog field descriptors and path consistency."""
import argparse, json, re, sys
from pathlib import Path
KINDS={"identifier","text","number","boolean","enum","assetId"}
SOURCE={"None","HumanoidModel","Accessory"}
OUTPUT={"NPC","Companion","Cosmetic","WorldProp","InteractiveProp","UtilityGadget"}
PATH=re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)*$")
def main():
 p=argparse.ArgumentParser(); p.add_argument('--catalog',default='examples/v9/catalog.json'); a=p.parse_args(); data=json.loads(Path(a.catalog).read_text(encoding='utf-8')); errors=[]
 try:
  import jsonschema
  catalog_schema=json.loads((Path(__file__).resolve().parents[1]/'schemas/v9-family-catalog.schema.json').read_text(encoding='utf-8'))
  errors.extend(f'catalog JSON Schema: {e.message}' for e in jsonschema.Draft202012Validator(catalog_schema).iter_errors(data))
 except ImportError:
  print('WARNING: jsonschema not installed; running custom catalog checks only')
 ids=set()
 for fam in data.get('families',[]):
  fid=fam.get('id')
  if fid in ids: errors.append(f'duplicate family id: {fid}')
  ids.add(fid)
  if fam.get('sourceRequirement') not in SOURCE: errors.append(f'{fid}: invalid sourceRequirement')
  if fam.get('outputKind') not in OUTPUT: errors.append(f'{fid}: invalid outputKind')
  if not isinstance(fam.get('schemaVersion'),int) or fam['schemaVersion']<1: errors.append(f'{fid}: invalid schemaVersion')
  paths=[]
  for f in fam.get('fields',[]):
   path=f.get('path',''); kind=f.get('kind')
   if not PATH.fullmatch(path): errors.append(f'{fid}: invalid field path {path!r}')
   if kind not in KINDS: errors.append(f'{fid}.{path}: unsupported kind {kind!r}')
   if path in paths: errors.append(f'{fid}: duplicate field path {path}')
   paths.append(path)
   if kind=='number':
    if not isinstance(f.get('default'),(int,float)) or isinstance(f.get('default'),bool): errors.append(f'{fid}.{path}: numeric default required')
    if 'min' in f and 'max' in f and f['min']>f['max']: errors.append(f'{fid}.{path}: min greater than max')
    if 'min' in f and f.get('default',0)<f['min']: errors.append(f'{fid}.{path}: default below min')
    if 'max' in f and f.get('default',0)>f['max']: errors.append(f'{fid}.{path}: default above max')
   if kind=='enum':
    opts=f.get('options',[])
    if not opts or len(opts)!=len(set(opts)): errors.append(f'{fid}.{path}: enum options must be nonempty and unique')
    if f.get('default') not in opts: errors.append(f'{fid}.{path}: enum default not in options')
   if kind=='boolean' and not isinstance(f.get('default'),bool): errors.append(f'{fid}.{path}: boolean default required')
   if kind in {'text','identifier','assetId'} and not isinstance(f.get('default'),str): errors.append(f'{fid}.{path}: string default required')
  for x in paths:
   for y in paths:
    if x!=y and y.startswith(x+'.'): errors.append(f'{fid}: scalar path {x} conflicts with nested path {y}')
 if errors:
  print('\n'.join('ERROR '+e for e in errors)); return 1
 print(f'PASS: {len(ids)} families and {sum(len(f.get("fields",[])) for f in data.get("families",[]))} field descriptors valid')
 return 0
if __name__=='__main__': raise SystemExit(main())
