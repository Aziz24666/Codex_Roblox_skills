# V8 local utilities

- `v8_config_lint.py`: checks supported fields/enums/basic bounds for V8 NPC and non-combat gadget JSON.
- `v8_definition_diff.py`: reports changed JSON paths; it does not decide compatibility.
- `v8_prefab_manifest_lint.py`: checks a manifest's shape; it does not inspect Studio Instances.
- `v8_module_boundary_audit.py`: heuristic require-site/layer smell report; it is not a Luau parser.
- `v8_plugin_source_check.py`: checks for expected source affordance tokens; it is not a plugin security audit or execution test.

All utilities use the Python standard library. Run from package root and consult `--help`. Never treat a static check as a Studio runtime test.
