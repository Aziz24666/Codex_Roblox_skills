\
#!/usr/bin/env python3
"""V13 package doctor: metadata, schemas, Python syntax and V13 references."""
from pathlib import Path
import argparse, json, py_compile, re, sys, tempfile, hashlib

def run(root: Path) -> dict:
    errors=[]; warnings=[]; counts={}
    skills=sorted((root/'.agents/skills').glob('*/SKILL.md'))
    counts['skills']=len(skills)
    for p in skills:
        text=p.read_text(encoding='utf-8',errors='replace')
        m=re.match(r'^---\n(.*?)\n---\n',text,re.S)
        if not m: errors.append(f'{p}: malformed skill frontmatter')
        elif re.search(r'^\s*#{1,6}\s',m.group(1),re.M): errors.append(f'{p}: Markdown appears inside YAML frontmatter')
    try:
        import jsonschema
        count=0
        for ex in sorted((root/'schemas/examples').glob('v13-*.example.json')):
            schema=root/'schemas'/(ex.name.replace('.example.json','.schema.json'))
            if not schema.exists(): errors.append(f'{ex}: missing schema'); continue
            jsonschema.validate(json.loads(ex.read_text()),json.loads(schema.read_text())); count+=1
        counts['v13SchemaExamplesValidated']=count
    except ImportError:
        warnings.append('jsonschema not installed; V13 schema validation skipped')
        counts['v13SchemaExamplesValidated']='NOT RUN'
    except Exception as exc: errors.append(f'V13 schema validation failed: {exc}')
    counts['jsonFiles']=0
    for p in root.rglob('*.json'):
        if any(x in p.parts for x in {'.git','__pycache__','node_modules'}): continue
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as exc: errors.append(f'{p}: invalid JSON: {exc}')
        counts['jsonFiles']+=1
    counts['pythonFiles']=0
    # Compile into a temporary directory so the doctor never pollutes the project
    # with __pycache__ files or changes the artifact being audited.
    with tempfile.TemporaryDirectory(prefix='v13-pack-doctor-') as temp_dir:
        temp=Path(temp_dir)
        for index, p in enumerate(root.rglob('*.py')):
            if any(x in p.parts for x in {'.git','__pycache__','node_modules'}): continue
            try: py_compile.compile(str(p),cfile=str(temp/f'{index}.pyc'),doraise=True)
            except Exception as exc: errors.append(f'{p}: Python syntax error: {exc}')
            counts['pythonFiles']+=1
    # Validate local references in new docs and prompts.
    for base in ('docs','prompts'):
        for p in (root/base).glob('V13_*.md'):
            body=p.read_text(encoding='utf-8')
            for ref in re.findall(r'`((?:docs|templates|schemas|prompts|examples|tools)/[^`]+)`',body):
                if not (root/ref).exists(): errors.append(f'{p}: broken reference {ref}')
    for req in ('AGENTS.md','README.md','INDEX_V13.md','V13_TEST_RESULTS.md','PACKAGE_INVENTORY.md','V13_SHA256SUMS.txt'):
        if not (root/req).exists(): errors.append(f'missing required file {req}')
    # Verify the manifest covers every other regular file and every digest is valid.
    manifest=root/'V13_SHA256SUMS.txt'
    if manifest.exists():
        try:
            seen=set()
            for line in manifest.read_text(encoding='utf-8').splitlines():
                if not line.strip(): continue
                digest, rel=line.split('  ',1); target=root/rel
                if rel in seen: errors.append(f'duplicate checksum entry {rel}')
                seen.add(rel)
                if not target.is_file(): errors.append(f'checksum target missing: {rel}')
                elif hashlib.sha256(target.read_bytes()).hexdigest()!=digest: errors.append(f'checksum mismatch: {rel}')
            actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p != manifest and not any(x in p.parts for x in {'.git','__pycache__','node_modules'})}
            missing=actual-seen; extra=seen-actual
            if missing: errors.append(f'checksum manifest missing {len(missing)} files')
            if extra: errors.append(f'checksum manifest has {len(extra)} extra entries')
            counts['checksumEntries']=len(seen)
        except Exception as exc: errors.append(f'invalid checksum manifest: {exc}')
    counts['totalFiles']=sum(1 for p in root.rglob('*') if p.is_file() and not any(x in p.parts for x in {'.git','__pycache__','node_modules'}))
    return {'ok':not errors,'counts':counts,'errors':errors,'warnings':warnings}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',nargs='?',type=Path,default=Path('.')); a=ap.parse_args(); r=run(a.root); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['ok'] else 1)
if __name__=='__main__': main()
