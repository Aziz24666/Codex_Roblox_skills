#!/usr/bin/env python3
"""Static contract check for the V9 modular Studio plugin. Not a Luau compiler."""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
files=list((ROOT/'studio-plugin/src').rglob('*.lua'))
required=['CreateDockWidgetPluginGuiAsync','TryBeginRecording','FinishRecording','FinishRecordingOperation.Cancel','FinishRecordingOperation.Commit','PreviewRenderer.Render','SchemaValidator.Validate','PrefabFactory.Generate','TemplateResolver.CloneSanitized','V9GenerationManifest','PrefabFactory.CanGenerate','Source selection changed after preview']
joined='\n'.join(p.read_text(encoding='utf-8') for p in files)
errors=[]
for token in required:
 if token not in joined: errors.append(f'missing required contract token: {token}')
for p in files:
 text=p.read_text(encoding='utf-8')
 if not text.startswith('--!strict'): errors.append(f'{p.relative_to(ROOT)}: missing --!strict')
 if 'loadstring' in text: errors.append(f'{p.relative_to(ROOT)}: loadstring is forbidden')
 if re.search(r'\bHttpService:GetAsync\s*\(',text): errors.append(f'{p.relative_to(ROOT)}: unexpected network request')
if not (ROOT/'studio-plugin/default.project.json').is_file(): errors.append('missing default.project.json')
if errors:
 print('\n'.join('ERROR '+x for x in errors)); raise SystemExit(1)
print(f'PASS: {len(files)} Luau source modules satisfy static source contracts (not compiled)')
