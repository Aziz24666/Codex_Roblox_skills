#!/usr/bin/env python3
"""Audit skill frontmatter, description length, duplicates, and broken skill-local links."""
from __future__ import annotations
import argparse, re, json
from pathlib import Path

def audit(root: Path, max_description: int = 160) -> dict:
    skills = root / ".agents" / "skills"
    seen = set(); rows=[]; errors=[]; warnings=[]
    for file in sorted(skills.glob("*/SKILL.md")):
        text=file.read_text(encoding="utf-8", errors="replace")
        match=re.match(r"^---\n(.*?)\n---\n", text, re.S)
        if not match:
            errors.append(f"{file}: missing YAML frontmatter"); continue
        fm=match.group(1)
        name=re.search(r"^name:\s*(.+)$", fm, re.M)
        desc=re.search(r"^description:\s*(.*)$", fm, re.M)
        if not name or not desc:
            errors.append(f"{file}: missing name/description"); continue
        skill_name=name.group(1).strip().strip("\"'")
        description=desc.group(1).strip().strip("\"'")
        if skill_name in seen: errors.append(f"duplicate skill name: {skill_name}")
        seen.add(skill_name)
        if len(description)>max_description: warnings.append(f"{skill_name}: description is {len(description)} chars (max {max_description})")
        rows.append({"name":skill_name,"path":str(file.relative_to(root)),"descriptionLength":len(description)})
    return {"skillCount":len(rows),"skills":rows,"warnings":warnings,"errors":errors,"ok":not errors}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("project",type=Path); ap.add_argument("--max-description",type=int,default=160); ap.add_argument("--json",action="store_true"); args=ap.parse_args()
    result=audit(args.project,args.max_description)
    print(json.dumps(result,indent=2) if args.json else f"Skills: {result['skillCount']} | errors: {len(result['errors'])} | warnings: {len(result['warnings'])}\n"+"\n".join(result['errors']+result['warnings']))
    raise SystemExit(0 if result['ok'] else 1)
if __name__=="__main__": main()
