# V9 Index — Schema-Generated Visual Authoring

## Start here
1. `README.md` — installation and quick start.
2. `AGENTS.md` — operating contract.
3. `docs/V9_SCHEMA_DRIVEN_EDITOR_ARCHITECTURE.md` — overall architecture.
4. `docs/V9_EXTENSION_GUIDE.md` — extend schemas, fields, and generators.
5. `studio-plugin/README.md` — build/install/test the Studio plugin source.

## V9 specialist skills
- `roblox-schema-driven-studio-editor`
- `roblox-dynamic-form-rendering`
- `roblox-content-template-authoring`
- `roblox-asset-reference-authoring`
- `roblox-prefab-generation-quality`
- `roblox-editor-transaction-safety`
- `roblox-generated-content-diff`
- `roblox-content-authoring-ux`

## V9 documentation
- `docs/V9_SCHEMA_DRIVEN_EDITOR_ARCHITECTURE.md`
- `docs/V9_SCHEMA_CATALOG_CONTRACT.md`
- `docs/V9_DYNAMIC_FORM_RENDERING.md`
- `docs/V9_ASSET_REFERENCE_FIELDS.md`
- `docs/V9_EDITOR_PREVIEW_AND_DRY_RUN.md`
- `docs/V9_PREFAB_FACTORY_TRANSACTIONS.md`
- `docs/V9_GENERATED_CONTENT_GOVERNANCE.md`
- `docs/V9_EXTENSION_GUIDE.md`
- `docs/V9_STUDIO_PLUGIN_BUILD_AND_INSTALL.md`
- `docs/V9_TEST_MATRIX.md`
- `docs/V9_SCHEMA_VERSIONING.md`
- `docs/V9_EDITOR_UX_CHECKLIST.md`

## Plugin source tree
`studio-plugin/src/` contains the plugin entrypoint and modules:
- `SchemaCatalog.lua`
- `FieldPath.lua`
- `SchemaValidator.lua`
- `TemplateResolver.lua`
- `DefinitionSerializer.lua`
- `DynamicFormRenderer.lua`
- `PreviewRenderer.lua`
- `PrefabFactory.lua`
- `EditorApp.lua`

## Content families included
- NPC
- Companion
- Cosmetic accessory
- World prop
- Interactive prop
- Harmless utility gadget

## Validation tools
- `tools/v9_schema_catalog_lint.py`
- `tools/v9_definition_validate.py`
- `tools/v9_plugin_source_check.py`
- `tools/v9_generated_manifest_lint.py`
- `tools/v9_editor_field_reference.py`
- `tools/v9_content_registry_lint.py`

## Preserved foundation
All V8 material remains available. Earlier V6/V7 indexes and package manifests are retained as historical references.
