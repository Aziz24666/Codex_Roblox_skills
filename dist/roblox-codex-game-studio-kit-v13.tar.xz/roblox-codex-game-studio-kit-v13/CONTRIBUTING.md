# Contributing

Thank you for considering a contribution to Roblox Codex Game Studio Kit.

## Before opening a change

1. Read `AGENTS.md` and the relevant specialist skills under `.agents/skills/`.
2. For Roblox API or tooling changes, research current official Roblox Creator Hub and upstream tool documentation first.
3. Prefer small, focused changes with clear module responsibilities and no unnecessary duplication.
4. Update the relevant documentation, prompts, templates, schemas, and examples when behavior changes.
5. Never add credentials, personal data, private asset identifiers, or production experience data.

## Local validation

Use Python 3.13 and install the pinned dependencies:

```bash
python -m pip install --requirement requirements-ci.txt
python tools/v13_ci_preflight.py .
python -m unittest discover -s tools/tests -p 'test_*.py' -v
```

For Luau syntax compilation, install the Luau CLI and run:

```bash
python tools/compile_luau_sources.py --root . --compiler luau-compile --min-files 50
```

For Rojo project builds, install the version pinned in `examples/v13/rokit.toml` and run:

```bash
rojo build project-template/default.project.json --output /tmp/RobloxExperience.rbxlx
rojo build studio-plugin/default.project.json --output /tmp/ContentFactoryPlugin.rbxmx
```

Roblox Studio playtests, Studio MCP operations, device testing, and published-experience checks must be reported separately. A successful static build is not evidence that those runtime checks passed.

## Pull requests

- Explain the player/developer problem being solved.
- List changed files and architectural decisions.
- Include research sources for platform/API choices.
- Include commands run and actual results.
- State any unavailable checks explicitly.
- Do not publish, deploy, or modify live Roblox data as part of a contribution.
