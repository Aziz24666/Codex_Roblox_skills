# Roblox Codex Game Studio Kit — V11 Index

## Start here
- `AGENTS.md` — concise global contract and safety/research rules.
- `README.md` — installation and validation.
- `INDEX_V11.md` — skill and reference routing.
- `PACKAGE_INVENTORY.md` — generated file inventory.
- `V11_TEST_RESULTS.md` — package validation and explicit runtime-test limitations.

## V11 specialist skills
- `$roblox-repository-health` — repository/source-of-truth audit.
- `$roblox-change-impact-analysis` — changed-module and regression scope.
- `$roblox-ci-reproducibility` — pinned tools and repeatable CI checks.
- `$roblox-release-engineering` — evidence gates and rollback preparation.
- `$roblox-test-evidence-governance` — traceable test records.
- `$roblox-defect-isolation` — reproduction and root-cause workflow.
- `$roblox-dependency-governance` — dependency graph and module boundaries.
- `$roblox-agent-context-optimization` — concise instructions and progressive disclosure.
- `$roblox-studio-mcp-workflows` — connected Studio MCP operations.
- `$roblox-generated-artifact-governance` — deterministic generation and drift.

## V11 additions
- Full orchestrator reference: `docs/V11_GAME_BUILDER_FULL_PLAYBOOK.md`
- Project starter workflow: `project-template/docs/V11_ENGINEERING_WORKFLOW.md`
- Context-efficient skill design: `docs/V11_CONTEXT_BUDGET_AND_SKILL_ROUTING.md`
- Repository ownership: `docs/V11_REPOSITORY_HEALTH_AND_OWNERSHIP.md`
- Change impact: `docs/V11_CHANGE_IMPACT_AND_TEST_SELECTION.md`
- CI/reproducibility: `docs/V11_CI_AND_REPRODUCIBILITY.md`
- Test evidence: `docs/V11_TEST_EVIDENCE_AND_QUALITY.md`
- Defect isolation: `docs/V11_DEFECT_ISOLATION_AND_RECOVERY.md`
- Dependency boundaries: `docs/V11_DEPENDENCY_GRAPH_AND_BOUNDARIES.md`
- Generated artifact integrity: `docs/V11_GENERATED_ARTIFACTS_AND_DRIFT.md`
- Studio MCP/Open Cloud: `docs/V11_STUDIO_MCP_AND_OPEN_CLOUD.md`
- Open Cloud Luau Execution: `docs/V11_OPEN_CLOUD_LUAU_EXECUTION.md`
- API currency: `docs/V11_API_CURRENCY_AND_DEPRECATION.md`
- Release/rollback: `docs/V11_RELEASE_AND_ROLLBACK.md`
- Human maintainability: `docs/V11_HUMAN_MAINTAINABILITY_REVIEW.md`
- Research source quality: `docs/V11_RESEARCH_SOURCE_QUALITY.md`
- Toolchain discovery: `docs/V11_TOOLCHAIN_DISCOVERY.md`
- Feature completion: `docs/V11_FEATURE_COMPLETION_CONTRACT.md`

## Skill routing
Always use `$roblox-game-builder` for whole-game work. Use the minimum matching specialists. New V11 skills: repository health, change impact, CI/reproducibility, release engineering, test evidence governance, defect isolation, dependency governance, agent context optimization, Studio MCP workflows, and generated artifact governance.

## Research gate
For any substantive Roblox code/API/tooling/architecture/security/testing/performance/release work, perform fresh research before implementation. See `AGENTS.md`, `docs/V10_RESEARCH_FIRST_STANDARD.md`, `docs/V11_RESEARCH_SOURCE_QUALITY.md`, and `research/decisions/V11_CONTEXT_AND_STUDIO_WORKFLOW.json`.

## V9/V10 editor system
Continue using the schema-driven Studio editor and content-factory references from `INDEX_V9.md` and the V9/V10 docs. Do not replace the user's source of truth or run live mutation operations without approval.

## V1–V10 history
Previous indexes and changelogs remain in the package for migration context. Prefer current V11 rules where old guidance conflicts; verify API-specific content afresh.
