--!strict
-- Reusable CollectionService component binder.
-- Each attach callback owns its per-instance resources and returns their cleanup function.

local CollectionService = game:GetService("CollectionService")

type Cleanup = () -> ()
type Attach = (instance: Instance) -> Cleanup?

export type Controller = {
    Start: () -> (),
    Stop: () -> (),
}

local Binder = {}

function Binder.new(tag: string, attachCallback: Attach): Controller
    assert(tag ~= "", "Tag must not be empty")

    local cleanups: { [Instance]: Cleanup } = {}
    local addedConnection: RBXScriptConnection? = nil
    local removedConnection: RBXScriptConnection? = nil
    local started = false

    local function attach(instance: Instance)
        if cleanups[instance] ~= nil then
            return
        end

        local ok, cleanupOrError = pcall(attachCallback, instance)
        if not ok then
            warn(string.format("[TaggedLifecycleBinder] Attach failed for %s: %s", instance.Name, tostring(cleanupOrError)))
            return
        end

        if typeof(cleanupOrError) == "function" then
            cleanups[instance] = cleanupOrError :: Cleanup
        else
            cleanups[instance] = function() end
        end
    end

    local function detach(instance: Instance)
        local cleanup = cleanups[instance]
        if cleanup == nil then
            return
        end

        cleanups[instance] = nil
        local ok, err = pcall(cleanup)
        if not ok then
            warn(string.format("[TaggedLifecycleBinder] Cleanup failed for %s: %s", instance.Name, tostring(err)))
        end
    end

    local function stop()
        if not started then
            return
        end
        started = false

        if addedConnection then
            addedConnection:Disconnect()
            addedConnection = nil
        end
        if removedConnection then
            removedConnection:Disconnect()
            removedConnection = nil
        end

        local instances: { Instance } = {}
        for instance in pairs(cleanups) do
            table.insert(instances, instance)
        end
        for _, instance in ipairs(instances) do
            detach(instance)
        end
    end

    local function start()
        if started then
            return
        end
        started = true

        -- Connect first, then enumerate. attach() is idempotent if both paths see an instance.
        addedConnection = CollectionService:GetInstanceAddedSignal(tag):Connect(attach)
        removedConnection = CollectionService:GetInstanceRemovedSignal(tag):Connect(detach)

        for _, instance in ipairs(CollectionService:GetTagged(tag)) do
            attach(instance)
        end
    end

    return {
        Start = start,
        Stop = stop,
    }
end

return Binder
