--!strict
-- Minimal example of a streamed client-only presentation component.
-- This does not own or mutate authoritative game state.

local Binder = require(script.Parent.TaggedLifecycleBinder)

local function attach(instance: Instance): (() -> ())?
    local highlight = Instance.new("Highlight")
    highlight.Name = "LocalTaggedPresentation"
    highlight.Adornee = instance
    highlight.Parent = instance

    return function()
        highlight:Destroy()
    end
end

local binder = Binder.new("LocalPresentationExample", attach)
binder.Start()

script.Destroying:Connect(function()
    binder.Stop()
end)
