# Sample profile evidence placeholder

This is a documentation fixture used by the JSON schema example. It is not a real Roblox performance capture. Replace it with an actual Studio/MicroProfiler/Developer Console capture before using the sample baseline as evidence.
