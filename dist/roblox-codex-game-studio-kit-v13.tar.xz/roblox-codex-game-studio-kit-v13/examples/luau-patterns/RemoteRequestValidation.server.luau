--!strict
-- Teaching example: validate client intent at the server boundary.
-- The server must independently calculate and authorize every consequential outcome.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local remotes = ReplicatedStorage:WaitForChild("Remotes")
local requestEvent = remotes:WaitForChild("RequestAction") :: RemoteEvent
local resultEvent = remotes:WaitForChild("ActionResult") :: RemoteEvent

local WINDOW_SECONDS = 5
local MAX_REQUESTS_PER_WINDOW = 8
local requestWindows: {[number]: {startedAt: number, count: number}} = {}

local function allowRequest(player: Player): boolean
    local now = os.clock()
    local userId = player.UserId
    local bucket = requestWindows[userId]

    if bucket == nil or now - bucket.startedAt >= WINDOW_SECONDS then
        requestWindows[userId] = {startedAt = now, count = 1}
        return true
    end

    if bucket.count >= MAX_REQUESTS_PER_WINDOW then
        return false
    end

    bucket.count += 1
    return true
end

local function isFiniteNumber(value: unknown): boolean
    return typeof(value) == "number"
        and value == value
        and value ~= math.huge
        and value ~= -math.huge
end

requestEvent.OnServerEvent:Connect(function(player: Player, actionId: unknown, amount: unknown)
    if not allowRequest(player) then
        resultEvent:FireClient(player, false, "TooManyRequests")
        return
    end

    if typeof(actionId) ~= "string" or #actionId < 1 or #actionId > 32 then
        resultEvent:FireClient(player, false, "InvalidRequest")
        return
    end

    if typeof(amount) ~= "number" then
        resultEvent:FireClient(player, false, "InvalidRequest")
        return
    end
    if not isFiniteNumber(amount) or amount < 0 or amount > 10 then
        resultEvent:FireClient(player, false, "InvalidRequest")
        return
    end
    local requestedAmount = amount -- validated input; do not treat it as an authoritative reward

    -- This allowlist and player-state check are illustrative.
    if actionId ~= "CollectSample" then
        resultEvent:FireClient(player, false, "UnknownAction")
        return
    end

    -- TODO: Verify authoritative world conditions, ownership, distance, cooldown,
    -- current player state, and whether this request has already been processed.
    -- Compute the actual reward on the server. Never apply requestedAmount as value.
    local _ = requestedAmount -- retained only to show it was validated; server formula remains authoritative
    local serverApproved = player.Character ~= nil
    if not serverApproved then
        resultEvent:FireClient(player, false, "NotReady")
        return
    end

    resultEvent:FireClient(player, true, "Accepted")
end)

Players.PlayerRemoving:Connect(function(player: Player)
    requestWindows[player.UserId] = nil
end)
