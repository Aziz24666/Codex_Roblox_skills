--!strict
-- Teaching pattern: manage instances as CollectionService tags are added/removed.
local CollectionService = game:GetService("CollectionService")
local TAG = "ManagedInteractable"
local active: {[Instance]: RBXScriptConnection} = {}
local function stop(instance: Instance)
    local connection = active[instance]
    if connection then connection:Disconnect(); active[instance] = nil end
end
local function manage(instance: Instance)
    if active[instance] then return end
    if not instance:IsA("BasePart") then warn("Unsupported tagged instance:", instance.ClassName); return end
    active[instance] = instance.Destroying:Connect(function() stop(instance) end)
end
for _, instance in CollectionService:GetTagged(TAG) do manage(instance) end
CollectionService:GetInstanceAddedSignal(TAG):Connect(manage)
CollectionService:GetInstanceRemovedSignal(TAG):Connect(stop)
