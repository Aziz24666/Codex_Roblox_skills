--!strict
-- Teaching pattern: explicit state transitions with one transition owner.
type State = "Waiting" | "Intermission" | "Active" | "Results"
local state: State = "Waiting"
local roundId = 0
local allowed: {[State]: {[State]: boolean}} = {
    Waiting = {Intermission = true},
    Intermission = {Active = true, Waiting = true},
    Active = {Results = true, Waiting = true},
    Results = {Intermission = true, Waiting = true},
}
local function transition(nextState: State): boolean
    if not allowed[state][nextState] then return false end
    local previous = state
    state = nextState
    if nextState == "Intermission" then roundId += 1 end
    print(("Round %d: %s -> %s"):format(roundId, previous, nextState))
    return true
end
-- Production code also needs bounded timers, cancellation, and cleanup.
return transition
