--!strict
-- Simple cleanup owner for RBXScriptConnections, Instances, and cleanup callbacks.
-- Extend only when the project needs more resource types or explicit task cancellation.

export type CleanupItem = RBXScriptConnection | Instance | (() -> ())
export type CleanupBag = {
    items: {CleanupItem},
    cleaned: boolean,
}

local CleanupBag = {}

function CleanupBag.new(): CleanupBag
    return {items = {}, cleaned = false}
end

function CleanupBag.add(bag: CleanupBag, item: CleanupItem): CleanupItem
    if bag.cleaned then
        if typeof(item) == "RBXScriptConnection" then
            item:Disconnect()
        elseif typeof(item) == "Instance" then
            item:Destroy()
        else
            item()
        end
        return item
    end
    table.insert(bag.items, item)
    return item
end

function CleanupBag.clean(bag: CleanupBag)
    if bag.cleaned then
        return
    end
    bag.cleaned = true

    for index = #bag.items, 1, -1 do
        local item = bag.items[index]
        local ok, message = pcall(function()
            if typeof(item) == "RBXScriptConnection" then
                item:Disconnect()
            elseif typeof(item) == "Instance" then
                item:Destroy()
            else
                item()
            end
        end)
        if not ok then
            warn("Cleanup failed:", message)
        end
        bag.items[index] = nil
    end
end

return CleanupBag
