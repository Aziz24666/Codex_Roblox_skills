--!strict
-- In-memory teaching example only. This is NOT durable across servers/restarts
-- and cannot replace transactional persistence or DataStore concurrency controls.

export type Ledger = {
    processed: {[string]: boolean},
}

local Ledger = {}

function Ledger.new(): Ledger
    return {processed = {}}
end

function Ledger.hasProcessed(ledger: Ledger, operationId: string): boolean
    return ledger.processed[operationId] == true
end

function Ledger.markProcessed(ledger: Ledger, operationId: string): boolean
    if ledger.processed[operationId] == true then
        return false
    end
    ledger.processed[operationId] = true
    return true
end

return Ledger
