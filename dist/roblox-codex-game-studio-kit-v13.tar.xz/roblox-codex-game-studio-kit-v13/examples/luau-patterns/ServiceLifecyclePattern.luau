--!strict
-- Teaching pattern: explicit lifecycle and idempotent connection cleanup.
local Service = {}
Service.__index = Service
type Self = { _started: boolean, _connections: {RBXScriptConnection} }
function Service.new(): Self
    return setmetatable({_started = false, _connections = {}}, Service) :: any
end
function Service.Start(self: Self)
    if self._started then return end
    self._started = true
    -- Save owned connections in self._connections.
end
function Service.Destroy(self: Self)
    self._started = false
    for _, connection in self._connections do connection:Disconnect() end
    table.clear(self._connections)
end
return Service
