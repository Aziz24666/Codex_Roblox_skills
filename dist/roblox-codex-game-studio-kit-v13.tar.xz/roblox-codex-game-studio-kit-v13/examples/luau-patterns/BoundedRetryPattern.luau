--!strict
-- Teaching pattern: bounded retry with jitter; operation must be idempotent/safe to repeat.
local function retry<T>(operation: () -> T, maxAttempts: number): (boolean, T?)
    local attempts = math.clamp(math.floor(maxAttempts), 1, 5)
    for attempt = 1, attempts do
        local ok, result = pcall(operation)
        if ok then return true, result :: T end
        if attempt == attempts then return false, nil end
        local delaySeconds = math.min(0.25 * (2 ^ (attempt - 1)), 4) + math.random() * 0.2
        task.wait(delaySeconds)
    end
    return false, nil
end
return retry
