--!strict
-- Teaching pattern: validate intent-based remote requests on the server.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local requestEvent = ReplicatedStorage:WaitForChild("RequestInteraction") :: RemoteEvent
local cooldowns: {[Player]: number} = {}
local COOLDOWN = 0.5
local MAX_DISTANCE = 18
local function isFinite(n: number): boolean return n == n and n > -math.huge and n < math.huge end
local function getRoot(player: Player): BasePart?
    local character = player.Character
    if not character then return nil end
    return character:FindFirstChild("HumanoidRootPart") :: BasePart?
end
requestEvent.OnServerEvent:Connect(function(player: Player, target: Instance)
    if typeof(target) ~= "Instance" or not target:IsA("BasePart") then return end
    local folder = workspace:FindFirstChild("Interactables")
    if not folder or not target:IsDescendantOf(folder) then return end
    local root = getRoot(player)
    if not root then return end
    local distance = (root.Position - target.Position).Magnitude
    if not isFinite(distance) or distance > MAX_DISTANCE then return end
    local now = os.clock()
    if now - (cooldowns[player] or -math.huge) < COOLDOWN then return end
    cooldowns[player] = now
    -- Recheck object state and permission; apply one authoritative, idempotent outcome.
end)
Players.PlayerRemoving:Connect(function(player) cooldowns[player] = nil end)
