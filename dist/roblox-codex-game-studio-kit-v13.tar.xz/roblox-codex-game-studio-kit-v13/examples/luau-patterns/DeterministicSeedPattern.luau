--!strict
-- Teaching pattern: explicit seed and generator version for reproducible layouts.
local function chooseVariant(seed: number, count: number): number
    assert(seed == seed and seed > -math.huge and seed < math.huge, "Seed must be finite")
    assert(count >= 1 and count % 1 == 0, "count must be a positive integer")
    return Random.new(math.floor(seed)):NextInteger(1, count)
end
return { GeneratorVersion = 1, ChooseVariant = chooseVariant }
