# Luau Teaching Patterns — V5

These are small teaching examples, not drop-in production services or proof of correctness. Adapt to the existing project and run the current Luau type checker and Studio tests.

- `RemoteContractPattern.server.luau` — intent-based server validation; add allowlists and feature state checks.
- `RoundStateMachine.server.luau` — explicit transitions; add timer ownership and cleanup.
- `ServiceLifecyclePattern.luau` — Start/Destroy and connection cleanup.
- `TaggedInstanceLifecycle.server.luau` — CollectionService tag lifecycle.
- `BoundedRetryPattern.luau` — transient failures only; never retry unsafe side effects blindly.
- `DeterministicSeedPattern.luau` — deterministic procedural selection with a generator version.
