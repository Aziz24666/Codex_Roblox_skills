--!strict
-- Small pure state-transition helper. Keep authoritative gameplay state on the server.

export type TransitionMap = {[string]: {string}}
export type StateMachine = {
    current: string,
    transitions: TransitionMap,
}

local StateMachine = {}

function StateMachine.new(initialState: string, transitions: TransitionMap): StateMachine
    assert(initialState ~= "", "initialState must not be empty")
    assert(transitions[initialState] ~= nil, "initialState must exist in transitions")
    return {current = initialState, transitions = transitions}
end

function StateMachine.getState(machine: StateMachine): string
    return machine.current
end

function StateMachine.canTransition(machine: StateMachine, nextState: string): boolean
    local allowed = machine.transitions[machine.current]
    return allowed ~= nil and table.find(allowed, nextState) ~= nil
end

function StateMachine.transition(machine: StateMachine, nextState: string): (boolean, string?)
    if not StateMachine.canTransition(machine, nextState) then
        return false, "InvalidTransition"
    end
    machine.current = nextState
    return true, nil
end

return StateMachine
