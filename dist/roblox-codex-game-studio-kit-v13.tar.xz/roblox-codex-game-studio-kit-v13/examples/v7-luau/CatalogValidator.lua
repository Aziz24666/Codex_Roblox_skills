--!strict
export type CatalogEntry = {
    id: string,
    kind: string,
    availability: string,
}
local CatalogValidator = {}

function CatalogValidator.validate(entries: {CatalogEntry}): (boolean, {string})
    local errors: {string} = {}
    local seen: {[string]: boolean} = {}
    for index, entry in ipairs(entries) do
        if entry.id == "" then table.insert(errors, `Entry {index} has empty id`) end
        if seen[entry.id] then table.insert(errors, `Duplicate id: {entry.id}`) end
        seen[entry.id] = true
        if entry.kind == "" then table.insert(errors, `Entry {entry.id} has empty kind`) end
        if entry.availability ~= "ACTIVE" and entry.availability ~= "DISABLED" and entry.availability ~= "RETIRED" then
            table.insert(errors, `Entry {entry.id} has invalid availability`)
        end
    end
    return #errors == 0, errors
end
return CatalogValidator
