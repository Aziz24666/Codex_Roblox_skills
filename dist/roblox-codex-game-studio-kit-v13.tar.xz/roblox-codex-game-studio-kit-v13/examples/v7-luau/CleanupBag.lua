--!strict
-- Minimal cleanup owner for RBXScriptConnection, Instance, or cleanup callback.
export type CleanupTask = RBXScriptConnection | Instance | (() -> ())
local CleanupBag = {}
CleanupBag.__index = CleanupBag

function CleanupBag.new()
    return setmetatable({ tasks = {}, closed = false }, CleanupBag)
end

function CleanupBag:add(task: CleanupTask)
    if self.closed then
        if typeof(task) == "RBXScriptConnection" then task:Disconnect()
        elseif typeof(task) == "Instance" then task:Destroy()
        else task() end
        return task
    end
    table.insert(self.tasks, task)
    return task
end

function CleanupBag:destroy()
    if self.closed then return end
    self.closed = true
    for index = #self.tasks, 1, -1 do
        local task = self.tasks[index]
        if typeof(task) == "RBXScriptConnection" then task:Disconnect()
        elseif typeof(task) == "Instance" then task:Destroy()
        else task() end
        self.tasks[index] = nil
    end
end

return CleanupBag
