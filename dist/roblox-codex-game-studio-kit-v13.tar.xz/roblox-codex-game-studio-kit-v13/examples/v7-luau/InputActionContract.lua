--!strict
-- Semantic actions are independent from physical key/button bindings.
export type ActionName = "Interact" | "Confirm" | "Cancel" | "OpenInventory"
export type InputMode = "Touch" | "KeyboardMouse" | "Gamepad"
export type ActionMap = {[ActionName]: boolean}

local InputActionContract = {}
function InputActionContract.isSupportedAction(name: string): boolean
    return name == "Interact" or name == "Confirm" or name == "Cancel" or name == "OpenInventory"
end
return InputActionContract
