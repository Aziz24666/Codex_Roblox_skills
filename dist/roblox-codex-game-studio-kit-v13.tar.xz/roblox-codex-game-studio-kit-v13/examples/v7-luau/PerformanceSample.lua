--!strict
-- Data shape only. The caller chooses approved sampling and privacy policy.
export type MetricSample = {
    buildId: string,
    scenario: string,
    deviceProfile: string,
    metric: string,
    value: number,
    unit: string,
}
local PerformanceSample = {}
function PerformanceSample.isFinite(sample: MetricSample): boolean
    return sample.value == sample.value and sample.value > -math.huge and sample.value < math.huge
end
return PerformanceSample
