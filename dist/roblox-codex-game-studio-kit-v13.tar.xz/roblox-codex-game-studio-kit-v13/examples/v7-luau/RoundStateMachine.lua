--!strict
-- Pure state-transition example. The caller owns serialization and side effects.
export type State = "Waiting" | "Intermission" | "Playing" | "Results"
export type Event = "EnoughPlayers" | "CountdownFinished" | "RoundFinished" | "Reset"

local allowed: {[State]: {[Event]: State}} = {
    Waiting = { EnoughPlayers = "Intermission" },
    Intermission = { CountdownFinished = "Playing", Reset = "Waiting" },
    Playing = { RoundFinished = "Results" },
    Results = { Reset = "Waiting" },
}

local StateMachine = {}
function StateMachine.transition(current: State, event: Event): (State?, string?)
    local nextState = allowed[current][event]
    if nextState == nil then
        return nil, `Illegal transition: {current} + {event}`
    end
    return nextState, nil
end
return StateMachine
