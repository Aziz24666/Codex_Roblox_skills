--!strict
export type JourneyStep = {
    id: string,
    prerequisites: {string},
    completionEvent: string,
    serverRewardId: string?,
}
export type JourneyProgress = {
    version: number,
    completed: {[string]: boolean},
}

local Journey = {}
function Journey.hasCompleted(progress: JourneyProgress, stepId: string): boolean
    return progress.completed[stepId] == true
end
return Journey
