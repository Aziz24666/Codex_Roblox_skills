--!strict
-- Illustrative server-side validation helpers. Call them from server-owned handlers.
local RequestValidation = {}

function RequestValidation.isFiniteNumber(value: any): boolean
    return typeof(value) == "number" and value == value and value > -math.huge and value < math.huge
end

function RequestValidation.isBoundedInteger(value: any, minimum: number, maximum: number): boolean
    return RequestValidation.isFiniteNumber(value)
        and value % 1 == 0
        and value >= minimum
        and value <= maximum
end

function RequestValidation.isKnownString(value: any, allowed: {[string]: boolean}, maxLength: number): boolean
    return typeof(value) == "string" and #value <= maxLength and allowed[value] == true
end

return RequestValidation
