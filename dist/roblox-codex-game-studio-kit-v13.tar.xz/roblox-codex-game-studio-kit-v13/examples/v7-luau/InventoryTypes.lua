--!strict
export type ItemDefinition = {
    id: string,
    maxStack: number,
    allowedSlots: {string},
}
export type OwnedItem = {
    instanceId: string,
    itemId: string,
    quantity: number,
}
export type Loadout = {[string]: string?} -- slot name -> owned instanceId

return {}
