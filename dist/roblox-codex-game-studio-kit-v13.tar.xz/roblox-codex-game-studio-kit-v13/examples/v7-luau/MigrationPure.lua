--!strict
-- Pure transformation example. The persistence adapter and write are intentionally omitted.
export type ProfileV1 = { coins: number }
export type ProfileV2 = { schemaVersion: number, currency: { coins: number } }

local Migration = {}
function Migration.v1ToV2(old: ProfileV1): ProfileV2
    return {
        schemaVersion = 2,
        currency = { coins = math.max(0, math.floor(old.coins)) },
    }
end
return Migration
