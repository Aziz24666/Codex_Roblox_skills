# V10 Examples

- `research/` contains dated example decision records. These are snapshots, not a substitute for fresh research on your task.
- `architecture/` contains a minimal module contract example and a layering example.
- `quality-fixtures/` contains intentionally imperfect Luau fixtures for the static architecture audit. They are test fixtures only, not production patterns.
