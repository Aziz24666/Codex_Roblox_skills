# Example Layering

```text
Content Definitions (immutable data)
            |
            v
Registry / Resolver ---- Approved Templates
            |
            v
Shared Runtime / Controllers
            |
            +---- Per-instance runtime state
            |
            v
Adapters (Roblox services, physics, animation, persistence)
            |
            v
Presentation (UI, sound, camera)
```

Keep Studio plugin/editor tooling outside this runtime graph. Keep networking as an explicit boundary and never let client data directly mutate authoritative state.
