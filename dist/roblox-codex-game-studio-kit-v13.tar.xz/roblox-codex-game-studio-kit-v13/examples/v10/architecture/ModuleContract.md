# Example Module Contract

**Module:** `EntityMovementService`

**Responsibility:** Apply movement goals for registered entities using a shared implementation.

**Non-goals:** Own entity definitions, create UI, persist player data, or make progression decisions.

**Public API:**
- `Register(entityId, model, definition)`
- `SetGoal(entityId, goal)`
- `Unregister(entityId)`

**State owner:** A private runtime record per registered entity. Definition tables are immutable input.

**Dependencies:** Path/goal adapter injected at construction; no hidden global module lookup.

**Lifecycle:** Register → update → unregister. All connections/tasks are cleaned up by unregister.

**Execution context:** Server-owned NPC movement; client presentation is separate.

**Test seam:** Pure goal-selection tests plus a disposable Studio pathfinding/movement test.
