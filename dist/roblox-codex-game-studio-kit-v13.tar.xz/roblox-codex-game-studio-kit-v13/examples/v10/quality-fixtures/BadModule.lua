-- Intentionally poor fixture for v10_architecture_quality_audit.py. Do not copy.
local RunService = game:GetService("RunService")
while true do
    RunService.Heartbeat:Wait()
    print("Doing a lot of things in one loop")
end
