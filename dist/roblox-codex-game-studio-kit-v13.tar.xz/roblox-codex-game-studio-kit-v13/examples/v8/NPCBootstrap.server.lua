--!strict
-- One bootstrap manages all tagged NPCs. It does not clone Script instances into NPC models.

local CollectionService = game:GetService("CollectionService")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local ServerScriptService = game:GetService("ServerScriptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local NPCController = require(ServerScriptService.Components.NPCController)
local Registry = require(ReplicatedStorage.Shared.Config.NPCDefinitionRegistry)
local Validator = require(ReplicatedStorage.Shared.Config.NPCDefinitionValidator)
local RouteResolver = require(ServerScriptService.Components.RouteResolver)

local TAG = "DataDrivenNPC"
local DEFINITION_ATTRIBUTE = "NPCDefinitionId"
local controllers: {[Model]: any} = {}

local function attach(instance: Instance)
    if not instance:IsA("Model") or controllers[instance] ~= nil then return end
    -- Generated prefabs live in ServerStorage; only live Workspace instances get controllers.
    if not instance:IsDescendantOf(Workspace) then return end
    local definitionId = instance:GetAttribute(DEFINITION_ATTRIBUTE)
    if type(definitionId) ~= "string" then
        warn(string.format("[NPCBootstrap] %s missing %s", instance:GetFullName(), DEFINITION_ATTRIBUTE))
        return
    end
    local definition, lookupError = Registry.Get(definitionId)
    if definition == nil then
        warn(string.format("[NPCBootstrap] %s", lookupError))
        return
    end
    local valid, issues = Validator.Validate(definition)
    if not valid then
        warn(string.format("[NPCBootstrap] Invalid %s: %s", definitionId, table.concat(issues, "; ")))
        return
    end
    local controller, reason = NPCController.new(instance, definition, {routeResolver = RouteResolver.GetRoute})
    if controller == nil then
        warn(string.format("[NPCBootstrap] Cannot attach %s: %s", definitionId, tostring(reason)))
        return
    end
    controllers[instance] = controller
end

local function detach(instance: Instance)
    if not instance:IsA("Model") then return end
    local controller = controllers[instance]
    if controller ~= nil then
        controller:Destroy()
        controllers[instance] = nil
    end
end

for _, instance in CollectionService:GetTagged(TAG) do
    attach(instance)
end
CollectionService:GetInstanceAddedSignal(TAG):Connect(attach)
CollectionService:GetInstanceRemovedSignal(TAG):Connect(detach)
Workspace.DescendantAdded:Connect(function(instance)
    if instance:IsA("Model") and CollectionService:HasTag(instance, TAG) then
        attach(instance)
    end
end)
Workspace.DescendantRemoving:Connect(function(instance)
    if instance:IsA("Model") then detach(instance) end
end)

-- One shared scheduler avoids a separate Heartbeat connection per NPC.
local accumulator = 0
RunService.Heartbeat:Connect(function(deltaTime)
    accumulator += deltaTime
    if accumulator < 0.25 then return end
    accumulator = 0
    for model, controller in pairs(controllers) do
        if model.Parent == nil then
            detach(model)
        else
            controller:Step()
        end
    end
end)
