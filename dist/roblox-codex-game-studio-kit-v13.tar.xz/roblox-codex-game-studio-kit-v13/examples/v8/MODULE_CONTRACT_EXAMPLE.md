# Example module contract

**Module:** `MovementController`

- Purpose: turn destination requests into safe humanoid movement.
- Execution side: server for this example.
- Owner: one `NPCController` instance.
- Inputs: Model, validated MovementConfig.
- Public API: `SetDestination`, `Stop`, `Destroy`.
- Mutable state: model/humanoid refs, cancellation state, path state.
- Does not own: behavior choice, NPC definitions, animation assets, dialogue.
- Failure cases: missing Humanoid, destroyed model, unreachable destination.
- Test seam: a movement adapter/path provider can be substituted in a fuller implementation.
