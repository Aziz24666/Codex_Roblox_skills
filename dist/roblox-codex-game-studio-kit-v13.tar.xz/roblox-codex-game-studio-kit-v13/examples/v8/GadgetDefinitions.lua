--!strict
-- Non-combat utility gadget definitions. Asset references are examples/placeholders.

local function deepFreeze(value)
    if type(value) ~= "table" or table.isfrozen(value) then return value end
    for _, child in pairs(value) do deepFreeze(child) end
    return table.freeze(value)
end

local definitions = {
    TrailLantern = {
        schemaVersion = 1,
        id = "TrailLantern",
        displayName = "Trail Lantern",
        utilityKind = "IlluminateArea",
        interaction = {interactionRadius = 12, cooldownSeconds = 0.5},
        visual = {meshAssetId = "", textureAssetId = "", iconAssetId = "", scale = 1},
        audio = {equipSoundAssetId = "", useSoundAssetId = "", volume = 0.7},
        animation = {equipAnimationAssetId = "", useAnimationAssetId = ""},
        utilityConfig = {durationSeconds = 8, intensity = 0.75},
    },
}

return deepFreeze(definitions)
