--!strict

local Follow = require(script.Parent.Behaviors.Follow)
local VendorIdle = require(script.Parent.Behaviors.VendorIdle)
local Patrol = require(script.Parent.Behaviors.Patrol)
local Wander = require(script.Parent.Behaviors.Wander)

local Registry: {[string]: any} = {
    Follow = Follow,
    Guide = Follow,
    VendorIdle = VendorIdle,
    Patrol = Patrol,
    Wander = Wander,
}

function Registry.Create(behaviorName: string, context)
    local behavior = Registry[behaviorName]
    if behavior == nil then
        return nil, string.format("Behavior '%s' is not registered", behaviorName)
    end
    return behavior.Create(context), nil
end

return table.freeze(Registry)
