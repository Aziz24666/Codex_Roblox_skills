# Add a new NPC using data only

1. Add a definition in `NPCDefinitions.lua` with a unique ID.
2. Choose a registered behavior key.
3. Set movement and presentation values.
4. Add the `DataDrivenNPC` tag to the Model.
5. Set the `NPCDefinitionId` attribute to the new ID.
6. Run the config validator and Studio test plan.

No new movement script is required. If the role needs a genuinely new decision policy, implement one behavior module and register it.
