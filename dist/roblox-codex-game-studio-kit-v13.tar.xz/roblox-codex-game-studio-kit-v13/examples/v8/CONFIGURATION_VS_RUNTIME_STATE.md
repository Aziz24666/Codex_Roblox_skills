# Configuration vs Runtime State

```luau
-- Shared definition: immutable values used by all instances with this ID.
local definition = NPCDefinitions[model:GetAttribute("NPCDefinitionId")]

-- Per-instance runtime state: separate for every controller.
local state = {
    currentBehaviorState = "Idle",
    currentWaypointIndex = 1,
    lastPathRequestAt = 0,
    connections = {},
}
```

Never write `definition.currentWaypointIndex = 2`; doing so makes one NPC affect every other NPC that shares the definition.
