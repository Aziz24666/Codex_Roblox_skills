--!strict
-- Shared low-level movement adapter. It contains no NPC-specific speeds or behavior policy.

export type MovementConfig = {
    walkSpeed: number,
    jumpPower: number?,
    arrivalRadius: number,
    repathInterval: number,
    stuckTimeout: number,
    maxPathRetries: number,
}

export type MovementController = {
    SetDestination: (self: MovementController, destination: Vector3) -> (),
    Stop: (self: MovementController) -> (),
    Destroy: (self: MovementController) -> (),
}

local MovementController = {}
MovementController.__index = MovementController

function MovementController.new(model: Model, config: MovementConfig): MovementController
    local humanoid = model:FindFirstChildOfClass("Humanoid")
    assert(humanoid ~= nil, "NPC model requires a Humanoid")

    humanoid.WalkSpeed = config.walkSpeed
    if config.jumpPower ~= nil then
        humanoid.JumpPower = config.jumpPower
    end

    local self = setmetatable({
        _model = model,
        _humanoid = humanoid,
        _config = config,
        _lastDestination = nil,
        _destroyed = false,
    }, MovementController)
    return (self :: any) :: MovementController
end

function MovementController:SetDestination(destination: Vector3)
    if self._destroyed then return end
    local lastDestination = self._lastDestination
    if lastDestination ~= nil and (lastDestination - destination).Magnitude < 2 then
        return
    end
    self._lastDestination = destination
    self._humanoid:MoveTo(destination)
end

function MovementController:Stop()
    if self._destroyed then return end
    self._lastDestination = nil
    self._humanoid:Move(Vector3.zero, false)
end

function MovementController:Destroy()
    if self._destroyed then return end
    self._destroyed = true
    self._humanoid:Move(Vector3.zero, false)
end

return MovementController
