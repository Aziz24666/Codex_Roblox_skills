--!strict
-- Data-only definitions. Do not store current path, timers, or per-model state here.

local function deepFreeze(value)
    if type(value) ~= "table" or table.isfrozen(value) then return value end
    for _, child in pairs(value) do deepFreeze(child) end
    return table.freeze(value)
end

local definitions = {
    VillageGuide = {
        schemaVersion = 1,
        id = "VillageGuide",
        displayName = "Village Guide",
        behavior = "Patrol",
        movement = {
            walkSpeed = 10,
            jumpPower = 35,
            arrivalRadius = 3,
            turnResponsiveness = 0.18,
            repathInterval = 2.5,
            stuckTimeout = 8,
            maxPathRetries = 3,
        },
        behaviorConfig = {
            routeId = "VillageLoop",
            pauseAtWaypointSeconds = 2,
        },
        presentation = {
            idleAnimationAssetId = "",
            walkAnimationAssetId = "",
            greetingSoundAssetId = "",
        },
    },
    Companion = {
        schemaVersion = 1,
        id = "Companion",
        displayName = "Trail Companion",
        behavior = "Follow",
        movement = {
            walkSpeed = 13,
            jumpPower = 42,
            arrivalRadius = 5,
            turnResponsiveness = 0.22,
            repathInterval = 1.5,
            stuckTimeout = 6,
            maxPathRetries = 3,
        },
        behaviorConfig = {
            followOffsetX = 3,
            followOffsetZ = 4,
            stopDistance = 5,
        },
        presentation = {
            idleAnimationAssetId = "",
            walkAnimationAssetId = "",
            greetingSoundAssetId = "",
        },
    },
}

return deepFreeze(definitions)
