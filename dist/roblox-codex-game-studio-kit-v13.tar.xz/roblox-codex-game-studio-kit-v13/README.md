# Roblox Codex Game Studio Kit

[![CI](https://github.com/Aziz24666/roblox-codex-game-studio-kit/actions/workflows/ci.yml/badge.svg)](https://github.com/Aziz24666/roblox-codex-game-studio-kit/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A research-first, modular Roblox game-development toolkit for Codex. It provides reusable Luau patterns, data-driven NPC and gameplay architecture, schema-generated Studio content editors, prefab factories, project templates, specialist skills, testing utilities, and GitHub Actions quality gates.

> **Current release: V13** — the cumulative package. You only need this repository; older version archives are not required.

## What this repository contains

- **Codex skills:** focused Roblox development skills with progressive disclosure. Start with `AGENTS.md` and `.agents/skills/roblox-game-builder/SKILL.md`.
- **Research-first engineering:** official Roblox documentation and reputable upstream sources must be checked before substantive API/tooling decisions. Research and decision records are kept under `research/`.
- **Modular/data-driven architecture:** reusable systems with configuration definitions, typed contracts, explicit lifecycles, and extension points.
- **NPC and gameplay examples:** shared runtime systems, behavior registries, validation, cleanup, and data-driven definitions.
- **Studio content factory:** a schema-driven plugin starter for generating editor controls, validating definitions, previewing and creating structured prefabs.
- **Testing and quality tools:** Python validators, schemas, test matrices, evidence checks, dependency audits, release preflight, and CI utilities.
- **Project template:** a Rojo-ready sample project under `project-template/`.

## Quick start

1. Clone or download this repository.
2. Open the repository root in Codex.
3. Read `AGENTS.md` and `INDEX_V13.md`.
4. Ask Codex to audit your existing Roblox project before copying or merging the project template.
5. Select only the specialist skills and reference documents relevant to the current task.

Suggested first instruction:

```text
Read AGENTS.md and INDEX_V13.md. Use $roblox-game-builder as the primary orchestrator.
Audit this project and identify its source of truth before changing files. Research current official Roblox documentation before substantive API or tooling decisions. Create a prioritized roadmap, then implement one complete playable vertical slice at a time. Prefer reusable data-driven systems and clean, strictly typed Luau. Run the available tests and builds, report actual evidence, and clearly identify Studio/runtime checks that were not available. Do not publish or modify live production data without explicit authorization.
```

## Repository map

| Path | Purpose |
|---|---|
| `AGENTS.md` | Global Codex instructions and workflow rules |
| `.agents/skills/` | Specialist Codex skills |
| `docs/` | Architecture, Roblox engineering, research, testing, release documentation |
| `prompts/` | Reusable development prompts |
| `templates/` | Project and process templates |
| `schemas/` | JSON Schemas and examples |
| `examples/` | Luau patterns, content definitions, editor examples |
| `studio-plugin/` | Schema-driven Roblox Studio content factory plugin source |
| `project-template/` | Example Rojo-managed Roblox experience |
| `tools/` | Python audits, validators, generators, and CI helpers |
| `.github/workflows/` | Automated quality, Luau compilation, and Rojo builds |
| `research/` | Research snapshots and architecture decision records |

## Local checks

Requirements: Python 3.13 and the pinned packages in `requirements-ci.txt`.

```bash
python -m pip install --requirement requirements-ci.txt
python tools/v13_ci_preflight.py .
python -m unittest discover -s tools/tests -p 'test_*.py' -v
```

Install the Luau CLI and compile every tracked Lua/Luau source file:

```bash
python tools/compile_luau_sources.py --root . --compiler luau-compile --min-files 50
```

Install Rojo 7.7.1 (see `examples/v13/rokit.toml`) and build both included projects:

```bash
rojo build project-template/default.project.json --output /tmp/RobloxExperience.rbxlx
rojo build studio-plugin/default.project.json --output /tmp/ContentFactoryPlugin.rbxmx
```

## GitHub Actions

Every push to `main`, pull request, and manual workflow dispatch runs `.github/workflows/ci.yml`:

1. Python package validation and the full unittest suite.
2. Luau syntax compilation using the pinned official Luau release and a verified SHA-256 digest.
3. Rojo builds for the sample experience and Studio plugin using the pinned Rojo release and verified SHA-256 digest.
4. Upload of the generated `.rbxlx` and `.rbxmx` build artifacts.

The workflow uses least-privilege read-only repository permissions, immutable action commit pins, and no publishing credentials. It does **not** publish to Roblox.

## What CI does not prove

A successful CI run proves the checks above ran successfully. It does not replace Roblox Studio playtests, multiplayer tests, physical-device tests, asset permission checks, published-experience analytics checks, or production deployment verification. Those must be performed in their appropriate environments and reported separately.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md), [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md), and [SECURITY.md](SECURITY.md). For platform/API changes, include current official documentation sources and explain why the selected approach is maintainable.

## License

This repository is released under the [MIT License](LICENSE). Roblox, Roblox Studio, and Luau are trademarks or projects of their respective owners; this repository is an independent community toolkit and is not affiliated with or endorsed by Roblox Corporation or OpenAI.
