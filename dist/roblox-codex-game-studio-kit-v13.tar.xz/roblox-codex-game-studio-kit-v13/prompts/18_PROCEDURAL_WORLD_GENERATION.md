# Procedural World Generation

Use `$roblox-procedural-content` and `$roblox-worldbuilding`.

Define deterministic seed behavior, generator version, world bounds, constraints, output budgets, streaming/chunk lifecycle, and server/client ownership. Implement abstract layout generation before Instance construction. Add validation for connectivity, reachability, overlap, spawn safety, and bounds. Test fixed seeds, boundary cases, repeated generation/cleanup, late join, and performance. Record seeds for reproducibility. Do not claim performance without a Studio profile.
