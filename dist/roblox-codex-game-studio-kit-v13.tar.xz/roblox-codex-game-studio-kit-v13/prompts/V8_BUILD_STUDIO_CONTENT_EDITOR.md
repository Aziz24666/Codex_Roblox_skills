# V8 Build Studio Content Editor

```text
Specify and implement a dockable Studio content editor from field metadata and JSON schemas. Separate view, form controller, parser, validator, factory, and report modules. Add validate-only, preview, generate, collision/drift detection, undo, and an output report. Do not perform public uploads or production actions.
```
