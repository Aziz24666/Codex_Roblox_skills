# Release Channel and Rollback Drill

Use `docs/V6_RELEASE_CHANNELS_AND_ROLLBACK.md`. Inspect environment separation, place targets, data API access, artifact hashes, schema migrations, flags, approval, and rollback. Do not publish or mutate production. Run a dry-run or isolated staging drill if genuinely available. Record what cannot be tested.
