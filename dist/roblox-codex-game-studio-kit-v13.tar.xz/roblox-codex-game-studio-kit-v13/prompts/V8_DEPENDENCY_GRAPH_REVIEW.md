# V8 Dependency Graph Review

```text
Generate a module dependency map. Find cycles, upward dependencies, shared modules requiring Workspace, config modules with side effects, and modules with unclear lifecycle ownership. Recommend minimal boundary changes.
```
