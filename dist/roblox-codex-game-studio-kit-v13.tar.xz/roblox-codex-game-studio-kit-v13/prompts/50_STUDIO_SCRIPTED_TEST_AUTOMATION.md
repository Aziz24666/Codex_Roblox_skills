# Studio Scripted Test Automation

Use `$roblox-studio-test-automation`.

Audit available Studio version, test APIs, plugin/build-pipeline entrypoints, and integrations. Verify exact current API signatures. Build a test strategy from acceptance criteria. Prefer pure logic tests first, then Studio integration and multi-client/device/network tests. Record actual environment and evidence. Do not invent APIs or claim execution from a harness file. Keep Studio-only services out of production scripts. If inaccessible, produce a precise manual runbook and mark the test not run/blocked.
