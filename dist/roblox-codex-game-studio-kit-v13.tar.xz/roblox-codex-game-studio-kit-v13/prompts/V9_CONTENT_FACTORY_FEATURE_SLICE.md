# Build One Content Factory Vertical Slice

Pick one allowed content family. Complete its schema, two definitions, dynamic form, validation, preview, source/template resolution, prefab generation, provenance, output validation, undo/redo tests, and human extension guide. Keep the shared framework generic and prove another family remains functional.
