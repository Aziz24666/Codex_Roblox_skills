# V12 Start New Project

Read AGENTS.md and INDEX_V12.md. Research the current Roblox toolchain and relevant Creator Hub docs before choosing architecture. Define the player experience, target device tiers, source of truth, modular systems, schema/content factory strategy, streaming assumptions, server/client boundaries, data lifecycle, test matrix, and initial performance scenarios. Build a playable vertical slice first; do not create an oversized framework without a demonstrated need.
