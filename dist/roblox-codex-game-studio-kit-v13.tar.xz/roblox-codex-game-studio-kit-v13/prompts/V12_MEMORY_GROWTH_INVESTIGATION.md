# V12 Memory Growth Investigation

Establish a repeatable baseline, run the same scenario repeatedly, and inspect ownership of Connections, Instances, tasks, caches, tag components, and streamed references. Identify whether memory is growing monotonically or a cache is stabilizing. Fix the lifecycle owner, repeat the scenario, and compare measured evidence. Do not add pooling unless profiling supports it.
