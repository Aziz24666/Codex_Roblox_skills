# V10 Architecture Comparison

Inspect existing code and identify the actual problem. Research current platform/tool recommendations. Compare at least two designs on simplicity, coupling, performance, state ownership, security, testability, and human editability. Choose the smallest design that meets the real need. Write an ADR/research record before implementation. Do not introduce a framework without a concrete benefit.
