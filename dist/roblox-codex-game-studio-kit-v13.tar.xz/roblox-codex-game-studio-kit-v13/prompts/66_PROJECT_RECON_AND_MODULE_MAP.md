# Project Reconnaissance and Module Map

Audit the repository without modifying it. Inspect Git state, nested instructions, project mappings, source-of-truth workflow, entrypoints, packages, remote surfaces, data schemas, tests, CI, toolchain versions, assets, and external integrations. Build a concise map of client/server/shared responsibilities and major dependencies. Label static/heuristic discoveries as unverified. Identify production data risks. Do not migrate architecture or move files. Deliver `PROJECT_MAP.md`, unknowns, risk register, exact checks run, and recommended next action.
