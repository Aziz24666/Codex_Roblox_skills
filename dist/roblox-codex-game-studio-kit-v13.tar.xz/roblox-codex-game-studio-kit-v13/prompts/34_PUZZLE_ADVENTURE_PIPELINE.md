# Puzzle / Adventure Pipeline

Use `$roblox-puzzle-adventure` and `$roblox-quest-content` if objectives are involved.

Build one self-contained puzzle with readable clues, explicit state, correct/incorrect responses, reset, and completion feedback. Decide whether state belongs to a player, party, or server. Test simultaneous interactions, duplicate completion, reset, reconnect, late join, and hints. Keep content original and objectives understandable without relying solely on color or sound.
