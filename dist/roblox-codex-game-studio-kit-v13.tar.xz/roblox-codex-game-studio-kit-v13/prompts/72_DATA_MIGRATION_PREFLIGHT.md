# Data Migration Dry-Run and Preflight

Use `$roblox-data-migration-operations`. Do not write to production. Identify schema versions, invariants, affected records, environment, and exact store/key scope. Build pure migration functions and fixtures for old/current/malformed/future data. Run local dry-run counts only on safe fixtures. Specify backup, canary, batch limits, stop conditions, forward repair, and rollback. Require explicit approval before any live mutation.
