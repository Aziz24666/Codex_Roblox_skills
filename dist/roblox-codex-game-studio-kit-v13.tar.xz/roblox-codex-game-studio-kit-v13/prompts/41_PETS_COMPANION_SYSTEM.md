# Prompt 41 — Pets and Companions System

Use `$roblox-pets-companions`, `$roblox-data-progression`, `$roblox-npc-ai`, and `$roblox-networking-security`.

Build a full slice: catalog → unlock/ownership → equip → follow presentation → unequip → save/rejoin. Separate definitions from player-owned records. Server-authorize ownership and slots. Bound follower count/update cost. Define collision, respawn, streaming, and cleanup. Avoid gambling-style paid random rewards or misleading odds. Test duplicate equip, full slots, missing assets, leave/rejoin, and concurrent requests.