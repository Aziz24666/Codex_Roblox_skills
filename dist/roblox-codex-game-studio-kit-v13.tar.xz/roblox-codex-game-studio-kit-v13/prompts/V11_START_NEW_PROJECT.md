# V11 START NEW PROJECT

Create a new Roblox experience using this kit. Research the current official Roblox docs and online best approaches before making technical choices. First inspect the available tools and choose a source-of-truth workflow. Write a concise product brief, architecture map, dependency-aware milestone plan, and risk register. Build the smallest complete playable vertical slice, test it at the levels actually available, fix failures, and report evidence. Keep systems modular and data-driven, and avoid creating abstractions before a real reuse need exists.
