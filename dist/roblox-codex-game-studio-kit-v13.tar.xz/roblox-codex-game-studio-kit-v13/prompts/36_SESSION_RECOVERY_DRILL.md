# Session and Recovery Drill

Use `$roblox-automated-test-engineering` and `$roblox-networking-security`.

Choose a critical feature and test disconnect during action, respawn during async work, duplicate request, simultaneous request, load/save timeout, late join, and shutdown. Write invariants first. Use isolated data and Studio test tools actually available. Verify no duplicated/lost rewards, stale callbacks, ghost state, or invalid ownership. Record BLOCKED for any drill that cannot be run. Do not use production data.
