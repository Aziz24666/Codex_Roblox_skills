# Release Candidate Quality Gate

Use `$roblox-qa-performance`, `$roblox-release-operations`, and `$roblox-luau-code-review`.

Prepare a local release candidate evidence pack. Include commit/build identity, pinned tool versions, changed features, automated check outputs, Studio/multi-client/device/network test results, data migration/recovery plan, asset provenance, privacy/player-trust/accessibility review, performance comparisons, known issues, and rollback plan. Do not publish, upload assets, modify permissions, spend Robux, or touch production data. Explicitly mark checks not run or blocked.
