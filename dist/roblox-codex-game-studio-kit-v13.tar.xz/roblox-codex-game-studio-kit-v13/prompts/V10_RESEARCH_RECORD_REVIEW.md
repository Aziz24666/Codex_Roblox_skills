# V10 Review a Research Decision

Validate each source title, domain, exact URL, access date, and supported claim. Check whether the source is primary and current. Re-open relevant docs today. Compare rejected options and explain why they lost. Reconcile the selected approach with actual implementation/tests. Mark stale/superseded records and generate a fresh record where needed.
