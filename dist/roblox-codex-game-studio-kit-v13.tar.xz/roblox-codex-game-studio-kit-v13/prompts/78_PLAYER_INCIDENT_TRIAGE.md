# Triage a Player-Reported Incident

Use `$roblox-player-support-triage`. Capture non-sensitive reproduction details, classify severity and confidence, identify affected build/system, and reproduce only with safe test data. Redact credentials and personal data. Link symptoms to evidence and a root-cause hypothesis. Separate confirmed impact from speculation. Do not contact players, edit production records, issue refunds, or change live settings without explicit authorization.
