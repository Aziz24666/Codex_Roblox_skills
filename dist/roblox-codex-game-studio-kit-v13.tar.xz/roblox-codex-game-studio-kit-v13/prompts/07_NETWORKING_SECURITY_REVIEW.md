# Prompt 07 — Networking and Security Pass

Use `$roblox-networking-security`.

Audit all client-triggerable paths related to the current feature: remotes, prompts, detectors, client-owned physics and other inputs. Build a registry of action, payload, validation, rate limit, state changed, response and tests. Check type/shape/bounds, player state, ownership, distance, ancestry, cooldown, rate, concurrency and idempotence. Remove client authority over rewards, currency, inventory, progression and shared outcomes. Do not add generic command remotes or arbitrary instance mutation.

Fix issues within scope, add regression tests, and mark any unresolved high-risk path as a blocker. Use current official Creator Hub security documentation when API-specific behavior is uncertain.
