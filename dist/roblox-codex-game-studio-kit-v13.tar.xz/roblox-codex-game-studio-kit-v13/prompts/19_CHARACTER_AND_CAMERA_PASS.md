# Character, Camera, and Controls Pass

Use `$roblox-character-gamefeel`, `$roblox-ui-ux`, and `$roblox-animation-audio` where applicable.

Audit character lifecycle, input bindings, camera modes, movement feedback, animation ownership, touch/controller support, and respawn cleanup. Define a target feel and control map. Change a small parameter set at a time and test keyboard/mouse, touch, controller, camera obstruction, focus loss, low frame rate, and respawn. Mark simulated device checks separately from physical-device tests.
