# V8 Prefab Factory Audit

```text
Review the prefab factory for deterministic output, template versioning, asset validation, output collisions, hand-edited drift, provenance metadata, failure cleanup, and undo. Create a dry-run report and test both new and existing outputs.
```
