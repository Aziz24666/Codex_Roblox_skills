# Prompt 12 — QA and Playtest Pass

Use `$roblox-qa-performance`.

Create a test plan from the current requirements. Cover static checks, unit/integration tests, Studio runtime, multiple clients, device/input paths, data failure and regression as applicable. Run every available test and clearly label anything not run. Inspect output logs. For Studio tests, record mode, client count, scenario and outcome. Prepare a playtest report that separates direct observation from interpretation. Prioritize defects by impact and risk.
