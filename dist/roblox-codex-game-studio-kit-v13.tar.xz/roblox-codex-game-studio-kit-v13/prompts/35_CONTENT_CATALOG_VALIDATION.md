# Content Catalog Validation

Use `$roblox-quest-content` and `$roblox-asset-pipeline` where relevant.

Inspect all content catalogs and define stable schemas and identifiers. Create a validator for duplicate IDs, missing references, invalid bounds, unreachable prerequisites, missing assets, and invalid reward definitions. Keep authoritative values separate from presentation. Add valid and invalid fixtures and report every failure with catalog path and ID. Do not mutate existing live player progress as part of validation.
