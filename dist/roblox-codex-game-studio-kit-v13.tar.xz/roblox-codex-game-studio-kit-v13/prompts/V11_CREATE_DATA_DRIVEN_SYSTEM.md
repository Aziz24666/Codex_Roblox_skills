# V11 CREATE DATA DRIVEN SYSTEM

Design a shared runtime plus validated definitions for the new content family. Research current Roblox APIs and alternatives first. Keep definition, runtime state, presentation, server validation, editor schema, and factory separate. Demonstrate two variants through the same implementation.
