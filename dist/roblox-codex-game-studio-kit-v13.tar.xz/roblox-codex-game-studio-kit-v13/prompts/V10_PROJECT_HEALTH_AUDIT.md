# V10 Project Health Audit

Inspect source-of-truth workflow, skills, docs, toolchain pins, module boundaries, API usage, research records, schemas, remotes, persistent data, assets, tests, and performance evidence. Run V10 tools. Prioritize risks by impact and confidence. Do not perform a broad rewrite; create a phased roadmap with quick wins and blockers.
