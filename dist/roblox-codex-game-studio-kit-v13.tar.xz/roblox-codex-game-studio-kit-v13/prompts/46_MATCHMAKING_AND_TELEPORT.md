# Prompt 46 — Matchmaking and Teleport Reliability

Use `$roblox-matchmaking-teleport`, `$roblox-networking-security`, `$roblox-data-progression`, and `$roblox-qa-performance`.

Design party membership, queue schema, expiry, duplicate suppression, destination selection, transfer context, arrival validation, and fallback. Use MemoryStore only for temporary coordination and DataStores for durable records. Messages are idempotent and not the only source of truth. Verify current APIs. Test leader disconnect, duplicate messages, partial teleport, destination unavailable, shutdown, and stale queue entries.