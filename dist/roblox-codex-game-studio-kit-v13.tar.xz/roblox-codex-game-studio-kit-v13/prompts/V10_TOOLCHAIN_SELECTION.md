# V10 Select a Roblox Toolchain

Research current official file-based workflow guidance and upstream docs. Inspect the existing project. Compare Studio-native, Script Sync, partially managed Rojo, and fully managed Rojo. Identify the source of truth for code, assets, terrain, UI, and place files. Choose the least complex workflow satisfying version-control/build needs; pin versions. Do not migrate automatically.
