# Validate a Data-Driven Content Catalog

Use `$roblox-content-catalog`. Inspect catalog schemas and runtime consumers. Check stable unique IDs, duplicate entries, missing cross-references, unsupported enum values, numeric bounds, localization keys, provenance, and backward compatibility with player saves. Produce a report with exact entry IDs and severity. Do not automatically rewrite content unless the fix is deterministic and scoped.
