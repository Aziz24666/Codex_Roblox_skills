# Competitive Ranking and Seasonal Reset

Use `$roblox-competitive-ranking`. Specify rating formula and assumptions, placements, visible tiers, season transitions, tie-breaks, inactivity, party rules, disconnect outcomes, and match settlement. Server derives the result from trusted match events. Make settlement idempotent. Test duplicate settlement, crash/retry, stale caches, rollover, and rollback.
