# Project Health Audit

Use `$roblox-game-builder` and `$roblox-luau-code-review`.

Audit architecture, Luau quality, dependency/toolchain health, remote security, data lifecycle, content integrity, performance, accessibility, tests, documentation, and release operations. Use read-only utilities first. Separate confirmed findings from heuristic flags. Rank issues by player impact and likelihood, propose the smallest useful remediation, and produce a prioritized backlog. Preserve all existing user work.
