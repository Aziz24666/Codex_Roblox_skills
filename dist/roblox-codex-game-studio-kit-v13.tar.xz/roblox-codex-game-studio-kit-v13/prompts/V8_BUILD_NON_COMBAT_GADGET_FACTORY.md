# V8 Build Non Combat Gadget Factory

```text
Build or extend a Studio editor for non-combat utility gadgets and interactive props. Use the V8 gadget schema and allowlisted utility kinds. Let creators enter display name, mesh/texture/icon IDs, sounds, animations, interaction radius, cooldown, and utility configuration. Validate all values and asset reference formats, preview output, then generate a Tool prefab with Handle, optional mesh, Sound/Animation references, attributes, and a versioned Definition module. Do not generate executable code from user fields or silently overwrite existing output.
```
