# V11 PROJECT HEALTH AUDIT

Audit repository structure, source-of-truth mapping, ownership, dependency graph, generated artifacts, tests, and documentation. Research any Roblox/toolchain claims first. Produce prioritized, evidence-backed findings; do not perform broad moves before approval.
