# Prompt 44 — Rhythm Game and Chart Pipeline

Use `$roblox-rhythm-games`, `$roblox-animation-audio`, `$roblox-accessibility-device`, and `$roblox-automated-test-engineering`.

Build a playable timing chart with original or properly licensed audio. Define time base, chart schema, hit windows, calibration, scoring, pause/resume, and visual cues. Do not reproduce copyrighted lyrics or use unlicensed tracks. Keep presentation responsive but never trust a client-submitted total score. Test frame rate, focus loss, audio offset, device input, chart boundaries, and multiplayer assumptions.