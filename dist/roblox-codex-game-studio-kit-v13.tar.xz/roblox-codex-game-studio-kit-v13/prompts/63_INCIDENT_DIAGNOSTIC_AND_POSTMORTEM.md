# Incident Diagnostics and Postmortem

Use `docs/V6_RUNTIME_OBSERVABILITY_AND_INCIDENT_RESPONSE.md`. Reconstruct timeline from redacted logs and build IDs. Separate user impact, symptoms, triggers, root causes, and contributing conditions. Propose mitigation, data reconciliation, verification, and preventive tasks. Avoid blame and avoid collecting private data.
