# Audit Cross-Platform Input and UI

Use `$roblox-cross-platform-input`, UI/UX, accessibility, and Studio workflow. Inventory semantic actions and bindings. Verify touch, mouse/keyboard, and gamepad behavior, including modal navigation and device switching. Identify mouse-only paths, inaccessible focus, tiny touch targets, overlapping controls, and stale prompts. Use device simulation if available and list physical-device checks still required.
