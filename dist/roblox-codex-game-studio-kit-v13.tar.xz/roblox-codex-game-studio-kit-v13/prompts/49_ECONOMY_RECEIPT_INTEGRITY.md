# Prompt 49 — Economy and Purchase Integrity

Use `$roblox-economy-transactions`, `$roblox-data-progression`, `$roblox-networking-security`, and `$roblox-automated-test-engineering`.

Audit or implement server-authoritative currency and developer-product receipts. Verify the current MarketplaceService receipt API before coding. Make fulfillment idempotent; handle duplicates, concurrency, uncertain writes; persist grant evidence before acknowledging success. Test using isolated development products and non-production data. Disclose costs/benefits; no gambling, deceptive odds, coercive timers, or fake scarcity. Do not spend Robux or publish without approval.