# V13 Test Harness Slice

Design isolated tests for the requested system. Separate pure Luau tests, Studio integration, multiplayer, device, and published-service validation. Include failure paths and teardown.
