# V13 Ci Security Review

Audit GitHub Actions workflows for least privilege, immutable action pins, unsafe pull_request_target/workflow_run patterns, secret exposure, and untrusted input interpolation. Treat scanner findings as review leads, not proof.
