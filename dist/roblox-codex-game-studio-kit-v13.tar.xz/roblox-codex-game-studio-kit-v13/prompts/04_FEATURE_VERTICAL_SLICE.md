# Prompt 04 — Implement One Feature Properly

Use `$roblox-game-builder` plus the relevant specialist skills.

Feature request:
[DESCRIBE ONE FEATURE]

First inspect related modules and existing conventions. Write a feature spec with states, player-facing behavior, acceptance criteria, edge cases, server/client ownership, remote/data impact, cleanup and tests. Implement the feature end to end in the smallest coherent set of changes. Preserve public interfaces unless a migration is necessary. Test normal, invalid, repeated, concurrent and leave/respawn paths where applicable. Update docs and report actual checks. Do not expand scope silently.
