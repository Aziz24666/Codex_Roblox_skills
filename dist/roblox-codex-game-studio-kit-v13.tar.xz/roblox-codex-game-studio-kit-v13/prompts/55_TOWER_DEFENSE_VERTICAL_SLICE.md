# Tower Defense Vertical Slice

Use `$roblox-tower-defense`. Build one small playable slice: one map lane, a short validated wave, one placement type, one targeting rule, upgrade, clear HUD feedback, win/loss, and reward settlement. Server validates placement, cost, ownership, and results. Add co-op and content variety only after the slice works. Simulate balance, then playtest actual pacing.
