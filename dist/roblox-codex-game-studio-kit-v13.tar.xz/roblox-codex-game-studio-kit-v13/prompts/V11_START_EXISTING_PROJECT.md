# V11 START EXISTING PROJECT

Take over this existing Roblox project carefully. Inspect Git status and preserve all user changes. Map the source of truth, Studio/CLI capabilities, modules, data schemas, content factories, tests, and release state. Research current docs for the areas that need changes. Produce a prioritized health report with evidence and low-risk improvements. Do not reorganize the whole repository or migrate toolchains just for consistency with the kit.
