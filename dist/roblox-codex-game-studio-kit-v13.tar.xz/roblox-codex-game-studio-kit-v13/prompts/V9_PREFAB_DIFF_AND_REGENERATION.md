# Prefab Diff and Regeneration

Implement a read-only diff of generated baseline against current prefab. Classify managed property changes, added/removed descendants, user-owned overrides, and unknown data. Default to Skip or Side-by-Side. Require explicit review before replacing; never delete source templates. Add fixture tests.
