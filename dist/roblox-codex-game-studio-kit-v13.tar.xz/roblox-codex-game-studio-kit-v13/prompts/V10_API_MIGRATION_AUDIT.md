# V10 API Migration Audit

Inventory Roblox API surfaces in the affected project. Search current Creator Hub docs, official updates/release notes, and upstream docs if tools are involved. Identify deprecated, changed, beta, permission-gated, or incompatible members. Create a migration matrix, compare replacement paths, prototype risky changes, and implement a reversible slice with regression tests.
