# System Architecture Review

Read `$roblox-system-architecture` and relevant references.

Trace one representative player journey end-to-end. Map DataModel placement, server/client/shared ownership, modules, remote contracts, persistent data, dependencies, lifecycle, and failure paths. Identify cycles, duplicate state owners, overly broad modules, hidden side effects, and streaming assumptions. Do not refactor automatically. Deliver a current architecture map, prioritized risks, and a minimal improvement plan.
