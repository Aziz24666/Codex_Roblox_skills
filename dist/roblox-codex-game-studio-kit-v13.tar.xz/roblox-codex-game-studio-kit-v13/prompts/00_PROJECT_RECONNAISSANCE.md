# Prompt 00 — Project Reconnaissance

Read `AGENTS.md` and use `$roblox-game-builder`.

Do not modify project files yet. Inspect the entire repository, hidden files, project manifests, source, assets, tests, CI, Git status, nested instructions and available toolchain. Identify whether the place is Studio-native, Rojo-managed, partially managed or mixed. Do not assume tools are installed.

Create a factual audit covering:
1. project structure and source of truth;
2. existing gameplay systems and their current status;
3. DataModel mapping and server/client/shared boundaries;
4. remotes and client-triggerable actions;
5. persistent data and schema risks;
6. assets and provenance gaps;
7. tests, build checks and Studio verification available;
8. broken references, TODOs and major technical risks;
9. immediate next milestone.

Update `docs/PROJECT_AUDIT.md` and `docs/PROJECT_STATUS.md` if the project uses these docs, preserving existing information. Do not overwrite uncommitted work. Finish with a staged plan. Do not publish, upload, touch production data, install tools or change account settings.
