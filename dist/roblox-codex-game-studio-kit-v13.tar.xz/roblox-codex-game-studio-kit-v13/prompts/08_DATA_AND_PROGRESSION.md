# Prompt 08 — Profiles, Inventory and Progression

Use `$roblox-data-progression` and `$roblox-networking-security`.

Implement the agreed player data/progression feature. Define and document a versioned schema, defaults, validation, server ownership, load/save lifecycle, retries, failure behavior, migration handling and test fixtures. Use a test experience or isolated test configuration, not production data. Protect against duplicated claims, double-spends and concurrent updates. Keep rewards transparent and the economy fair. Verify current DataStore APIs and limits from official documentation. Do not claim persistence works until tested in the intended environment.
