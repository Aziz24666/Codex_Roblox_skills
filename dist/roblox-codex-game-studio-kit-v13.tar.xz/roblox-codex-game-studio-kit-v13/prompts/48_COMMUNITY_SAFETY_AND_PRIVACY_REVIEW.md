# Prompt 48 — Community Safety and Privacy Review

Use `$roblox-community-safety`, `$roblox-social-roleplay`, and `$roblox-networking-security`.

Inventory user-generated/social surfaces. Review filtering, reporting, blocking, permissions, retention, logs, and minimization against current Roblox policy/docs. Identify unfiltered user text or client-trusted moderation state. Do not build moderation bypasses or private-chat archives. Report severity, files, remediation, tests, and uncertainties requiring authoritative review.