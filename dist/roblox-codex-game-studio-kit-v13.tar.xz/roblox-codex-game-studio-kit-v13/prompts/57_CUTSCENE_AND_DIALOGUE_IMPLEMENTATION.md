# Cutscene and Dialogue Implementation

Use `$roblox-cutscene-cinematics`. Define states, camera/input/UI/audio ownership, subtitle keys, skip, interruption, respawn, asset failure, and guaranteed cleanup. Keep authoritative objectives/rewards independent of local presentation. Test skip at every stage, low frame rate, touch/gamepad, locale expansion, and overlapping requests.
