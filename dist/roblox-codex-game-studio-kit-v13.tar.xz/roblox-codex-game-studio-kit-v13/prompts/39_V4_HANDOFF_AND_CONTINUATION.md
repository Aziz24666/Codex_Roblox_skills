# V4 Handoff and Continuation

Read all current project status artifacts and inspect Git status and the latest diff. Summarize the player-visible state, completed milestones, exact evidence, known defects, blocked tests, architecture decisions, current tool capabilities, and next actions. Identify the single safest/highest-value next milestone. Do not infer that a feature is done from a TODO list or code presence. Do not repeat completed work unless regression evidence requires it.
