# V11 RESEARCH THEN IMPLEMENT

For this task, perform fresh official Roblox documentation research and reputable online comparison before implementation. Record source URLs, access date, alternatives, decision, limitations, and tests. Then implement the smallest maintainable solution and run impact-selected checks.
