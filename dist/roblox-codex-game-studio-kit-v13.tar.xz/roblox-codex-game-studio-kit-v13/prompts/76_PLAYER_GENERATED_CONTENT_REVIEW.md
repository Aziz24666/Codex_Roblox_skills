# Review Player-Generated Content Safety

Use `$roblox-player-generated-content`, community safety, networking/security, and content catalog. Enumerate what players can create, how it is stored, who can see it, and how it can be reported/removed. Ensure structured, bounded data; reject arbitrary code and unrestricted asset references. Check ownership, size, rate, visibility, privacy, moderation-aware handling, persistence, and removal. Do not implement moderation bypasses.
