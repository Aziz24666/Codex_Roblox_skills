# Prompt 45 — Party Minigame Rotation

Use `$roblox-party-minigames`, `$roblox-matchmaking-teleport`, `$roblox-networking-security`, and `$roblox-automated-test-engineering`.

Implement lobby → countdown → minigame → score → intermission with explicit states and one adapter contract per minigame. Define player bounds, late joins, ties, disconnects, empty rounds, timeouts, and cleanup. Server owns outcomes. Test multiple clients, rapid leave/rejoin, duplicate finish events, minigame errors, and round reset. Clean connections, instances, and temporary state each round.