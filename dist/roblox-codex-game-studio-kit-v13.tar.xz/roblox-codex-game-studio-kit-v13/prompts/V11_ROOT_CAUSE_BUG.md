# V11 ROOT CAUSE BUG

Reproduce the defect, capture environment/logs, identify recent changes, inspect relevant docs, isolate the smallest failing case, fix root cause, add a regression test, and rerun impacted tests. Preserve unrelated user changes.
