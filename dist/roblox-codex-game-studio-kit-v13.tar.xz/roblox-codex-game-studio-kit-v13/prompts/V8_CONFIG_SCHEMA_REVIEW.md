# V8 Config Schema Review

```text
Review the config schema, Luau types, normalizer and runtime validator together. Check required/unknown fields, bounds, enums, asset references, defaults, uniqueness, schema versioning, and migrations. Add negative fixtures for invalid shapes and values.
```
