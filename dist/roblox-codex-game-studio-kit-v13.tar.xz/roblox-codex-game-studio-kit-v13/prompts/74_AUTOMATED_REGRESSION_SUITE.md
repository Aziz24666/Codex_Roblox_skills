# Build a Regression Test Suite

Use `$roblox-regression-engineering` and `$roblox-studio-test-automation`. Map requirements to tests. Separate pure logic, contract, integration, Studio runtime, multi-client, device/network, and staging checks. Use isolated data fixtures and deterministic inputs. Include failure, timeout, duplicate, disconnect, cleanup, and migration cases. Discover actual Studio automation capabilities before writing adapters. Do not claim tests were executed if only authored.
