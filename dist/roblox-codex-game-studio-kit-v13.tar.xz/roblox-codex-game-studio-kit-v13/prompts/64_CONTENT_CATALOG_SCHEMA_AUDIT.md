# Content Catalog and Schema Audit

Use `docs/V6_CONTENT_AUTHORING_AND_ASSET_VALIDATION.md`. Validate parsing, schemas, stable IDs, references, numeric ranges, graph consistency, localization keys, asset provenance, and runtime budgets. Produce a report first; do not silently rewrite catalogs. Distinguish schema pass from in-Studio asset load verification.
