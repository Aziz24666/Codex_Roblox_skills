# V11 REFACTOR SAFELY

Refactor only the requested boundary. Preserve behavior, write a before/after module contract, inspect callers, use small reversible steps, add characterization/regression tests, and compare diffs. Do not combine unrelated rewrites.
