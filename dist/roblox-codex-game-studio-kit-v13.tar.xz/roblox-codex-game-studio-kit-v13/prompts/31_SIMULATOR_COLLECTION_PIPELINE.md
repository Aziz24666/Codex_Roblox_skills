# Simulator / Collection Pipeline

Use `$roblox-simulator-collection`.

Implement one core player action, one server-owned reward, one stable catalog entry, one collection/inventory interaction, and one meaningful upgrade. Model progression before expanding values. Test invalid IDs, duplicate grants, capacity limits, save/rejoin, and server-side calculation. Do not introduce paid random rewards or gambling-like mechanics. Ensure pricing/effects are transparent and free progression remains coherent.
