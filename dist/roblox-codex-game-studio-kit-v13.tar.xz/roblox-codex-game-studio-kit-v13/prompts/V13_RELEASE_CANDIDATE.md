# V13 Release Candidate

Assemble a release candidate with commit/build identity, required test evidence, artifact hash, target environment, migration/rollback plan, and explicit human approval. Do not deploy.
