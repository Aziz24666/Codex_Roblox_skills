# Strategy Match System

Use `$roblox-strategy-games`. Define match state, legal actions, action ordering, hidden/public information, timeouts, disconnect/reconnect, and result settlement. Server validates each action and calculates outcomes. Test out-of-turn, duplicate, simultaneous, stale, and malformed requests; reconnect/resync; tie and timeout behavior.
