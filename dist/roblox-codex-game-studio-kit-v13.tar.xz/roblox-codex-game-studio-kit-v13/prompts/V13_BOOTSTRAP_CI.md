# V13 Bootstrap Ci

Inspect the project source-of-truth workflow, research current Roblox/toolchain guidance, create a minimal read-only CI profile, pin tools, and add checks that the current project can genuinely run. Do not create a publishing job.
