# Prompt 02 — Architecture and Milestone Plan

Use `$roblox-game-builder` and `$roblox-luau-engineering`.

Inspect the current brief and project. Design the simplest architecture that supports the agreed scope. Map Roblox services, DataModel placement, server/client/shared responsibilities, module contracts, remotes, state ownership, persistent schema, lifecycle cleanup, configuration, assets and test seams.

Break implementation into ordered milestones. For each milestone include player outcome, dependencies, files/systems expected, acceptance criteria, tests, risks, size estimate and rollback notes. Identify the highest-risk assumption and prototype it early. Do not migrate an existing project workflow or replace current systems without explaining the trade-off and obtaining approval where destructive.
