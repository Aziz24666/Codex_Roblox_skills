# V10 Extend the Schema-Generated Studio Editor

Read V9/V10 editor docs. Research current Studio plugin, widget, ChangeHistoryService, asset, and MCP APIs relevant to the change. Add a family/field type through the shared schema/renderer/validator/factory extension points. Keep preview read-only and generation explicit, deterministic, collision-safe, undoable, and provenance-stamped. Add positive and negative fixtures; test in a disposable Studio place.
