# Release Candidate Evidence Pack

Use `$roblox-release-operations` and `$roblox-qa-performance`.

Create a release candidate evidence packet: version, scope, changelog, asset provenance, schema compatibility, security review, test IDs/results, Studio modes, client count, device/network setup, performance measurements, known issues, rollback/mitigation, and approval-gated operations. Mark unrun and blocked tests honestly. Do not publish.
