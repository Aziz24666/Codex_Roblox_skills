# V10 Full Module Review

Map modules, public APIs, dependencies, execution context, mutable state, event ownership, lifecycle, and tests. Run the V10 architecture audit. Review strict typing, cyclic dependencies, mega-modules, hidden globals, dynamic require, error swallowing, and documentation. Research any proposed Roblox API changes freshly. Return prioritized fixes; do not rewrite healthy code just to match a template.
