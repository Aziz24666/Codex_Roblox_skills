# Studio Plugin Design and Safety Review

Use `$roblox-plugin-development`. Specify internal/distributable scope, Studio versions, permissions, project mutations, undo/restore behavior, and dependencies. Verify current Plugin API. Provide preview/dry-run and confirmation for destructive actions. Separate plugin code from runtime code. Test install/reload/disable, malformed inputs, cancellation, and undo. Do not collect secrets.
