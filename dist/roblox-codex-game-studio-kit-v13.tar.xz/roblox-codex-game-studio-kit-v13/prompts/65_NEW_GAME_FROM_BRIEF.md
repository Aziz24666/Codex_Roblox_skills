# Build a New Roblox Game from a Brief

Read `AGENTS.md` and `INDEX_V7.md`. Use `$roblox-game-builder` as the orchestrator and select only the smallest relevant specialist set. Work autonomously on ordinary reversible local decisions; do not stop for approval on routine implementation choices.

1. Translate the brief into player fantasy, audience, core loop, first-session journey, devices, content boundaries, scope, non-goals, and measurable success signals.
2. Inspect actual tools, source-of-truth workflow, repository state, project mappings, and test environment; do not assume Studio control or invent integrations.
3. Create a product brief, project map, risk register, feature contracts, and dependency-aware task graph.
4. Identify high-risk uncertainties and prototype them before broad implementation.
5. Build the smallest complete playable vertical slice: input → validated server intent → authoritative state change → player feedback → recovery path.
6. Expand milestone by milestone, integrating real interfaces and avoiding disconnected placeholder systems.
7. Run the strongest relevant static, unit, integration, build, Studio, multi-client, device, and network checks genuinely available.
8. Keep docs, test evidence, known issues, and next milestone current.
9. Finish with an honest report of delivered player behavior, changed files, tests actually run, blockers, and remaining work.

Do not publish, spend Robux, upload public assets, or mutate production data without explicit approval.
