# Coordinate Parallel Development Workstreams

Use `$roblox-feature-orchestration`. Assign one integration owner. Break work into independent contracts with explicit files, dependencies, acceptance criteria, and tests. Never assign the same shared file to multiple agents. Agree on API/data/remote interfaces before parallel coding. Require handoff reports with changed files, tests actually run, evidence, and blockers. Integrate early and run one end-to-end scenario before calling the feature complete.
