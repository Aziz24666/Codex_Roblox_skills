# V11 DEPENDENCY IMPACT

Map direct and reverse dependencies for the requested change. Identify runtime contexts and contracts affected. Use the graph as a heuristic, inspect dynamic registrations manually, and produce a targeted regression plan before editing.
