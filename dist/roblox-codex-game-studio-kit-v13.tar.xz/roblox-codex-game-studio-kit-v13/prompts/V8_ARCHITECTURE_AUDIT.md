# V8 Architecture Audit

```text
Audit the project for duplicated behavior, unclear module ownership, cyclic dependencies, mutable shared config, per-instance script copies, and content authoring bottlenecks. Produce a dependency map and a prioritized refactor plan. Preserve working behavior and refactor one slice at a time.
```
