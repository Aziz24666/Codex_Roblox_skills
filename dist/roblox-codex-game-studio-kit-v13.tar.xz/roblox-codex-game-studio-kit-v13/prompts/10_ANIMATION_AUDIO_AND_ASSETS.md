# Prompt 10 — Animation, Audio and Asset Integration

Use `$roblox-animation-audio` and `$roblox-asset-pipeline`.

Integrate only assets whose identifiers and usage rights are confirmed. Define playback scope, ownership, priority, fade, loop, interruption, spatial behavior and cleanup. Do not invent asset IDs or upload/replace live assets. Confirm missing-asset fallback, repeated trigger behavior, respawn and device mix. Update the asset register and keep audiovisual feedback consistent with gameplay state.
