# Prompt 09 — NPC AI and Navigation

Use `$roblox-npc-ai` and `$roblox-qa-performance`.

Implement the requested NPC behavior using explicit states and bounded updates. Define perception, destination rules, path creation/replanning, blocked/failed path recovery, stuck detection, despawn and cleanup. Avoid per-frame scans and unbounded path retries. Test open, blocked, dynamic, narrow and unreachable routes, multiple NPCs, player interference, respawn and server shutdown. Verify current PathfindingService API details before implementation.
