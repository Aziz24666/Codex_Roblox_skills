# Automated Test Plan and Harness

Use `$roblox-automated-test-engineering`.

For [FEATURE], inspect existing test tooling and propose a test pyramid. Separate deterministic logic tests from engine/Studio integration. Define fixtures, isolation, cleanup, repeatability, and test data. Cover happy path, invalid input, boundaries, duplicate operations, concurrency/order changes, disconnect, and recovery. Implement tests using the existing project conventions. Run available commands and report exact outputs and gaps. Do not add an unpinned dependency without authorization and rationale.
