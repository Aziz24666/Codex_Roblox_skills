# Prompt 43 — Player Building Sandbox

Use `$roblox-building-sandbox`, `$roblox-worldbuilding`, `$roblox-data-progression`, and `$roblox-networking-security`.

Implement placement with a reviewed catalog, client preview, server validation, ownership, quotas, deletion, and compact persistence. Accept catalog IDs and bounded transforms only; never accept arbitrary Instance trees or code paths. Validate bounds, overlap, owner, cost, allowlist, and rate. Test simultaneous placement, invalid transforms, oversized builds, plot transfer, rejoin, and missing assets.