# Prompt 13 — Profile and Optimize

Use `$roblox-qa-performance` and relevant world/NPC/engineering skills.

Do not optimize by guesswork. Establish a representative baseline and identify the target device class. Profile frame time, server work, memory, rendering, physics, replication, loading and NPC work as relevant. Select the largest measurable hotspot, implement one focused change, then repeat the same measurement and compare. Preserve gameplay quality and test regressions. Do not invent performance numbers. Record environment and limitations.
