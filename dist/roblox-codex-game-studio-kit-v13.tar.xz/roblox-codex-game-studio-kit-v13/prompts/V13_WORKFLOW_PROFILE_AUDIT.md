# V13 Workflow Profile Audit

Audit Studio-native, Script Sync, Rojo, or hybrid ownership. Map every important service/content area to its source of truth and propose the least-complex safe automation profile.
