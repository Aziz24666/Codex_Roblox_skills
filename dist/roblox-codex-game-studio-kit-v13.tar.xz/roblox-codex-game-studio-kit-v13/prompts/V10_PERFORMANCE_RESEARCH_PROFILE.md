# V10 Performance Research and Profile

Open current Creator Hub performance guidance. Define the symptom, workload, device, player count, and measurable budget. Capture a baseline before changes. Use the current profiler/MicroProfiler guidance, identify the hotspot, change one factor, and compare under identical conditions. Record raw measurements. Do not add pooling or per-frame work without evidence.
