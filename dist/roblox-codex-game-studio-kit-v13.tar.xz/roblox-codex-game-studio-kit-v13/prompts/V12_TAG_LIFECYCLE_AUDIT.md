# V12 Tag Lifecycle Audit

Research the current CollectionService API. Inspect all tag-driven registration paths. Check startup enumeration, per-instance added/removed signals, idempotency, cleanup of connections/tasks/temporary instances, and shutdown behavior. Use static tools as hints only. Add runtime tests for pre-existing tags, new tags, removed tags, destruction, and repeated attach/detach.
