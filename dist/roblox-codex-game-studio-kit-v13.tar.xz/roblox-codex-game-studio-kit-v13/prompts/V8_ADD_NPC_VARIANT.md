# V8 Add Npc Variant

```text
Add a new NPC variant using data only wherever possible. Read the NPC schema, registry, movement and behavior contracts. Create one definition, assign the tag/definition ID to the prefab, validate it, and test it. Do not duplicate scripts or change shared behavior unless the requested role is genuinely new.
```
