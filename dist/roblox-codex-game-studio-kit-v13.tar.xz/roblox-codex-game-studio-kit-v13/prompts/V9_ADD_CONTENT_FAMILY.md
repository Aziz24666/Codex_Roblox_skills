# Add a New Content Family

Add a new family to the existing schema-generated editor without copying the form UI. Define family metadata and field descriptors, JSON Schema, examples, template/source requirement, allowlisted generator handler, preview plan, post-generation validator, and tests. Demonstrate two variants through the same form and handler. Preserve collision protection, provenance, undo transactions, and human-readable docs.
