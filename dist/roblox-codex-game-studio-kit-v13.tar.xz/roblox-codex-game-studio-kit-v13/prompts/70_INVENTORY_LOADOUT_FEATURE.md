# Implement Inventory and Loadouts

Use `$roblox-inventory-loadouts` and `$roblox-content-catalog`. Define catalog IDs, owned instance records, capacity, stacks, slots, operation contracts, and persistence version. Keep item ownership and equip decisions server-authoritative. Validate every mutation request. Add clear loading/pending/rejected/success UI states. Test full inventory, duplicate requests, stale catalog, migration, reconnect, and load failure. Do not silently reset existing data.
