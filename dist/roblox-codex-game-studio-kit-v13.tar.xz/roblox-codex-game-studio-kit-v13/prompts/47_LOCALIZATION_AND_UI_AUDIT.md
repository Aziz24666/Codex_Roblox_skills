# Prompt 47 — Localization and UI Resilience Audit

Use `$roblox-localization`, `$roblox-ui-ux`, and `$roblox-accessibility-device`.

Inventory player-visible strings and use semantic keys where appropriate. Define fallback, translator context, placeholders, expansion, RTL considerations, and font coverage. Test narrow/wide layouts, long strings, missing translations, focus navigation, touch/gamepad, and non-color/non-audio feedback. Verify current localization APIs; do not invent methods.