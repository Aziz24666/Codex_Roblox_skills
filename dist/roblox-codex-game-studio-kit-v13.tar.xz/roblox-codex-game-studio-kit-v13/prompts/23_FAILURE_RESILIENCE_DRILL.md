# Failure and Recovery Drill

Use `$roblox-qa-performance` and `docs/FAILURE_RECOVERY_AND_INCIDENTS.md`.

Choose one important system and test safe failure cases: service unavailable, malformed response, disconnect, delayed response, duplicate request, interrupted save, missing asset, and shutdown. Use isolated test data. Verify bounded retry, user feedback, idempotency, no data overwrite, cleanup, and recovery. Do not simulate destructive production failures.
