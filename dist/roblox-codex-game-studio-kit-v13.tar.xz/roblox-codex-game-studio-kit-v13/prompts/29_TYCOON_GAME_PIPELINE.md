# Tycoon Game Pipeline

Use `$roblox-tycoon-builder` and `$roblox-game-builder`.

Build the smallest complete tycoon loop: claim one plot, place one production object, generate one server-owned reward, spend it on one upgrade, and preserve the result after a safe rejoin test. Before implementation, inspect the project, write plot/placement/purchase contracts, define concurrency invariants, and plan multiplayer tests. Validate ownership, placement bounds, object caps, duplicate requests, save failure, plot release, and cleanup. Expand only after this slice passes its evidence gate.
