# Prompt 01 — New Game Discovery and Brief

Use `$roblox-product-design` and `$roblox-game-builder`.

I want to create this Roblox game:

[DESCRIBE THE IDEA HERE]

Before building, produce a practical game brief. Define the player fantasy, intended audience and content boundaries, genre, core loop, first-session flow, session shape, player verbs, progression, world structure, social/multiplayer role, target devices, controls, accessibility, art/audio direction, launch-critical scope, later features, non-goals and measurable success criteria.

Resolve ordinary unknowns with labeled, reversible assumptions. Ask only about decisions that materially change the game's identity or risk. Create the game brief, risk register, first milestone plan and acceptance criteria. Do not implement the full game in this step. Recommend the smallest prototype that validates the most important assumption.
