# Establish a Performance Baseline

Use `$roblox-performance-benchmarking` and QA. Define target device tiers and representative journey. Record build, Studio/client version, device/network profile, player count, warm/cold state, duration, sample count, and metrics. Use actual profiler/runtime captures where available. Separate static estimates from runtime measurements. Compare like with like, identify the dominant cost, change one major factor, and rerun. Produce raw evidence plus a concise report.
