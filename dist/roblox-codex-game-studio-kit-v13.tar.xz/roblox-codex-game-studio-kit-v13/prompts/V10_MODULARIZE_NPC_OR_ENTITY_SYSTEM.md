# V10 Modularize an Entity System

Research current Roblox NPC/navigation/animation/CollectionService/streaming APIs as relevant. Design one shared runtime plus validated immutable definitions and per-entity runtime state. Compare relevant scheduling/behavior architectures. Prove two distinct variants use the same runtime. Define cleanup for spawn/despawn/respawn and test in Studio. Do not clone scripts per entity.
