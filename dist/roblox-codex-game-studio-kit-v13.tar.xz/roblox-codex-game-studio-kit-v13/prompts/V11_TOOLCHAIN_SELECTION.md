# V11 TOOLCHAIN SELECTION

Discover installed tools and versions first. Research current official/upstream docs and compare the minimum viable approaches. Recommend a toolchain compatible with the repository source of truth; do not install or migrate without a plan.
