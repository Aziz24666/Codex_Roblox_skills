# Technical Art and Visual Budget Audit

Use `$roblox-technical-art`. Inventory content assets, provenance, hierarchy, embedded scripts, scale/pivots, collision, materials, texture budgets, effects, lighting, streaming, and device target. Establish budgets from measurement and profile representative scenes. Do not equate a clean asset register with license verification or runtime performance.
