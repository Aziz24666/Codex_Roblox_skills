# V13 Luau Quality Adoption

Research current Luau analyzer and formatter guidance. Establish a baseline, fix changed/new code first, configure pinned static checks, and avoid unrelated mass rewrites.
