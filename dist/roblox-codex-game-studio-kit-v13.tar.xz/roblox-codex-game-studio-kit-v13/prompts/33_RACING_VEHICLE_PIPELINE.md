# Racing / Vehicle Pipeline

Use `$roblox-racing-vehicle`.

Prototype one vehicle with accessible input and camera behavior. Then implement a server-defined race state machine and checkpoint sequence. Never trust client-reported finish times or checkpoint completion. Define vehicle ownership/replication assumptions, reset/disconnect behavior, and ties. Test with multiple clients and simulated network conditions where available; profile physics and replication before adding more vehicles or tracks.
