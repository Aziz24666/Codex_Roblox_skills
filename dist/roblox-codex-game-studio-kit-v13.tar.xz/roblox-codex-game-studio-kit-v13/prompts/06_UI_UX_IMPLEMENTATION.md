# Prompt 06 — UI/UX Implementation

Use `$roblox-ui-ux` and `$roblox-gameplay-systems`.

Implement this interface/system:
[DESCRIBE SCREEN OR FLOW]

Define screen hierarchy, open/close behavior, states (loading, ready, pending, success, failure, empty), navigation, input mapping and accessibility. Bind it to real game state. Every control must perform its advertised behavior and show appropriate feedback. Networked actions must wait for authoritative server confirmation. Test supported input modes and multiple aspect ratios. Do not replace existing UI wholesale without inspecting it first.
