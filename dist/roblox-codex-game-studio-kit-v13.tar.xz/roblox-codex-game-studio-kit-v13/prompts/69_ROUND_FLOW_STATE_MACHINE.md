# Implement a Round-Based Game Flow

Use `$roblox-round-based-games`. Define the minimal server-owned state machine and legal transitions. Document entry/exit effects, timers, joining, leaving, empty-server behavior, reconnect, settlement, and cleanup. Make result and reward operations idempotent. Clients render state and send intent only. Test every legal transition and representative illegal/race transitions. Report any Studio multi-client tests that could not be run.
