# Design the First-Session Journey

Use `$roblox-experience-onboarding`, UI/UX, accessibility, and localization as needed. Map discovery through first success and first core-loop repetition. Teach by contextual actions with immediate feedback. Support skip/resume/reconnect, touch/gamepad, and returning players. Persist only meaningful milestones. Make reward grants server-authoritative and idempotent. Include a first-session playtest plan and measurable, privacy-conscious success signals.
