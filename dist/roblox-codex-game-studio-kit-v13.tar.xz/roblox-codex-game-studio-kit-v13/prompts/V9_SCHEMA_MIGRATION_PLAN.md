# Plan a Definition Schema Migration

Inspect all definitions and their schema versions. Propose a deterministic pure migration; report renamed/removed/added fields, unit changes, enum changes, default choices, and data loss risk. Do not write definitions or modify generated prefabs until the plan and dry-run output are reviewed.
