# V11 STUDIO MCP PLAYTEST

Discover connected Studio instances and current official MCP capabilities. Confirm target studio_id/place before writes. Use a disposable test environment; run a test scenario, collect output/evidence, and report unverified dimensions. Do not publish or mutate production.
