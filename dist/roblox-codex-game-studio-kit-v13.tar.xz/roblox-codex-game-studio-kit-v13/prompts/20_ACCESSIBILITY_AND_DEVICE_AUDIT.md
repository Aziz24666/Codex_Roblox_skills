# Accessibility and Device Audit

Use `$roblox-accessibility-device` and `$roblox-ui-ux`.

Audit the critical player journeys across phone, tablet, desktop, and controller/TV where supported. Check text readability, contrast, non-color indicators, focus order, touch targets, safe areas, localization expansion, motion intensity, audio dependence, and recovery messages. Produce an issue list ranked by player impact and a verification matrix. Do not claim physical-device verification from emulator screenshots.
