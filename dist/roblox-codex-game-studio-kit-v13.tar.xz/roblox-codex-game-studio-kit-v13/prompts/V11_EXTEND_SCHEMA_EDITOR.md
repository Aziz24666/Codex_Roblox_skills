# V11 EXTEND SCHEMA EDITOR

Extend the schema-driven Studio editor by adding a catalog schema, field descriptors, validation, preview behavior, source/template resolution, and generator handler. Keep catalog as source of truth, regenerate code, check drift, and test invalid inputs and collision behavior.
