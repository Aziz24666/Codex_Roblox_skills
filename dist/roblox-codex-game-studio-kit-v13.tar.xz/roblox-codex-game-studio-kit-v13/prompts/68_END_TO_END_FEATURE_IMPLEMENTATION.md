# End-to-End Feature Implementation

Use `docs/V7_END_TO_END_FEATURE_FACTORY.md`. Inspect callers and dependencies. Write the feature contract before implementation: ownership, contexts, API, data/remote schema, lifecycle, errors, UX, acceptance criteria, and tests. Implement one complete path, integrate through real interfaces, run relevant checks, review security/data/performance/accessibility, and attach evidence. Do not mark DONE based on generated code alone.
