# Multi-Place Universe Architecture

Use `$roblox-multi-place-universe`. Map all known places and responsibilities. Do not invent IDs. Define durable, temporary, server-local, and transition-hint state. Specify teleport payload contracts, party integrity, arrival validation, failure recovery, stale queues, and cross-place data ownership. Add tests for duplicate/expired/malformed transitions and data reconciliation. Require approval before creating/deleting places or publishing.
