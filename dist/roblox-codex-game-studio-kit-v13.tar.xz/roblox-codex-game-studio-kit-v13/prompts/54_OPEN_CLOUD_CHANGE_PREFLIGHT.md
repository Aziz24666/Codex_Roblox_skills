# Open Cloud Change Preflight

Use `$roblox-open-cloud-operations`. Classify exact operation and target. Verify API version and available connector. Produce dry-run plan, least-privilege scope, environment, impact, reversibility, rollback, and verification. Keep secrets out of chat/repository/logs. Ask explicit approval for publish, production data, permissions, public assets, and irreversible operations. Do not execute if target or permission is ambiguous.
