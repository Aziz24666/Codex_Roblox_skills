# Analytics and Live Operations Plan

Use `$roblox-analytics-liveops`.

Start from product/reliability questions. Define only the minimum events and fields needed, data minimization, volume, access, retention, and failure behavior. Design versioned live configuration with a safe default and rollback plan. Identify which data can be measured and which is only an assumption. Do not add invasive tracking or manipulative event mechanics.
