# V12 Analytics Catalog Review

Research current AnalyticsService custom event docs and limits. Review each event for a specific product question, necessity, bounded fields, minimal data, privacy risks, cardinality, environment, and removal criteria. Reject sensitive/personal fields. Separate Studio tests from published-server custom-event delivery. Require explicit approval before introducing production telemetry.
