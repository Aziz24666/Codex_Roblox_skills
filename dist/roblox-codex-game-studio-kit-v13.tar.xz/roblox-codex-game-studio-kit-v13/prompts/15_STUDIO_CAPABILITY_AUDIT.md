# Studio Capability and Workflow Audit

Read `AGENTS.md` and use `$roblox-studio-workflow`.

Inspect the project workflow without changing it. Determine whether the project is Studio-native, Rojo, Script Sync, mixed, or unknown. Inventory actual installed tools and versions, available Studio integrations, project mappings, sync direction, CI commands, and Studio-only steps. Do not assume control of Studio or publish capabilities. Produce a capability matrix for file editing, static checks, builds, Studio verification, multi-client/device/network testing, and external operations. Identify risks and recommend the least disruptive next step.
