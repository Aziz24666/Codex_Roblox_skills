# Audit Asset Reference Handling

Inventory asset fields and their expected kinds. Separate syntax validation from existence/load/permission/compatibility verification. Find invented/fallback IDs, silent substitutions, and asset references embedded in free-form code. Produce an asset review report; do not upload or publish assets.
