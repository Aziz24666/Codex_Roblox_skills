# V10 Release Documentation Recheck

Before release, re-open current docs and updates for all APIs, assets, data, plugin, input, and moderation/policy topics in scope. Check deprecations, beta/rollout status, asset availability/permissions, and current publication requirements. Verify staging tests and rollback. Publishing, public asset upload, permission changes, and production data mutation require explicit permission.
