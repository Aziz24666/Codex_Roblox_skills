# V12 Device Tier Validation

Define actual target device classes from the game's audience. Create an equivalent test matrix for low/mid/high tiers and touch, keyboard/mouse, and gamepad as applicable. Record actual hardware vs emulation, build, Studio version, scenario, frame-time, memory, join time, UI and streaming outcomes. Never label an emulator result as physical-device validation.
