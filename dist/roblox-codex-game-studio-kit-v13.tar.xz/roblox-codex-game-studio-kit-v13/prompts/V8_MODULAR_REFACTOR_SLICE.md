# V8 Modular Refactor Slice

```text
Select one duplicated subsystem. Define observable behavior and current tests, extract a shared module with a narrow typed contract, move differences into validated definitions, preserve compatibility through an adapter if needed, update callers, and test at least two variants. Do not refactor unrelated areas in the same change.
```
