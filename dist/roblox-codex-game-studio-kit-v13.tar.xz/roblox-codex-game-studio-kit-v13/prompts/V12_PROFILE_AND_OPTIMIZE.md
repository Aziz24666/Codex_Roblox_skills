# V12 Profile and Optimize

Research current Roblox performance and profiling docs first. Inspect the project and discover actual Studio/MCP tools. Define one reproducible player scenario, capture the client/server baseline separately, and identify the largest measured cause. Make the smallest targeted change, repeat the identical scenario, compare raw evidence, and run gameplay/streaming/device regressions. Never claim an improvement without comparable before/after evidence. Use V12 performance templates and schemas.
