# V10 DataStore Design Review

Open current DataStore best-practice and limits pages. Compare data layout, UpdateAsync/SetAsync semantics, buffering, retry order/backoff/jitter, concurrency/session ownership, migration, and recovery. Test against isolated data and record the schema/migration evidence. Do not touch live data.
