# V10 Research-First Task Start

Read `AGENTS.md` and `INDEX_V10.md`. Inspect the project and actual tools first. Before any code or architecture change, perform fresh web research: current Creator Hub guides, exact API references, current Roblox updates/release notes, and upstream/reputable sources for alternatives. Compare viable approaches. Create and lint a V10 research decision record. If web research is unavailable, mark the implementation BLOCKED. Then produce a plan, implement a small complete slice, test it, and update the record with evidence.
