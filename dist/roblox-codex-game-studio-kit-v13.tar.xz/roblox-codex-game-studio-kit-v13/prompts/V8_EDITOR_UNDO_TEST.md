# V8 Editor Undo Test

```text
In a disposable Studio place, test editor validation without mutation, generation, undo, redo, generation failure, existing output collision, edited output drift, and missing asset references. Never run this against production content.
```
