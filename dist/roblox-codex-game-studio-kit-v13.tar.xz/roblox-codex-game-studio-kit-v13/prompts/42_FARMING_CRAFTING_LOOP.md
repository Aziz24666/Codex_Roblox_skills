# Prompt 42 — Farming and Crafting Loop

Use `$roblox-farming-crafting`, `$roblox-economy-transactions`, `$roblox-data-progression`, and `$roblox-networking-security`.

Implement acquire → station/plot interaction → server recipe validation → consume inputs → grant output once → UI update → persist. Define IDs, stacks, recipes, capacities, timing, and failures. Never trust client yields/costs/balances/elapsed time. Test repeated/concurrent craft, insufficient materials, full inventory, disconnect, and isolated data recovery.