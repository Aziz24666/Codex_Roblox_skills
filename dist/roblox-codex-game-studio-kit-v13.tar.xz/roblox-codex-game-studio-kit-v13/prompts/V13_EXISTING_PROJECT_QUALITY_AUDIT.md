# V13 Existing Project Quality Audit

Audit a real Roblox project without migrating its source of truth. Identify which static, build, Studio, multiplayer, device, and release checks are applicable and create a phased adoption plan.
