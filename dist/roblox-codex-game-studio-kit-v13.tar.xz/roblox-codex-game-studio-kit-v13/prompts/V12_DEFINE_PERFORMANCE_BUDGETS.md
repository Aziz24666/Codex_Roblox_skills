# V12 Define Performance Budgets

Do not invent targets. Define audience/device tiers, scenarios, and metric questions. Capture representative baselines first, then propose project-specific thresholds with rationale and review dates. Mark sample values as placeholders. Validate files with V12 tools and record actual Studio evidence separately.
