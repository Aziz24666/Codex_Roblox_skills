# Prompt 40 — Sports/Skill Game Vertical Slice

Use `$roblox-sports-games`, `$roblox-character-gamefeel`, `$roblox-networking-security`, and `$roblox-automated-test-engineering`.

Build one complete loop: lobby/spawn → ready → attempt → server-validated score → result feedback → replay/exit. Inspect the project and preserve its workflow. Define rules, inputs, scoring, tie handling, round lifecycle, and acceptance tests. Prototype controls on available devices. Keep authoritative scores on the server. Build one arena/track slice before content volume. Test ties, simultaneous results, leave/rejoin, respawn, invalid score requests, and supported devices. Record actual Studio modes; do not claim cross-device fairness without evidence.