# Prompt 11 — Bug Fix by Root Cause

Use `$roblox-qa-performance` and the relevant engineering skill.

Bug:
[DESCRIBE BUG AND REPRO STEPS]

Reproduce or inspect the available evidence first. Identify expected versus observed behavior, likely owning system, state/lifecycle involved and regression risk. Find the root cause rather than masking symptoms. Implement the smallest safe fix, add a regression test and run focused plus relevant regression checks. Do not suppress errors, rewrite unrelated files or claim a runtime fix without reproducing it.
