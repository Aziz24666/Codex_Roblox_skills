# V10 API Research and Spike

Research every class/member against current Creator Hub docs and release notes. Record exact signature, security context, availability, behavior, limits, thread/yield notes, and caveats. Compare any viable alternative. If uncertain, create a disposable Studio spike, record Studio build, steps, expected and actual behavior, and keep it out of production code until verified.
