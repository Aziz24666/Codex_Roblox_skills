# Luau Code Review

Use `$roblox-luau-code-review`.

Review these changes: [FILES / DIFF]. Read surrounding modules and project conventions before judging. Trace execution context, consumers, nilability, yields, lifecycle, cleanup, server authority, remote payload validation, data writes, concurrency, and hot paths. Check tests and current API assumptions. Report findings by severity with exact file/line, impact, and smallest safe fix. Distinguish confirmed defects from questions or risks. Do not rewrite the entire system unless asked; patch only confirmed issues after explaining the change plan in the report.
