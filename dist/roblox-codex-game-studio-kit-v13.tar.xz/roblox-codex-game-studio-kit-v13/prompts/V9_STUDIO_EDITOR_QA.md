# Studio Editor QA

Use the V9 test matrix in a disposable place. Test every field kind, invalid/boundary inputs, family tabs, preview staleness, source selection, collision, generation, final hierarchy, undo/redo, and failure cancellation. Capture Studio version, place context, evidence, and accurate status. Do not claim runtime success from static checks.
