# Obby Game Pipeline

Use `$roblox-obby-builder`.

Create a short, high-quality obstacle-course slice. First prototype controls and camera, then graybox 3–5 varied obstacles, add server-validated checkpoint order, reset/respawn recovery, and clear feedback. Test keyboard/mouse, touch, and controller where supported. Check collision fairness, visibility, landing surfaces, and multiplayer checkpoint behavior. Do not expand the course until the first slice is readable and reliable.
