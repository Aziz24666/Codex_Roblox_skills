# V13 Artifact Reproducibility

Build the same project twice from clean checkouts with the pinned toolchain, create SHA-256 manifests, compare artifacts, investigate expected nondeterminism, and record the limits.
