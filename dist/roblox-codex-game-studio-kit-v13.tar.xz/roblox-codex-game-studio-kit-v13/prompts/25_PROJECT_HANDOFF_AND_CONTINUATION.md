# Project Handoff and Continuation

Use `$roblox-game-builder`.

Summarize the project's current source of truth, architecture, toolchain and versions, implemented systems, data schemas, asset provenance, tests and results, known issues, pending decisions, and next milestone. Update project status and docs. Verify no user changes were lost. Do not claim background progress or tests that were not run.
