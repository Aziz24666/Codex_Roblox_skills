# Social / Roleplay Pipeline

Use `$roblox-social-roleplay`.

Design one social space with a clear arrival, activity, participation, and exit loop. Minimize personal data, use supported platform safety systems, and define ownership/permissions for roles or props. Test role transitions, simultaneous interactions, player departure, late join, and cleanup. Do not build custom chat/safety features that claim to replace Roblox platform moderation or facilitate harassment/surveillance.
