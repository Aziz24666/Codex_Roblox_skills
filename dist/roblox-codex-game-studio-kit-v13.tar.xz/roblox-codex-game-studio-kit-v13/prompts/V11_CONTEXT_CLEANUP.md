# V11 CONTEXT CLEANUP

Audit AGENTS.md, skill descriptions, skill routing, and linked references. Remove stale/duplicate rules, shorten skill metadata, keep detailed procedures progressively disclosed, validate all references, and test skill selection on sample tasks.
