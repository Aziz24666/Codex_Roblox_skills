# V12 Start Existing Project

Read AGENTS.md and INDEX_V12.md. Preserve existing work and identify the source of truth. Research current official Roblox documentation and appropriate upstream tool docs before technical choices. Audit architecture, content schemas, runtime lifecycle, streaming assumptions, performance evidence, device matrix, Studio/MCP availability, and release readiness. Create a prioritized roadmap with reversible steps. Implement one complete feature slice at a time and prove each claim with actual evidence.
