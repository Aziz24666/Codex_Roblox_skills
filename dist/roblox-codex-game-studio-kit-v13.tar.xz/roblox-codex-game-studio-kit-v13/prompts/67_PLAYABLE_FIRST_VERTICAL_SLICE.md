# Build the First Playable Vertical Slice

Implement the smallest complete player loop, not a menu-only shell or disconnected scripts. Define the player outcome and acceptance tests. Include input, UI feedback, server validation, game-state change, failure handling, cleanup, and persistence only if needed. Use existing architecture. Prototype high-risk assumptions. Run local checks and Studio tests only if actual tooling is available. Record blockers. Do not expand scope until the slice is playable and its known limits are documented.
