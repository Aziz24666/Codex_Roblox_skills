# V8 Data Migration Tests

```text
Add deterministic fixtures for every supported config schema version. Test migration idempotence, preservation of expected fields, default changes, unknown fields, invalid old definitions, and a no-write dry run.
```
