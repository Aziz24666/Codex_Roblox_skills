# V10 Discover and Use Studio MCP

Open current Creator Hub MCP documentation. Discover whether the active Studio session and Codex client are connected; enumerate tools and all available Studio sessions. Confirm the target studio/place identifier before each write. Use only exposed capabilities. Inspect before editing, make narrow changes, read back outputs, run a relevant playtest, and record evidence. Do not publish or touch live data without explicit approval.
