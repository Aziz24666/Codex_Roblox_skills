# Gameplay Prototype Spike

Use `$roblox-gameplay-prototyping`.

I want to validate this uncertain mechanic: [DESCRIBE]. First inspect the project and identify the smallest representative prototype. State the hypothesis, success/failure signals, test setup, and disposable boundaries. Build only the minimum needed to test the question. Do not polish or expand into production architecture prematurely. Run the available test, record observations and limitations, then recommend KEEP / CHANGE / DROP with evidence. If retained, provide a short productionization plan. Do not claim Studio behavior was tested unless a real Studio test ran.
