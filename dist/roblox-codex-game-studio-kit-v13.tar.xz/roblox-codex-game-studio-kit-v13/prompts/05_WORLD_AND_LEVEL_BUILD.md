# Prompt 05 — Build a World/Level Pass

Use `$roblox-worldbuilding` and `$roblox-asset-pipeline`.

Build the next agreed world area based on the game brief and reference style. Start with player flow and graybox geometry. Define spawn, landmarks, route, interactions, sightlines, traversal scale, safe areas, mobile readability and streaming assumptions. Then improve silhouette, primary materials, lighting and props in deliberate passes.

Preserve existing Studio-authored content. Do not invent asset IDs or use unverified third-party content. Record asset provenance. Verify collision, camera readability, spawn safety, interaction range and performance in Studio when available. Keep the scope to the requested area.
