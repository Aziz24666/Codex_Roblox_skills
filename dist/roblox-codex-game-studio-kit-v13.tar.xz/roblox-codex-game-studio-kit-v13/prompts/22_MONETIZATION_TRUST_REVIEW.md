# Monetization and Player Trust Review

Use `$roblox-data-progression`, `$roblox-networking-security`, and `docs/MONETIZATION_AND_PLAYER_TRUST.md`.

Review product clarity, price/benefit presentation, cancellation/failure states, receipt validation, idempotency, entitlement persistence, and test isolation. Flag deceptive prompts, coercive urgency, confusing currencies, gambling-style paid randomness, client-authoritative grants, and unverified receipt flows. Do not perform purchases or production changes.
