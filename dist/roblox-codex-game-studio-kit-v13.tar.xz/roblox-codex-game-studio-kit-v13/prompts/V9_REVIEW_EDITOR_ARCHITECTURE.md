# Review the Schema Editor

Review boundaries between schema registry, UI renderer, validator, preview, template resolver, generator, transaction service, and runtime. Look for duplicated family UI, schema-driven arbitrary class/source execution, DataModel mutation during preview, missing undo cancellation, overwrite paths, stale previews, unverified asset claims, and missing provenance. Provide file-specific findings and fixes.
