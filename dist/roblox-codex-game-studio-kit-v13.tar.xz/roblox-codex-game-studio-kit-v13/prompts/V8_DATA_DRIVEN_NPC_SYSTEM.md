# V8 Data Driven Npc System

```text
Build one shared server-side NPC runtime for the project. Use tagged models and an NPCDefinitionId attribute, typed versioned definitions, a registry/validator, a shared MovementController, a behavior registry, and per-instance state. Support only the non-hostile roles required by the game. Do not copy behavior scripts into each model. Demonstrate two different definitions using the same code.
```
