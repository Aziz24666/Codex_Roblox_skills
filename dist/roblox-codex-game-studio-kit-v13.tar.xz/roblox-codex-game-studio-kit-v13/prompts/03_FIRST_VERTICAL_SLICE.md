# Prompt 03 — Build the First Complete Vertical Slice

Use `$roblox-game-builder` and the relevant specialist skills.

Implement only the first agreed vertical slice. It must be a real playable path from entry/input through server validation and authoritative state to visible feedback and recovery behavior. Include tests and update documentation. Do not add unrelated features or leave fake buttons, placeholder success responses or critical TODOs.

Before editing, summarize acceptance criteria and files likely to change. Then implement, run available static/build/automated checks, and use Studio if available. Inspect the diff and report exact verification evidence. If Studio is unavailable, mark runtime behavior as not verified in Studio and provide exact manual test steps.
