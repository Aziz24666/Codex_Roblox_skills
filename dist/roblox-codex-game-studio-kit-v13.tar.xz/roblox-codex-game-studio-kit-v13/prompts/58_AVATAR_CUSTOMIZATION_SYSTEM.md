# Avatar Customization System

Use `$roblox-avatar-customization`. Separate cosmetic preview from owned/equipped state. Server validates ownership, catalog entry, and allowed combinations. Persist only confirmed loadout changes with versioned schemas. Audit provenance and embedded scripts for imported assets. Test invalid/unowned IDs, save failure, cancellation, rapid toggles, respawn, and cross-place consistency.
