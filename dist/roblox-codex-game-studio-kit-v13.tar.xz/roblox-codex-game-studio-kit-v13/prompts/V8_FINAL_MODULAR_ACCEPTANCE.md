# V8 Final Modular Acceptance

```text
Run the V8 reusable-system acceptance template for the latest subsystem. Verify at least two definitions share one implementation, per-instance state is independent, invalid data is rejected, cleanup works, prefab output is consistent, and the human extension guide is complete. Report exact evidence and unrun checks.
```
