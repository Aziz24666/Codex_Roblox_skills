# Feature Implementation Packet

Use `$roblox-game-builder`, `$roblox-gameplay-systems`, and the relevant specialist skills.

Before coding, create a feature brief, state diagram/table, module/remote contracts, acceptance criteria, edge-case list, risk assessment, and test matrix. Implement one complete vertical slice. Keep server authority explicit. Do not leave fake buttons, hard-coded success, or disconnected placeholders. Run available checks, inspect the diff, and record test evidence and blocked Studio steps.
