# V8 Add Npc Behavior

```text
Add one new NPC behavior as a small strategy module implementing the existing behavior contract. Define config type and validation, register it explicitly, keep movement separate, add deterministic tests, update diagnostics and the human extension guide. Avoid expanding the controller into a god module.
```
