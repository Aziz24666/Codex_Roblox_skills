# Add a Reusable Field Kind

First prove existing kinds are insufficient. Define parsing, display, normalization, and validation contracts. Add one renderer control, validator, schema-lint rules, help/accessibility behavior, and positive/negative/boundary fixtures. Do not add a special-case form field for one family.
