# V11 AUTONOMOUS MILESTONE

Complete the next milestone end to end. Load only the relevant skills and references. Research current platform/tool docs first, create a bounded change plan, inspect dependencies, implement one complete vertical slice, run impact-selected tests, fix failures, inspect the final diff, update research and project docs, and record evidence. Continue through safe local work without stopping after the first draft. Stop only at a genuine blocker, approval boundary, or defined milestone completion.
