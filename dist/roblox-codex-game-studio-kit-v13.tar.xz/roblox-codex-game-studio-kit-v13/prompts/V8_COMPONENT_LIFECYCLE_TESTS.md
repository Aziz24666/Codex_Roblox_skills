# V8 Component Lifecycle Tests

```text
Test component startup with existing tagged instances, dynamic additions, duplicate attach, removal, destroyed models, invalid definition IDs, respawn, and cleanup of connections/tasks. Record Studio test evidence separately from static checks.
```
