## Summary

## Research and design decisions
- Official documentation checked:
- Alternatives considered:
- Reason for selected approach:

## Validation performed
- [ ] Python preflight
- [ ] Unit tests
- [ ] Luau source compilation (when source changed)
- [ ] Rojo build (when project/plugin changed)
- [ ] Roblox Studio verification (or explain why unavailable)

## Risks and follow-up

## Confirmation
- [ ] No credentials or private player data included
- [ ] No live Roblox publishing or production-data modification performed
