# Security Policy

## Supported versions

Security fixes are made against the latest version on the default branch. Older generated bundles may not receive backports.

## Reporting a vulnerability

Please do not publish exploit details, credentials, private place files, player data, or sensitive asset information in a public issue.

Use GitHub's **Report a vulnerability** feature on this repository when it is enabled. If private vulnerability reporting is unavailable, contact the maintainer through the private contact method shown on the GitHub profile and ask for a secure reporting channel. Do not include secrets in the first message.

## Scope

This repository is a development toolkit and documentation pack. Static scanners and examples are not a guarantee that a consuming Roblox experience is secure. Game owners must independently review server authority, RemoteEvent validation, persistence, permissions, assets, and deployment configuration.
