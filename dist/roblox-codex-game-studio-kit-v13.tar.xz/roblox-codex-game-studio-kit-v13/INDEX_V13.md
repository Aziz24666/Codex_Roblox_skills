# Roblox Codex Game Studio Kit — V13 Index

## Start here
- `AGENTS.md` — concise global contract.
- `README.md` — installation and quality checks.
- `INDEX_V13.md` — skill and reference routing.
- `PACKAGE_INVENTORY.md` — generated counts.
- `V13_TEST_RESULTS.md` — evidence and limitations.

## V13 specialist skills
- `$roblox-ci-pipeline-engineering` — PR/main quality workflows.
- `$roblox-workflow-profile-selection` — source-of-truth workflow selection.
- `$roblox-test-harness-engineering` — isolated tests and fixtures.
- `$roblox-luau-static-analysis` — Luau analysis, formatting and linting.
- `$roblox-toolchain-reproducibility` — pinned tools and safe upgrades.
- `$roblox-github-actions-security` — Actions permissions and untrusted code.
- `$roblox-build-artifact-provenance` — deterministic artifact identity.
- `$roblox-release-candidate-assembly` — release evidence and approval.
- `$roblox-studio-test-pipeline` — Studio tests and Open Cloud boundaries.
- `$roblox-ci-quality-gate-orchestration` — check selection and ordering.

## V13 documentation
- `docs/V13_AUTOMATED_QUALITY_PIPELINE.md`
- `docs/V13_WORKFLOW_PROFILE_SELECTION.md`
- `docs/V13_TEST_HARNESS_AND_FIXTURES.md`
- `docs/V13_LUAU_STATIC_ANALYSIS.md`
- `docs/V13_TOOLCHAIN_PINNING_AND_UPGRADES.md`
- `docs/V13_GITHUB_ACTIONS_SECURITY.md`
- `docs/V13_BUILD_ARTIFACT_PROVENANCE.md`
- `docs/V13_RELEASE_CANDIDATE_AND_DEPLOYMENT_GUARD.md`
- `docs/V13_STUDIO_TESTING_AND_OPEN_CLOUD.md`
- `docs/V13_CI_FAILURE_TRIAGE.md`
- `docs/V13_PROJECT_AUTOMATION_BOOTSTRAP.md`
- `docs/V13_SKILL_FORMAT_AND_PROGRESSIVE_DISCLOSURE.md`
- `docs/V13_MIGRATION_FROM_V12.md`
- `docs/V13_RESEARCH_SNAPSHOT.md`

## V13 tools
- `tools/v13_skill_frontmatter_audit.py`
- `tools/v13_workflow_profile_lint.py`
- `tools/v13_toolchain_lock_audit.py`
- `tools/v13_github_actions_security_audit.py`
- `tools/v13_artifact_manifest.py`
- `tools/v13_test_matrix_lint.py`
- `tools/v13_release_preflight.py`
- `tools/v13_luau_toolchain_report.py`
- `tools/v13_pack_doctor.py`
- `tools/v13_ci_preflight.py`

## Existing V1–V12 material
All prior skills, docs, prompts, schemas, templates, examples, and tools remain. V13 repairs 11 inherited skill frontmatter blocks so Codex can parse their YAML metadata cleanly. Prefer current V13 guidance where it adds CI and release details.
