# V12 Analytics Event Governance

## Start with a question
For every custom event, write the product question it answers, the decision that could change based on the metric, and why a built-in metric is insufficient. Remove events with no actionable use.

## Minimal and privacy-conscious schema
- Prefer bounded enumerations and numeric aggregates over free-form text.
- Do not include passwords, tokens, email addresses, phone numbers, precise location, health details, or other sensitive personal data.
- Avoid raw user-entered strings and unnecessary identifiers.
- Define retention/ownership and access expectations for exported reports.
- Use the current event catalog limits and rate limits from official documentation; do not hardcode them forever.

## Roblox custom-event constraints
The current Creator Hub docs state custom events can only be sent from the server in published experiences, not from Studio/client sessions, and document a limit of 100 custom events. Verify the current limits again before implementation because platform rules can change.

## Testing separation
Studio tests should validate that instrumentation code calls the expected adapter and handles failure. They do not populate published-experience custom event dashboards. Published telemetry verification requires an explicitly approved production/staging environment and permission.

## Review
Run `python tools/v12_analytics_catalog_lint.py schemas/examples/v12-analytics-event-catalog.example.json`. The linter detects risky field names and catalog count/shape issues; it is not a legal/privacy compliance review.
