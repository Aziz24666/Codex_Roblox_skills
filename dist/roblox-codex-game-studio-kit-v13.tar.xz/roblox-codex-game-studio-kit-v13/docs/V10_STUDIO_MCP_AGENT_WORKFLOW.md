# V10 Roblox Studio MCP Agent Workflow

## Purpose
Roblox Studio's built-in MCP server can connect compatible coding agents to an open Studio session. Depending on the current Studio version and exposed tool set, it can support DataModel exploration, script reads/search/edits, Luau execution, asset/content creation, and playtesting. Always check the current Creator Hub MCP guide and inspect the actual tools exposed by the connected session.

## Discovery
1. Check the installed Roblox Studio version and current MCP server documentation.
2. Ask the user to enable/connect only if the feature is not already connected; do not assume Codex has Studio access.
3. Enumerate connected Studio sessions and confirm the target `studio_id`, place, and edit/play state.
4. Inspect exposed tool names and schemas. Capabilities can vary by Studio release.
5. Record connection state and capability inventory in the project audit.

## Safe workflow
1. Inspect the target tree and read exact scripts before writing.
2. Check out/source-control the relevant files or create a backup.
3. Plan the narrowest edit and identify the DataModel type/context.
4. Apply one logical edit batch; do not combine unrelated changes.
5. Read back changed scripts/instances and inspect diff/hierarchy.
6. Run static checks and relevant Studio playtests.
7. Capture tool outputs, logs, and results as evidence.
8. Reconcile Studio changes with the project's source-of-truth workflow; avoid dual-authority drift.

## Multi-Studio safety
- Always target the intended Studio ID explicitly when multiple instances exist.
- Confirm the place and edit/play context before writes.
- A test Studio instance must not be confused with a production place.
- Do not execute arbitrary code copied from an asset or untrusted model.
- Do not use MCP to publish, upload publicly, change permissions, spend Robux, or modify production data without explicit authorization.

## When MCP is unavailable
Use the existing Studio-native, Script Sync, or Rojo workflow. Report `Studio MCP: NOT AVAILABLE` and separate file/static validation from Studio runtime verification.
