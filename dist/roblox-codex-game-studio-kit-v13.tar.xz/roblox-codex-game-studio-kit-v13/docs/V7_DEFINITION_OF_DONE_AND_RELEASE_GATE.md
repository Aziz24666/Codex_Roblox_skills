# V7 Definition of Done and Release Gate

A feature is complete only when all applicable conditions are met:

- Player-visible outcome matches the approved feature scope.
- No placeholder path remains in the delivered flow.
- Module contracts, ownership, and lifecycle are documented where non-obvious.
- Client input is validated at the correct authority boundary.
- Persistence and migrations preserve data invariants.
- Failure, timeout, disconnect, retry, and cleanup paths are implemented.
- UI handles loading, pending, success, empty, and failure states.
- Relevant device, accessibility, content, and localization checks are complete or explicitly blocked.
- Automated/static/runtime tests have evidence and accurate status.
- Performance is within agreed feature budgets or has an approved exception.
- Asset provenance and dependencies are recorded.
- Diff, generated files, docs, known issues, and rollback impact are reviewed.

Release decisions are owned by the user/team, not an agent. Production publication and external mutations require explicit approval. A `PASS` on package validation does not imply game readiness.
