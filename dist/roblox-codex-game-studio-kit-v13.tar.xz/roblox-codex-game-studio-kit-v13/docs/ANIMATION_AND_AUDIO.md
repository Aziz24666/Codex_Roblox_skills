# Animation and Audio Integration

## Asset readiness
Confirm source, rights, moderation/availability, intended duration, loop behavior, naming, and target use before integration. Do not invent asset IDs.

## Animation
- Identify rig and expected character type.
- Define who loads and plays tracks.
- Establish priority, loop, fade, interruption and cleanup behavior.
- Keep gameplay-critical state server-authoritative; visual animation is not proof that an action succeeded.
- Handle character respawn and track teardown.

## Audio
- Choose 2D/UI or spatial sound intentionally.
- Define volume group, priority, rolloff/falloff and playback scope.
- Avoid duplicate playback from server/client echo.
- Make critical state understandable without audio.
- Respect device volume and avoid excessive simultaneous ambience/effects.

## Synchronization
Use events or replicated state for meaningful changes. Don't rely on arbitrary frame delays to synchronize gameplay. If timing matters, define the authoritative event and let animation/audio follow it.

## Verification
Check missing asset behavior, repeated triggers, respawn, late join, audio distance, volume mix, animation interruption and memory cleanup.
