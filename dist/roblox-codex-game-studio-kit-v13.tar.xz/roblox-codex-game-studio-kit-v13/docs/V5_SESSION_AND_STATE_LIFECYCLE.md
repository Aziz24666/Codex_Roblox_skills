# V5 Session, Character, and System Lifecycle

For every connection, task, instance, profile, character, round, and temporary object, identify the cleanup owner. Cleanup should be safe to call more than once where practical.

Consider PlayerAdded, character spawn/removal, death/respawn, leave, reconnect, shutdown, and async profile loading that finishes after a player leaves. Rebind character-dependent input/animation/references after respawn. Disconnect old-character connections and invalidate stale tasks.

Each round has one owner, one state machine, bounded timers, and one cleanup path for success, cancellation, error, shutdown, and zero-player state. Use cancellation tokens/generation IDs or stale-result guards when old asynchronous work could overwrite new state. Bound retries/timeouts and client-triggered work.

Test duplicate cleanup, respawn during action, leave during load/save, round cancellation, delayed async completion, and repeated start/stop.
