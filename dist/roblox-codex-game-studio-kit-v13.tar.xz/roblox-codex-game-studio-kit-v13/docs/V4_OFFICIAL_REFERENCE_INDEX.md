# V4 Official Reference Index

Use official current documentation for API signatures and platform behavior. Documentation URLs are starting points; follow the relevant class/member page and verify against the installed Studio version. Checked for this V4 package on 2026-11-15.

## Roblox Creator Hub

- [Studio testing modes](https://create.roblox.com/docs/studio/testing-modes) — solo, client/server, multiple clients, device and network simulation.
- [Improve performance](https://create.roblox.com/docs/performance-optimization/improve) — performance and streaming guidance.
- [Data stores](https://create.roblox.com/docs/cloud-services/data-stores) — persistent player data.
- [Data store best practices](https://create.roblox.com/docs/cloud-services/data-stores/best-practices) — key design, buffering, request patterns, lifecycle.
- [Memory stores](https://create.roblox.com/docs/cloud-services/memory-stores) — temporary cross-server coordination.
- [Memory store best practices](https://create.roblox.com/docs/cloud-services/memory-stores/best-practices) — expiration, request failures, quotas, update patterns.
- [Data stores versus memory stores](https://create.roblox.com/docs/cloud-services/data-stores-vs-memory-stores) — choose service by durability and access needs.
- [Roblox Studio](https://create.roblox.com/docs/studio) — Studio capabilities and workflows.

## Codex skill authoring

- [Build skills](https://learn.chatgpt.com/docs/build-skills) — skill directory, `SKILL.md`, metadata, references, scripts, and activation.
- [Customization overview](https://learn.chatgpt.com/docs/customization/overview) — reusable workflows and skill organization.

## Source policy

Use official docs first for engine/service semantics. Use community examples only as secondary context. If an API is unfamiliar or recently changed, verify the member's current signature, security/permission requirements, thread-safety/replication behavior where relevant, and Studio/runtime availability. Record the exact page and verification date in the project when the decision matters.
