# Roblox Architecture and DataModel Placement

Architecture should make ownership visible and keep code in the correct runtime context.

## Runtime boundaries
Roblox experiences run in a client-server model. The server is the authoritative owner of shared game state. Clients render the world, handle local input and present UI. Replication synchronizes selected state; it is not a guarantee that every object is available on every client at all times.

## Typical service placement
Use the actual project structure where one exists. Common placements include:
- `ServerScriptService`: server-only scripts and modules.
- `ServerStorage`: server-only assets/data that should not replicate by default.
- `ReplicatedStorage`: shared modules, remote definitions and assets the client needs.
- `StarterPlayerScripts` / `StarterCharacterScripts`: client startup and character-local scripts.
- `StarterGui`: UI templates and client-facing presentation.
- `Workspace`: live world instances and interactive geometry.
- `Lighting`, `SoundService`, `TextChatService`: their respective engine configuration and presentation responsibilities.

This is a guide, not a command to move existing instances. Verify the correct service and runtime context for each object.

## Ownership map
For each system record:
- source of truth;
- runtime owner (server/client/shared);
- storage location;
- public API;
- events/remotes;
- persistent fields;
- lifecycle owner;
- tests.

## Dependency direction
Prefer a clear flow: bootstrap → composition/root service → system modules → small pure/shared utilities. Avoid cyclic module dependencies. Shared modules must not contain secrets or trust client values. Client code should not `require` server-only modules.

## Configuration placement
Public presentation configuration may be shared. Secrets, reward authority and secure rules must be server-owned. Avoid replicating full server configuration when the client only needs a small display subset.

## Mixed project content
In partially managed projects, identify which service branches are controlled by files and which remain Studio-authored. Configure Rojo mappings to avoid overwriting artist-owned content. Preserve unknown instances and test sync behavior before using it on a valuable place.
