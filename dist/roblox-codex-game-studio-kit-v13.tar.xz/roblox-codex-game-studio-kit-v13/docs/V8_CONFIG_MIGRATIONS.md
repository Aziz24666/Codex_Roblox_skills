# V8 — Config Schema Migrations

Every definition has a schema version. When a shape changes:
1. Add a new schema version and migration function.
2. Keep migration deterministic and pure.
3. Add fixtures for each supported old version.
4. Test old → current and current → current normalization.
5. Preserve unknown user data only when the schema explicitly allows it.
6. Produce a migration report and do not silently drop fields.

Do not mutate the user's source config just to load it. Normalize in memory first; write back only through an explicit authoring operation. Separate content-definition migrations from player profile/data migrations.
