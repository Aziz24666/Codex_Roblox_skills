# V7 Official Reference Index

**Reference check date:** 2026-11-15. This index is a starting point, not a permanent API contract. Verify the exact member page, security tags, availability, engine version, and deprecation state before implementing version-sensitive behavior.

## Roblox Studio and testing
- Studio testing modes and scripted testing: https://create.roblox.com/docs/studio/testing-modes
- `StudioTestService`: https://create.roblox.com/docs/reference/engine/classes/StudioTestService
- TestService: https://create.roblox.com/docs/reference/engine/classes/TestService
- Network Simulator: https://create.roblox.com/docs/studio/network-simulator
- Performance optimization and profiling: https://create.roblox.com/docs/performance-optimization/identify

## Authority and networking
- Server authority model: https://create.roblox.com/docs/projects/server-authority
- Server authority techniques: https://create.roblox.com/docs/projects/server-authority/techniques
- Network ownership, movement validation, and physics: https://create.roblox.com/docs/scripting/security/network-ownership
- Security tactics: https://create.roblox.com/docs/scripting/security/security-tactics

## Luau and systems
- Luau type checking: https://create.roblox.com/docs/luau/type-checking
- Roblox services: https://create.roblox.com/docs/scripting/services
- Data stores: https://create.roblox.com/docs/cloud-services/data-stores
- Data Stores vs. Memory Stores: https://create.roblox.com/docs/cloud-services/data-stores-vs-memory-stores
- Memory stores: https://create.roblox.com/docs/cloud-services/memory-stores
- Cross-server messaging: https://create.roblox.com/docs/cloud-services/cross-server-messaging

## Experience production
- Localization: https://create.roblox.com/docs/production/localization
- Experience and place configuration: https://create.roblox.com/docs/projects/configure-experiences
- Rojo workflow (community-maintained tool): https://create.roblox.com/docs/projects/rojo

## Codex skills and context
- OpenAI: Rethinking skills and prompts: https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
- Skills concept: https://developers.openai.com/plugins/concepts/skills
- Build skills: https://developers.openai.com/plugins/build/skills

## Implementation rule
Read the current official page, not only this index. Record the exact URL and review date when an API is material to the feature. Do not assume beta/preview features are generally available. Do not infer Studio control from the presence of documentation.
