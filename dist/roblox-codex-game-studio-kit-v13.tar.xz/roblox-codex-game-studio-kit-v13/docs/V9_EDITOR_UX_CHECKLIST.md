# V9 — Editor UX Checklist

- [ ] Family tabs have plain-language labels and descriptions.
- [ ] Fields are grouped by purpose; advanced settings are not mixed into basic values.
- [ ] Every field has label, default, type, bounds/options, and short help where needed.
- [ ] Required fields are visually marked.
- [ ] Invalid fields identify the exact field path and expected format/range.
- [ ] Enum values are selected from a closed option list.
- [ ] Asset fields show asset kind and verification state separately.
- [ ] Form state is a draft and does not modify the DataModel.
- [ ] Preview is read-only and displays stale state after any change.
- [ ] Generate is a distinct explicit action.
- [ ] Output path, template and provenance are visible.
- [ ] Existing content is never silently replaced.
- [ ] Undo/redo behavior is tested in Studio.
- [ ] Keyboard focus, scrolling, panel resizing, dark theme/readability, and compact layouts are checked.
- [ ] The editor explains how to add another variant without writing another script.
