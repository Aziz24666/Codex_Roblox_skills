# V10 Testing and Performance Gates

## Testing layers
1. Formatting and lint.
2. Luau type analysis/static diagnostics.
3. JSON/schema/catalog validation.
4. Generated-output determinism and diffs.
5. Pure module/unit tests where available.
6. Contract and integration tests.
7. Roblox Studio solo client/server tests.
8. Multi-client test for replication, remotes, shared state, join/leave.
9. Device/input/orientation and network simulation.
10. Physical device and longer-session checks when release risk requires them.
11. Staging smoke tests with isolated data.

Use Studio's currently documented testing modes and scripted test services if available. Confirm the active Studio build and capabilities; do not assume a service is enabled merely because a doc page exists.

## Performance workflow
- Define device/server/player-count budgets before optimization.
- Capture baseline on representative workload.
- Profile script time, rendering, physics, memory, replication, instance count, loading, and network behavior as relevant.
- Fix measured hotspots one at a time.
- Compare under the same test setup and preserve raw evidence.
- Test low-end/mobile and long-session behavior when the feature can affect them.

## Completion
A test is PASS only when executed and the expected result is observed. Keep `BLOCKED`, `NOT RUN`, and `NOT APPLICABLE` distinct. A build or linter is not a Studio runtime proof.
