# Luau Engineering Standards

## Language and typing
- Write Luau, not generic Lua.
- Prefer `--!strict` for new modules and scripts when practical.
- Define exported types for public module data and method contracts.
- Avoid broad `any`; if unavoidable, isolate it at a boundary, explain why and validate immediately.
- Model optional values explicitly. Avoid assuming `WaitForChild` or remote payloads have the expected class without checking when uncertainty exists.

## Style
- Use descriptive names, small cohesive functions and early validation.
- Keep constants/configuration in named modules with units.
- Avoid magic values, duplicated rules and oversized modules.
- Separate pure transformation/calculation logic from engine effects when it makes testing easier.
- Avoid top-level work that starts loops or connects long-lived events as a side effect of requiring a module.

## Asynchrony
- Use task scheduling intentionally and bound retries.
- Handle cancellation, player departure and object destruction.
- Avoid tight polling loops; prefer events or signals.
- Ensure spawned tasks cannot mutate stale or destroyed state.
- Do not swallow errors with broad `pcall`; handle expected failure at the correct boundary and preserve diagnostic context.

## API accuracy
When uncertain about an API, enum, parameter, security behavior or deprecation status, check current Creator Hub/reference docs. Do not invent methods from memory. Prefer the smallest proof-of-concept to validate unclear behavior.

## Static checks
Use available Luau analysis, lint and formatting tools, but verify installed tool/version and project configuration first. Static analysis cannot prove the runtime behavior of Instances, replication, physics or Studio-only features.
