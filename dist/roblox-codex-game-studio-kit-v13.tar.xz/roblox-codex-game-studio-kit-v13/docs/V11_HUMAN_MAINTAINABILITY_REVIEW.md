# V11 Human Maintainability Review

Review code from the perspective of the developer who will need to modify it later.

## Questions
- Can the purpose be understood from the name and first few lines?
- Does the module have one coherent responsibility?
- Are public inputs/outputs and side effects explicit?
- Is configuration separate from behavior?
- Are state ownership and lifecycle obvious?
- Are errors actionable rather than swallowed?
- Are comments explaining intent and constraints rather than restating code?
- Can a new variant be added through data/schema without copying core logic?
- Are generated files clearly marked and reproducible?
- Are tests focused on contracts rather than implementation trivia?

Prefer deletion and simplification over introducing a framework for a one-off use case. Explain non-obvious trade-offs in an ADR.
