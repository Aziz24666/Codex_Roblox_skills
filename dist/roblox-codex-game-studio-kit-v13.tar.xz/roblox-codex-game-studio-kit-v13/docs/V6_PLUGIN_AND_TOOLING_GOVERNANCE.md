# V6 Studio Plugin and Developer Tool Governance

## Plugin classification
Classify the plugin as personal tool, team-internal tool, project-specific editor, or distributable plugin. Record supported Studio versions, DataModel changes, permission needs, external dependencies, source provenance, and owner.

## Safety model
- Treat plugins as privileged developer tools. Review code and dependencies before enabling.
- Separate editor-only code from published gameplay code.
- Provide dry-run/preview before structural changes.
- Require confirmation for deletes, bulk renames, overwrites, asset replacements, and publication.
- Use transactions or backups for multi-step changes where possible.
- Implement undo or a clear restore path.
- Never collect credentials, cookies, or unnecessary personal data.
- Make logging local and redacted by default.

## Plugin architecture
Separate toolbar/menu entry, dock widget/presentation, command routing, input validation, project adapter, mutation layer, and diagnostic reporting. Use cancellation and bounded operations for long tasks. Avoid blocking the Studio UI.

## Compatibility
Verify exact API signatures against current Creator Hub pages. Test install, enable, disable, reload, plugin update, empty project, unexpected selection, malformed files, permissions, undo, and user cancellation.

## Third-party package review
Check publisher/provenance, source availability, permissions, embedded scripts, network/file access, dependency chain, update policy, license, and necessity. If risk cannot be evaluated, do not install or run it.
