# V6 Simulation Testing and Deterministic Reproduction

## Use deterministic logic where it helps
Pure game rules, wave generation, loot tables (non-gambling), puzzle generation, scoring, and state transitions can often be separated from engine services and tested with fixed inputs/seeds. Use injected clock/randomness/config dependencies where practical.

## Do not promise full physics determinism
Roblox physics, replication, frame scheduling, and network timing should not be assumed to produce identical results across devices or sessions. Use invariant and tolerance-based checks for physics. Record environment and seed for reproducible content generation, not as a claim of deterministic whole-game simulation.

## Scenario fixtures
Each fixture identifies initial state, actions, simulated time progression, expected state, invariant assertions, and cleanup. Keep test fixtures separate from production data.

## Failure injection
Where test architecture supports it, simulate delayed responses, rejected writes, duplicate messages, disconnects, missing assets, cancellation, and service unavailability. Make failure injection explicit and disabled in production.

## Reproducibility record
Record commit, tool versions, random seed, config version, fixture ID, time source, Studio version, client count, device/network profile, test data environment, and output artifact.

## Avoid false confidence
A passing pure-function simulation does not prove remotes, physics, DataStores, TeleportService, or UI work in Studio. Escalate to the relevant integration/runtime test.
