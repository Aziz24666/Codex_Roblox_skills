# V5 Platform Compliance, Privacy, and Player Trust

This is an engineering checklist, not legal advice or a substitute for current Roblox policy. Re-check official requirements before release.

## User-generated content
Inventory content players can create, upload, name, share, or display. Use current platform filtering/moderation systems for applicable content. Never build moderation bypasses, hidden archives, or alternate unfiltered display routes.

## Privacy
Collect minimum data for a named purpose. Do not collect credentials, session cookies, contact details, private chat, sensitive personal data, or unnecessary behavioral profiles. Redact identifiers in logs where possible. Define access, retention, deletion, and incident response. Keep test and production data isolated.

## Social features
Use privacy-aware defaults, report/block/mute affordances where supported, server-side permissions, and safe failure behavior. Do not expose moderation tools based on client flags or build features designed to shame/harass players.

## Age-appropriate design
Avoid gambling mechanics, deceptive purchase flows, hidden odds, coercive timers, harassment, and dangerous real-world instructions. Monetization should be transparent and not misrepresent benefits.

## Release re-check
Verify current community standards, content maturity/age guidance, privacy/data rules, filtering, marketplace requirements, and API policy. Record exact links and review date. Block release pending authoritative review when uncertain.
