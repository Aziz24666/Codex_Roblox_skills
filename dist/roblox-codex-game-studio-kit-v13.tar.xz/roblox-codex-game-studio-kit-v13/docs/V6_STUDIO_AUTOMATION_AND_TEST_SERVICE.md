# V6 Studio Automation and Scripted Test Services

## Purpose and capability boundary
Roblox Creator Hub documents Studio-only scripted testing facilities in addition to manual Test, Test Here, Run, client/server toggle, Server & Clients, Device Simulator, Controller Emulator, Network Simulator, and Player Emulator workflows.

The currently documented Studio-only services include:
- `StudioTestService` for programmatic multi-client simulation.
- `StudioDeviceSimulatorService` for device profile/orientation/resolution/DPI simulation.
- `VirtualInput`, obtained through `UserInputService:CreateVirtualInput()`, for simulated mouse/keyboard/pointer input.

These facilities are Studio-only and do not run as production gameplay services. Their API signatures and availability must be verified against the active Studio version and current Creator Hub references. This document is a workflow guide, not a substitute for exact API reference pages.

## Capability probe
1. Ask what Studio version/project is being used or inspect it if the integration exposes that information.
2. Verify the official documentation for each required API.
3. Inspect whether a Studio plugin/build-pipeline entrypoint is available.
4. Compile/inspect the test adapter in its intended Studio environment.
5. Run a harmless smoke test that opens/closes a test session without changing production data.
6. Record result as `AVAILABLE`, `UNAVAILABLE`, `BETA_OR_VERSION_DEPENDENT`, or `NOT VERIFIED`.

Do not write guessed methods or reflect undocumented members. If the exact service cannot be accessed from the current context, create a manual Studio runbook instead.

## Recommended test pyramid
1. Pure Luau tests for data transforms, state transitions, validation, math, and configuration.
2. Service-level tests with fake dependencies for persistence, time, and transport boundaries.
3. Studio single-client integration tests for DataModel wiring, lifecycle, remotes, UI, and input.
4. Studio multi-client tests for replication, simultaneous actions, join/leave, party/session logic, and ownership.
5. Device/input tests for touch, keyboard/mouse, gamepad, orientation, safe areas, and UI scale.
6. Network tests with latency, jitter, and packet loss where supported.
7. Staging smoke tests only after separate environment/data protection is confirmed.

## Test matrix axes
- Player count: 1, 2, representative party size, and stress count only if the environment supports it.
- Client lifecycle: join, late join, respawn, disconnect, reconnect, leave during action.
- Device: desktop, touch phone, tablet, gamepad, TV/VR only when the game supports them.
- Locale: default, long strings, right-to-left if supported, missing translation fallback.
- Network: baseline, delayed, jittered, packet loss, asymmetric direction where tools allow.
- Data: fresh profile, returning profile, malformed legacy record, load failure, write failure, migration.
- State: normal, boundary, simultaneous request, duplicate, timeout, server shutdown.

## Evidence record
Record Studio version, API/doc revision checked date, project commit, plugin/test adapter version, test name, test clients, device preset, locale, network profile, test data environment, expected/actual, status, Output/console artifact, screenshot or log path, and limitations.

## Never do
- Never put Studio-only test services in published gameplay scripts.
- Never point a test run at production DataStores.
- Never claim tests ran merely because a test harness file exists.
- Never equate device emulation with physical-device verification.
- Never publish merely to enable a test unless separately approved.

## Sources to re-check
See `docs/V6_OFFICIAL_REFERENCE_INDEX.md` for Creator Hub links and verification date.
