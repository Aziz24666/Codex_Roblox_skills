# V7 Context Management and Skill Routing

## Principle
Use skills as focused workflows, not as a second monolithic system prompt. Recent OpenAI guidance emphasizes revisiting accumulated instructions and avoiding bloated context. Preserve concise root instructions; load detail only when needed.

## Selection procedure
1. Classify work: product/design, architecture, feature implementation, defect, refactor, content batch, test, performance, incident, or release.
2. Start with `$roblox-game-builder` for project-wide or multi-system work. Small isolated tasks may use only a specialist.
3. Select the smallest specialist set from `docs/V7_SKILL_ROUTING_MATRIX.md`.
4. Add `roblox-networking-security` for client-triggerable state, `roblox-data-progression` or `roblox-data-migration-operations` for persistence, and `roblox-regression-engineering`/`roblox-qa-performance` when verification boundaries are affected.
5. Read references only for the systems and risks involved. Prefer current V7 docs; consult prior version docs only where V7 does not supersede them.
6. Verify implementation facts against source code and current official docs.

## Context hierarchy
- Root `AGENTS.md`: short universal contract and safety gates.
- Nested `AGENTS.md`: local path-specific constraints.
- `SKILL.md`: when to use the workflow and its steps.
- `references/` or `docs/`: deep detail loaded on demand.
- Templates/schemas: concrete artifacts only when the task warrants them.

## Anti-patterns
Do not activate all skills; paste every reference into every prompt; maintain duplicate conflicting instructions; create documentation without an owner or use; or mark a skill as used merely because it exists.

## Completion report
State selected skills, important sources inspected, decisions, changed files, tests actually run, and remaining blockers. Keep routine reports concise.
