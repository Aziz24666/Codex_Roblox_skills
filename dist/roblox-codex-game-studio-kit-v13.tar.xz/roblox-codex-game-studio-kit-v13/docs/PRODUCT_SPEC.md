# Product Specification Guide

A product spec explains the experience the player should receive. It is not a long list of implementation tasks.

## Required sections
1. **Pitch:** one or two sentences describing the distinctive experience.
2. **Player fantasy:** what role/action should feel compelling?
3. **Audience and content boundaries:** intended audience, complexity, social exposure and age-appropriate tone.
4. **Core loop:** entry → goal → action → feedback → reward/progression → next choice.
5. **Session shape:** first minute, first five minutes, normal session, stopping/return path.
6. **Player verbs:** the actions players repeatedly perform.
7. **World structure:** hub, activity zones, levels, rounds or other spatial organization.
8. **Progression:** unlocks, goals, cosmetics, collection or mastery; keep it comprehensible.
9. **Social role:** solo, cooperative, competitive, shared building or social presence.
10. **Controls/platforms:** target device classes and input mappings.
11. **UX requirements:** onboarding, status feedback, menus, accessibility and error states.
12. **Non-functional requirements:** performance, concurrency, persistence, security and supported devices.
13. **Content rules:** asset provenance, tone and prohibited content.
14. **Scope:** launch-critical, later and explicitly out of scope.
15. **Success signals:** observable playtest outcomes and technical reliability measures.
16. **Acceptance criteria:** specific conditions that can be checked.

## Writing a good requirement
Weak: "Make the shop good."
Better: "A player can open the shop from the hub, inspect the name and cost of each available item, see their current balance, submit one purchase request, and receive a server-confirmed success or clear failure message. A repeated request cannot charge twice."

## Assumptions
Mark each unknown as `ASSUMPTION`, give its reason and impact, and choose reversible defaults. Ask the project owner only when the unknown changes the game's identity, creates a major cost/risk, or authorizes an external side effect.
