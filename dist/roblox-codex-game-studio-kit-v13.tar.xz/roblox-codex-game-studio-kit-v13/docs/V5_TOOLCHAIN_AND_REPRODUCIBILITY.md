# V5 Toolchain Pinning and Reproducibility

Record OS, Roblox Studio version/date, Rojo, Luau formatter/linter/type checker, test framework, package manager, CI runner, and plugins. Mark missing tools unavailable.

Prefer project-local version files/lockfiles supported by each tool. Do not silently upgrade during feature work. Document dependency purpose, license, maintenance, compatibility, and replacement. Avoid `latest` tags for release-critical CI actions. Distinguish local convenience tools from required build dependencies.

Provide a reproducible sequence for install, validation, build, tests, and packaging. Missing prerequisites should fail clearly. Ordinary validation must not publish or change live settings.

For unfamiliar APIs, verify official docs and record URL/date, class/member, signature, yield/thread behavior, permissions, quotas, and failure semantics. CI should run safe static/build/unit checks; publish/deploy must be isolated behind explicit approval. Never print secrets.
