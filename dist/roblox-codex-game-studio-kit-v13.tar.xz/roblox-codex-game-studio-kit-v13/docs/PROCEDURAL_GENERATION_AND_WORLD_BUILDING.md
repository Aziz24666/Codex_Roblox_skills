# Procedural Generation And World Building



## Generation contract

A generator must declare: seed, generator version, coordinate system, output bounds, maximum instance count, target time/memory budget, constraints, server/client ownership, persistence behavior, and cleanup strategy.

## Recommended phases

1. Parse and validate configuration.
2. Establish deterministic seed and stable identifiers.
3. Generate abstract layout data without creating Instances.
4. Validate constraints (bounds, reachability, overlap, clearance, spawn safety, objective connectivity).
5. Build Instances in bounded batches.
6. Apply decoration after required gameplay geometry is valid.
7. Activate only the content needed for the current area.
8. Deactivate, recycle, or destroy content when it is no longer needed.

## Determinism

Use an explicit seed and stable ordering. Do not depend on unordered table iteration for output that must be reproducible. Store seed and generator version with bug reports. If generation rules change, decide whether old seeds must remain reproducible and document compatibility.

## Streaming considerations

Workspace instances may not exist on a client when a LocalScript first runs. Use streaming-aware waits/events and avoid assuming a full world hierarchy is immediately present. Keep server-required geometry authoritative. Avoid moving large world assets into ReplicatedStorage to bypass streaming.

## Validation matrix

Run fixed known seeds, multiple random seeds, minimum/maximum supported settings, invalid configuration, disconnected paths, overlapping objects, boundary chunk transitions, repeated generation/cleanup, late join, and server load. Profile in Studio; static estimates alone are not enough.

## Content safety

Generated content should be age-appropriate, readable, accessible, and consistent with the game's stated fantasy. Avoid generation approaches that produce inaccessible traps, confusing dead ends, or harmful player experiences.
