# V5 Release and Operations Runbook

## Candidate checklist
Freeze scope/build reference; confirm toolchain; review critical/high issues; verify asset rights; review server/client ownership and remotes; test migrations/rollback with isolated data; complete relevant Studio solo/multi-client/device/network tests; review privacy, moderation, accessibility, purchase handling; write release notes and known issues.

## Approval gate
A local release candidate is not permission to publish. Publishing, public asset upload, live settings, production migration, or permission changes require explicit approval.

## Rollback
Define trigger, decision owner, prior known-good version, rollback method, data compatibility, feature flags, communications, and post-rollback verification. Code rollback does not reverse migrations or processed transactions; handle these separately.

## Live operations
Use versioned validated config, staged rollout where available, bounded telemetry, and safe kill switches. Avoid reacting to one anomalous metric. Document how to disable events without corrupting progress.

## Incident response
Detect/classify → mitigate safely → preserve redacted logs/version data → identify scope → reversible correction → validate recovery → document root cause/prevention. Never expose secrets or private player data.
