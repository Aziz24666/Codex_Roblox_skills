# V7 Performance Benchmarking

## Benchmark contract
A benchmark is identified by build/commit, place, Studio/client version, device profile, graphics setting, network profile, server player count, journey/scenario, warm/cold state, duration, sample count, and metric definition.

## Metrics to consider
Client frame time/FPS, memory, draw/render cost, instance count, script execution, network send/receive, asset load, streaming readiness, server heartbeat, physics simulation cost, and join time. Select the few that reflect the feature's risks.

## Statistics
Use enough runs to make the comparison meaningful. Report p50/p95 or min/median/max when appropriate, sample count, and variance. Do not compare measurements taken on different environments without noting the mismatch.

## Regression policy
Set a baseline and threshold per device/scenario. Require an explanation when a change exceeds budget. Avoid rigid universal FPS or memory numbers that ignore the target device and experience scope.

## Workflow
Profile → identify dominant cost → form one hypothesis → change one major factor → rerun same scenario → compare → inspect side effects. Preserve capture files and raw data.

## Runtime limitation
Static code scans and project audits cannot prove runtime performance. Studio profiling, representative device testing, and production telemetry (when approved and privacy-compliant) are different evidence levels.
