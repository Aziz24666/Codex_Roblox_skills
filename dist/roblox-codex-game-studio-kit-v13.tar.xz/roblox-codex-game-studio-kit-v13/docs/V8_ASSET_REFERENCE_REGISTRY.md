# V8 — Asset Reference Registry

Store asset references as explicit data fields with semantic names. A string such as `rbxassetid://123` is only a syntactically shaped reference, not proof that the asset exists, is permitted for the experience, is the right type, or will load.

Recommended asset record: stable `assetKey`, `assetType`, Roblox asset reference, intended use, rig compatibility where relevant, owner/provenance, review status, and optional thumbnail/preview note. Keep the reference separate from presentation logic so an asset can be changed without editing movement or interaction code.

At runtime, handle delayed/unavailable assets gracefully. Never make core functionality depend on an unverified optional cosmetic/audio reference.
