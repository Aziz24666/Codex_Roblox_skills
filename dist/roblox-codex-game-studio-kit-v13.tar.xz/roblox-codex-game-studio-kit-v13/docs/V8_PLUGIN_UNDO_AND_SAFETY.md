# V8 — Plugin Undo and Safe DataModel Mutation

Studio plugins mutate user projects; they must be predictable.

- Validate all draft data before starting mutation.
- Revalidate current selection at the moment the user presses Generate.
- Use Studio's supported change-history/undo workflow for a single logical action; verify the current API signature.
- On any error, cancel/rollback the operation when possible and report partial work.
- Never use `pcall` to hide a failed generation; include object path and failure reason.
- Keep an output staging folder. Do not edit the selected source template.
- Require a separate explicit replace action for an existing prefab.
- Avoid external network calls and never request/store credentials.
- Treat third-party models/plugins as untrusted and inspect embedded scripts before reuse.
