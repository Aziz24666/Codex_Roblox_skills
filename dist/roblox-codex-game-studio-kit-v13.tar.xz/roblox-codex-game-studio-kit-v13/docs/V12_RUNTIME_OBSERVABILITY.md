# V12 Runtime Observability

## Principles
Instrument only what answers a real operational or product question. Keep logs structured, bounded, and useful to a developer who must diagnose an issue.

## Useful signals
- Startup/initialization stage duration.
- Feature initialization success/failure category.
- Data load/save result category (never credential contents).
- Asset load success/failure category.
- Scene/round transition duration.
- Component attach/detach counts for development diagnostics.
- Aggregated player-flow metrics approved by the project.

## Privacy and safety
Never log secrets, credentials, authentication tokens, contact details, precise location, health information, or raw arbitrary client text. Do not turn diagnostics into surveillance. Avoid unbounded labels or identifiers that explode metric cardinality.

## Environment separation
Use debug logs for Studio and test sessions. Published experience AnalyticsService custom events have distinct environment constraints; keep test assertions and production analytics separate.

## Operational report
Every important signal has an owner, meaning, valid range, severity, action, and disable/removal plan.
