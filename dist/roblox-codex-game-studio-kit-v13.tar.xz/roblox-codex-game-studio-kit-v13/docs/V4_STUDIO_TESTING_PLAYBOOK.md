# V4 Roblox Studio Testing Playbook

Use current Studio controls and confirm names/availability in the installed version. The official Studio testing-modes guide is the reference for available modes.

## Select the right mode

- **Run:** inspect world scripts/scene behavior without inserting a player character.
- **Test / Test Here:** basic player flow and client/server inspection.
- **Server & Clients:** replication, ownership, round logic, party/session behavior, and race conditions across clients.
- **Device Simulator / controller emulation:** responsive layout and input preview.
- **Network Simulator:** latency, jitter, and packet-loss scenarios for network-sensitive behavior.
- **Team Test:** collaborative behavior when a real shared Studio session is required.

## Minimum test passes

### Pass A — startup smoke

Check that the place loads, startup scripts initialize, no unexpected errors appear, the player spawns, and primary UI is available.

### Pass B — first-session journey

Complete the exact new-player journey from spawn through the first meaningful reward or outcome. Record confusing steps, dead ends, and missing feedback.

### Pass C — lifecycle

Test respawn, character replacement, leaving, rejoining, and round/activity transitions where relevant. Confirm connections and temporary Instances are cleaned up.

### Pass D — multiplayer

Use two or more clients for features involving ownership, shared state, trading-like exchanges, parties, races, shared puzzle state, or rounds. Verify every client sees consistent authoritative results.

### Pass E — adverse network

Introduce simulated delay/jitter/loss for time-sensitive features. Look for double actions, stale state, broken prediction, missed events, and unclear pending UI.

### Pass F — device and input

Preview mobile/tablet/desktop/controller layouts and controls. Confirm critical actions are accessible without hover and without precise pointer targeting.

### Pass G — performance

Profile representative scenes and gameplay states. Record device assumptions and baseline. Compare after any optimization.

## Evidence

Use `templates/STUDIO_TEST_RUN_TEMPLATE.md`. Capture logs or screenshots only when permitted and redact account identifiers, credentials, and private information.
