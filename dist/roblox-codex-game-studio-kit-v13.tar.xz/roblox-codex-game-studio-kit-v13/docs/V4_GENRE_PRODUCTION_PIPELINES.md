# V4 Genre Production Pipelines

Genre skills are reusable starting points, not mandatory frameworks. Start with the common core: first-session journey, one complete loop, clear feedback, server-owned rewards, stable save behavior, device parity, and a test plan. Add genre-specific systems only after the loop works.

## 1. Tycoon / builder

**Core loop:** claim space → place/activate a production unit → earn through server simulation → reinvest → unlock a new capability.

**Systems:** plot ownership, purchase catalog, placement validation, production scheduler, upgrade tree, UI price display, persistence, reset/rebirth only if it serves the design.

**Rules:** validate plot ownership and placement server-side; cap object counts; avoid per-part production loops; use deterministic configuration; make purchases/rewards idempotent; show exact prices and effects before a purchase.

**Milestones:** (1) claim one plot, (2) place one unit, (3) server calculates one reward, (4) save/rejoin, (5) unlock one upgrade, (6) multi-player ownership/permissions test, (7) content scaling.

## 2. Obby / platforming

**Core loop:** understand obstacle → execute movement/timing → receive fair feedback → checkpoint → continue.

**Systems:** checkpoint ownership, stage progression, fall/reset recovery, hazard state, timer if applicable, assist options, leaderboard if appropriate.

**Rules:** no client-only stage completion; validate checkpoint transitions and order; avoid unfair collision geometry; support touch controls; make failure readable and recovery fast; never make a paid skip the only reasonable route through difficulty.

**Milestones:** graybox 3 obstacles → tune movement/camera → checkpoints → mobile input → multiplayer race testing → accessibility options → expand course.

## 3. Social / roleplay

**Core loop:** arrive → discover a social affordance → participate safely → form a session/activity → return.

**Systems:** safe shared spaces, optional role assignment, emotes/props, room/party lifecycle, lightweight activities, reporting/moderation-aware UI hooks where platform APIs support them.

**Rules:** do not create harassment, surveillance, doxxing, impersonation, or coercive social mechanics. Do not build custom chat moderation that pretends to replace Roblox platform systems. Avoid storing unnecessary personal information. Check current platform policy and API requirements before adding social features.

**Milestones:** one room → one interaction → safe exit/reset → party/session behavior → multi-client tests → moderation and UX review → content expansion.

## 4. Simulator / collection / incremental

**Core loop:** perform an understandable action → earn a non-randomized or clearly described reward → collect/organize → upgrade capability → access new content.

**Systems:** action economy, collection catalog, inventory limits, upgrade costs, reward pacing, server-owned progress, optional quests, clear UI.

**Rules:** avoid paid random rewards and gambling-like mechanics. Explain reward rules. Prevent duplicate grants, negative currency, overflow, spoofed multipliers, and client-owned reward totals. Balance through simulation and playtests, not arbitrary price inflation.

**Milestones:** one action → one server reward → one collection item → one upgrade → save/rejoin → balance simulation → new world/content tier.

## 5. Racing / vehicle

**Core loop:** join event → ready/countdown → race through valid checkpoints → finish → authoritative result → return to lobby.

**Systems:** vehicle selection/config, spawn ownership, checkpoint sequence, lap state, race timer, finish validation, result display, vehicle reset, anti-grief boundaries.

**Rules:** do not trust client-reported finish times or checkpoint claims. Define how physics ownership and replication are handled, then test under network simulation. Keep vehicle handling accessible and avoid requiring high-end frame rates for fair input. Test disconnects and race-server shutdown.

**Milestones:** one controllable vehicle → one checkpoint route → server-tracked race state → multi-client race → latency tests → device input pass → additional tracks.

## 6. Puzzle / adventure

**Core loop:** observe clue → infer rule → manipulate state → verify solution → unlock next beat.

**Systems:** puzzle state machine, clue delivery, interactables, reset/undo, team ownership if co-op, progression gates, save checkpoints.

**Rules:** separate puzzle logic from presentation; make states inspectable; guard against multiple simultaneous activation; support reset and recovery from disconnect; don't hide critical progression behind unclear UI.

**Milestones:** one self-contained puzzle → hint UX → clean reset → save checkpoint → co-op synchronization → content-authoring format → puzzle chain.

## Common scorecard

For every genre, rate 1–5 after playtesting: clarity of goal, time to first fun, control reliability, feedback quality, fairness, session pacing, social safety, mobile readability, return motivation, and save reliability. Explain scores with observed player behavior. Do not infer quality from feature count.
