# V8 — Modular Architecture Anti-Patterns

- **Copy-per-entity scripts:** use one runtime plus definitions and tags.
- **God module:** split by responsibility and execution boundary.
- **Everything in JSON:** algorithms and invariants belong in code.
- **Shared mutable config:** definitions are immutable; instance state is separate.
- **Untyped config soup:** schemas, Luau types, and runtime validation agree.
- **Config-specific `if` ladders:** use explicit behavior strategies when genuinely different behavior is required.
- **Too many tiny modules:** keep cohesive code together; abstractions must earn their existence.
- **Unreviewed prefab generation:** validate, preview, track provenance, and support undo.
- **Editor that writes scripts from user strings:** use allowlisted strategy IDs and safe structured data.
- **Silent override:** report missing assets, invalid defaults, output collisions, and drift.
