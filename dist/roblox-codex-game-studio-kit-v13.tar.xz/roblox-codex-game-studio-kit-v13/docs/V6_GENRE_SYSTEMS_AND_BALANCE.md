# V6 Genre Systems and Balance Playbook

## General method
For each genre, define its player fantasy, repeating loop, match/session structure, progression, social layer, skill expression, content cadence, device constraints, accessibility needs, and non-goals. Prototype the core interaction before building a large content catalog.

## Tower defense
Wave schedule, spawn budget, path graph, placement validation, targeting rules, upgrade tree, economy flow, co-op contribution, and wave-end settlement. Balance spawn pressure, income, upgrade cost, route complexity, and session duration together.

## Strategy
Turn/tick state machine, legal action catalog, information visibility, action sequencing, timeouts, reconnect/resync, tie-break, surrender, spectator view, and rating settlement. Clients submit intent; server recomputes legal outcomes.

## Competitive ranked modes
Define rating uncertainty, placement matches, visible tier, season cadence, inactivity, disconnect policy, party eligibility, result verification, and dispute handling. Use unique match IDs and idempotent settlement.

## Avatar customization
Separate preview from owned/equipped state, validate catalog ownership, persist only confirmed choices, and design for accessory conflicts, loadout slots, locale expansion, and cross-place consistency.

## Presentation-heavy experiences
For cutscenes and cinematic sequences, define interruption, skip, camera ownership, UI/input restoration, audio/subtitle synchronization, reduced motion, and character respawn behavior.

## Balance simulation
Use spreadsheet or script simulations to explore parameter ranges and edge cases. Track assumptions, distributions, sensitivity, and known omitted effects. Simulated balance is not player telemetry. Validate with real playtests and privacy-conscious aggregate measures.

## Monetization and trust
Keep costs and benefits clear. Avoid deceptive odds, manipulative scarcity, coercive timers, or monetization that invalidates competitive integrity. Ensure the experience remains understandable without purchase.
