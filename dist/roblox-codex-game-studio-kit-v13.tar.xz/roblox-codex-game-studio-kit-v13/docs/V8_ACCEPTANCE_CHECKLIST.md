# V8 Acceptance Checklist

## Architecture
- [ ] Shared algorithm is implemented once.
- [ ] At least two definitions use that exact runtime.
- [ ] Per-instance mutable state is independent.
- [ ] Module dependency direction is documented and acyclic.
- [ ] Runtime cleanup is tested.

## Data
- [ ] Schema, Luau type, normalizer, and runtime validator agree.
- [ ] Stable IDs and schema versions exist.
- [ ] Unknown enums, duplicate IDs, invalid bounds, and missing required references fail clearly.
- [ ] Definition tables are not mutated by runtime systems.

## Authoring and prefab generation
- [ ] Fields have labels, descriptions, defaults, units, and bounds.
- [ ] Validate-only makes no DataModel changes.
- [ ] Preview shows intended hierarchy and bindings.
- [ ] Output collision and user-edited drift are detected.
- [ ] Generation has undo and a report.
- [ ] Generated prefab contains schema/template/generator provenance.

## Human maintainability
- [ ] One page explains how to add a data-only variant.
- [ ] One page explains how to add a behavior.
- [ ] Names and folder structure are consistent.
- [ ] New developer can locate config, runtime, tests, and extension point.

## Evidence
- [ ] Local static checks recorded accurately.
- [ ] Luau analysis/compile status recorded.
- [ ] Studio plugin execution tested in disposable place.
- [ ] Runtime NPC variants tested in Studio.
- [ ] Multiple-instance/performance test recorded.
