# V5 Structured Content and Schema Validation

JSON Schemas under `schemas/` describe feature specs, test evidence, asset records, and game briefs. They keep artifacts structured; they do not prove claims, validate Roblox APIs, verify licenses, or demonstrate gameplay.

Rules: version schemas, migrate intentionally, exclude secrets/personal data, link feature/test/asset IDs, verify provenance separately from existence, and test acceptance criteria separately from JSON structure.

Workflow: copy example → fill fields/assumptions → parse JSON → use an already-approved JSON Schema validator if installed → review semantic consistency → link the artifact to project status. Do not silently add a dependency just to validate schemas.
