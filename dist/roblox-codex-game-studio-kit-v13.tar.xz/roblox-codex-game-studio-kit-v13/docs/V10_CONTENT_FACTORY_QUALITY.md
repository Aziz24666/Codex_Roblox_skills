# V10 Content Factory Quality

A content factory should make creation more consistent and safer, not hide complexity or create opaque assets.

## Required flow
1. Select family and version.
2. Load a validated schema.
3. Edit definition data.
4. Validate fields, semantics, references, and source template.
5. Preview without DataModel mutation.
6. Display dry-run hierarchy and all planned changes.
7. Require explicit Generate action.
8. Start an undo transaction.
9. Create only allowlisted objects and approved templates.
10. Validate generated output and provenance.
11. Finish or cancel transaction as one logical operation.
12. Emit a human-readable report and stable manifest.

## Safety
- No user-provided Luau code in data fields.
- No arbitrary dynamic module loading from untrusted asset IDs.
- No silently replacing existing objects.
- No embedded scripts copied from untrusted source models.
- No assumption that an asset ID grants permission or will load.
- Plugin writes must use the currently documented undo/recording workflow.
- Test generator idempotence and undo/redo in Studio.

## Human maintainability
Provide clear field help, defaults, constraints, examples, actionable validation messages, version migration, and a documented extension process. Generic fields should be reusable across content families.
