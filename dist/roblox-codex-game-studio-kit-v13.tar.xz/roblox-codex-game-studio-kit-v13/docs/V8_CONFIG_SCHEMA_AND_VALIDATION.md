# V8 — Configuration Schema and Validation

## Required fields
Every definition should include `schemaVersion`, a stable `id`, and a content-family discriminator where the family is not obvious from the registry. Add descriptive names and only relevant family-specific fields.

## Validation layers
1. **Decode**: confirm the file/module can be loaded.
2. **Shape**: object/table, required keys, allowed keys, correct primitive/array/nested shape.
3. **Semantics**: numeric bounds, allowed behavior enum, cross-field rules, IDs unique.
4. **References**: referenced path/asset/route/animation exists or is explicitly marked optional.
5. **Normalization**: apply centralized defaults and convert to a canonical type.
6. **Freeze**: treat normalized definitions as immutable where practical.
7. **Runtime guard**: validate again at external boundaries and when data may be stale.

## Error model
Return a structured result with `ok`, `value`, `errors`, and `warnings`. Each issue has a stable code, field path, human-readable message, and severity. Do not crash the whole registry because one optional cosmetic reference is missing; do not run an NPC with a missing required humanoid or invalid movement value.

## Defaults
A default is applied once in `NormalizeDefinition`, not independently by each consumer. Defaults are versioned; changing a default may change old content, so record it in the changelog and test existing definitions.

## Data validation is not authority
A well-formed config can still request an inappropriate action. Runtime systems enforce their own invariants. Config validation does not replace server-side permission checks.
