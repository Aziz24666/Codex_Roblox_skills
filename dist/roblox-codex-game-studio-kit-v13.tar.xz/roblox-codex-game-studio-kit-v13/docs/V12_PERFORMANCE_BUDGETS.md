# V12 Performance Budgets

## Purpose
Budgets are agreed project-specific limits for target experiences and devices. They are not Roblox platform guarantees and must not be copied blindly from a sample.

## Budget definition
Every metric includes a stable key, unit, threshold, applicable device tier/scenario, capture method, rationale, owner, and review date. Keep server/client metrics distinct.

## Recommended categories
- Client: frame time/consistency, memory, content load/join time, input responsiveness.
- Server: frame time, script cost, memory, request/queue pressure where measured.
- World: instance/asset memory, streaming region size, content density.
- Experience: first playable time, transition time, failure/retry rate.

## Threshold selection
1. Measure a representative baseline on target devices.
2. Select a product quality target with headroom for variance.
3. Document sample count and uncertainty.
4. Set a warning threshold and a blocking threshold if useful.
5. Review after major content/platform changes.
6. Do not weaken thresholds to make CI pass without evidence and approval.

## Validation
Run `python tools/v12_perf_budget_check.py <baseline.json> <budget.json>`. The tool compares supplied numbers only. It does not capture performance, validate hardware identity, or prove the evidence is authentic.
