# V12 Content Load and Memory

## Inventory first
List the content needed for first playable interaction, content needed soon after spawn, and optional content that can load later. Classify assets by type, size where known, location, sharing, and fallback behavior.

## Streaming
For large Workspace worlds, evaluate instance streaming against the world layout and player paths. Streaming does not automatically solve every asset-memory issue; measure the actual content and ensure scripts tolerate stream-out/re-entry.

## Load experience
- Keep the first playable path small and robust.
- Defer optional presentation if it does not block meaningful play.
- Show clear progress only when the progress value is real and measurable.
- Define retry and fallback behavior for failed/late asset references.
- Avoid loading the same resource repeatedly from multiple systems without a shared ownership/cache policy.
- Monitor memory and join-time behavior on target device tiers.

## Do not
- Put every asset in ReplicatedStorage and assume that makes it streamed.
- Use Persistent models as a general substitute for correct references.
- Hide a slow join behind a fake progress bar.
