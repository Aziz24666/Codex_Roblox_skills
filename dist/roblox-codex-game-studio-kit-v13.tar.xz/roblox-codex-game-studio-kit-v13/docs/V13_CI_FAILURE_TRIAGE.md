# V13 CI Failure Triage

Classify failures before editing:
- **Environment:** missing/pinned tool, runner image, permissions, unavailable network.
- **Static correctness:** Luau parse/type/lint, schema or config validation.
- **Unit test:** isolated logic and fixture failure.
- **Build mapping:** Rojo project tree, path collision, missing mapping or asset serialization.
- **Studio integration:** DataModel, plugin, engine behavior or replication issue.
- **Flaky test:** timing, non-determinism, shared state, external service.
- **Security gate:** unpinned action, excessive token scope, secrets on untrusted workflow.

Preserve the first failing log, reproduce locally where possible, isolate the smallest failure, fix the root cause, add a regression test, and rerun the affected and broader suites. Do not suppress, skip, weaken budgets, or add retry loops simply to turn CI green.
