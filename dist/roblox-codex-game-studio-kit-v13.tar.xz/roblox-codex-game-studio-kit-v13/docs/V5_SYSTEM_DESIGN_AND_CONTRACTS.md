# V5 System Design and Contracts

Every system must have understandable boundaries before implementation.

## System specification
| Field | Required question |
|---|---|
| Purpose/non-goals | What does this solve, and what does it not own? |
| Entry points | Which server/client scripts invoke it? |
| Execution context | Server, client, shared pure module, Studio tooling? |
| State owner | Who owns the source of truth? |
| Public API | Which functions/events/types are supported? |
| Remote contract | What request may a client send? |
| Persistence | Is it durable? Which schema/migration? |
| Lifecycle | Who starts, stops, reconnects, and cleans it? |
| Failure | Missing asset, timeout, duplicate request, partial state? |
| Observability | What bounded non-sensitive signal explains failure? |
| Test seam | How are pure logic and engine integration tested? |

## Suggested boundaries
- **Bootstrap/composition root:** obtains dependencies and starts systems in order.
- **Domain modules:** deterministic rules/state transitions; no UI ownership.
- **Adapters:** Roblox services, DataStores, remotes, teleport, asset lookup.
- **Presentation:** UI, camera, sound, animation, local effects.
- **Contracts:** types, constants, versioned payload and schema definitions.
- **Tests:** pure rules, integration adapters, Studio runbooks.

Do not make every folder a service. A service needs cohesive behavior, clear ownership/lifecycle, and meaningful complexity or multiple callers.

## Remote contract fields
Document action ID, endpoint/direction, allowed caller, payload schema, max size, numeric bounds, instance class/ancestry, player state, ownership, proximity, permissions, cooldown/rate budget, expected server cost, state mutation, response, and rejection behavior.

Prefer intent requests such as `RequestEquip(itemId)` over outcome setters such as `SetCurrency(value)`. Reject arbitrary paths, code/module IDs, and unrestricted instance mutation.

## State transitions
For each transition document source/destination, authority, initiating event, guard, side effects, idempotency key, timeout/cancellation, cleanup, and terminal state.

## Data contracts
Use stable IDs, schema version, migration path, load/save validation, defaults that do not erase unknown player progress, size/count bounds, session/concurrency semantics, and recovery for load failure/unknown write outcome.

## Review gate
Reject designs where state ownership is ambiguous, client data decides outcomes, interfaces are undocumented, lifecycle is unclear, persistent data is unversioned, or important invariants have no test seam.
