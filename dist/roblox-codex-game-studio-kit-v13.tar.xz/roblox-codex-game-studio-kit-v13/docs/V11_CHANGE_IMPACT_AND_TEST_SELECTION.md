# V11 Change Impact and Test Selection

## Goal
Use the changed files and dependency graph to choose an evidence-backed regression set without running every possible test for every edit.

## Procedure
1. Identify direct changes and generated outputs.
2. Map dependencies in both directions: what the changed module uses and what depends on it.
3. Include shared schemas, remotes, profile fields, plugin interfaces, and public module contracts.
4. Identify runtime contexts affected: server, client, shared, plugin, command-line tooling, CI.
5. Select tests by risk: data/security/concurrency changes receive stronger verification than isolated copy edits.
6. Include at least one integration/Studio test for changed runtime behavior when Studio is available.
7. Add a regression test for each fixed defect when practical.
8. Record untested dependency branches and why.

## Test selection matrix
- Type/schema/config-only: validators, generator reproducibility, consumer contract tests.
- Shared module: direct unit tests plus dependent integration tests.
- Remote contract: invalid-input tests, rate-limit tests, ownership/state tests, multi-client tests.
- Persistence: serialization, retry/budget/error paths, migration fixture, recovery test; never casually use production data.
- Studio plugin: plugin load, widget state, selection edge cases, undo/redo, preview isolation, generation collision tests.
- Generated content: deterministic output, manifest validation, no script injection, hierarchy contract.
- UI/input: keyboard, touch, gamepad, resolution/device checks as relevant.
- Performance: baseline and before/after profile under a repeatable scenario.

## Limits
Dependency scans are approximate, especially for dynamic require paths, framework registries, tags, reflection, and DataModel references. Ask for manual mapping when the static graph is incomplete.
