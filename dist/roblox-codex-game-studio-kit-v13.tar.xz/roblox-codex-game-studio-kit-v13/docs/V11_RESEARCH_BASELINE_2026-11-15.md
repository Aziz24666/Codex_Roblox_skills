# V11 Research Baseline — 2026-11-15

This is a dated snapshot for the V11 package design, not a permanent guarantee. Re-open the sources for future tasks.

- Roblox Studio MCP: https://create.roblox.com/docs/studio/mcp — current docs describe DataModel inspection, script operations, Luau execution, playtesting, asset workflows, specific Studio instance targeting, and local stdio transport.
- Studio MCP Open Cloud permissions: https://create.roblox.com/docs/studio/mcp-open-cloud — permissions are controlled per game and per scope; high-risk scopes can affect live game or player state.
- Roblox Luau Execution: https://create.roblox.com/docs/cloud/reference/features/luau-execution — documented headless execution task APIs; verify current availability, limits, auth, and target place before use.
- StudioTestService: https://create.roblox.com/docs/reference/engine/classes/StudioTestService — plugin-security testing service with play/run/multiplayer test methods.
- OpenAI Codex skill and AGENTS guidance: https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra — recommends concise triggers, progressive disclosure, current AGENTS instructions, contextual reads, and defining completion.
