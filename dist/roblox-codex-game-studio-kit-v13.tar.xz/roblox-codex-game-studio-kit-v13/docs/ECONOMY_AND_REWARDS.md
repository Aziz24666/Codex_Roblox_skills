# Economy, Inventory and Rewards

## Economy design
Define each currency/item by: stable ID, display name, purpose, acquisition sources, sinks, maximum/allowed quantity, tradeability and persistence rules. Avoid multiple currencies without a clear player benefit.

## Transaction lifecycle
1. Client requests an intent (buy known item, claim available reward).
2. Server resolves the item/reward from trusted configuration.
3. Server validates player state, ownership, prerequisites, price, balance and cooldown.
4. Server performs an atomic or otherwise consistency-safe update appropriate to the data model.
5. Server responds with success only after authoritative confirmation.
6. UI displays updated balance/inventory from confirmed state.

## Idempotence and concurrency
Protect against double-clicks, repeated remote calls, simultaneous purchases, replayed claims, and a player leaving during an operation. Use a transaction state or unique claim key when required. Define whether a failed operation can be retried safely.

## Reward balancing
Use transparent deterministic rewards. Document the reason a player receives each reward. Keep prices and value progression readable. Do not design gambling-like paid random rewards, manipulative scarcity, or misleading purchase flows.

## Monetization integration
Use current official platform guidance and APIs. Do not invent product IDs or claim a platform purchase has succeeded before verified server-side fulfillment. Any actual purchase setup, spending, product creation or live configuration requires explicit owner approval.
