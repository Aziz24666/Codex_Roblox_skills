# V10 API Currency and Release-Notes Watch

Before using a Roblox API, verify its exact class/member reference, security context, availability, parameters/returns, event order/yield behavior, limits, replication, and known caveats. Search official Roblox updates/release notes and announcements for relevant recent changes. The release feed can distinguish introduced, pending, and live changes; a feature being introduced does not necessarily mean it is available to every creator.

For third-party tooling, verify the installed version and upstream changelog. Pin versions in the repository's toolchain manifest where possible. Avoid upgrading tools during an unrelated feature task; make upgrades isolated and reproducible.

Recheck triggers:
- new API/member or engine feature;
- deprecation or beta-to-release change;
- Roblox Studio update affecting the API;
- tool/plugin/MCP version bump;
- changed permission, asset ownership, or policy requirements;
- bug report or unexpected test output;
- release candidate or production incident.

Record the version/build observed and the source date. Never infer availability from the date a forum post was published alone.
