# V7 Content Catalog Governance

## Catalog shape
Each catalog entry should have stable ID, kind, schema version, display/localization keys, references, numeric bounds, availability state, and owner. Keep display labels separate from identifiers.

## Cross-catalog checks
Validate referenced item/quest/level/asset IDs exist, enums are recognized, IDs are unique, numeric values are bounded, localization keys exist, and assets have provenance/permission records.

## Versioning
Use semantic catalog versions or explicit schema versions. Existing player saves may reference retired IDs; define compatibility aliases, tombstones, or migration behavior. Do not reuse a retired ID for a different meaning.

## Runtime policy
Only server-approved definitions affect durable progression, reward calculations, and purchases. Client display copies are non-authoritative. Decide whether a catalog is immutable for a session or refreshed through a versioned process.

## Content review
Check readability, accessibility, cultural/context suitability, asset provenance, performance footprint, and removal/rollback behavior.
