# Error Handling and Diagnostics

## Error categories
Separate expected user outcomes (invalid interaction, cooldown, insufficient balance) from operational failures (DataStore failure, missing asset, unexpected nil, invalid configuration) and programmer defects.

## User-facing behavior
- Use concise messages that explain what happened and what the player can do next.
- Do not expose stack traces, internal names or sensitive details to players.
- Never show a success message before the authoritative operation succeeds.
- Distinguish retryable from permanent errors.

## Developer diagnostics
- Include useful system and operation context.
- Avoid logging credentials, tokens, private user data or excessive per-frame noise.
- Rate-limit repeated diagnostics when a failing loop might spam output.
- Keep errors actionable and avoid catch-all suppression.

## Failure injection
Test missing assets, malformed payloads, unavailable services, timeout/retry, player departure during async work, and shutdown during saving. Ensure the system does not leave partial or contradictory state.
