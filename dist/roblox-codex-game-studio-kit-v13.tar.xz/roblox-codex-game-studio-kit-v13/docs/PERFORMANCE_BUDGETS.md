# Performance Budgets and Profiling

Set budgets based on the target device classes and actual game scale. Do not copy arbitrary limits without measuring.

## Dimensions to monitor
- client frame time and frame pacing;
- server script and heartbeat work;
- memory and instance count;
- rendering cost, lighting and effects;
- physics assemblies and collisions;
- replication/network traffic;
- initial load time and streamed content;
- NPC/pathfinding work;
- UI update and input responsiveness.

## Workflow
1. Establish a representative baseline scene/session.
2. Define target devices and a measurable budget for each important dimension.
3. Profile before changing code.
4. Identify the highest-cost path using engine tools/available profiler.
5. Make one focused change.
6. Re-run the same scenario and compare.
7. Test visual/gameplay quality to ensure the optimization did not break behavior.
8. Record measurement environment and before/after evidence.

## Common pitfalls
- per-frame scans over all instances;
- unnecessary remote traffic and replication;
- large initial replicated asset sets;
- excessive physics/collision complexity;
- too many simultaneously active NPCs/effects;
- repeated path computations;
- long blocking initialization;
- UI rebuilding everything for every state change.

Prefer event-driven updates, streaming where appropriate, bounded work and profiling-guided changes. Do not optimize solely from intuition.
