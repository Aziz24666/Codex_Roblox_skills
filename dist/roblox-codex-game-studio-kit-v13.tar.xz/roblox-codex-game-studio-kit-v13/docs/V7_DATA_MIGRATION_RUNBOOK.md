# V7 Data Migration Runbook

## Preparation
Define owner, affected store/key namespace, old/new versions, population estimate, data invariants, and approved environment. Inspect actual stored shapes using a safe non-production source.

## Pure migration
Write `migrate(oldRecord) -> newRecord` as a deterministic transformation. It should not perform network calls, write data, depend on current time, or mutate shared global state. Keep default creation separate from migration of existing records.

## Test cases
- Every supported historical version.
- Current version (idempotent no-op).
- Missing optional field and malformed required field.
- Oversized/unexpected values.
- Unknown future version (fail safe; do not overwrite).
- Repeated migration and concurrent update.

## Rollout
1. Dry-run and count eligible records.
2. Verify backup/export and recovery route.
3. Canary on synthetic/staging data.
4. Use bounded batches, checkpointing, rate control, and a stop threshold.
5. Verify invariants and sample records after each batch.
6. Expand only after approval and evidence.
7. Keep a forward repair plan if rollback is not safely reversible.

## Production protection
Never point Studio tests at production data. Never silently reset a player's data when a read fails. Explicitly separate test credentials/store names from production. Require user approval for production writes, backfills, resets, and schema migrations.
