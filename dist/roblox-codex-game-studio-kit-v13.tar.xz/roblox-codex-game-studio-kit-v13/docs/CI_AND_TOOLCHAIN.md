# CI, Tools and File-Based Workflows

## Identify before installing
Check whether the project already uses Rojo, Rokit, Wally, Lune, Selene, StyLua, Luau LSP, test frameworks or CI. Read lockfiles/config first. Verify installed versions and commands using actual tool output.

## Rojo
Rojo is a community-maintained file-system-first workflow that synchronizes files with a Studio plugin and can build place/model files. It is optional, not required for every Roblox project. Preserve Studio-native and partially managed workflows where appropriate. Pin the tool/plugin versions as a team and inspect project mappings carefully to avoid replacing artist-owned content.

## Toolchain discipline
- Prefer local project pins to global upgrades.
- Do not update multiple tools at once without a reason.
- Verify official source and release before installing.
- Run help/version output before assuming command flags.
- Keep dependency manifests and lockfiles in sync.
- Do not download/run unknown binaries.

## Suggested checks (only if configured/available)
- format check;
- lint;
- Luau type analysis;
- Rojo project validation/build;
- unit tests;
- CI pipeline;
- Studio runtime tests.

## File mapping
Inspect `$path`, `$className`, aliases, ignore behavior and service mappings. Test builds to a local output path before connecting Studio or publishing. Never assume a build output proves the place runs correctly.

## CI safety
CI should not contain live credentials in logs or repository files. Use least privilege and protected secrets for authorized workflows. Publishing from CI must be opt-in and protected by an explicit release process.
