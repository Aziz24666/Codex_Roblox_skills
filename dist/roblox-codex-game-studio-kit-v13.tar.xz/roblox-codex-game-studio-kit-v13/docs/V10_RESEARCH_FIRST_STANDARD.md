# V10 Research-First Engineering Standard

## Purpose
Roblox APIs, Studio features, workflows, and platform constraints evolve. A technically plausible answer based on memory can still be deprecated, incorrectly scoped, or inferior to a newer supported workflow. V10 therefore makes fresh research a precondition to implementation.

## When research is mandatory
Research before any non-trivial change involving Roblox engine APIs, Luau patterns, plugin APIs, Studio MCP, input/UI, animation, physics, networking, persistence, packages/assets, performance, tests, releases, policy, or external tooling. Research also precedes architecture changes that determine source of truth, state ownership, module boundaries, or data format.

## Required source sequence
1. Current Creator Hub guide for the feature area.
2. Exact API reference pages for classes and members being used.
3. Current updates/release notes and official announcements for rollout/deprecation context.
4. Upstream documentation for any external tool/library.
5. One or more reputable independent sources to discover trade-offs and failure cases.

Use exact pages, not search snippets. For API claims, official docs win. If a current official announcement conflicts with an older docs page, record the discrepancy and test an isolated minimal example; do not silently choose one.

## Research record checklist
A valid decision record contains:
- task and affected files/systems;
- date and search queries;
- at least one current official Roblox source and a second distinct source domain when credible sources exist;
- title, URL, domain, source kind, accessed date, and the claim supported by each source;
- API classes/members, execution/security context, beta/deprecation/availability notes;
- at least two viable options for meaningful architectural or tooling choices;
- chosen approach and concise evidence-based rationale;
- assumptions not yet verified, prototype plan, acceptance criteria, and recheck triggers.

## What does best mean?

Best means the least complex stable approach that meets the actual project needs and preserves a clear source of truth, ownership, security, testability, performance, and human readability. Do not choose a new or beta API merely because it is newer. Avoid introducing a third-party dependency when the native platform feature already solves the problem adequately; also avoid rebuilding complex infrastructure without comparing maintained options.

## No access to the web
If online research is unavailable, do not present a current/best-practice claim and do not proceed with an API-sensitive implementation. Mark the task `BLOCKED — RESEARCH NOT VERIFIED`, list the APIs/decisions that need verification, and ask for web access or provide a non-implementation plan only.

## Re-research
Freshly re-open docs for every new task that touches the API/approach, even if a research record exists. Recheck when Roblox releases a relevant update, an API enters/leaves beta, a tool version changes, a bug is reported, or test evidence contradicts the record.
