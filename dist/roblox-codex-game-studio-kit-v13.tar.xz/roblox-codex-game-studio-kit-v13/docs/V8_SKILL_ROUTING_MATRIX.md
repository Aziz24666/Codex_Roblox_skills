# V8 Skill Routing Matrix

| Task | Load these first | Add only when needed |
|---|---|---|
| Refactor repeated systems | `roblox-data-driven-architecture`, `roblox-module-boundary-design`, `roblox-maintainable-luau` | subsystem-specific skill, QA |
| Shared NPC movement/AI | `roblox-data-driven-npc-runtime`, `roblox-component-system`, `roblox-config-schema-engineering` | NPC AI, pathfinding/performance, Studio QA |
| Build Studio editor | `roblox-studio-editor-automation`, `roblox-plugin-tooling`, `roblox-config-authoring-validation` | content factory, plugin safety, UI/UX |
| Generate prefabs | `roblox-content-factory`, `roblox-prefab-governance`, `roblox-config-schema-engineering` | asset pipeline, Studio QA |
| Human code cleanup | `roblox-maintainable-luau`, `roblox-module-boundary-design`, `roblox-human-readable-architecture` | Luau code review, testing |

Start with the smallest relevant set. Read a deep reference only when the task needs it.
