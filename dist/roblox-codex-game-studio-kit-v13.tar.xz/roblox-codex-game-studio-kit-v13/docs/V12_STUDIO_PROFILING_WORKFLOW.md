# V12 Studio Profiling Workflow

1. Discover connected Studio/MCP sessions and list the operations actually available.
2. Identify the exact place and build. Obtain confirmation before any write-capable action on a non-disposable target.
3. Establish a baseline scenario and capture configuration.
4. Start playtest with the minimum required clients; use more clients only for the test question.
5. Capture logs, profiler evidence, frame/memory observations, and the result of the scenario.
6. Stop playtest and verify the environment returned to the expected edit state.
7. Preserve evidence in the project without secrets or sensitive player data.
8. If Studio MCP is unavailable, report the exact missing capability and use only source/CLI checks that genuinely work.

Do not call Plugin Security-only APIs from ordinary game code. For ScriptProfilerService, confirm the current API's permissions and the context in which the action is being executed.
