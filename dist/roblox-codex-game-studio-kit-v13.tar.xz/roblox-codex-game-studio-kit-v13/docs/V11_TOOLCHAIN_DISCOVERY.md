# V11 Toolchain Discovery

Before proposing installs or edits, inspect what's already available: Git, Rojo, Roblox Studio, Studio MCP, Luau CLI/analyzer, StyLua, Selene, package managers, test runners, CI provider, and project-specific scripts. Query versions safely and do not install or upgrade automatically.

Choose the smallest toolchain that supports the project's source-of-truth workflow. Verify installation and compatibility from upstream docs. Pin versions where practical. Avoid adopting tools merely because they appear in a template. Record unavailable tools and adjust the verification plan honestly.
