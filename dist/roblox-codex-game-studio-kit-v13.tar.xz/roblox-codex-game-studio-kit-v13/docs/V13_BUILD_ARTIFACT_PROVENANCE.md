# V13 Build Artifact Provenance

Every managed build should be attributable to its source and toolchain.

Record:
- repository commit and dirty/clean state;
- source-of-truth workflow profile;
- project file and selected place mapping;
- exact Rojo/tool versions;
- build command and exit status;
- artifact relative path, size, SHA-256;
- build environment/OS and timestamp in the external run report (not in deterministic file-content manifest);
- logs and limitations.

Use `tools/v13_artifact_manifest.py` to produce a stable file list and SHA-256 manifest. Use `verify` to detect missing, extra, or altered files. This proves file identity only; it does not prove the artifact is a valid Roblox place or behaviorally correct.

For identical-source reproducibility, compare two independent builds with compatible toolchains. If outputs differ, inspect timestamps, generated IDs, source mapping, asset serialization, and tool versions before deciding whether the difference is expected.
