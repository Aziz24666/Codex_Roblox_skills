# V12 Maintenance and Research Refresh

Review API-sensitive documentation before each substantive implementation. For framework maintenance, schedule a periodic review of:
- Creator Hub changes to profiling and MicroProfiler tools.
- Streaming API/property guidance and model behavior.
- CollectionService API deprecations and lifecycle semantics.
- AnalyticsService custom event caps, delivery rules, and privacy controls.
- Luau type checker/tooling and Studio Script Analysis changes.
- Studio MCP capabilities, client connection workflow, and permissions.
- OpenAI/Codex skill metadata and progressive-disclosure guidance.

Update the research snapshot only after checking sources. Keep old decisions as history; do not silently rewrite their access dates or make stale sources appear current.
