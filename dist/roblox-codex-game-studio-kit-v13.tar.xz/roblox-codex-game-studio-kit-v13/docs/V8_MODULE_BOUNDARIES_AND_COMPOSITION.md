# V8 — Module Boundaries and Composition

## Module contract template
Every reusable ModuleScript should answer:
- Purpose and non-goals.
- Execution context: server, client, or shared pure code.
- Owner and lifecycle.
- Public types and methods.
- Dependencies and allowed dependency direction.
- Inputs/outputs and failure behavior.
- Mutable state ownership.
- Test seam and diagnostics.

## Suggested dependency direction

```text
Bootstrap / Composition Root
  ├── Config Registry + Validator
  ├── Component Registry
  │    ├── NPC Controller
  │    │    ├── Movement Controller
  │    │    ├── Behavior Registry -> Behavior modules
  │    │    └── Presentation Adapter
  │    └── Interactable Controller
  └── Diagnostics / Metrics
```

Definitions must not require runtime services. Pure utilities must not require Workspace. Presentation should not decide durable game outcomes. Bootstrap is the only place that assembles high-level dependencies.

## Anti-patterns
- One 1,000-line `GameManager` handling NPCs, UI, data, input, and effects.
- A copy of `NPCBrain.server.lua` under every NPC model.
- A `Config` module that also starts loops and manipulates Workspace when required.
- Circular `require` dependencies.
- Generic `Utils` modules with unrelated functions.
- A giant `any` config table whose keys are guessed at runtime.
- Shared mutable config tables used as per-NPC state.

## Practical size guideline
Split when a module has multiple unrelated reasons to change, unclear ownership, or several consumers needing different slices. Do not split merely to reach an arbitrary line count.
