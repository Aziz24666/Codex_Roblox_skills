# V10 Security Threat Model

For each feature, document assets/state at risk, attacker-controlled inputs, server authority, access controls, and abuse cases.

## Required questions
- Can a client fabricate, replay, reorder, or spam this request?
- Can the client request an impossible target, asset, path, or operation?
- Are values bounded and finite? Are strings/table sizes capped?
- Is ownership, proximity, life state, round state, and resource cost checked on the server?
- Can network ownership or client physics bypass a check?
- Are rewards and durable writes idempotent under retries and concurrency?
- Can a remote trigger unbounded work or fan-out?
- Can dynamic asset loading or `require` execute untrusted content?
- Is there a rate limit and useful telemetry?

Treat every client value as untrusted. Client-side checks are UX, not authority. Minimize remote surface area; keep remote contracts typed and bounded. Test negative cases and abuse scenarios. Re-read current Creator Hub security docs before implementation because platform guidance and limits can change.
