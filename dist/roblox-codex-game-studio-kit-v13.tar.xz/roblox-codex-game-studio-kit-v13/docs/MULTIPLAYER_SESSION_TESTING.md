# Multiplayer Session Testing


# Multiplayer and Session Testing

## Why multiplayer needs separate tests

Roblox runs separate server and client simulations. A solo playtest does not prove two players see consistent state, that simultaneous requests are resolved correctly, or that disconnects are safe.

## Scenario matrix

| Scenario | What to verify |
|---|---|
| Two clients join together | Spawn, initialization, ownership and replicated state |
| Late join | Correct current round/world state without replaying invalid effects |
| Simultaneous interaction | One authoritative resolution; no duplicate reward/state |
| One player disconnects | Cleanup, ownership transfer, round/trade handling |
| Respawn during action | No stale character or orphaned task |
| Server shutdown | Best-effort save and clean session release |
| High latency/jitter | Timeouts, pending states and reconciliation |
| Temporary packet loss | No permanent UI lock or incorrect assumed success |
| Multiple NPCs/players | Server work remains bounded |

## Studio modes

Use Server & Clients to observe multiple clients and a server. Use network simulation when timing and unreliable event behavior matter. Use device simulation for device layouts and input. Record client count and simulation settings in the test report.

## Race-condition review

Identify operations that can overlap: purchase grants, inventory changes, trading-like transfers if present, objective completion, round ending, checkpoint updates, and profile saves. Use explicit state machines, idempotency keys, ownership checks, and server sequencing where appropriate. Do not rely on task scheduling order unless it is guaranteed by the chosen design.

## Test isolation

Use separate test experiences or isolated test keys. Never point experimental Studio sessions at live player data. Make destructive test fixtures resettable without touching real records.
