# V13 Test Harness and Fixtures

## Test pyramid
1. Pure functions and schema validators: fast, deterministic, no Roblox engine.
2. Module/service tests: mock only external dependencies; test contracts and error cases.
3. Studio integration tests: DataModel, physics, UI, remotes, streaming and lifecycle behavior.
4. Multiplayer/device tests: interactions that require clients, network simulation, touch/gamepad, or device profiles.
5. Published validation: only where behavior depends on published-only services; isolate non-production environments.

## Fixture rules
- Every test owns the data it creates and cleans it in teardown/finally paths.
- No test may use production DataStores, live players, public asset publishing or external spend.
- Use deterministic seeds for procedural fixtures; record the seed.
- Use fake clocks/random sources for time- and randomness-sensitive logic when feasible.
- Keep fixtures small and representative; avoid giant shared fixture objects.
- Add tests for rejection paths, retries, duplicate requests, disconnects and partial initialization.

## Studio-specific automation
StudioTestService is a Studio-only plugin capability. Use it only after checking current permissions/API. It can drive Play/Run and multiplayer simulation; it does not replace real physical-device testing or published-service testing.

## Evidence
For each run record test ID, commit/build hash, runner/tool/Studio version, mode, clients, seed, expected/actual result, logs, status and cleanup confirmation.
