# Failure Recovery And Incidents



## Failure categories

Classify failures as player input, client presentation, server logic, network, external Roblox service, persistence, asset availability, configuration, or deployment. Capture enough context to reproduce without exposing credentials or sensitive player data.

## Recovery principles

- Fail closed for permissions and consequential actions.
- Prefer a clear recoverable error over silent corruption.
- Do not replace unknown or unloaded saved data with defaults and save over it.
- Make retries bounded, ordered where necessary, and limited to transient errors.
- Use idempotency for rewards, purchase grants, and operations that may be repeated.
- Provide a fallback experience when optional content or telemetry is unavailable.

## Incident checklist

1. Identify player impact and scope.
2. Stop risky changes and preserve relevant logs.
3. Reproduce safely with test data.
4. Identify the last known good version and recent changes.
5. Choose a reversible mitigation.
6. Request approval before production changes or data operations.
7. Verify the mitigation with evidence.
8. Document root cause, timeline, impact, recovery, and prevention work.

## Data incident caution

Never “fix” a production data issue by wiping keys, applying a speculative migration, or mass-writing defaults. Prepare a read-only diagnosis and proposed recovery plan first. Production restore or migration requires explicit approval and a verified backup/recovery strategy.
