# Api And Dependency Verification



## API verification

Before using an unfamiliar or recently changed Roblox API:
1. Search current official Creator Hub documentation.
2. Confirm class/member name, parameter types, return values, security tags/capabilities, thread-safety/yield behavior, and service availability.
3. Inspect Studio autocomplete or Script Analysis where available.
4. Build the smallest local proof in an isolated place if behavior is unclear.
5. Record source URL and verification date for material decisions.

Do not copy signatures from stale examples or assume an API exists because another engine uses it.

## Dependency intake

For every library/plugin/tool record source, owner, release/version, license, maintenance state, install path, transitive dependencies, and why the project needs it. Prefer project-local pinning. Inspect code and permissions before trusting it.

## Update policy

Do not upgrade dependencies as incidental cleanup. Change one controlled dependency at a time, review the changelog and breaking changes, run the complete relevant test set, and document rollback. Do not silently use floating latest versions in reproducible build workflows.

## Toolchain reproducibility

Record the exact commands and tool versions used for formatting, linting, type checks, Rojo build, tests, and packaging. If a tool is missing, say so rather than inventing a result.
