# Feature Vertical Slice Playbook



A vertical slice connects every layer needed for one real player outcome. Do not interpret “vertical slice” as a thin prototype with fake server behavior.

## Feature brief

Record: player problem, desired outcome, entry point, controls, feedback, valid/invalid states, dependencies, data changes, permissions, target devices, accessibility, exclusions, and acceptance criteria.

## Design artifacts

- State model: states, transitions, owners, timeout and cancel behavior.
- Server contract: request, validation, state mutation, response, rate limit.
- Client contract: input, local feedback, pending state, reconciliation.
- Data contract: persistent or temporary state, version, migration and recovery.
- World/UI contract: interaction point, navigation, loading and error states.
- Lifecycle contract: join, leave, death, respawn, character replacement, round transition, shutdown.

## Implementation order

1. Add pure rules/data types.
2. Add server-owned state transition.
3. Add narrow remote or server-side interaction entry point.
4. Add client input and pending/confirmed feedback.
5. Add world and UI presentation.
6. Add persistence only if the feature must survive sessions.
7. Add cleanup and failure behavior.
8. Add tests and documentation.

## Acceptance evidence

For every criterion, state exact test case and result. Include at least one normal path, one rejected/invalid path, one interruption path, and a regression path. Add multi-client tests if ownership, visibility, or simultaneous use is relevant.

## Slice exit gate

The slice is accepted only when it can be entered, understood, completed, interrupted, retried, and exited without incorrect state or misleading feedback. Remove fake data and temporary shortcuts before marking the slice done.
