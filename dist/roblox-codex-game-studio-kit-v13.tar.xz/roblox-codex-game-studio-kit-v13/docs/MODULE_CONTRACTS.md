# Module and System Contracts

A contract defines how systems interact without requiring callers to know implementation details.

## Required module contract
- **Name / responsibility:** one sentence.
- **Owner:** server, client or shared.
- **Initialization:** constructor or bootstrap entry and required dependencies.
- **Public functions:** arguments, return types, expected side effects.
- **Events:** names, payloads, ordering assumptions and cleanup.
- **State:** authoritative fields and who mutates them.
- **Errors:** expected failure modes and caller behavior.
- **Lifecycle:** create, start, stop, destroy and player/character scope.
- **Tests:** isolated logic and runtime integration checks.

## Design rules
- Keep modules cohesive; separate unrelated responsibilities.
- Make initialization order explicit. Do not rely on child ordering or incidental require side effects.
- Avoid global mutable state and cyclic dependencies.
- Use stable IDs for gameplay entities; do not depend on names where names can change.
- Avoid passing broad Instance references from clients when a server-resolved identifier is safer.
- Keep remote payloads versionable and narrow.
- Keep configuration distinct from live mutable state.

## Integration sequence
1. Agree on contract.
2. Implement provider with tests.
3. Implement consumer against the contract.
4. Integrate in bootstrap.
5. Add end-to-end test.
6. Remove temporary stubs and document lifecycle.

A stub may exist temporarily during parallel work, but it must be clearly labeled, not mistaken for a finished feature, and removed before milestone completion.
