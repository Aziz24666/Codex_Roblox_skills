# V5 Economy and Transaction Integrity

## Economy definition
For each currency/item record stable ID, sources, sinks, earning rate, cap/overflow, tradeability, ownership, persistence schema, and test scenarios. Simulate inflation, progression stalls, unreachable costs, and dominant strategies.

## Transaction state
Use explicit states such as `Pending → Validated → Applied → Recorded`, plus failure/recovery states. Each operation has a stable unique ID and duplicate delivery must be harmless.

## Developer product fulfillment
- Verify the current official MarketplaceService receipt API before implementation.
- Use one clearly owned server-side receipt processing path appropriate to the current API.
- Validate player/product/receipt identity and supported state.
- Grant exactly once and persist fulfillment evidence before acknowledging success.
- Handle duplicate/concurrent callbacks and unknown write outcomes.
- Follow documented platform return/retry semantics when fulfillment cannot complete safely.
- Never grant from a client prompt closing or LocalScript success report.
- Test with isolated development products and non-production data.

## Player trust
Clearly disclose cost, contents, and limits. Do not use gambling, misleading odds, fake scarcity, deceptive buttons, hidden fees, coercive timers, or paid random reward mechanics. Optional purchases must not undermine basic usability or fair play.

Test unknown product, missing player, unavailable data service, duplicate receipt, concurrency, shutdown, full inventory/cap, and uncertain write/grant outcome. Do not spend Robux or publish without approval.
