# V11 to V12 Skill Routing

| Request | Route |
|---|---|
| Diagnose stutter or server/client CPU | `$roblox-runtime-performance-profiling` + `$roblox-performance-benchmarking` |
| Large map, stream-in/out, or missing client objects | `$roblox-instance-streaming-readiness` + `$roblox-data-driven-architecture` |
| Reusable tagged object behavior | `$roblox-tagged-component-lifecycle` + `$roblox-component-system` |
| Memory increases during a long session | `$roblox-memory-and-resource-lifecycle` + `$roblox-defect-isolation` |
| Set/validate performance limits | `$roblox-performance-budget-governance` |
| Add AnalyticsService custom events | `$roblox-analytics-event-governance` + `$roblox-analytics-liveops` |
| Slow join or content loading | `$roblox-content-loading-optimization` + `$roblox-technical-art` |
| Verify low/mid/high devices | `$roblox-device-tier-validation` + `$roblox-accessibility-device` |
| Prevent performance regressions | `$roblox-performance-regression-testing` + `$roblox-ci-reproducibility` |
| Add diagnostics/telemetry | `$roblox-runtime-observability` |

Load the minimum relevant references. Do not read every V12 document for an unrelated feature.
