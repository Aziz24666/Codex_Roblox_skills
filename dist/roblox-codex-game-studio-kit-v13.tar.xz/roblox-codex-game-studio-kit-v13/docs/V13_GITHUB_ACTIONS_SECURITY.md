# V13 GitHub Actions Security

## Pull-request workflow defaults
- Use `pull_request` for untrusted contributions where possible.
- Set top-level `permissions: contents: read`; elevate only the specific job that needs more.
- Pin third-party actions to full 40-character commit SHAs from the action's official repository; keep the release version as a comment.
- Set `persist-credentials: false` for checkout jobs that do not need Git credentials.
- Do not expose Open Cloud keys or publishing credentials to PR jobs.
- Do not use `pull_request_target` to check out and execute untrusted PR code. Avoid `workflow_run` privilege escalation patterns.
- Avoid interpolating untrusted PR title/body/branch text directly into shell scripts. Pass values through environment variables and validate them.
- Upload only reviewed artifacts. Treat artifacts from untrusted runs as untrusted input.

## Deployment separation
Production jobs must be in a separate workflow or gated job with protected environment approvals, least-privilege credentials, explicit target universe/place, source revision, release candidate evidence, and rollback plan. The V13 sample CI workflow does not publish.

## Audit limits
The included scanner is heuristic. It flags common risky patterns; it is not CodeQL, an OpenSSF Scorecard, or a full workflow security review.
