# Remote Contract Registry

Maintain a registry for every RemoteEvent and RemoteFunction. A remote is a public boundary between untrusted client data and server behavior.

## Contract template
| Field | Required detail |
|---|---|
| Name | Stable, descriptive action name |
| Direction | Client→server, server→client or server broadcast |
| Purpose | One sentence describing the intent |
| Payload | Typed fields, value limits and expected shape |
| Validation | All server checks and ownership rules |
| Rate | Burst/window or cooldown policy; server enforced |
| State changed | Exact authoritative fields changed |
| Response | Result, event or replicated state |
| Failure | Invalid, stale, unauthorized, cooldown and operational cases |
| Tests | Normal, malformed, spam, concurrency, leave/respawn |

## Contract design
- Prefer one semantic action per remote over a generic command bus.
- Do not let the client specify arbitrary instance paths, code/module IDs, reward totals or unrestricted property values.
- Validate instance arguments by class, parent/ancestor and expected registry membership.
- Bound strings, arrays, tables and numerical ranges.
- Use stable identifiers that the server resolves to known objects/configuration.
- Use server rate limiting even if the UI has a local cooldown.
- Avoid RemoteFunctions for work that can hang or block in ways the UI cannot handle gracefully; choose the interaction pattern deliberately.

## Test cases
Test a valid request, missing fields, wrong types, huge payload, unexpected instance, out-of-range value, invalid state, repeated request, simultaneous request, request after respawn and request after leaving. Confirm no unauthorized state changes occur.
