# V9 — Editor and Factory Test Matrix

| Area | Positive cases | Negative/boundary cases | Evidence |
|---|---|---|---|
| Schema catalog | all family entries load | duplicate family ID, unknown control kind, conflicting paths | catalog lint output |
| Form renderer | all control kinds render | empty/long labels, compact width, enum with invalid current value | Studio screenshots/test notes |
| Number fields | valid min/mid/max | below min, above max, NaN, infinity, nonnumeric | form behavior + validator result |
| Asset fields | blank optional, valid-form reference | malformed string, wrong asset kind, asset that fails to load | status must distinguish format from load/permission |
| Preview | source clone/proxy visible | no selected source, unarchivable source, missing camera | Studio test evidence |
| Dry run | expected hierarchy plan | stale preview, collision, missing template | preview report |
| Generation | NPC + companion + prop examples | duplicate definition/prefab, invalid source | output hierarchy and report |
| Transaction | successful commit | begin-recording failure, injected generator error | Studio Undo/Redo results |
| Provenance | metadata complete | missing required version field | generated manifest lint |
| Governance | no drift, side-by-side candidate | modified/user-owned descendants | diff report; no silent overwrite |
| Human extension | new field appears from schema only | requires family UI copy | code review and test fixture |

## Test statuses
Use only `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, and `NOT APPLICABLE`. Static checks in this package are package-level checks. Studio runtime rows remain `NOT RUN` until executed in Studio.
