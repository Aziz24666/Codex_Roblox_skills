# Security Review Checklist

## Inventory
Enumerate all client-originated inputs: remotes, prompts, click/drag detectors, touch events, tool activation, client-owned physics, chat-triggered actions and any plugin/HTTP integration that affects the experience.

## Review each path
- What can the player cause the server to do?
- What is the maximum impact if the request is repeated rapidly?
- Does the server validate type, bounds, state, permission and distance?
- Is the referenced object known and in the expected hierarchy?
- Can the request choose arbitrary paths, IDs, modules, assets or property names?
- Can physics ownership move the object and bypass assumptions?
- Can concurrent calls double-grant, double-spend or duplicate an item?
- Is rate-limit state cleaned up?
- Are errors and logs safe?

## Data and asset safety
- No secrets in replicated containers or source control.
- No client-driven dynamic `require` or arbitrary code loading.
- No hidden backdoors or admin paths.
- Production data is not used for experiments.
- Asset uploads and live changes require authorization.

## Findings
Classify as Critical / High / Medium / Low / Note. For each finding include affected path, exploit preconditions, player impact, root cause, remediation and regression test. A security audit is incomplete if important client-triggerable paths were not inspected.
