# V5 Content Pipeline and Asset Provenance

Record every non-trivial asset with internal ID, type, source, creator/owner, license/permission evidence, permitted use, edit history, dependencies, file/hash, import settings, budget, fallback, and approval status.

## Intake
1. Define why the asset is needed and consider an original alternative.
2. Confirm permission to use, modify, and distribute in the intended context.
3. Inspect models for scripts, unexpected descendants, external references, heavy meshes, hidden parts, and unwanted behavior.
4. Check media dimensions/duration/compression and platform constraints.
5. Normalize names, pivots, scale, collision, materials, metadata.
6. Test import in an isolated place/project copy.
7. Record final asset ID and fallback.

Use semantic catalog IDs. Never load or execute arbitrary client-supplied asset IDs/module paths. Define per-level/session budgets and measure them in Studio/device profiles. File existence is not proof of permission; asset register fields are not legal verification.
