# V10 DataStore Reliability

Do not design persistent data from memory. Re-read current Creator Hub DataStore documentation for request budgets, payload limits, retries, UpdateAsync behavior, key/version constraints, and any new migration tooling.

## Design checklist
- Define data ownership, key format, schema version, defaults, and migration path.
- Keep data that must change atomically together when possible.
- Prefer a small, fixed set of stores and stable keys; split only for justified access/size/throughput boundaries.
- Buffer player profile state in server memory; do not write on every tiny gameplay mutation.
- Use UpdateAsync when a write depends on current state or concurrent writers may exist; use SetAsync only when replace semantics are correct.
- Retry transient errors with bounded exponential backoff and jitter; do not retry permanent/invalid requests.
- Serialize writes per key to avoid older retries overwriting newer values.
- Account for unknown write outcomes, duplicate actions, server shutdown, disconnect, and session ownership.
- Test in isolated test stores/place IDs; never let Studio tests touch live data.
- Keep migration code idempotent, observable, and recoverable. Document irreversible steps.
