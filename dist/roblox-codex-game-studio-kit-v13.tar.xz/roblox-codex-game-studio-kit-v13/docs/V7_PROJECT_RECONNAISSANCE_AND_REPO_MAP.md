# V7 Project Reconnaissance and Repository Map

## Goal
Understand the project as it exists before editing or moving files.

## Inspection checklist
- Git branch, status, diff, ignored files, untracked files, and recent commit context.
- Root/nested `AGENTS.md`, README, design docs, decisions, issue notes, and active task board.
- Project source-of-truth: Studio-native, Rojo-managed, partially managed, Script Sync, mixed, or unknown.
- Project mappings, place/universe manifests, package manifests, tool versions, lockfiles, CI, tests, and generated artifacts.
- Runtime service tree, client/server/shared code, module entrypoints, remote surfaces, data stores, asset IDs, and external integrations.
- Test environments and whether any Studio DataStore or cloud integration points to production.

## Repository map deliverable
Create `docs/PROJECT_MAP.md` only when the project has enough complexity to benefit. Include high-level directory purpose, entrypoints, execution context, module owners, important data/remote contracts, build/test commands, and unresolved unknowns.

## Dependency model
Start from actual `require` sites, project mappings, remote names, data contracts, and asset references. Mark heuristic discoveries as `UNVERIFIED`; do not convert text search into a definitive dependency graph. Resolve dynamic requires or reflection manually.

## Preservation
Do not reformat or move unrelated files. Before large changes, record the baseline diff. Keep generated output outside source directories where practical. Never delete unfamiliar files simply because they look generated.

## Exit criteria
The agent can identify how the project becomes a place file, where client/server code runs, how tests are launched, and which facts remain unknown.
