# V11 Roblox Studio MCP and Open Cloud

## Discovery first
Read the current official Studio MCP and Open Cloud permission docs. Discover connected Studio instances and ask which target to use if ambiguous. Record the Studio session identifier and place context before writing.

## Capability use
Use Studio MCP for appropriate DataModel inspection, script reads/edits, Luau execution, asset/editor workflows, and Studio playtests only when the corresponding tool is actually exposed. Use the current tool schema; names and capabilities can change.

## Write safety
- Read target state before editing.
- Use narrow edits and inspect the resulting diff.
- Keep source-control/source-of-truth synchronization consistent.
- Run tests in a disposable place when possible.
- Do not assume saving a local place is publishing.
- Never perform production mutations, public uploads, purchases, publishing, or permission escalation without explicit authorization.

## Open Cloud
Open Cloud access through MCP is permission-scoped per game. Verify scopes and operation risk; request only the minimum required capability. Treat full-access permissions as high risk. Do not request or handle credentials when Studio-managed permissions are available.

## Reporting
State which Studio session and capabilities were actually connected, what operations succeeded, and what was not available.
