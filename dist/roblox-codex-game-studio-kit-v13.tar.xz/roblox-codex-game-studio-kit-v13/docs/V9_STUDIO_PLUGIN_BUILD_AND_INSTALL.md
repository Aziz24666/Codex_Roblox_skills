# V9 — Studio Plugin Build and Install

## Source layout
The plugin is modular under `studio-plugin/src/`. `init.server.lua` is the entrypoint; sibling modules are required from `Modules/`. `default.project.json` describes the plugin model for a Rojo-capable workflow.

## Build path
1. Install/verify a current Rojo version separately; the package does not bundle it.
2. From `studio-plugin/`, run `rojo build default.project.json -o V9SchemaStudioPlugin.rbxmx`.
3. Inspect the generated model hierarchy in a disposable place.
4. Install the resulting model as a local Studio plugin using Studio's documented local plugin workflow.
5. Restart/enable the plugin and open the `V9 Schema Studio` toolbar button.

If not using Rojo, create a plugin Script and a `Modules` Folder with one ModuleScript per file in `src/Modules/`; copy the source into matching children. Ensure the module names match the `require` calls.

## APIs used
- `plugin:CreateToolbar()` and toolbar button `Click` event.
- `plugin:CreateDockWidgetPluginGuiAsync()` with `DockWidgetPluginGuiInfo.new()` to create a dockable panel. The current Studio widgets guide documents the dock-widget workflow and widget parenting.
- `ChangeHistoryService:TryBeginRecording()` and `FinishRecording()` around changes; use Cancel on failure. The ChangeHistoryService docs explicitly say recording begins before DataModel mutation.
- `Selection:Get()` and `Selection:Set()` for source selection/output selection.
- `CollectionService:AddTag()` for runtime-discovery tags.

## Test in a disposable place
1. Open the widget; confirm tabs, labels, controls, scroll behavior, and errors.
2. Choose NPC; select an approved Model with Humanoid; change a speed value; validate; preview; generate.
3. Confirm the output Model, definition module, tags, attributes, and expected hierarchy.
4. Undo; verify both prefab and definition disappear. Redo; verify both return.
5. Repeat with a second NPC definition through the same schema/form/generator.
6. Choose Companion and generate from a compatible approved rig.
7. Choose Cosmetic and generate from a selected Accessory with a valid Handle.
8. Generate a World Prop and Interactive Prop with and without optional asset references.
9. Try malformed JSON, missing required fields, out-of-range numbers, invalid enums, invalid asset syntax, wrong selected source type, and duplicate IDs; each must be rejected without partial output.
10. Cause a controlled failure after the transaction starts and confirm cancellation.
11. Close/reopen the plugin and check that no generated objects were left in the preview UI or temporary folders.

## Limitations
This source package is not a signed/published plugin. The build container has no Roblox Studio or Luau compiler, so it does not claim plugin runtime, Luau compilation, preview rendering, undo/redo, or prefab-generation tests passed. Confirm API signatures against Creator Hub for the Studio version in use.
