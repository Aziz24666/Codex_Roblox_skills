# V5 Multiplayer, Party, Matchmaking, and Cross-Server Architecture

## Choose the right mechanism
- In-server state: server-owned memory for the active server.
- Durable cross-session data: DataStoreService.
- Temporary shared coordination: MemoryStoreService with expiry and bounded payloads.
- Cross-server notifications: MessagingService where appropriate; notifications are not the sole source of truth.
- Place/server handoff: TeleportService with failure and recovery behavior.

Verify current official API behavior and limits before implementation.

## Party model
Document party ID, leader, members, join/leave/invite permissions, capacity, privacy, ownership, expiry, and leader-disconnect behavior. Mutations are server-authorized and idempotent.

## Queue model
Define eligibility, match criteria, queue timestamp, timeout, cancellation, reservation ownership, expiry, and duplicate protection. Use stable IDs, schema versions, and bounded records. Never put durable profiles in expiring MemoryStore entries.

## Handoff
1. Validate all members and destination eligibility.
2. Create uniquely identified transfer record.
3. Reserve/select destination through current supported APIs.
4. Send minimum necessary transfer context.
5. Handle partial failure and prevent duplicate assignment.
6. Validate transfer context and authoritative record at destination.
7. Confirm arrival or use bounded retry/fallback.
8. Expire abandoned transfer records and clean ownership.

A successful request does not prove every client arrived.

## Failure matrix
| Failure | Required behavior |
|---|---|
| Leader leaves | Transfer leadership or dissolve under documented rules |
| Queue item expires | Remove safely; allow requeue |
| Duplicate notification | Idempotent handler and authoritative re-check |
| Destination unavailable | Bounded retry or safe lobby fallback |
| Partial party teleport | Reconcile arrived/missing members; avoid duplicate reward |
| Server shutdown | Release owned state where possible; expiry is fallback |
| Stale reservation | Expire and reacquire |
| Data service unavailable | Degrade safely; never fabricate durable success |

Test duplicate/delayed/out-of-order messages, party changes during queueing, shutdown, teleport failures, and late arrival in isolated test places/data.
