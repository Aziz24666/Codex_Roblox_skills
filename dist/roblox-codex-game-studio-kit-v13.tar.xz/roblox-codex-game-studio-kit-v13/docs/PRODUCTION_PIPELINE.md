# V5 Production Pipeline — 30 Dependency-Aware Evidence Gates

This is a dependency-aware path, not a rigid waterfall. Small tasks may skip irrelevant stages with a one-line reason, but not applicable security, data, ownership, verification, and approval gates.

| # | Stage | Work | Exit evidence |
|---:|---|---|---|
| 1 | Scope classification | New game, feature, defect, content, audit, performance, release | Task frame and player outcome |
| 2 | Repository reconnaissance | Source, assets, docs, Git, nested instructions | Audit and preserved baseline |
| 3 | Tool capability audit | Studio, Rojo, Script Sync, CLI, plugins | Capability matrix/source of truth |
| 4 | Product definition | Fantasy, audience, genre, loop, boundaries | Brief with assumptions |
| 5 | Player journey | Onboarding, first win, session arc, recovery | First-session map |
| 6 | Trust constraints | Devices, accessibility, privacy, social, content, purchases | Constraint register |
| 7 | Scope and risk | Dependencies, risks, critical path, WIP | Milestone graph |
| 8 | Architecture | DataModel, modules, execution context, ownership | Architecture/contracts |
| 9 | API/dependency provenance | APIs, packages, licenses, imports | Verified sources and versions |
| 10 | Data/state model | Schemas, transitions, migration, sessions | Data contract |
| 11 | Network/trust model | Remotes, bounds, permissions, rates | Threat model |
| 12 | Risk-first prototype | Test riskiest assumption | Spike decision |
| 13 | Core vertical slice | Full player action/result/feedback path | Acceptance evidence |
| 14 | Gameplay systems | Mechanics, state, rounds, rules | Integrated system tests |
| 15 | World/content | Layout, navigation, spawn, generation | Playable content slice |
| 16 | Character/input | Camera, physics, input parity | Input test matrix |
| 17 | UI/audio/feedback | HUD, menus, cues, accessibility | UX review |
| 18 | Economy/progression | Rewards, sinks, caps, fairness | Balance model/server rules |
| 19 | Genre integration | Sports, pets, farming, building, rhythm, party | Genre acceptance matrix |
| 20 | Social/cross-server | Parties, queues, teleport, moderation | Multi-client/failure evidence |
| 21 | Asset/content pipeline | Provenance, rights, imports, budgets | Asset register |
| 22 | Data lifecycle/recovery | Load/save, retries, idempotency, migration | Isolated data evidence |
| 23 | Accessibility/localization | Input, readable UI, translations, motion/audio | Device/locale matrix |
| 24 | Automated verification | Format, lint, type, unit, build, content checks | Actual command outputs |
| 25 | Studio runtime validation | Solo, client/server, multi-client, device/network | Studio report |
| 26 | Performance/scale | CPU, memory, network, rendering, startup | Profile and budget comparison |
| 27 | Balance/playtest | Difficulty, pacing, onboarding, fairness | Findings and decisions |
| 28 | Regression/code review | Diff, lifecycle, concurrency, edge cases | Resolved review findings |
| 29 | Release candidate gate | Privacy, policy, rights, rollback, data safety | Local candidate evidence |
| 30 | Handoff/operations | Status, known issues, observability, next steps | Truthful handoff/runbook |

## Gate rules
- Failed prerequisites block dependent work. Fix, reduce scope explicitly, or mark downstream work `BLOCKED`.
- Every stage has inputs, outputs, an owner, and evidence. No empty paperwork.
- `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, and `NOT APPLICABLE` are distinct.
- Ask before irreversible, costly, public, production, account, or permission-changing operations.

## Work sizing
XS: isolated copy/config; S: one module/UI flow; M: several modules or client/server feature; L: schema/remote/multi-system feature; XL: cross-place architecture or large migration. Break L/XL into testable slices.

## Critical path and WIP
Prioritize the tasks that unlock the next player-visible slice. Limit parallel work. Never parallel-edit root instructions, shared modules, schemas, project mappings, or remote contracts.

## Definition of done
Acceptance criteria pass; ownership and invalid-input behavior are reviewed; failure paths and cleanup are covered; relevant tests have real evidence; docs are current; unverified Studio/device/network behavior is disclosed.
