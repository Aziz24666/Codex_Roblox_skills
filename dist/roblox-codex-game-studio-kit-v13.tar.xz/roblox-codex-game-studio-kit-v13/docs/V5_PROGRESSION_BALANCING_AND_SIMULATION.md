# V5 Progression Balancing and Simulation

Represent progression as a graph of unlocks/gates. Record requirements, expected sessions, resource inputs, rewards, failure recovery, and alternate paths. Find dead ends, runaway loops, unreachable content, and excessive grind.

Build deterministic offline simulations with explicit assumptions for earning rates, session length, reward distributions, costs, caps, sinks, and player segments. Simulator output is not actual player telemetry. Compare scenarios and sensitivity, not one isolated result.

Ask: Can new players identify their next useful action? Is the first reward reachable? Do costs outpace expected earning? Does one activity dominate? Are timed systems fair to players with different schedules? Are optional purchases clearly separate? Can duplicate requests inflate the economy?

Playtest loop: hypothesis → controlled variable change → representative test → objective and qualitative notes separated → unintended strategies/accessibility review → keep/revert/follow-up. Avoid punitive loss, artificial urgency, gambling-like loops, and manipulative retention.
