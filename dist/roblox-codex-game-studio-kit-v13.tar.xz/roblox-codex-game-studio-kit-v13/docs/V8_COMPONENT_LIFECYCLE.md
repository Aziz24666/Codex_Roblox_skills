# V8 — Component Lifecycle

Each component follows a lifecycle: validate → attach → update/respond to events → detach. The component registry guarantees at most one live component per instance and component type.

## Required API shape

```luau
export type Component = {
    Destroy: (self: Component) -> (),
}

export type Context = {
    model: Model,
    definitionId: string,
}

-- Constructor validates all preconditions and returns a controller or a clear failure.
```

## Lifecycle rules
- `Attach` is idempotent or guarded by the registry.
- Resolve required descendants once and validate class/type; do not repeatedly search the entire model in hot paths.
- Every connection, task, path, temporary Instance, and callback has one cleanup owner.
- `Destroy` can be called more than once without throwing or double-releasing.
- A component must stop work when its model is removed or no longer valid.
- Use bounded retries. Do not leave a yielded task waiting forever for a deleted object.
- Separate server behavior from client presentation when both are needed.

## Registry rules
Use a weak-key table only where its collection semantics are appropriate and understood. Otherwise explicitly unregister on removal. Diagnostics should report attached component count and rejected definitions in development builds.
