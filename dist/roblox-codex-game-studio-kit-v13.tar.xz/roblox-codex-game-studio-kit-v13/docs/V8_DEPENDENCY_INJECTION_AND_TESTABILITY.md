# V8 — Dependency Injection and Testability

Inject collaborators when a system needs replacement or deterministic testing: route resolver, clock, random generator, asset resolver, path adapter, or logger. Prefer explicit constructor parameters over a global service locator.

Do not inject every Roblox service into every module. A small module may call a stable engine service directly if doing so keeps the code clearer and it is not a meaningful testing seam. Keep pure functions pure and engine adapters narrow.

Test boundaries include:
- Definition normalization without Workspace.
- Behavior transition decisions with a fake clock/context.
- Movement policy with a fake path adapter.
- Prefab plan generation without mutating the DataModel.
- Studio plugin mutation in a disposable place with undo verification.
