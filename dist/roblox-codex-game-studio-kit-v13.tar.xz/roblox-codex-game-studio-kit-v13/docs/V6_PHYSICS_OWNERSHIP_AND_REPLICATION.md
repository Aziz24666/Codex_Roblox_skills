# V6 Physics, Network Ownership, and Replication

## Core rule
A client may simulate some physics for responsiveness, but client-simulated motion is not automatically trustworthy game truth. Any outcome that grants value, affects a competition, changes shared state, or moves a player into protected areas must be validated by server-owned rules.

## Assembly inventory
For each important assembly, document:
- Components and root part.
- Whether anchored or simulated.
- Expected network owner and transition rules.
- Collision groups and query/touch behavior.
- Mass/constraints/forces and expected ranges.
- Streaming and replication behavior.
- Lifecycle owner and cleanup path.
- Gameplay outcome, if any, derived from motion.

## Server validation
Use context-aware tolerances, not brittle exact coordinates. Validate finite numbers, bounded deltas, plausible speed/acceleration, time, proximity, collision/state invariants, ownership, and allowed route/zone where relevant. Account for legitimate latency, frame-rate variation, and physics solver behavior. False positives can be as harmful as missed abuse.

## Design patterns
- Prefer server-controlled simulation for high-integrity objects when responsiveness permits.
- For player-responsive movement, keep responsive presentation separate from canonical progression/rewards.
- Use explicit constraints and bounded forces; avoid unbounded impulses or per-frame correction loops.
- Keep hit/interaction outcomes based on server-side checks and verified context.
- Define what happens when ownership changes, a player leaves, an object streams out, or an assembly becomes invalid.

## Performance
Measure frame time, physics cost, active assemblies, replication rate, memory, and network traffic. Use representative device and player counts. Avoid optimizing from a single desktop solo run.

## QA matrix
Test ownership handoff, two clients interacting with one assembly, collision at boundaries, low frame rate, latency, jitter, streaming boundaries, character respawn, object removal, server shutdown, and invalid remote requests tied to physics outcomes.
