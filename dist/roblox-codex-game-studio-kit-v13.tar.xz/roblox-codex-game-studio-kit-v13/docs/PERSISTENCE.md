# Player Data Persistence

Persistent data is a server-owned system. Design for failure rather than assuming every load/save succeeds.

## Separate data categories
- persistent profile data;
- session-only runtime data;
- derived/cached data;
- global/shared experience data;
- temporary cross-server coordination data.

Use the appropriate Roblox service and architecture for the requirement. Do not store large transient state in a player profile merely because it is convenient.

## Schema design
- Version the schema.
- Define defaults and validation.
- Bound numbers, strings, arrays and dictionaries.
- Store stable IDs rather than fragile display names.
- Define currency units and rounding rules.
- Keep migrations deterministic and testable.

## Lifecycle
1. Player joins; create a session context.
2. Load profile on the server with a bounded retry strategy.
3. Validate and migrate schema before exposing it to gameplay systems.
4. Do not allow save-dependent actions to proceed as though data were loaded when they were not.
5. Update through one profile owner or well-defined transaction interface.
6. Save on appropriate lifecycle events and handle shutdown best-effort.
7. Release session locks or ownership when the chosen data library requires it.
8. Clean session resources on leave.

## Failure behavior
- Do not overwrite valid saved data with defaults after a failed load.
- Do not claim a reward/purchase saved until the authoritative operation is confirmed.
- Bound retries and avoid request storms.
- Preserve enough context to diagnose failures without logging private data.
- Test throttling, timeout, malformed old data and player departure during an async operation.

## Studio testing
Use a separate test experience and controlled test data. Follow current Creator Hub guidance for Studio API access. Never enable experiments against a production experience's live data by default.
