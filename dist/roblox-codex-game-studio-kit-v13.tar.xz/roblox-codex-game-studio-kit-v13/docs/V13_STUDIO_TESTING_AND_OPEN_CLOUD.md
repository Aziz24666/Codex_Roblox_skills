# V13 Studio Testing and Open Cloud

## Choose the correct execution environment
- `StudioTestService` is a Studio/plugin testing surface for scripted Play/Run and multiplayer tests. Check current API security and Studio version.
- Manual Test/Test Here/Run and server-client switching remain useful for exploratory verification.
- Roblox Open Cloud Luau Execution can run Luau tasks headlessly against a place/version. It requires API-key authentication and is a separate external-service operation.

## Safety and correctness
- Prefer Studio testing for local iteration when connected.
- Use isolated test places or a deliberate non-production version for external execution.
- Never send a production place mutation, data reset, publish, or sensitive secret without explicit authorization.
- A successful headless task does not prove UI behavior, touch/gamepad input, physical-device performance or live service delivery.
- Record the target place/version, test script revision, tool/Studio version, execution result and logs.
