# V12 Memory and Resource Lifecycle

## Ownership table
For every long-lived component, document who owns and releases: RBXScriptConnections, temporary Instances, animation tracks, event subscriptions, tasks/coroutines, caches, references to streamed objects, and per-entity tables.

## Cleanup triggers
Use explicit cleanup on tag removal, character replacement, player removal, scene/round end, plugin/widget close, stream-out, and system shutdown as applicable.

## Measurement workflow
1. Record memory before a repeatable scenario.
2. Execute the scenario enough times to expose accumulation.
3. Tear down the scene/components using normal lifecycle paths.
4. Allow a defined settling interval.
5. Capture memory and active-instance/connection counters again.
6. Repeat to distinguish stable caches from unbounded growth.

## Guidance
- Avoid retaining references to destroyed or streamed-out Instances.
- Avoid global registries without explicit release rules.
- Do not build custom object pools by default; Roblox instance creation and garbage collection behavior should be measured in the target scenario before adding a pool.
- A weak table is not a substitute for deterministic cleanup of connections or external resources.
- Ensure delayed tasks verify that their owner is still active before applying results.
