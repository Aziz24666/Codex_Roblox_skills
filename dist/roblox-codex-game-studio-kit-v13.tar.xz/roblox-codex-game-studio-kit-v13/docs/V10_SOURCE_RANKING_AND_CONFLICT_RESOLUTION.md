# V10 Source Ranking and Conflict Resolution

## Source hierarchy
1. Current Roblox Creator Hub topic documentation and exact API reference: primary authority for platform contracts and signatures.
2. Official Roblox release notes, Creator Updates, and official DevForum announcements: primary context for availability, rollouts, changes, beta status, and deprecations.
3. Upstream documentation and release notes for third-party tools (Rojo, Rokit, Wally, Lune, Selene, StyLua, MCP client): primary authority for that tool.
4. Maintained open-source implementations and technical postmortems: practical implementation evidence, not platform-contract authority.
5. Expert community discussions/DevForum: useful for pitfalls and alternative patterns; verify claims against primary docs and reproducible tests.
6. General tutorials, blogs, short videos, scraped pages, and AI summaries: discovery only; reject as sole support for version-sensitive decisions.

## Conflict procedure
- Check publication and last-updated dates; older posts can describe changed API behavior.
- Check exact Studio build, API availability, security context, and rollout cohort.
- Prefer explicit current API reference for signature/guarantee, but consult current announcements when feature rollout is changing.
- If docs disagree, record both sources, build a minimal isolated reproduction, and mark the result uncertain until verified.
- Do not blend incompatible API examples from different versions.

## Quality markers
A source is stronger when it has a named maintainer, current version, complete API references, explicit limitations, reproducible samples, release history, and issue tracking. A high star count alone is not proof of maintenance or suitability.

## Anti-patterns
- trusting the first search result;
- accepting a search snippet as documentation;
- using a tutorial from an old engine version;
- treating a beta/feature-flagged API as generally available;
- assuming a plugin API works in a runtime Script;
- assuming an API permitted in Studio has the same permission in a published experience;
- assuming a package or asset ID is usable without ownership/permission checks.
