# Streaming and Large-World Design

Roblox instance streaming affects which Workspace objects are present on a client at a given moment. Do not build client logic that assumes every map object exists when the player joins.

## Design checklist
- Identify client scripts that search Workspace at startup.
- Use appropriate streaming-aware patterns and current documented signals/behavior.
- Handle streamed-out references and reappearance.
- Keep authoritative state on the server or in a replicated data model designed for it, not only inside a streamed part.
- Avoid storing essential global configuration solely on world instances that may not be present.
- Keep ReplicatedStorage limited to what clients need; large assets can be stored server-side and made available deliberately when appropriate.
- Verify zone transitions, teleports, respawn and late join under streaming.

## Validation
Test a large route from different spawn points and movement speeds. Watch for missing UI targets, infinite waits, nil references, duplicated event connections and stale cached instances. Confirm behavior in Studio with streaming settings that match the experience.
