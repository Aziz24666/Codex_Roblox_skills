# V8 — Non-Combat Gadget and Interactive-Prop Editor

This content editor is for harmless utility items and interactive props, such as a lantern, camera, journal, map beacon, music player, collectible display, or guided-tour tool. It is not a combat-item editor.

## Example data fields

| Group | Fields | Validation |
|---|---|---|
| Identity | `id`, `displayName`, `description`, `category` | Stable ID, unique within catalog, length bounds |
| Visual | `meshAssetId`, `textureAssetId`, `iconAssetId`, `scale` | Asset reference format, positive bounded scale |
| Audio | `equipSoundAssetId`, `useSoundAssetId`, volume | Optional reference, volume 0–1 |
| Animation | `equipAnimationAssetId`, `useAnimationAssetId` | Optional reference and rig compatibility note |
| Interaction | `interactionRadius`, `cooldownSeconds` | Positive bounds and project limits |
| Utility | `utilityKind`, `durationSeconds`, `intensity` | Strict allowlist for non-combat effects |

## Supported utility examples
- `IlluminateArea`
- `PlaySoundCue`
- `ShowWaypointMarker`
- `OpenJournal`
- `CapturePhoto`
- `CollectNearbyTokens`

The editor does not author arbitrary executable code. A utility kind is an enum resolved by a reviewed runtime registry. Unknown kinds fail validation.

## Generation output
A prefab `Tool` with a `Handle`, optional `SpecialMesh`, a presentation folder containing optional `Sound` and `Animation` references, stable attributes, and a versioned `Definition` ModuleScript. Store generated prefabs in a controlled server-side template/output location; do not automatically place them in a live player's Backpack.
