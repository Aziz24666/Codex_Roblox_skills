# V10 Data-Driven Schema Governance

A schema catalog is valuable when many instances share a shape and can be safely expressed as data. Do not force every arbitrary subsystem into a generic schema.

## Layers
- **Schema:** field types, defaults, constraints, help text, version, family, validation semantics.
- **Definition:** versioned instance values and stable references.
- **Template:** approved source hierarchy and required components.
- **Shared runtime:** reusable implementation consuming validated definitions.
- **Runtime state:** per-instance mutable state, created separately.
- **Editor:** dynamic controls from schema, no per-family duplicated form code.
- **Validator:** schema, definition, semantic, template, asset, and compatibility checks.
- **Generator:** deterministic outputs, collision protection, undo, and provenance.

## Change workflow
1. Add schema fields compatibly where possible.
2. Bump schema version for breaking shape/semantic changes.
3. Add explicit migration from supported previous versions.
4. Keep unknown-field policy intentional: reject, preserve, or warn.
5. Validate defaults and examples.
6. Regenerate generated catalog and verify deterministic diff.
7. Test at least two definitions through the same form/generator/runtime.
8. Keep generated artifacts out of manual-edit paths.

## Data/runtime boundary
Never store mutable runtime objects such as Instances, event connections, state machines, or coroutine handles in shared definitions. Definitions should contain serializable primitives and stable IDs; runtime resolvers turn IDs into approved assets/templates at the appropriate boundary.
