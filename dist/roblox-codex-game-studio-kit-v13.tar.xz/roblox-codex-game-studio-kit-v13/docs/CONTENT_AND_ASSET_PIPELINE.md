# Content And Asset Pipeline



## Asset intake

Every imported asset needs a stable name, source, creator/owner, rights/permission status, purpose, format, expected size/cost, target location, and fallback. Unknown provenance is a blocker for release use.

## Untrusted content review

Inspect imported models and plugins for scripts, modules, hidden remotes, unexpected instances, dynamic `require`, external requests, and unrelated behavior. Review source before placing content into a trusted project. Do not run unknown code to “see what it does.”

## Optimization

Validate model pivots, scale, collision, mesh complexity, texture dimensions, animation compatibility, sound duration/volume, and platform impact. Keep source files where permitted and record any lossy conversion.

## Placement and streaming

Only replicate assets clients need. Keep server-only templates in server-owned containers. Treat Workspace streaming as normal: clients may not have every region at once. Use deliberate loading states and streaming-aware access patterns.

## Content gate

Required assets are present, permitted, correctly named, mapped, performant enough for target devices, and verified in Studio. An asset ID or successful import is not proof of rights or final usability.
