# V10 Research and Implementation Loop

Every substantial change must move through:

`Inspect → Research → Compare → Decide → Prototype (if risky) → Implement → Verify → Record`

The loop is repeated when a task reveals a new API or changes scope. Do not let an implementation sprint silently bypass the research gate. If a change is purely internal and does not affect Roblox APIs or design decisions, still inspect relevant code and document why external research was unnecessary.

A decision record is a living engineering artifact: it must explain what was researched, what was selected, what was rejected, what remains uncertain, and how the implementation was verified. A URL list with no reasoning is not a decision record.
