# V11 CI and Reproducible Validation

## Goal
Make local and CI checks repeatable, version-pinned, fast enough to run often, and meaningful for Roblox projects.

## Toolchain strategy
Discover tools first; do not assume Rojo, Luau CLI, Selene, StyLua, Wally, Rokit, or Studio MCP is installed. Record exact versions. Pin versions in the project tool manifest/lockfiles when supported. Use upstream install docs and release notes before changing pins.

## Recommended validation layers
1. Repository and skill metadata lint.
2. JSON/schema/config validation.
3. Generated catalog/artifact drift check.
4. Luau formatting, lint, and type analysis where the project toolchain supports it.
5. Rojo build or selected project build.
6. Unit tests using isolated fixtures.
7. Studio plugin/runtime integration tests.
8. Multiplayer/device tests.
9. Performance regression checks.

## Reproducibility
- Same source + pinned generator/tool version should produce the same artifact.
- Do not rely on implicit environment variables or unrecorded local plugins.
- Keep test fixtures deterministic and disposable.
- Preserve logs and tool versions with evidence.
- Avoid secrets in logs or CI artifacts.

## CI safety
CI should not publish, change live experience settings, upload public assets, or access production player data by default. Use least privilege and disposable test resources. Any release/deploy workflow needs a separate protected job and human approval.

## Build truth
A successful static check is not a successful Studio session. Report each layer independently.
