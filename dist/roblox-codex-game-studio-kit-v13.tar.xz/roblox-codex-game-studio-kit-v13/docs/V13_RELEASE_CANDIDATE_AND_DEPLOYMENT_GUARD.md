# V13 Release Candidate and Deployment Guard

## Candidate assembly
1. Freeze candidate commit and identify artifact hash.
2. Confirm current research for changed platform APIs and tool versions.
3. Run project-profile-appropriate static checks and tests.
4. Run Rojo build only for managed Rojo profiles with pinned tools.
5. Complete Studio integration, multiplayer, streaming, and device checks required by the change.
6. Review data/config migration and rollback behavior.
7. Produce evidence bundle and release manifest.
8. Obtain explicit approval for any live deployment action.

## Preflight tool boundary
`v13_release_preflight.py` evaluates a JSON release-evidence document. It never calls Roblox APIs and never publishes. A `PASS` means evidence fields satisfy the local policy, not that Roblox accepted a deployment.

## Production guard
Production candidate requires a human approval record with approver identity/role, timestamp, candidate revision, target universe/place, rollback plan and change summary. No credential belongs in the evidence document.
