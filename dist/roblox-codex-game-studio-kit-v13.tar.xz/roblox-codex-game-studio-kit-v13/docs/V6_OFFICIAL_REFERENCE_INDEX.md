# V6 Official Reference Index

**Reference check date:** 2026-11-15. Re-check version-sensitive pages before implementing an API, Studio test harness, cloud integration, or publishing workflow. URLs below point to official Roblox Creator Hub documentation unless otherwise stated.

## Studio testing
- Studio testing modes, manual client/server, multi-client, device/network simulation, and scripted testing services: https://create.roblox.com/docs/studio/testing-modes
- Network Simulator: https://create.roblox.com/docs/studio/network-simulator
- Performance diagnostics / MicroProfiler: https://create.roblox.com/docs/performance-optimization/identify

## Scripting and types
- Luau type checking: https://create.roblox.com/docs/luau/type-checking
- Roblox services overview: https://create.roblox.com/docs/scripting/services

## Data and cross-server
- Data stores: https://create.roblox.com/docs/cloud-services/data-stores
- Choose between data and memory stores: https://create.roblox.com/docs/cloud-services/data-stores-vs-memory-stores
- Memory stores: https://create.roblox.com/docs/cloud-services/memory-stores
- Cross-server messaging: https://create.roblox.com/docs/cloud-services/cross-server-messaging

## Project workflows
- Rojo (community-maintained tool; not maintained by Roblox): https://create.roblox.com/docs/projects/rojo
- Roblox file-based workflow overview: https://create.roblox.com/docs/projects

## Implementation rule
The reference index is a starting point, not an API contract. Open the exact class/member page, verify security tags, thread-safety, deprecation, behavior, and Studio/client/server availability before coding. Record the exact page and check date in the feature spec when the API is material.
