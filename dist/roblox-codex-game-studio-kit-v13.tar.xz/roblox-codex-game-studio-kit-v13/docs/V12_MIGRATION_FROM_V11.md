# Migrating from V11 to V12

## What changes
V12 adds runtime performance, streaming, tag-component lifecycle, memory, device-tier, and analytics governance. It retains the V11 research-first process and project-reliability controls.

## Safe adoption
1. Back up/commit the current project using its normal workflow.
2. Read current project `AGENTS.md` and preserve local instructions.
3. Merge V12's global V12 sections rather than replacing project-specific rules.
4. Install the ten V12 skills and route only relevant tasks to them.
5. Add the new schemas/templates if the project wants structured performance and analytics records.
6. Run the V12 package checks on the kit, then run source audits on the project.
7. Establish baseline captures before adopting any proposed budget.
8. Introduce streaming and analytics changes incrementally with the appropriate Studio tests.

## Do not
- Enable/alter streaming settings automatically without understanding the world and testing it.
- treat sample performance limits as universal.
- assume AnalyticsService custom events can be verified in Studio.
- use Plugin Security profiler methods from ordinary game scripts.
- replace an existing source-of-truth/toolchain just to match the kit.
