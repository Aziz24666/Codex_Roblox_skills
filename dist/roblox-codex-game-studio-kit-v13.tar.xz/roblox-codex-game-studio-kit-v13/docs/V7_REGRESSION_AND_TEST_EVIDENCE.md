# V7 Regression Engineering and Test Evidence

## Test pyramid
1. Pure logic tests: fast and isolated.
2. Module/contract tests: interface and invariants.
3. Service integration: data, remotes, state ownership.
4. Studio runtime: actual engine behavior.
5. Client/server and multi-client: replication and concurrency.
6. Device/network: input, layout, latency, packet behavior.
7. Staging/release smoke: approved release candidate only.

## Acceptance mapping
Every material acceptance criterion receives an ID and test case. Tests may cover multiple criteria, but each criterion needs an explicit evidence record or a justified not-applicable decision.

## Evidence fields
Test ID, requirement ID, build/commit, environment, Studio version, tools, entrypoint/command, setup, players/clients, device/network profile, expected, actual, status, artifact path, timestamp, and operator/automation source.

## Status semantics
`PASS` means executed and met expected behavior. `FAIL` means executed and failed. `BLOCKED` means unable to run due to a named dependency or permission. `NOT RUN` means not attempted. `NOT APPLICABLE` requires a reason. A written test plan is not test evidence.

## Flaky tests
Capture first failure, reproduction, environment, and rerun count. Quarantine only with owner and remediation date; don't turn flaky into pass by repeated reruns.

## Release gate
No critical requirement can remain `FAIL`. Critical `BLOCKED` tests require explicit release-risk acceptance by an authorized owner; the agent must not make that decision for production.
