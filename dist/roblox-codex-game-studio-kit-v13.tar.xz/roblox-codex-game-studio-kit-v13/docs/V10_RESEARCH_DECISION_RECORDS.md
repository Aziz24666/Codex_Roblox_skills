# V10 Research Decision Records

Store one structured JSON record per meaningful decision in `research/decisions/`. The record is not a link dump: each source must support a specific claim and each option must have a trade-off.

## File name
`YYYY-MM-DD-short-topic.json` — use lowercase kebab-case and a stable `recordId`.

## Required lifecycle
1. Draft before implementation.
2. Validate with the V10 record linter.
3. Link the record from the relevant feature/spec/module README.
4. Update it after prototype/test results.
5. Mark it superseded when later research changes the decision; retain history.

## Required fields
- `recordId`, `recordType`, `task`, `decisionType`, `researchedAt`;
- `scopeFiles`, `queries`, `sources`;
- `apiSurface`, `approachesCompared`, `chosenApproach`, `decisionRationale`;
- `constraints`, `assumptions`, `verificationPlan`, `recheckTriggers`;
- `status` and `supersedes` when relevant.

## Source fields
`title`, `url`, `domain`, `sourceType`, `accessedAt`, `publishedAt` when known, `claim`, `limitations`.

## Status
Use `RESEARCHED`, `NEEDS_SPIKE`, `BLOCKED`, or `SUPERSEDED`. A researched decision does not imply the implementation was built or tested. Implementation/test evidence belongs in the same record's `implementationEvidence` or linked test evidence.
