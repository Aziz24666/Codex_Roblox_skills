# UI/UX and Accessibility

## Screen inventory
List each screen, purpose, entry trigger, exit path, primary action and state variations. Keep a single clear owner for navigation state.

## Layout hierarchy
- Prioritize the current player task.
- Keep essential information in stable locations.
- Respect device safe areas and differing aspect ratios.
- Avoid placing controls under thumb zones that conflict with movement or camera.
- Use readable text and contrast; don't encode status by color alone.
- Avoid dense text and unexplained icons.

## Input
Define action maps rather than assuming keyboard. Map supported input modes deliberately. Test mouse/keyboard, touch and gamepad as applicable. Ensure focus/selection can reach primary controls. Prevent UI actions from triggering twice due to input mode changes or repeated signals.

## UI state model
For networked data, distinguish loading, ready, pending, success, failure, empty and unavailable. The UI must not optimistically claim authoritative success unless it can safely reconcile and correct the display.

## Onboarding
Teach the next useful action in context, reveal complexity gradually, and let players revisit instructions. Use visible progress and concise language. Avoid forcing players through a long tutorial before they can act.

## Accessibility review
Check text size, contrast, focus order, input alternatives, non-color status cues, readable motion, audio-independent feedback and effects intensity. Test on a smaller screen and at a range of aspect ratios.
