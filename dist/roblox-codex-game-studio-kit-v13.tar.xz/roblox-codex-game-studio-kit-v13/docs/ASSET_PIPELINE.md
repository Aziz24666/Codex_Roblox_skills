# Asset Pipeline and Provenance

## Asset register fields
Stable key, asset type, display name, source, creator, permission/license basis, project use, identifier, import date, moderation/availability status, quality checks, variants and notes.

## Review before import
- rights and source are clear;
- dimensions and scale are appropriate;
- pivot/orientation are correct;
- collision is intentional;
- textures and mesh complexity are reasonable;
- audio/animation length and loop are appropriate;
- no sensitive or disallowed content is included;
- the asset can be used in the intended experience.

## Storage and replication
Place assets based on who needs them and when. Keep server-only assets out of client-visible locations. Avoid placing large unused content in replicated containers. Use streaming and deliberate loading for large worlds.

## IDs
Only record IDs obtained from actual user input, project contents or verified tool output. Never fabricate asset IDs. Check asset ownership/permissions and availability in Studio before treating integration as complete.

## Originality
Use references to guide broad style, not to reproduce another creator's proprietary assets, maps, interface, music, or identity. Document any externally sourced content.
