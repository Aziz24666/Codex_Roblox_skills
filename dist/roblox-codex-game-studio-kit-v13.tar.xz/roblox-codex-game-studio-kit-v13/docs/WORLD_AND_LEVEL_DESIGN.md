# World and Level Design

## Start with spatial purpose
For every area write: player goal, expected time spent, entry/exit, landmark, traversal method, interactables, social role, visual identity and performance cost.

## Flow
- Spawn area should orient players and avoid immediate danger/confusion.
- Main activity should be easy to find.
- Optional paths should look optional.
- Return routes should be clear.
- Distinct areas need recognizable silhouettes, lighting, materials or landmark objects.

## Graybox checklist
- scale and movement distance;
- jump/obstacle dimensions;
- camera visibility and occlusion;
- safe spawn and respawn;
- interaction distance and line of sight;
- mobile visibility and touch reach;
- collision fidelity;
- player capacity and crowding;
- streamed content availability.

## Environment polish
Work in passes: silhouette and landmarks → primary materials → lighting → major props → secondary detail → particles/audio → polish. Keep decoration from obscuring navigable surfaces or interaction targets. Build reusable kits where it reduces inconsistency.

## Studio review
Inspect from player camera height, not only from editor camera. Walk every route, test each collision, and verify the player can identify the next activity without relying on developer knowledge.
