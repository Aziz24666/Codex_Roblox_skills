# V5 Autonomous Repair, Planning, and Orchestration

## Task record
Every substantial task gets a stable ID, player outcome, scope/non-goals, priority, risk, dependencies, owner, expected files, acceptance criteria, verification level, status, and evidence.

Prioritize: safety/data/security blockers → broken core loop → first-session friction → feature dependencies → reliability/performance → polish → optional expansion.

## Autonomy table
| Decision | Default |
|---|---|
| Naming, helpers, reversible local refactors | Decide independently; preserve conventions |
| Local tests/docs and safe code edits | Proceed and verify |
| Small unspecified product choices | Choose reversible default; record assumption |
| New external dependency | Avoid unless justified; inspect license, maintenance, compatibility, need |
| Workflow migration | Do not perform by default; request approval |
| Delete user work or broad data | Ask first unless explicitly authorized and recoverable |
| Publish, public upload, permissions, Robux, production data | Explicit approval required |
| Credentials/tokens/cookies | Never request, expose, or commit |

## Dependency graph
1. Break the goal into meaningful independently verifiable tasks.
2. Identify the critical path and highest-risk unknown.
3. Prototype uncertainty before broad implementation.
4. Limit active work-in-progress.
5. Integrate one vertical slice at a time.
6. Block descendants when a contract changes.
7. Rerun integration checks after merging.

Do not create dozens of microtasks with no standalone evidence. A task should represent a player outcome or a technical proof.

## Autonomous repair loop
1. Capture exact command, version, environment, output, and failing artifact.
2. Reproduce the smallest failing case.
3. Classify root cause: source, API assumption, mapping/tool, environment, test, or external service.
4. Assess blast radius and data-loss risk.
5. Make the smallest reversible correction.
6. Rerun the failing check, then relevant regression checks.
7. Review diff for accidental/unrelated edits.
8. Record root cause, correction, evidence, and remaining uncertainty.

Do not endlessly rerun a failure without changing the diagnosis. Do not weaken or delete tests just to obtain a green result. If Studio or external access is missing, mark the check `BLOCKED` and state the exact verification needed.

## Session continuation
At the end of substantial work, update project status with completed tasks/evidence, active task/next action, blocked tasks/needed access, changed contracts/schemas, commands and versions, and known risks. At next session, verify status against current files and Git state.

## Final report
Report player-visible outcome, architecture, files, exact checks, Studio status, limitations, and one next step. Never claim completion because code was generated.
