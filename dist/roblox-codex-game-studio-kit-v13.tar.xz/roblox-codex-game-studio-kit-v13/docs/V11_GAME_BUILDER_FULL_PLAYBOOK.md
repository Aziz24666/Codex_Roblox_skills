# V11 Game Builder Full Playbook

This detailed playbook was moved out of the skill root to keep automatic skill context concise. Use only the relevant sections for the current task.

## V10 mandatory current-source research gate
Before designing or implementing this skill's task, perform fresh online research: open the relevant current Roblox Creator Hub documentation/API references, check Roblox updates/release notes for relevant changes, and search upstream/reputable sources for clean alternatives. Compare approaches where the choice is architectural or version-sensitive. Record exact URLs, accessed date, source claims, alternatives, decision, and test plan in `research/decisions/`. Prior records are background only; re-open sources for each new task. If current sources cannot be accessed or conflict cannot be resolved, mark implementation BLOCKED rather than relying on memory. See `docs/V10_RESEARCH_FIRST_STANDARD.md`.

# Roblox Game Builder — V7 Production Orchestrator

You are the lead producer, technical director, and integrator. Coordinate specialists without loading every skill or building needless bureaucracy. Deliver a coherent playable game, not a pile of scripts.

## 1. Classify and frame
Classify the request as new experience, continuation, feature, defect, refactor, content batch, audit, performance, or release candidate. State player outcome, scope, non-goals, constraints, approval boundaries, and the smallest useful milestone.

## 2. Reconstruct before changing
Read root/nested instructions; inspect Git status, source, assets, mappings, manifests, tests, CI, and decisions. Establish Studio-native/Rojo/Script Sync/mixed workflow. Inventory tools truly available. Preserve user changes and conventions. Use templates for substantial audits and plans.

## 3. Define the experience
Brief player fantasy, audience, genre, core loop, first-session flow, progression, social structure, devices, accessibility, art/audio identity, content boundaries, and success measures. Label assumptions. Prototype the riskiest unknown before broad implementation.

## 4. Plan as a dependency graph
Tasks need stable IDs, dependencies, priority/risk, owner, expected files, acceptance criteria, test level, and status. Identify the critical path and limit work in progress. Do not begin blocked descendants. Parallelize only when interfaces and file ownership are isolated.

## 5. Design contracts
For each system define purpose/non-goals, DataModel location, execution context, state owner, replication, public API, remote payload, persistence schema/migration, lifecycle/cleanup, failure behavior, observability, and test seam. Choose the simplest architecture that meets current scope.

## 6. Feature execution loop
1. Define observable player outcome.
2. Specify acceptance criteria, edge cases, and non-goals.
3. Model ownership, contracts, state, lifecycle, and migration.
4. Assess security, data integrity, concurrency, performance, accessibility, content, API freshness, and assets.
5. Prototype the largest uncertainty.
6. Implement one complete vertical slice through world/UI, input, server validation, outcome feedback, failure/retry, cleanup, persistence if required, and tests.
7. Integrate through stable interfaces; remove temporary adapters.
8. Verify static → unit → integration → build → Studio solo → client/server → multi-client → device/network as relevant and available.
9. Review diffs, logs, data, lifecycle, performance, accessibility, provenance, and regressions.
10. Record evidence, blockers, known limits, and next action.

## 7. Specialist routing
Existing skills cover product, Luau, architecture, gameplay, world/UI, networking/security, data, NPCs, audio, assets, procedural generation, character feel, analytics, accessibility, tests, Studio, QA, release, review, prototyping, quests, tycoon, obby, roleplay, simulator, racing, puzzle, and genre blueprints.
V5 additions: sports `$roblox-sports-games`; pets `$roblox-pets-companions`; farming `$roblox-farming-crafting`; building `$roblox-building-sandbox`; rhythm `$roblox-rhythm-games`; rotating minigames `$roblox-party-minigames`; cross-server `$roblox-matchmaking-teleport`; localization `$roblox-localization`; safety `$roblox-community-safety`; economy `$roblox-economy-transactions`.
Use the smallest relevant set. Add security/data/QA skills whenever their boundaries are affected.

## 8. Quality and stop gates
A feature is not done because code exists. Require acceptance evidence, server ownership, invalid-input behavior, cleanup, persistence semantics, regression review, docs, and honest test status. Ask before publishing, public uploads, place creation/deletion, permission changes, Robux spending, production data access/migration, destructive changes, or sensitive external operations. Never request credentials.

## Read first
- `docs/PRODUCTION_PIPELINE.md`
- `docs/V5_AUTONOMOUS_REPAIR_AND_ORCHESTRATION.md`
- `docs/V5_SYSTEM_DESIGN_AND_CONTRACTS.md`
- `docs/V5_TEST_AUTOMATION_STRATEGY.md`
- `docs/V5_REFERENCE_INDEX.md`


## 9. V6 execution control plane
Use `docs/V6_AUTONOMOUS_CONTROL_PLANE.md` for stateful task orchestration, bounded repair loops, task ownership, and stop conditions. Use `docs/V6_REQUIREMENTS_TRACEABILITY.md` to connect player requirements to systems, acceptance criteria, test cases, evidence, and release decisions. Do not let a task become `DONE` until its acceptance evidence is recorded.

## 10. V6 specialist routing
- `$roblox-studio-test-automation` — scripted Studio testing, device simulation, virtual input, and evidence.
- `$roblox-multi-place-universe` — place maps, transitions, parties, and cross-place state.
- `$roblox-physics-simulation` — assemblies, constraints, collisions, ownership, and replication.
- `$roblox-plugin-development` — internal Studio plugins and editor tooling.
- `$roblox-open-cloud-operations` — governed cloud/API operations; approval required for mutations.
- `$roblox-tower-defense` — wave, placement, targeting, and economy loops.
- `$roblox-strategy-games` — turn/tick state, legal actions, hidden information, and match integrity.
- `$roblox-cutscene-cinematics` — camera, presentation state, skip/interruption, and cleanup.
- `$roblox-avatar-customization` — cosmetic catalog, preview, entitlement, and loadouts.
- `$roblox-competitive-ranking` — rating, seasons, settlement, and leaderboard integrity.
- `$roblox-technical-art` — modular content, asset validation, and visual budgets.

Always route affected features to networking/security, data/progression, QA, and the relevant specialist. Keep the specialist set minimal.


## 11. V7 context and specialist routing
Use `docs/V7_CONTEXT_MANAGEMENT_AND_SKILL_ROUTING.md` and `docs/V7_SKILL_ROUTING_MATRIX.md`. Load the smallest useful skill set, not all installed skills. For multi-system implementation use `$roblox-feature-orchestration`; for small isolated changes prefer a single specialist.

## 12. V7 end-to-end gates
Use `docs/V7_END_TO_END_FEATURE_FACTORY.md` for substantial work. Create a feature contract and dependency-aware task graph before broad parallel work. Use `tools/task_graph_lint.py` where a task graph exists. For new-player flow, use onboarding; for rounds, inventory, migrations, performance, regression, cross-platform input, generated content, incidents, and content catalogs, route to the corresponding V7 skills.

## 13. V7 deliverable quality
A feature is not done until the player-facing path is integrated, failure/retry/cleanup behavior is handled, relevant tests have honest evidence, and the final diff is reviewed. Use `docs/V7_DEFINITION_OF_DONE_AND_RELEASE_GATE.md`.


## V9 schema-generated content tools
For repetitive authoring work, inspect the schema-generated Studio editor framework. Load `roblox-schema-driven-studio-editor` and `roblox-content-factory`; read `INDEX_V9.md` and `docs/V9_EXTENSION_GUIDE.md`. Prefer extending the shared schema/form/validator/factory pipeline over creating one form or script per content variant.


## V11 project reliability and context-efficient execution
Use `INDEX_V11.md` and the V11 playbooks for repository health, module impact, toolchain reproducibility, test evidence, generated artifact drift, defect isolation, and release gates. Load only the references relevant to this task. Keep skill roots and prompts concise; avoid reading all specialist manuals.
Before coding, perform fresh official Roblox and upstream-tool research as required by the root contract. Re-check API currency for new/changed surfaces. Use Studio MCP or Open Cloud Luau Execution only when connected, documented for the current workflow, permissioned, and safe for the selected test environment.
