# V4 Luau Analysis and Review Workflow

Use this workflow with the project's actual formatter, linter, type checker, and tests. Do not assume any tool is installed simply because it is mentioned here.

## Review order

1. Confirm Luau source location and script execution context.
2. Read surrounding modules, types, consumers, and project mapping.
3. Run the repository-pinned formatter/linter/type checker if configured.
4. Review API signatures against Creator Hub or Studio autocomplete.
5. Trace nilability, yield points, event lifetimes, task lifetimes, mutation, and error handling.
6. Trace each remote from client call to server validation and server-owned state change.
7. Trace each persistent write from validation through idempotency, failure recovery, and shutdown.
8. Inspect hot paths, allocations, physics work, UI layout work, and replication volume.
9. Confirm tests cover behavior and invalid inputs.
10. Review the diff for accidental scope expansion and dead code.

## Type discipline

Prefer `--!strict` for new modules. Export explicit types for stable interfaces. Use discriminated unions or tagged result tables when a function has multiple outcomes. Keep optional fields explicit. Narrow unknown values at input boundaries. Avoid `any` as a convenience; each `any` should have a documented reason and a narrow scope.

## Defect classes to search

- wrong client/server execution context;
- trusting client values for rewards or ownership;
- missing nil checks or stale Instance references;
- unbounded `while`/`for` loops or per-frame scans;
- connections/tasks that outlive their owner;
- yields while holding a mutable state transition open;
- race conditions between join/leave/respawn and async work;
- duplicate purchase/reward processing;
- save requests that can overwrite newer state;
- missing streaming-aware access to Workspace content;
- hidden dependency cycles and expensive module initialization;
- non-deterministic tests and global mutable state.

## Automated audit limits

The included pattern scanner searches text patterns only. A match is a review prompt, not a confirmed defect. No match is not evidence that the code is secure or correct. Use Roblox-aware static tools and Studio tests for stronger verification.
