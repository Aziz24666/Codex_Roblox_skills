# V8 — Official Roblox and Codex References

Verify API signatures in the current Creator Hub before implementation. These references informed the V8 architecture:

- ModuleScripts and reuse: https://create.roblox.com/docs/scripting/module
- ModuleScript API: https://create.roblox.com/docs/reference/engine/classes/ModuleScript
- CollectionService tags: https://create.roblox.com/docs/reference/engine/classes/CollectionService
- Luau overview and typing: https://create.roblox.com/docs/luau
- Luau type checking: https://create.roblox.com/docs/luau/type-checking
- Studio widgets: https://create.roblox.com/docs/studio/build-studio-widgets
- Plugin API: https://create.roblox.com/docs/reference/engine/classes/Plugin
- Instance properties and attributes: https://create.roblox.com/docs/studio/properties
- Codex/Agent Skills format: https://developers.openai.com/api/docs/guides/tools-skills

This list is a starting point, not a guarantee that every API in examples is current. Consult exact class/member pages for each implementation.
