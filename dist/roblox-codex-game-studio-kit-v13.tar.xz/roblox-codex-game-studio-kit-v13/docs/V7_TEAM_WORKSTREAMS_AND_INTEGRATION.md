# V7 Team Workstreams and Integration

## Work breakdown
Split by player-visible outcome and stable system boundaries. A useful work item names one owner, exact file area, dependency, interface, acceptance criteria, tests, and handoff artifact.

## Parallel work rules
- Never assign the same shared file to multiple agents without an explicit integration owner.
- Agree on module names, method signatures, data schema, remote payload, and state ownership before parallel implementation.
- Prefer parallel research, documentation, asset audits, and isolated modules over simultaneous edits to shared architecture.
- Keep work-in-progress low; finish integration before starting multiple new feature branches.

## Handoff contract
Each specialist reports: objective, source inspected, files changed, contract changed, assumptions, commands/tests run, actual results, evidence paths, unresolved defects, and next dependency.

## Integration
The orchestrator checks naming, ownership, type shapes, require paths, project mapping, duplication, cleanup, and error behavior. Then run contract tests and one end-to-end scenario.

## Conflict resolution
Preserve the repository's source of truth and user changes. Do not resolve merge conflicts by discarding one side without understanding semantics. Record architecture decisions when the choice is durable.
