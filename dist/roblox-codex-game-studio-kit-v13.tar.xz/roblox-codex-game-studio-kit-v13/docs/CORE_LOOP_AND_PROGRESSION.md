# Core Loop and Progression Design

## 1. Model the core loop
Describe a typical play cycle in player language:
- **Orient:** where am I and what can I do?
- **Choose:** what goal/action do I select?
- **Act:** what input or skill is required?
- **Respond:** what does the world do immediately?
- **Resolve:** did I succeed, fail, or make partial progress?
- **Reward:** what changed and why?
- **Continue:** what meaningful next choice is available?

Every transition should be visible and understandable. A loop with no meaningful choice or feedback becomes repetitive; a loop with too many menus becomes slow.

## 2. Use a goal ladder
- Immediate: next action or short challenge.
- Session: complete a level, activity, round or collection target.
- Long term: unlock a new area, personalize a space, master a mechanic or complete a collection.

Do not use time pressure as a substitute for interesting goals. Give players a natural stopping point.

## 3. Reward principles
- Tell players what the reward is and what condition grants it.
- Keep reward grants authoritative on the server.
- Do not show success until the server confirms it.
- Make duplicate and replay behavior explicit.
- Avoid reward loops that rely on paid random outcomes or confusing odds.

## 4. Balancing
Store tunable values in named configuration with units. Use a small test matrix and change one major variable at a time. Capture observations: time to understand, completion rate, confusion points, perceived fairness, and repeat interest. Small samples are directional, not proof of universal player behavior.

## 5. First-session onboarding
Show the next useful action in context. Teach one concept at a time. Avoid lengthy walls of text. Let players recover from mistakes and revisit important help. Provide a clear explanation of the objective and controls.

## 6. Progression pitfalls
Avoid runaway inflation, opaque upgrade value, hard paywalls that block the core loop, excessive grind, and rewards that have no meaningful use. Make every progression layer earn its complexity.
