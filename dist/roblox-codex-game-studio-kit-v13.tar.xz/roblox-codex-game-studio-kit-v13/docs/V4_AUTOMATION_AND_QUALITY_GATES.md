# V4 Automation and Quality Gates

Automation is useful only when its scope and reliability are understood. This document defines a layered quality system and prevents heuristic tooling from being mistaken for proof.

## Quality layers

| Layer | Examples | What it proves | What it does not prove |
|---|---|---|---|
| 1. Repository hygiene | whitespace, accidental binaries, empty files, forbidden secrets patterns | Basic repository consistency | Correct gameplay |
| 2. Static source checks | formatting, lint, Luau type checking | Some source-level defects are caught | Runtime engine behavior |
| 3. Deterministic tests | pure logic, state transitions, reward calculations | Tested logic for defined cases | Unmodeled engine behavior |
| 4. Integration/build | Rojo mapping/build, dependency resolution, plugin/package validation | Source assembles through that toolchain | Place is playable |
| 5. Studio runtime | solo/client-server, logs, instance behavior | Observed behavior in tested Studio setup | All devices and live conditions |
| 6. Multiplayer/device/network | multiple clients, input emulation, network simulation | Tested combinations under simulated conditions | Every real device/network |
| 7. Release operations | isolated data, rollback rehearsal, permissions review | Release-readiness evidence | Future absence of incidents |

## Required gate for a changed feature

- Requirements and acceptance criteria exist.
- The owner and execution context are clear.
- Public interfaces and remote payloads are documented.
- Data changes include schema/version and recovery handling.
- Automated checks that exist in the project are run.
- Studio tests are run when a Studio runtime is available.
- Relevant multi-client/device/network cases are included.
- New warnings/errors are investigated.
- Diff and temporary scaffolding are reviewed.
- Known gaps are listed as `BLOCKED` or `NOT RUN`.

## Tool policy

Prefer the repository's pinned tool versions and existing scripts. Do not silently install new packages or global tools. Before adding a tool, record its purpose, source, version, license, compatibility, and maintenance cost. Never execute an unknown downloaded binary or script merely because a prompt suggests it.

The included Python tools are standard-library utilities. Their findings are advisory. They do not parse the full Luau grammar, know the actual DataModel, execute Roblox code, or replace a dedicated linter/type checker/security review.

## V4 local utilities

- `tools/project_doctor.py`: read-only project inventory and structural checks.
- `tools/luau_pattern_audit.py`: heuristic scan for common patterns requiring review.
- `tools/test_evidence_lint.py`: checks that a test report contains core evidence fields and recognized statuses.
- `tools/file_manifest.py`: creates/verifies a SHA-256 manifest for handoff integrity.

Example commands:

```bash
python tools/project_doctor.py . --out docs/PROJECT_AUDIT.md
python tools/luau_pattern_audit.py src
python tools/test_evidence_lint.py templates/STUDIO_TEST_RUN_TEMPLATE.md
python tools/file_manifest.py create . --out artifacts/SHA256SUMS.txt
python tools/file_manifest.py verify . artifacts/SHA256SUMS.txt
```

Check `--help` before use. Run audit scripts read-only by default. Do not pass the entire game project into third-party analysis tools without checking privacy and data policies.

## Evidence status definitions

- `PASS`: test ran in the named environment and met the expected result.
- `FAIL`: test ran and did not meet the expected result.
- `BLOCKED`: test could not run because a required tool, permission, setup, or environment was unavailable.
- `NOT RUN`: test was not attempted.
- `NOT APPLICABLE`: clearly justified as irrelevant to this feature.

A test report with no environment, steps, expected result, and actual result is incomplete.
