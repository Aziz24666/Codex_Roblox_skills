# Device And Accessibility Matrix



## Required device coverage

| Device family | Input | Main risks |
|---|---|---|
| Small phone | Touch | Small targets, safe areas, thumb reach, text overflow |
| Large phone | Touch | Layout scaling, orientation, chat overlays |
| Tablet | Touch/controller as applicable | Wide layout, interaction spacing |
| Desktop | Keyboard/mouse | Focus loss, cursor behavior, high resolution scaling |
| Controller/TV where supported | Gamepad | Focus order, selection visibility, navigation loops |

## Accessibility checks

- Essential information is not conveyed by color alone.
- Critical text remains readable at expected screen sizes.
- Important controls are discoverable and consistently placed.
- Focus and selected states are visible for controller/keyboard.
- Audio is not the only carrier of essential instructions or alerts.
- Essential interactions are not dependent on tiny targets or excessive precision.
- Motion, camera shake, and repeated visual effects are not overwhelming; offer alternatives where needed.
- Localization does not cause clipping or inaccessible controls.
- Failure messages explain how to recover.

## Evidence

Record device/simulator, resolution/orientation, input mode, UI scale, test path, issues, screenshots if available, and whether the check used a simulator or physical device. Do not describe a simulated check as a physical-device test.
