# V9 — Asset Reference Fields

## Asset field data
An asset field should include a reference string, expected content kind, optional/required status, and verification status. Do not collapse these into one boolean.

Example states:
- `EMPTY_OPTIONAL`
- `FORMAT_VALID_UNVERIFIED`
- `VERIFIED_IN_STUDIO`
- `INVALID_FORMAT`
- `LOAD_FAILED`
- `INCOMPATIBLE_TYPE`
- `PERMISSION_UNCONFIRMED`

## What a format check proves
A value matching `rbxassetid://123` (or accepted bare digits that are normalized) proves only that it resembles an asset reference. It does not prove the asset exists, loads, is moderated/approved, belongs to an allowed creator, is permitted for the experience, is the expected asset kind, or is compatible with the selected rig.

## Authoring behavior
- Never invent an ID or silently substitute another asset.
- Show asset kind beside the field: Mesh, Image/Decal, Sound, Animation, etc.
- Allow optional empty references.
- Keep asset resolution/permission checks separate and require Studio verification or an available official API/tool.
- If asset loading is not available, status remains `FORMAT_VALID_UNVERIFIED`.
- Record provenance and verification evidence in an asset manifest when materially useful.
