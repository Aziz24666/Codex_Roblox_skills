# V4 Content Authoring and Validation

Treat maps, stages, quests, puzzles, shop catalogs, dialogue, and collectibles as authored data with schemas and validation—not as unrelated hard-coded branches.

## Content pipeline

1. Define a schema with required fields, types, stable IDs, and version.
2. Create a small sample catalog with valid and intentionally invalid entries.
3. Add a validator for duplicate IDs, missing references, invalid ranges, unreachable gates, and invalid rewards.
4. Separate presentation metadata from authoritative gameplay values.
5. Build tooling or a simple table format that content authors can maintain safely.
6. Test malformed and incomplete content.
7. Add content to a versioned catalog and record its provenance.
8. Run an in-game smoke test for the newly authored slice.

## Stable identity

Use stable IDs for quests, stages, catalog entries, unlocks, and migration mappings. Do not use display names as persistent identifiers. Renaming a display label must not orphan existing player progress.

## Validation rules

Validate prerequisites, reward definitions, unlock references, sequence numbers, placement bounds, duplicate keys, missing text/audio assets, unsupported device assumptions, and content safety constraints. Content validation can prevent broken references but does not replace playtesting for clarity or fun.
