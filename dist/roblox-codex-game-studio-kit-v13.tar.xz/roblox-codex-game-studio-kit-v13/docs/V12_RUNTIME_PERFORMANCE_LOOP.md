# V12 Runtime Performance Loop

## Purpose
Use a repeatable measurement loop instead of guessing at optimizations. Roblox's current performance guidance frames optimization as design, identify, improve, and monitor. Treat every reported improvement as a measured result tied to a reproducible scenario.

## Required sequence
1. **Question:** state the user-visible symptom or product objective (stutter, slow join, memory growth, server frame-time spikes, etc.).
2. **Scenario:** define place/build, representative route/action, player count, warm-up, duration, and whether the run is cold or warm.
3. **Environment:** record Studio/engine version, client/server context, device tier, emulator or physical hardware, graphics setting, network conditions, and test date.
4. **Baseline:** capture the relevant metric and raw evidence before editing.
5. **Diagnosis:** use the correct tool and identify a dominant measured cause. Client and server costs are separate questions.
6. **Single change:** make the smallest change that targets the cause.
7. **Repeat:** run the same scenario and configuration; collect multiple captures when noise is material.
8. **Compare:** report before/after values, delta, variance, and any trade-offs.
9. **Regression:** run relevant gameplay, streaming, device, and correctness checks.
10. **Monitor:** for published changes, review appropriate operational metrics after release; never substitute a plan to monitor for actual evidence.

## Metrics to select
Choose only those tied to the problem: frame time/consistency, script execution cost, memory, join time, asset/content load, network/streaming behavior, or server responsiveness. Avoid optimizing to a vanity number.

## Decision rule
A source-code pattern is a hypothesis. A profiler capture is evidence. A budget checker validates supplied structured values; it does not produce those values or prove the capture is honest.

## Do not
- Compare Studio emulation with a physical device as if identical.
- Compare different builds, places, device tiers, graphics settings, or scenarios without disclosing the difference.
- claim FPS improved from source inspection alone.
- increase budgets to hide a regression.
- introduce object pooling or complex scheduling unless profiling shows it helps.
