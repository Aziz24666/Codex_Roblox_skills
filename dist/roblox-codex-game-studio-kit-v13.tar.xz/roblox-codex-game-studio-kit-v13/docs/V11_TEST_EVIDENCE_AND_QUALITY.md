# V11 Test Evidence and Quality

## Evidence record
Every meaningful test record should capture: test ID, requirement/feature ID, environment, Studio version/session/place where relevant, tool versions, entry point, setup/fixture, expected behavior, actual behavior, result status, logs/screenshots, timestamp, and limitations.

## Allowed statuses
`PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, `NOT APPLICABLE`.

## Evidence hierarchy
1. Static validation: file shape, schema, lint, type analysis.
2. Unit: deterministic module behavior.
3. Integration: modules and service contracts together.
4. Build/sync: project mapping or artifact successfully assembled.
5. Studio runtime: behavior inside the engine.
6. Multiplayer: server/client interactions and concurrency.
7. Device/network: physical device or realistic simulation evidence.
8. Release: staged candidate verified under release procedure.

Do not collapse these into one green check. A test passing at one level does not prove a higher level.

## Failure discipline
Keep failing logs, minimize reproduction, identify root cause, add a regression test, rerun affected tests, and report remaining uncertainty. Do not hide known failures by weakening assertions without a documented reason.
