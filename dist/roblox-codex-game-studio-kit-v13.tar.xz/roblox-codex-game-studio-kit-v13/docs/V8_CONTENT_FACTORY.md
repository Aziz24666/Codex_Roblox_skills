# V8 — Content Factory

The content factory turns three inputs into a generated prefab:
1. Validated content definition.
2. Approved template (or explicitly selected source model).
3. Generator version and rules.

It produces a hierarchy plus metadata describing what generated it. The runtime then consumes the metadata through a shared system.

## Factory stages
- Parse and validate definition.
- Resolve the requested template by stable ID/version.
- Check output name collisions.
- Build a dry-run plan.
- Clone approved template.
- Apply property and asset bindings.
- Add stable tags/attributes and a config reference.
- Validate final hierarchy and required descendants.
- Commit to output folder using Studio undo support.
- Emit a generation report.

## Idempotence and drift
The same definition and template version should produce the same intended hierarchy. Before regenerating, compare the target to its recorded generated baseline. If user edits are detected, show a diff and ask before replacement. Keep manual overrides in a separate override layer instead of mixing them into generated base values.

## Do not
- Create hundreds of per-instance scripts.
- Write executable source from untrusted form fields.
- assume asset identifiers are valid or permitted.
- silently substitute missing animation/sound/mesh assets.
- overwrite existing content just because the name matches.
