# V8 — Tagged Instance Registration

Use CollectionService when many instances need the same attached behavior. The server bootstrap should:
1. Connect to the tag's added and removed signals.
2. Process instances that already have the tag at startup.
3. Validate that each instance is the expected class/model.
4. Read a stable definition ID attribute.
5. Resolve and validate the definition.
6. Construct exactly one controller and store it in a registry.
7. On removal, destroy the controller and clear its registry entry.

Do not depend on client-added tags for server authority. Tags replicate and serialize, but streamed instances can leave and re-enter a client's view. Keep local visual binding resilient to those lifecycle events. Verify exact API details against current Creator Hub documentation.
