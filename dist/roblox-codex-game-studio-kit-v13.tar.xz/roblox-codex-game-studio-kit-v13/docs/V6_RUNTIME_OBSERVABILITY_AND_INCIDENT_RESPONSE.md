# V6 Runtime Observability and Incident Response

## Purpose
Make failures diagnosable without collecting unnecessary player data or exposing secrets.

## Signals
Use a small set of meaningful signals tied to player outcomes:
- Join/load success and duration.
- Match start/finish/abort and reason category.
- Teleport attempt/success/failure and recovery.
- Data load/save success, retry count, and latency buckets.
- Purchase/transaction processing status (never log secrets or unnecessary personal data).
- Server/client error categories and performance budgets.

## Event contract
Each event needs a stable name, schema version, timestamp source, environment, correlation ID, subject type, necessary fields, retention purpose, sampling rules, and owner. Avoid raw chat, secrets, precise location, or sensitive personal data. Pseudonymous IDs should only be used where necessary and under applicable platform policy.

## Logging rules
- Prefer structured messages with stable error codes.
- Include operation and correlation IDs.
- Redact credential-like values and player-private payloads.
- Rate-limit repetitive warnings.
- Do not swallow errors silently.
- Separate expected user errors from unexpected faults.

## Incident response
1. Detect and classify severity/player impact.
2. Freeze risky rollout or disable affected feature if a safe flag exists.
3. Preserve redacted evidence.
4. Identify affected environments/builds and data paths.
5. Mitigate without destructive data reset.
6. Reconcile data and restore service.
7. Verify recovery.
8. Write a blameless postmortem with contributing factors and prevention tasks.

## Privacy
Collect only what answers a defined operational question. Document retention and access. Never instrument private communications as general analytics. Use current platform policy and privacy documentation for any user-data collection.
