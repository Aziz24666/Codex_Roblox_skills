# V5 Official Reference Index

These are starting points. Re-check current documentation during implementation because APIs, limits, and policy can change.

## Codex
- Skills: https://learn.chatgpt.com/docs/build-skills
- Codex source: https://github.com/openai/codex

## Luau and Studio
- Luau: https://create.roblox.com/docs/luau
- Type checking: https://create.roblox.com/docs/luau/type-checking
- Studio testing modes: https://create.roblox.com/docs/studio/testing-modes
- Performance: https://create.roblox.com/docs/performance-optimization/improve
- MicroProfiler: https://create.roblox.com/docs/performance-optimization/microprofiler
- Streaming: https://create.roblox.com/docs/workspace/streaming

## Security and data
- Client/server boundary: https://create.roblox.com/docs/scripting/security/client-server-boundary
- Security tactics: https://create.roblox.com/docs/scripting/security/security-tactics
- Data stores: https://create.roblox.com/docs/cloud-services/data-stores
- Data store best practices: https://create.roblox.com/docs/cloud-services/data-stores/best-practices
- Memory stores: https://create.roblox.com/docs/cloud-services/memory-stores
- Memory store best practices: https://create.roblox.com/docs/cloud-services/memory-stores/best-practices

## Multiplayer, localization, transactions, assets
- Teleport service: https://create.roblox.com/docs/projects/teleport
- Cross-server messaging: https://create.roblox.com/docs/cloud-services/cross-server-messaging
- Localization: https://create.roblox.com/docs/production/localization
- MarketplaceService: https://create.roblox.com/docs/reference/engine/classes/MarketplaceService
- Developer products: https://create.roblox.com/docs/production/monetization/developer-products
- Packages: https://create.roblox.com/docs/projects/assets/packages
- Version history: https://create.roblox.com/docs/projects/version-history

Before using an API verify current class/member, signature, thread/yield behavior, permission requirements, quotas, failure behavior, and stability/deprecation status. Record the checked date. Prefer official Creator Hub documentation over copied snippets.
