# V4 Genre Acceptance Matrices

Use the matrix matching the project genre, then add project-specific cases. Every test needs environment, setup, steps, expected result, actual result, and status.

## Tycoon / builder

- two players claim different plots;
- duplicate plot claim is rejected;
- placement outside owned plot is rejected;
- placement count cap is enforced server-side;
- one production cycle grants exactly one reward;
- duplicate request does not duplicate currency;
- leave/rejoin restores owned progress;
- plot owner leaves and plot resets according to stated policy.

## Obby / platforming

- checkpoint is activated in valid order;
- client cannot claim a distant/future checkpoint;
- respawn restores the intended checkpoint;
- reset does not corrupt stage state;
- touch and controller controls can finish the first obstacle;
- simultaneous finish/checkpoint events resolve consistently.

## Social / roleplay

- player can enter and leave an activity cleanly;
- role/prop ownership follows documented permissions;
- player departure clears presence and temporary state;
- UI does not expose private account details;
- reporting/moderation affordances follow supported platform flows;
- blocked/filtered content is not reintroduced through custom display paths.

## Simulator / collection

- reward is calculated and granted by server;
- catalog IDs are stable and unique;
- inventory capacity is enforced;
- duplicate reward requests are idempotent;
- upgrade costs and resulting effect match the UI;
- profile load failure does not create a new empty profile over existing data.

## Racing / vehicle

- invalid vehicle selection is rejected;
- race state transitions are server-owned;
- out-of-order checkpoint claims are rejected;
- duplicate finish request does not change results;
- disconnect and vehicle reset have defined outcomes;
- results remain consistent across clients under simulated latency.

## Puzzle / adventure

- correct solution advances once;
- incorrect solution does not corrupt state;
- two simultaneous interactions resolve deterministically;
- reset restores the documented puzzle baseline;
- hints do not reveal unintended future content;
- co-op participants see the same authoritative solved state.
