# V11 Dependency Graph and Module Boundaries

## Contract
A dependency graph is a decision aid, not an oracle. Static scans can miss dynamic module resolution, CollectionService registration, attributes/tags, reflection, dependency injection, and DataModel references.

## Module contract
For each important module record: purpose, non-goals, execution context, public API, state ownership, dependencies, lifecycle, events/remotes, error contract, persistence impact, and tests.

## Healthy graph signs
- Dependencies point toward stable shared abstractions or data contracts.
- Feature modules do not reach into unrelated private state.
- Server-only code does not accidentally become client-accessible.
- Shared modules do not import server-only services.
- Cycles are absent or explicitly justified and isolated.
- Registries and factories use explicit, typed identifiers.

## Refactoring
Map call sites and reverse dependencies first. Create adapter boundaries for staged migrations. Delete old paths only after all consumers and tests are moved. Prefer behavior-preserving commits and avoid simultaneous architectural rewrites across unrelated features.
