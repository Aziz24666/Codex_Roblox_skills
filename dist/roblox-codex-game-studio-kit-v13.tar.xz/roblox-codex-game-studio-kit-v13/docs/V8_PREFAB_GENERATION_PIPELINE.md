# V8 — Prefab Generation Pipeline

## Required stages
1. Parse draft.
2. Validate shape and semantics.
3. Resolve all required asset/template references.
4. Build a dry-run hierarchy plan.
5. Check name collision and source drift.
6. Begin an undoable Studio operation.
7. Clone approved template or create an allowed base hierarchy.
8. Apply attributes, children, and references.
9. Attach schema/template/generator provenance.
10. Validate the result after generation.
11. Commit operation; cancel on failure.
12. Select/reveal output and generate a report.

## Generated metadata
- `DefinitionId`
- `DefinitionSchemaVersion`
- `TemplateId`
- `TemplateVersion`
- `GeneratorVersion`
- `GeneratedAt` (editor metadata only; not used as identity)

## Replace behavior
Default action is `Create New` or `Skip Existing`. A separate `Preview Replace` compares generated baseline to current object. Require explicit confirmation before replacing changed content. Never delete source templates.
