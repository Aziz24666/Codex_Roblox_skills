# V11 Generated Artifacts and Drift Governance

## Source-of-truth rules
Every generated artifact must point to its canonical input(s), generator path, generator/tool version, output path, generation timestamp or deterministic build ID, and integrity hash. Hand-edited generated output is not authoritative.

## Generation contract
- Validate schema and inputs before writing.
- Normalize ordering and serialization for deterministic output.
- Reject unknown fields unless the schema explicitly permits extensions.
- Never evaluate configuration values as code.
- Write to a temporary path, verify output, then replace only when the operation is authorized.
- Emit a dry-run diff and generation report.
- Preserve existing outputs by default; replacement requires explicit confirmation.

## Drift check
Compare current generated output to a fresh generation in a disposable path. Report exact differences. Do not automatically overwrite a developer's local artifact during a check.
