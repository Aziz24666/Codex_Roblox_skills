# V5 Genre Compendium

Genre skills tailor player design; they never replace architecture/security/testing.

- **Sports/skill:** prototype controls/fairness; server owns results; test ties, simultaneous finishes, input modes, latency.
- **Pets/companions:** separate definitions from owned records; bound equips/path updates/replication; test respawn, streaming, ownership duplicates.
- **Farming/crafting:** data-driven recipes and deterministic conversions; server validates station/ownership/materials/cooldown; cap elapsed growth.
- **Building sandbox:** reviewed catalog and compact placement records; validate transform, boundaries, overlap, owner, cost, quota; never accept arbitrary Instance trees.
- **Rhythm:** original/licensed audio, deterministic charts, calibration/accessibility; do not trust client total score; test frame rate, latency, focus loss.
- **Party minigames:** explicit round states and adapters; cleanup every connection/instance; test empty rounds, ties, late join, rapid leave/rejoin.
- **Matchmaking:** DataStores for durable records, MemoryStore for temporary queues; idempotent messages and teleport recovery.
- **Puzzle/adventure:** explicit puzzle state, server-validated critical progression, softlock recovery, cooperative ownership.
- **Social/roleplay:** platform moderation/filtering where relevant, privacy-aware defaults, reporting/blocking, server permissions.

For every genre, document loop, failure state, fairness, devices, data, security surface, accessibility risks, and Studio cases.
