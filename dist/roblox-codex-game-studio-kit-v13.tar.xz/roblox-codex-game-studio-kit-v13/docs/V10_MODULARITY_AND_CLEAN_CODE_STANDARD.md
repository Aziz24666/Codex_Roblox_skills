# V10 Modularity and Clean Code Standard

## Goal
Code should be easy for the project owner to read, modify, and extend. Clean does not mean maximum abstraction; it means obvious responsibility, explicit data flow, and low surprise.

## Module contract
Every meaningful module documents:
- one-sentence responsibility and non-goals;
- public types and API;
- dependencies and execution context (server/client/plugin/shared);
- mutable state ownership;
- initialization/teardown order;
- events/remotes it owns or listens to;
- error and cancellation behavior;
- tests and evidence.

## Rules
1. One module should have one cohesive reason to change.
2. Separate definitions, runtime state, controllers, adapters, presentation, I/O, and persistence.
3. Keep data definitions immutable; clone per-instance runtime state when needed.
4. Prefer composition and explicit dependencies.
5. Keep public interfaces small, named, typed, and stable.
6. Avoid cyclic `require`, deep facade stacks, generic managers, global mutable tables, hidden dynamic module loading, and mega-modules.
7. Extract a helper when it clarifies repeated behavior or isolates a meaningful domain rule; don't extract a trivial one-use wrapper without reason.
8. Name functions by outcome; keep side effects visible.
9. Use structured error results for expected failure; do not suppress exceptions with empty `pcall` handlers.
10. Keep one source of truth for schemas/catalogs/generated files.
11. Keep configuration in data, behavior in reusable modules, instance state in instance-owned records.
12. Add comments for why/constraints, not to narrate obvious syntax.

## Review questions
Can a new developer locate the source of truth? Can they add another variant by changing data? Can they test the pure logic without Studio? Can they see what mutates the DataModel? Can they identify where state lives? Does the design have fewer concepts than the problem requires?
