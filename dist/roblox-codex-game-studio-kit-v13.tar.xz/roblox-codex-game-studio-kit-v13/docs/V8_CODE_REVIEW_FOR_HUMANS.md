# V8 — Human-Friendly Code Review

Review each new module with these questions:
1. Can I describe its responsibility in one sentence?
2. Are its inputs, outputs, dependencies, and execution side obvious?
3. Can I add a new data definition without copying code?
4. Can I add a new behavior without editing unrelated systems?
5. Does mutable state belong to one instance?
6. Are errors reported with useful field/module context?
7. Are event connections, tasks, Instances, and path computations cleaned up?
8. Are shared configs protected from accidental mutation?
9. Are external references validated?
10. Is there a test that exercises the contract?

Reject code that is clever but difficult to extend. Prefer a small obvious adapter over reflection or dynamic dispatch when the latter hides the call graph.
