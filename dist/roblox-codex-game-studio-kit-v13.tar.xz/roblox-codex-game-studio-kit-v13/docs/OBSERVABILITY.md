# Observability and Game Health

Observe system health without collecting unnecessary personal information.

## Useful operational signals
- load/save success and failure rates;
- remote validation rejection counts (aggregated, not raw payload dumps);
- server/client error frequency by system;
- session startup failures;
- activity completion and stuck states;
- matchmaking/teleport success if used;
- performance samples by device class where supported;
- asset loading failures.

## Privacy and minimization
Collect only what is needed to improve reliability and experience. Avoid sensitive personal information, raw chat, credentials, unnecessary identifiers or detailed behavioral profiles. Follow Roblox policy and applicable privacy requirements. Do not add external analytics services or transmit data externally without explicit approval.

## Diagnostics
Use stable event names, bounded cardinality, sampling where appropriate and clear retention expectations. Logs should help diagnose a system, not expose private player data. Keep player-facing messages separate from developer diagnostics.
