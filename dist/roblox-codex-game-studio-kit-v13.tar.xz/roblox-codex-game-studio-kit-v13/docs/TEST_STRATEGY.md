# Test Strategy and Evidence

## Testing layers
1. **Static:** formatting, lint, type analysis and project structure checks.
2. **Unit:** deterministic functions and pure logic.
3. **Integration:** modules, remotes, persistence adapters and system boundaries.
4. **Studio runtime:** actual engine behavior, physics, UI, animation, audio and lifecycle.
5. **Multiplayer:** multiple clients, shared state, ordering, concurrency and late join.
6. **Device:** mobile, desktop and controller paths declared by the product.
7. **Release regression:** core loop and critical systems after integrated changes.

## Test case format
ID, requirement, setup, steps, expected result, observed result, environment, pass/fail/block, evidence and notes.

## Negative tests
Include invalid type, missing data, out-of-range, repeated action, simultaneous action, player death/leave, unavailable asset, delayed response, data failure, streamed-out content and full/empty state where relevant.

## Studio honesty
Record Studio mode, client count, device emulation, output log result and exact flow tested. A test not run is `NOT RUN`, not pass. A local build is not proof of successful Roblox runtime behavior.

## Defect severity
- Critical: data loss, unauthorized high-impact state change, severe exploit or core experience unavailable.
- High: major loop or common path broken.
- Medium: limited feature degraded or workaround exists.
- Low: minor UI/content issue.
- Note: improvement or non-blocking risk.

## Evidence quality
Prefer reproducible steps, output logs, test results, screenshots or profiling captures produced by the actual environment. Do not invent screenshots, performance numbers or test output.
