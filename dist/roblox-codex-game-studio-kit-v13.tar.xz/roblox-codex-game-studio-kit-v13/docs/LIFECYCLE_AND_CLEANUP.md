# Lifecycle, Connections and Cleanup

Every long-lived resource needs a clear owner and a cleanup event.

## Resources to track
- RBXScriptConnections;
- task threads or delayed callbacks;
- temporary Instances and cloned models;
- animation tracks and sound instances;
- pathfinding state and movement controllers;
- per-player/per-character tables;
- UI listeners and input bindings;
- rate-limit buckets and session state.

## Ownership scopes
Consider these lifetimes separately:
- server process;
- player session;
- character spawn;
- round/activity;
- UI screen;
- short interaction.

Do not attach a character-specific connection to a server-global owner without a cleanup path. Do not leave player keyed data after departure unless deliberately persisted or bounded.

## Cleanup procedure
1. List resources created by the system.
2. Identify owner and end condition.
3. Store handles or create a cleanup container.
4. Disconnect/cancel/destroy idempotently.
5. Protect callbacks from using stale state after cleanup.
6. Test repeated create/destroy, respawn, leave and shutdown.

Cleanup should be safe to call more than once. Avoid retaining references to destroyed characters or UI objects.
