# V13 Roblox Workflow Profile Selection

Roblox documents distinct source-of-truth models. Choose based on how the project is actually authored.

| Profile | Source of truth | CI scope |
|---|---|---|
| `studio-native` | Roblox Studio place | repository metadata/tests; no full place build assumed |
| `script-sync` | Studio place, with scripts mirrored to files | script checks and Git review; do not assume non-script instances are tracked |
| `partially-managed-rojo` | Git for code, Studio for most content | lint/build code mapping where practical; Studio validates content integration |
| `fully-managed-rojo` | Git for code and managed content | pinned Rojo build plus asset/content validation and gated deployment |
| `hybrid` | Explicit ownership per service/content family | profile must specify each directory/service owner and conflict rules |

## Decision process
1. Inventory current repository, Studio project, synced folders, place IDs, Rojo project files, packages, and Team Create use.
2. Write `workflow-profile.json`; identify ownership at least for scripts, world/maps, UI, assets, tags/attributes, and configuration.
3. Identify unsynced or Studio-only content. Do not assume a file build contains it.
4. Pick the simplest profile that solves source-control and collaboration requirements.
5. If migrating, create a copy/branch and a content reconciliation plan first.
6. Add only the checks the profile can actually support.

Do not treat Rojo as an official Roblox-maintained product. Pin its version and check its upstream documentation. Script Sync is a built-in Studio option and has different sync boundaries. Re-read the official workflow comparison before migration.
