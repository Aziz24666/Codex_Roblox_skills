# V11 Defect Isolation and Recovery

## Workflow
1. Capture the exact symptom, reproduction steps, environment, and frequency.
2. Identify recent changes and affected runtime context.
3. Form a small set of hypotheses; do not patch randomly.
4. Minimize the reproduction in a disposable place/fixture when possible.
5. Inspect logs, state transitions, module boundaries, and relevant platform documentation.
6. Find the root cause and the smallest correct fix.
7. Add a regression test that fails before the fix and passes after it.
8. Re-run the impact-based test set.
9. Record residual risk and recovery/rollback instructions.

## Recovery rules
- Preserve the user's uncommitted work.
- Prefer a small reversible patch over a large rewrite.
- Do not reset player data or overwrite public content to reproduce a bug.
- If the issue affects live data or service state, stop before mutation and request approval.
