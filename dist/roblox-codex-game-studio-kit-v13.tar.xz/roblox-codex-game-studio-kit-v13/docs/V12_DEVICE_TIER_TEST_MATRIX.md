# V12 Device-Tier Test Matrix

## Define tiers from the audience
Choose representative physical devices or a clearly documented Studio emulator profile for low, mid, and high tiers. A tier should describe hardware/performance capabilities, not an assumed demographic.

## Matrix dimensions
- Device model/OS or emulator profile.
- Studio/engine build and game build.
- Graphics quality and display resolution.
- Input: touch, keyboard/mouse, gamepad.
- Network: normal and relevant degraded conditions.
- Client count and server context.
- Scenario: first join, common gameplay loop, dense area, scene transition, long session, respawn/re-entry.

## Evidence
Record frame-time/FPS observations, memory, load/join time, input correctness, UI layout, and streaming behavior where relevant. Capture actual device model and whether the run was emulated.

## Status vocabulary
Use `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, or `NOT APPLICABLE`. Emulation is not physical-device verification.
