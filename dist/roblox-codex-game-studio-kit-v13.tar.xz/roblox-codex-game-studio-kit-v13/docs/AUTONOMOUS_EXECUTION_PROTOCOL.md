# Autonomous Execution Protocol



## Purpose

This protocol lets Codex make independent progress without uncontrolled scope expansion. Autonomy means independently completing reversible local work, not taking authority over accounts, production data, publishing, spending, or irreversible actions.

## Task classification

At intake, classify the request:
- **Discovery:** inspect, explain, audit, or plan.
- **Feature:** add or modify one player-facing capability.
- **System:** change a cross-cutting foundation.
- **Repair:** reproduce and fix a defect.
- **Quality:** test, profile, harden, or refactor.
- **Release:** prepare or carry out a controlled release.

Identify the expected player outcome and define explicit non-goals.

## Decision tiers

| Tier | Examples | Default action |
|---|---|---|
| A — reversible local | Naming, small module boundaries, UI spacing, local tests | Decide, implement, document |
| B — impactful but reversible | New dependency, schema extension, major system interface | Compare options, choose safest, document trade-off; ask only if it changes user intent materially |
| C — destructive or externally visible | Delete user content, migrate production data, publish, upload/replace public assets, change permissions, spend Robux | Stop before action; present plan and request explicit authorization |

## The execution loop

1. **Read:** instructions, history, repository, project status, relevant skill.
2. **Frame:** player outcome, scope, constraints, unknowns, risks.
3. **Plan:** dependency-ordered tasks, acceptance criteria, proof for each.
4. **Probe:** test the highest-risk assumption cheaply.
5. **Build:** implement one coherent slice.
6. **Check:** run the smallest fast checks first, then deeper checks.
7. **Inspect:** review diff, logs, security, lifecycle, performance, and accessibility.
8. **Record:** update status, decisions, tests, and known issues.
9. **Continue:** take the next independent task while budget and scope allow.
10. **Handoff:** report the result and blockers; do not invent future work or claim background execution.

## Progress state

Maintain a concise status record with `Not started`, `In progress`, `Blocked`, `Ready for verification`, `Verified`, or `Done`. `Done` requires acceptance evidence. Do not report tasks as done merely because code was written.

## Context management

- Read the primary skill first, then only references relevant to the current feature.
- Keep a compact source-of-truth index of architecture, commands, test setup, and unresolved decisions.
- Do not repeatedly reread the entire repository when a reliable audit exists; verify changed areas and stale assumptions.
- Before a context handoff, write current objective, changes, commands/tests, blockers, and next action into project status.

## When blocked

Try safe alternatives, isolate the missing capability, and complete preparatory work. Examples: produce Studio-ready scripts when Studio automation is absent, produce a manual test checklist when runtime is unavailable, or run local validators when a build tool is missing. Label the exact check as `BLOCKED` or `NOT RUN`.

## Stop conditions

Stop before any Tier C action. Also stop if a requested feature would require hidden backdoors, credential exposure, policy evasion, unsafe data collection, or a harmful player experience. Offer a safe alternative only when appropriate.
