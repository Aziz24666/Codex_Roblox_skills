# V6 Open Cloud and External Mutation Governance

## Purpose
Allow Codex to prepare and, where an explicitly available connector/API exists and the user approves, execute well-defined external Roblox operations without treating project access as permission to change a live experience.

## Operation classification
- Read-only inspection.
- Local artifact generation.
- Development/staging mutation.
- Production mutation.
- Public asset or release action.
- Permission/account/group change.
- Irreversible or hard-to-reverse action.

Classify before invoking any external action.

## Preflight
A change request must identify exact API/operation, target universe/place/resource, environment, permission scope, expected before/after state, user-visible impact, data-loss risk, rollback, and verification method. Require a dry-run for bulk or destructive work.

## Approval
Explicit approval is required before production mutations, publishing, public asset uploads/replacements, permission changes, place creation/deletion, production data reads/writes/migrations, or account changes. Approval for one action does not authorize a broader batch.

## Secret management
Use least-privilege, short-lived or rotated credentials where supported. Store them only in an approved secret store/environment configured by the user. Do not ask the user to paste secrets in chat or source files. Scan logs and generated artifacts for accidental disclosure.

## Execution record
Record operation ID, target, API/version, start/end time, result, response identifier, errors, rollback status, and user approval reference. Exclude secret values and unnecessary player data.

## Failure handling
Do not blindly retry non-idempotent operations. Confirm whether a request may have succeeded before retrying. Reconcile state and report partial completion. Never claim rollback unless the target state was inspected afterward.
