# V7 Player Journey and Onboarding

## Journey map
For each target persona/device, map: discover → join → orient → first action → first feedback → first success → core-loop repetition → progression choice → social/returning session.

## First-session design
- Show a clear goal quickly; keep essential action visible.
- Teach through one action at a time, then let the player act.
- Distinguish critical instruction from optional tips.
- Provide skip, pause, resume, and help access where appropriate.
- Avoid blocking players behind a tutorial sequence that can be completed through normal play.
- Do not promise rewards or progress before server confirmation.

## Tutorial data model
Use stable step IDs and a version. A step may define prerequisites, localized title/body, target action, visual cue, completion condition, and optional server-side reward. Do not persist transient animation/timer state unless required.

## Returning and migration behavior
If tutorial content changes, define how existing players are mapped to the new version. Never reset unrelated progression. Ensure reward grants are idempotent.

## Metrics
Measure completion funnel and drop-off only with privacy-conscious, approved analytics. Avoid collecting unnecessary personal data. Do not treat correlation as causal proof.

## QA matrix
Fresh profile, returning profile, tutorial skipped, interrupted, reconnect, respawn, low-resolution/touch, gamepad, localization, and reward retry.
