# V10 Baseline Research Snapshot — 2026-11-15

This is a dated starting snapshot, not a substitute for fresh research on future tasks. The links below were opened/searched during V10 authoring on 2026-11-15. Re-open current pages before using the relevant approach.

## Findings used in V10

### 1. Roblox Studio MCP is now a first-party Studio integration
The current Creator Hub MCP guide describes a built-in Studio MCP server and tools for DataModel exploration, script read/search/edit, Luau execution, asset/content generation, specialized subagents, and playtesting. It also notes that clients connect to an active local Studio session. V10 therefore instructs Codex to discover actual tools/session IDs and use MCP when genuinely available, while preserving source-control discipline.

- https://create.roblox.com/docs/studio/mcp
- https://devforum.roblox.com/c/updates/announcements/36

### 2. Roblox documents multiple source-of-truth workflows
The current workflow comparison distinguishes Studio-native, partially managed, and fully managed approaches. It recommends starting with the simplest workflow that meets the need and notes that fully managed workflows add complexity. Script Sync and Rojo have different purposes; Rojo is community-maintained. V10 therefore requires project inspection and deliberate workflow selection rather than auto-migrating to Rojo.

- https://create.roblox.com/docs/projects/file-based-workflows
- https://create.roblox.com/docs/scripting/sync
- https://create.roblox.com/docs/projects/rojo
- https://rojo.space/docs/

### 3. Security guidance places authority on the server
Roblox's security docs instruct developers to treat client-supplied data as manipulated and keep critical validation/server state authoritative. Remote communication semantics also differ: RemoteEvents are one-way, RemoteFunctions yield for request/response, and UnreliableRemoteEvents trade ordering/reliability for appropriate transient data. V10 makes these boundaries explicit and requires threat-model testing.

- https://create.roblox.com/docs/scripting/security/security-tactics
- https://create.roblox.com/docs/scripting/security/client-server-boundary
- https://create.roblox.com/docs/scripting/events/remote

### 4. DataStore recommendations are specific and operational
Current best practices include using a small fixed set of stores, stable key patterns, in-memory buffering, bounded retries with exponential backoff and jitter, ordered retries per key, and UpdateAsync when concurrent/current-state writes matter. V10 requires fresh verification of the relevant guidance rather than generic save-script patterns.

- https://create.roblox.com/docs/cloud-services/data-stores/best-practices

### 5. Testing is multi-layered and Studio supports multiple modes
Creator Hub describes client/server and multi-client testing, plus Studio-only scripted testing facilities. V10 separates static checks, builds, solo play, multi-client, device emulation, and physical-device tests and records actual evidence for each.

- https://create.roblox.com/docs/studio/testing-modes
- https://create.roblox.com/docs/reference/engine/classes/StudioTestService

### 6. Performance should be measured, not guessed
Current performance docs highlight high-frequency event work, expensive table operations, memory behavior, instance streaming, and profiling. Device docs also recommend real hardware/network testing for representative conditions. V10 requires before/after measurements and avoids speculative pooling or micro-optimization.

- https://create.roblox.com/docs/performance-optimization
- https://create.roblox.com/docs/performance-optimization/improve
- https://create.roblox.com/docs/performance-optimization/test-on-hardware

### 7. DataModel packages and source organization are part of maintainability
Roblox packages support reusable, versioned instance hierarchies. V10 treats package reuse as one option alongside code modules and schema-driven definitions, with asset provenance and review before insert/update.

- https://create.roblox.com/docs/projects/assets/packages

### 8. Luau strict typing remains a key quality tool
Creator Hub documents Luau gradual typing and `--!strict` behavior. V10 recommends strict mode for new or significantly modified modules where practical, while avoiding unsafe blanket annotation changes without testing.

- https://create.roblox.com/docs/luau
- https://create.roblox.com/docs/luau/type-checking

## Important dates and limitation
Roblox updates can be pending, gated, or rolled out gradually. The current update feed and official Developer Forum announcements should be searched during each task. This snapshot does not claim every linked feature is available in every Studio build or account.
