# Multiplayer Test Matrix

Run relevant cases in Studio with multiple clients. One-client testing cannot reveal all shared-state and replication defects.

| Scenario | What to verify |
|---|---|
| Two players interact with same object | Only valid state transition wins; no duplicate rewards |
| Two players claim a shared objective | Consistent ownership and reward rules |
| One player leaves during action | No stale references, stuck locks or partial state |
| Late join | Current shared state is reconstructed correctly |
| Respawn during activity | Character-bound resources are recreated and cleaned |
| Repeated remote request | Server rate and state validation prevent duplicate effects |
| Delayed response | UI shows pending/failure correctly and reconciles state |
| One client loses streamed objects | Other clients/server continue consistently |
| Simultaneous purchases/claims | No double-spend or duplicate grant |
| Server shutdown during save | Best-effort save and documented risk behavior |

Record client count, exact setup, actions, server/client logs, outcome and unresolved issues.
