# V8 — Human Extension Guide

A finished reusable system must explain common modifications in plain language.

## Add an NPC variant
1. Add a new entry in `NPCDefinitions.lua` with a unique ID.
2. Choose an existing supported behavior (`Wander`, `Follow`, `Patrol`, `Guide`, `VendorIdle`).
3. Set movement/presentation values.
4. Assign the `DataDrivenNPC` tag and `NPCDefinitionId` attribute to the rig.
5. Validate the config and run the NPC test matrix.
6. Do not add another movement Script.

## Add a new behavior
1. Create a focused module implementing the documented behavior interface.
2. Define its config type and validator.
3. Register it in `BehaviorRegistry` using a typed, explicit key.
4. Add a definition fixture and transition tests.
5. Update the extension guide and debug-state display.

## Add a utility gadget
1. Create a schema-valid gadget definition.
2. Choose an approved template and asset references.
3. Preview/validate in the Studio content editor.
4. Generate a new prefab and inspect the generated hierarchy.
5. Connect the utility kind to a reviewed runtime handler if it is not already supported.
6. Do not create a one-off script inside each gadget.

## Change shared movement
Update `MovementController` once, add regression coverage, and test all NPC definitions because shared changes have broad impact.
