# V6 Multi-Place Universe Architecture

## Goals
Make a multi-place experience feel like one game while treating transitions, data, and party state as explicit contracts.

## Place map
For each place record: stable name, place ID (never fabricate), role, public/private/reserved status, environment, source-of-truth ownership, entrypoint, assets required, audience, expected player count, and fallback behavior. Keep `universe.manifest.json` in sync with actual project configuration.

## Responsibility boundaries
Typical responsibilities:
- Start place: onboarding, routing, party setup, safe fallback.
- Hub: social presence, queue UI, loadout, progression view.
- Match place: authoritative match lifecycle and settlement.
- Instance place: isolated cooperative or challenge session.
- Test place: isolated test data and unpublished/controlled deployment.

Do not create extra places without a gameplay, scaling, or operational reason.

## State categories
- Durable: progression, owned items, settings, long-term results. Use a durable data design and concurrency rules.
- Temporary cross-server: queues, server presence, reservations/leases. Define expiry and stale-entry cleanup.
- Server-local: current match state, NPC state, local round clock.
- Transition hints: minimal versioned routing context. Never treat as authority for currency, ownership, permissions, purchase fulfillment, or final rewards.

Roblox documents DataStores as cross-place/cross-server durable data, while MemoryStores are temporary/expiring shared data. Re-check current limits and behavior before implementation.

## Transition contract
Define source and destination, trigger, party validation, payload schema/version, maximum payload size, correlation ID, expiry, retry policy, failure UX, duplicate-arrival strategy, and recovery route. Verify the current TeleportService API signatures and platform requirements from the official docs.

On arrival, validate all payload fields, then fetch canonical entitlements/progression from trusted server-owned sources. Assume a transition can fail, arrive late, be repeated, or be interrupted.

## Cross-server messages
Use cross-server messaging only for appropriate ephemeral event distribution. Treat messages as notifications, not a durable transaction log. Include schema/version, idempotency key, expiry, and consumer behavior. Reconcile important state through durable storage.

## Test plan
Test destination unavailable, party member leaves, duplicate transition, stale/expired payload, malformed payload, join after transition, data mismatch, server shutdown, rejoin, queue cleanup, and fallback to start/hub. Verify data consistency from more than one place.
