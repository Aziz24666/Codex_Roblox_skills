# V11 API Currency and Deprecation Management

Before using an API, verify the exact class/member/page, security context, client/server/plugin availability, thread safety when relevant, deprecation/beta status, engine version or feature rollout, and relevant limits. Use official Creator Hub/API reference as the authority for signatures and guarantees. Use release notes/announcements for rollout context. Third-party tools require their upstream documentation and version history.

Maintain a lightweight API inventory only for platform surfaces the project actually depends on. Do not create a giant speculative list. When a project upgrades a tool or migrates an API, run targeted compatibility tests and update the decision record.
