# V12 CollectionService Lifecycle

## Preferred per-instance signals
Use `GetInstanceAddedSignal(tag)`, `GetInstanceRemovedSignal(tag)`, and `GetTagged(tag)` for tag-driven component registration. Current docs mark the older `ItemAdded`/`ItemRemoved` events as deprecated.

## Safe startup order
1. Create a `cleanupsByInstance` map.
2. Connect the added signal.
3. Connect the removed signal.
4. Enumerate already tagged instances via `GetTagged()`.
5. Route every attach through one idempotent function.

Connecting before enumeration prevents missing an instance added during initialization; idempotency prevents double attach if the signal and enumeration observe the same instance.

## Cleanup contract
An attach callback should return a cleanup function. On tag removal, instance destruction, or binder shutdown, invoke cleanup once, remove the map entry, and release references. Protect cleanup with `pcall` where teardown must continue despite one faulty component.

## Replication note
Tags replicate from server to client. Client-added tag changes can be overwritten by server tag replication. Treat client-side tag mutations as local/temporary and never use them as authoritative state.

## Anti-patterns
- Connecting only to added events and never to removed events.
- Registering only future additions and ignoring objects tagged before startup.
- Allowing multiple attach calls to allocate duplicate resources.
- Leaving connections alive after detach.
- Using deprecated CollectionService signals without a verified compatibility reason.
