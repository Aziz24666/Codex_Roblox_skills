# V10 Asset and Package Provenance

Track assets by ID, asset type, creator/owner when visible, source, package/version, permissions/experience access, moderation/availability, dependencies, embedded scripts, and last actual load verification. Syntax-only ID validation is not provenance or permission proof.

Inspect imported models/packages before use. Identify scripts, remotes, hidden descendants, external requires, unusual constraints, and unexpected runtime behavior. Prefer owned/reviewed assets and packages. Keep package version and update behavior explicit. Recheck official package, asset, and permission docs before automation or upload. Public upload and permission changes require explicit owner authorization.
