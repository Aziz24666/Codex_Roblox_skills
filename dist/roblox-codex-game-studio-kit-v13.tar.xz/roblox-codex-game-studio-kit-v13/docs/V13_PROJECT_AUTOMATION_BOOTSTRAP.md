# V13 Project Automation Bootstrap

1. Detect repository and source-of-truth profile.
2. Ask only for decisions that cannot be inferred safely: chosen workflow, target place mapping, expected CI provider, and intended deployment policy.
3. Create a project profile, toolchain pin file, test inventory, and quality-gate configuration.
4. Add read-only CI checks first; do not add publishing credentials or production jobs.
5. Add Luau analyzer/formatter/build steps only when their exact versions and project support are verified.
6. Add Studio test automation after confirming Studio plugin capability and permissions.
7. Verify that clean checkout reproduces the same checks.
