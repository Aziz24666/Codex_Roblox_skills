# V7 Inventory and Loadout Contracts

## Data model separation
- Catalog definition: immutable item identity and rules.
- Owned instance: player-specific item ID, optional instance ID, quantity, and allowed state.
- Loadout: ordered slot-to-owned-item references.
- UI projection: client-facing view derived from server state; never canonical ownership.

## Operations
Grant, remove, consume, equip, unequip, move, split, merge, and restore each need preconditions, idempotency key, result, and audit/debug event. Avoid generic mutation endpoints that accept arbitrary properties.

## Validation
Check item allowlist, ownership, quantity, capacity, slot compatibility, prerequisites, match state, and request duplication on the server. Clamp bounded numeric inputs and reject NaN/infinity. Never accept client-provided item value, rarity, entitlement, or reward amount.

## Persistence
Use versioned schema, size limits, migration, safe retries, and explicit load-failure behavior. Do not save transient UI selection unless it affects player experience and is intentional.

## Synchronization
Replicate only the player-visible data needed. Handle stale requests and update UI from confirmed server state. Provide explicit pending/error/empty/loading states.

## Tests
Full capacity, last item, stack edge, same item in two slots, stale catalog, duplicate grant/remove, equip race, disconnect during save, migration, and load failure.
