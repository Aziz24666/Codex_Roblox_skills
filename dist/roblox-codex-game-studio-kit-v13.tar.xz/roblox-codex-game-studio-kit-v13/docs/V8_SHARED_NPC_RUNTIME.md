# V8 — One Shared NPC Runtime, Many Data Definitions

## Intended result
One movement implementation and one small behavior registry serve every NPC. New variants are data-only when they use an existing supported behavior. Adding a genuinely new behavior adds one behavior module, not a duplicate controller.

## Instance setup
- Add the `DataDrivenNPC` CollectionService tag to each NPC Model.
- Set the `NPCDefinitionId` attribute to a key in `NPCDefinitions`.
- Ensure the model has a valid Humanoid and root part (or define a documented adapter for another rig type).
- Do not insert a copy of the movement script into the model.

## Definition example
`VillageGuide` may select `Patrol`, speed 10, arrival radius 3, turn smoothing 0.18, route ID `VillageLoop`, and walk/idle animation references. `Companion` may select `Follow`, speed 13, follow offset, stop distance 5, and idle/walk/run animation references. Both run through the same `NPCController` and `MovementController`.

## Runtime composition
- `NPCBootstrap`: discovers tagged models and attaches/detaches controllers.
- `NPCDefinitionRegistry`: resolves, validates, normalizes, and freezes definitions.
- `NPCController`: owns the per-model runtime state and composes other services.
- `MovementController`: handles path requests, waypoint following, turn/movement settings, stuck recovery, and cancellation.
- `BehaviorRegistry`: maps a strict behavior name to a module implementing a narrow interface.
- `AnimationPresenter`: maps movement state to animation references.
- `Diagnostics`: exposes state/route/path failures in development builds.

## Behavior interface
A behavior receives a read-only definition plus a per-instance context (model, movement adapter, clock, route resolver, and state). It can request a destination or wait for an event; it cannot mutate the registry or reach arbitrary server services.

## Safe behavior set in this example
`Wander`, `Follow`, `Patrol`, `Guide`, and `VendorIdle`. Do not let a behavior module quietly become an unrelated all-purpose brain. Add new policies explicitly and document their contracts.

## Performance
Stagger periodic decisions, avoid path recomputation every frame, share route data, cap concurrent path requests, reduce work for distant/inactive NPCs where appropriate, and clean up on removal. Test multiple simultaneous definitions, malformed IDs, blocked paths, despawn, and server load.
