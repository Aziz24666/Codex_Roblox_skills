# V4 Progression Balancing and Simulation

Balance the player journey with measurable hypotheses, not arbitrary increases to prices or grind.

## Model the loop

List player actions, time/effort inputs, reward outputs, resource sinks, unlock gates, and the next meaningful choice. Use a table or small spreadsheet-friendly data set for costs, rewards, and expected progression. Keep all consequential formulas server-owned.

## Simulate before tuning

Create a deterministic simulation for representative player profiles: new, typical, highly active, and returning after a break. Simulate earning rates, unlock times, inventory capacity, resource overflow, and upgrade value. Use scenarios, not a single average.

## Fairness rules

- Explain costs and effects before the player commits.
- Do not create paid random reward mechanics or gambling-like loops.
- Avoid false urgency and misleading scarcity.
- Ensure free progression is coherent and intentionally paced.
- Make mistakes recoverable where possible.
- Test whether one strategy dominates all alternatives.
- Avoid progression cliffs that abruptly invalidate player effort.

## Telemetry

Measure aggregate events needed to evaluate the design, such as tutorial completion, time to first meaningful action, stage completion, retry frequency, session length bands, and progression bottlenecks. Minimize collection, avoid unnecessary personal data, and respect applicable platform policies. Analytics are evidence about patterns, not a substitute for qualitative playtesting.
