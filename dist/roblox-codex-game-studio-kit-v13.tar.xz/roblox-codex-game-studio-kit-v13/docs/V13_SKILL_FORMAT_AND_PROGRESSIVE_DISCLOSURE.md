# V13 Skill Format and Progressive Disclosure

Each `.agents/skills/<skill>/SKILL.md` must have a valid YAML frontmatter block with exactly the `name` and `description` fields before the closing `---`. Do not place headings or body text inside frontmatter.

Keep descriptions short and specific about when to use the skill. Put detailed procedures, long checklists and examples in linked references. Root skill files should route the agent, not duplicate the whole manual. Load only skills relevant to the task.

The V13 skill audit verifies:
- frontmatter opens and closes correctly;
- `name` matches the folder and is unique;
- description is non-empty and within the configured length;
- no Markdown body appears inside frontmatter;
- the body contains a relevant focused reference.
