# Public repository and CI guide

## Repository metadata

Suggested repository name: `roblox-codex-game-studio-kit`

Suggested GitHub description:

> Research-first Roblox game-development toolkit for Codex: modular Luau systems, data-driven NPCs, schema-driven Studio editors, prefab factories, testing, and CI.

Suggested topics: `roblox`, `roblox-studio`, `luau`, `codex`, `game-development`, `data-driven-architecture`, `studio-plugin`, `github-actions`, `testing`, `modular-architecture`.

## CI design

The active workflow is `.github/workflows/ci.yml`. It separates Python package checks from Roblox/Luau build validation. Luau and Rojo downloads are version-pinned and SHA-256 verified before use. GitHub Actions references are immutable full commit SHAs.

The pipeline compiles every `.lua` and `.luau` source file as a syntax check. It also runs Rojo builds for the sample experience and Content Factory plugin. Luau CLI compilation does not provide Roblox Studio's full type environment and is not a substitute for Studio tests.

## Build artifacts

The workflow uploads:
- `RobloxExperience.rbxlx`: generated from `project-template/default.project.json`.
- `ContentFactoryPlugin.rbxmx`: generated from `studio-plugin/default.project.json`.

These are build artifacts for inspection/testing, not automatically published experiences or installed plugins.
