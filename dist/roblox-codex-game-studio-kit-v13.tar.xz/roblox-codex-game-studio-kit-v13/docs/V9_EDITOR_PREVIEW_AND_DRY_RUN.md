# V9 — Preview and Dry-Run

## Invariants
Preview must not create, reparent, tag, rename, or change properties of DataModel instances. It may clone a source into a `ViewportFrame`-owned `WorldModel`, provided the clone stays under the preview UI and is cleaned up on refresh/close.

## Preview output
- selected family and definition ID;
- selected source/template and compatibility check;
- planned output paths;
- intended hierarchy and child references;
- required and optional asset fields;
- unresolved or unverified assets;
- collision status;
- generator/template/schema versions.

## Dry-run checks
Perform parsing, schema checks, semantic checks, template requirements, source type checks, and output-collision checks before starting any ChangeHistoryService recording. If any hard error remains, disable Generate.

## Staleness
A preview is stale whenever a field, selected source, schema version, target output root, or template selection changes. Display `Preview outdated`; require re-preview before generation.
