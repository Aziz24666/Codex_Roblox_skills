# V7 Round and Session State Machines

## Required contract
State machine ID/version, states, legal transitions, transition owner, entry/exit effects, timeout, cancellation, replication shape, persistence boundary, and recovery behavior.

## Example states
`WaitingForPlayers → Intermission → Loading → InProgress → Resolving → Results → Returning`. Use fewer states if the experience is simpler; never keep a state only because it appears in this example.

## Invariants
- Only the server changes canonical match state.
- Each transition has a server-side guard and stable event/round ID.
- End-of-round settlement is idempotent.
- A player can be a spectator/participant/removed only through a documented transition.
- Disconnect and server shutdown have defined semantics.
- Timers use a server-owned deadline; clients render remaining time, not dictate it.

## Concurrency
Serialize or guard transitions. Reject stale transition versions. Make repeated end, payout, or reward requests safe. Decide how simultaneous last-player departure and match resolution are ordered.

## Recovery
Define reconnect policy, result persistence, place transition fallback, and behavior when a destination cannot be reached. A teleport payload is not canonical inventory/currency truth.

## Verification
Test every legal transition, representative illegal transitions, timing boundary, duplicated request, disconnect at each phase, late join, server-empty, and settlement retry.
