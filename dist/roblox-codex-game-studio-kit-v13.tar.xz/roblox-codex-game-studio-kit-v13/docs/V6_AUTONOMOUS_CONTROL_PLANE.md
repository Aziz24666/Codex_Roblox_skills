# V6 Autonomous Development Control Plane

## Purpose
Turn long game-building requests into small, inspectable, restartable development tasks. Codex should operate independently on reversible work while preserving user control over destructive or external operations.

## 1. Session bootstrap
Before editing, write down:
- Repository and branch; working tree status.
- Project source of truth and project/toolchain versions.
- Available tools and permissions, each marked `AVAILABLE`, `UNAVAILABLE`, or `NOT VERIFIED`.
- Existing architecture, important directories, entrypoints, mappings, and tests.
- Current game build state and top known risks.

Do not treat previous generated documentation as ground truth until compared with the repository.

## 2. Task graph
Each task should have:
- Stable ID and concise title.
- Player outcome / defect being addressed.
- Inputs and assumptions.
- Dependencies and blocking reason.
- Owned files or modules.
- Execution context (server/client/shared/Studio tooling).
- Acceptance criteria with observable outcomes.
- Risk class: local reversible, data-affecting, external, destructive.
- Test levels required.
- Status and evidence path.

Recommended states: `BACKLOG`, `READY`, `IN_PROGRESS`, `BLOCKED`, `REVIEW`, `VERIFIED`, `DONE`, `CANCELLED`. `DONE` requires acceptance evidence, not merely code completion.

## 3. Bounded work loops
For each task:
1. Read relevant instructions and skills only.
2. Inspect the exact code path and callers.
3. Form a short hypothesis and expected behavior.
4. Make the smallest coherent change.
5. Run the narrowest relevant check.
6. Inspect the diff and logs.
7. Expand test scope only after the narrow check passes.
8. Update traceability/evidence/status.

Limit repeated repair attempts. If two attempts fail for the same reason, stop and collect more information. If an error is not understood, do not suppress it or replace it with a broad catch-all.

## 4. Decision levels
**Autonomous:** local reversible edits, formatting, isolated tests, documentation updates, non-destructive validation, and clearly scoped refactors.

**Prepare but ask:** schema migration, broad dependency upgrades, place hierarchy rewrites, replacing source-of-truth workflow, large asset import, major economy changes, changes that can remove player progress.

**Explicit approval required:** publish/unpublish, production data operation, public asset upload/replacement, place creation/deletion, permissions, Robux spending, Creator Dashboard settings, contacting users, destructive repository operations, external services with irreversible effects.

## 5. Parallelism rules
Parallel tasks only when each has stable interfaces and separate file ownership. Do not parallelize simultaneous edits to shared modules, schemas, remote contracts, project mappings, root instructions, or migration files. Integrate serially and rerun shared checks.

## 6. Stop conditions
Stop and mark `BLOCKED` when required Studio access, tool credentials, API permissions, a user decision, test data, or an authoritative API reference is missing. Stop on suspected production impact, unexplained data loss, secret exposure, unexplained external mutation, repeated identical failures, or unclear destructive scope.

## 7. Handoff
A handoff must name exact branch/commit, changed files, task IDs, commands run, actual pass/fail/block status, evidence paths, remaining blockers, and next safe action. Do not say "continue" without telling the next session what to inspect first.
