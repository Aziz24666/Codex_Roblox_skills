# Performance Profiling Playbook



## Profile first

Identify the actual problem and reproduce it under a representative scenario. Capture a baseline before changing code. Record device or Studio environment, player/NPC count, map area, duration, and test conditions.

## Profile dimensions

- Client frame time and rendering cost.
- Server frame time and script activity.
- Memory growth and instance count.
- Network traffic and replication volume.
- Join/load time and streaming behavior.
- Physics and pathfinding cost.
- UI layout/animation work.
- DataStore/MemoryStore request volume and failures.

Use current Roblox profiling tools such as MicroProfiler and available Studio performance views. Confirm the exact current UI/workflow in Creator Hub before documenting a fixed click path.

## Optimization order

1. Remove unnecessary work and duplicate events.
2. Reduce unbounded loops/scans and per-frame allocations.
3. Reduce unnecessary instances, physics, and replication.
4. Use streaming and appropriate asset placement.
5. Batch or stagger non-urgent work.
6. Cache only when invalidation is clear.
7. Tune asset fidelity and UI effects for target devices.

## Before/after evidence

Use comparable conditions and record baseline, change, result, and side effects. Reject optimizations that improve one metric while breaking correctness, readability, accessibility, or maintainability. A guessed FPS improvement is not evidence.
