# V12 Performance Regression Policy

## When to run
Run the relevant performance comparison when a change affects loops, world density, asset loading, replication, streaming, rendering, UI updates, physics, persistence, or long-lived lifecycle resources.

## Comparable baseline rules
Build, place, Studio/engine version, device tier, scenario, client count, graphics level, and network profile must match or differences must be called out. Use repeated captures for noisy values.

## Gate behavior
- Missing evidence: `BLOCKED` or `NOT RUN`, never PASS.
- Exceeded budget: FAIL until investigated or a documented, reviewed budget update is accepted.
- Faster metric but broken gameplay: FAIL.
- Optimization with worse memory or join time: document the trade-off and evaluate against the product requirement.

## Review artifact
Attach baseline JSON, budget JSON, raw capture references, before/after summary, test selection rationale, and known limitations.
