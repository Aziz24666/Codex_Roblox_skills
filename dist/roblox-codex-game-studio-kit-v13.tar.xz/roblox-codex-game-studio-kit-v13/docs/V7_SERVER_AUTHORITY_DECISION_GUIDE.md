# V7 Server Authority Decision Guide

## Do not enable by slogan
A server-authority model may help experiences where competitive fairness and authoritative simulation matter, but it has engine prerequisites and behavior trade-offs. Confirm current feature status, compatibility, Studio version, and exact supported setup before adoption.

## Decision inputs
Genre, movement/physics complexity, latency sensitivity, existing character/controller architecture, use of custom simulation, replication requirements, device performance, and migration cost.

## If adopting
- Follow the exact current Creator Hub setup checklist; never copy property names from an old note without verifying.
- Identify client prediction, server confirmation, misprediction, rollback/resimulation, and input contract.
- Ensure gameplay decisions and persistent outcomes remain authoritative.
- Test normal and degraded network profiles, player counts, respawn, streaming, and ownership transitions.
- Measure before/after responsiveness and server/client cost.

## If not adopting
Continue to validate client requests and critical outcomes on the server. Network ownership or client prediction alone does not mean the client is trusted to award currency, inventory, damage results, match outcomes, or persistent progression.

## Evidence
Record platform feature availability, current configuration, tested build, Studio version, scenarios, and observed results. Do not claim server-authority guarantees from a static configuration review.
