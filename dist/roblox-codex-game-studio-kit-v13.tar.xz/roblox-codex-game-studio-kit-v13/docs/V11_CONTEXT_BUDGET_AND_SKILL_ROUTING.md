# V11 Context Budget and Skill Routing

## Why
A large skill library is useful only when the agent can select the right parts. Codex guidance favors concise, trigger-specific descriptions, minimal root routers, progressive disclosure, and keeping `AGENTS.md` current. This playbook applies those ideas to this kit.

## Rules
1. Keep root `AGENTS.md` limited to global invariants, research gate, safety boundaries, and routing.
2. Keep each skill's frontmatter description short, specific, and based on a real trigger. Do not make every skill say it applies to all Roblox work.
3. Keep `SKILL.md` as a router. Put detailed procedures, examples, schemas, and checklists in `docs/` or skill-local references.
4. Load the orchestrator plus the smallest relevant specialist set. Add networking, persistence, security, QA, or performance skills only when affected.
5. Read project docs contextually: architecture for boundaries, persistence for schema changes, release docs for releases, plugin docs for plugin work.
6. Remove duplicate rules, stale version labels, contradictory requirements, and obsolete tool instructions during maintenance.
7. Do not optimize context by deleting critical security, research, or approval requirements.

## Skill trigger quality review
A useful description answers: what workflow does this skill perform, and when should it be invoked? Avoid generic triggers such as "Use for all game development". Prefer specific phrases such as "Use when changing player-profile schema or migration code".

## Context budget process
- Inspect skill descriptions and count metadata length.
- Identify overlapping triggers and ambiguous names.
- Verify every referenced doc exists.
- Verify the main orchestrator routes to current skill names.
- Keep high-detail content behind a linked reference.
- Test the router with representative tasks and confirm it selects a minimal skill set.

## Completion
The skill library is complete when a task can find the right procedure without reading unrelated manuals and without losing a mandatory safety or research rule.
