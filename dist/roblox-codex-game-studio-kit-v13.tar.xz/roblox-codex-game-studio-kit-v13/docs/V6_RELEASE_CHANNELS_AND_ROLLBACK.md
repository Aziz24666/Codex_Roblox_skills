# V6 Release Channels, Rollout, and Rollback

## Environment separation
Define local, automated, Studio test, staging, and production environments. Each environment needs separate place targets and data safety rules. Never assume a Studio place is isolated from production DataStores; confirm the actual experience and API access configuration.

## Release manifest
Record release version, source commit, toolchain versions, artifact hashes, place targets, environment, schema versions, feature flags, migration plan, approval, tests, and rollback artifact.

## Promotion sequence
1. Local checks and tests.
2. Build artifacts and verify hashes.
3. Development Studio smoke test.
4. Multi-client/device/network checks as relevant.
5. Staging test with isolated data.
6. Review release manifest and migration/rollback.
7. Obtain explicit approval for publish/production mutation.
8. Perform one bounded release action.
9. Verify resulting experience/build and critical player flows.
10. Monitor and decide continue/rollback.

## Rollback is not always code-only
A code rollback cannot automatically reverse player-data migrations, purchases, public asset changes, or external configuration. For each irreversible change, define forward repair, compensating action, or manual recovery. Never roll back data by blindly restoring an older snapshot without understanding writes after the snapshot.

## Feature flags
Use flags for bounded rollout where supported. Define default, owner, audience, expiration date, fallback behavior, telemetry, and cleanup task. Do not leave permanent undocumented flags.

## Approval gate
Any production publish, public asset upload/replacement, permission change, place creation/deletion, or live-data migration requires explicit approval for the exact target and action.
