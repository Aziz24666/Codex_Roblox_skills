# V11 Open Cloud Luau Execution

Roblox documents a Luau Execution feature for running supported Luau tasks against a place through Open Cloud. Before relying on it, re-open the current API docs and verify endpoint version, authentication, limits, permissions, supported services, and availability for the target experience.

## Use only when
- The user's account/project has the required capability and permissions.
- The task is safe for the selected test place/version.
- The test is isolated from production player data and live mutations.
- The script and payload are reviewed and deterministic enough for the intended test.

## Do not assume
- Every Roblox account or experience has the same access.
- A headless task is identical to Studio play mode or a live server.
- Open Cloud Luau execution is automatically safe for production data.
- A task result proves client UX, device input, replication, or multiplayer behavior unless those were explicitly exercised.

Prefer disposable test places and record place/version, task identifier, logs, duration, and status. Recheck the current official docs before use.
