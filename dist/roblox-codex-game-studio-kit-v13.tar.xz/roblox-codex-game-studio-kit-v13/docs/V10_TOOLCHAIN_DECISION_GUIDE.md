# V10 Roblox Toolchain Decision Guide

Do not migrate a project just because one tool is familiar. First identify the source of truth for scripts, models, terrain, UI, assets, project settings, generated files, and place builds.

| Workflow | Good fit | Trade-off |
|---|---|---|
| Studio-native | Small single-place projects or workflows centered on Team Create | Simplest; source of truth stays in Studio; version-control coverage can be limited |
| Script Sync | Studio remains source of truth, but scripts should be edited/reviewed in a local IDE/Git | Built-in and less disruptive; does not by itself version the full DataModel |
| Partially managed Rojo | Code/config in Git, place assets/terrain/UI remain Studio-managed | Useful compromise; requires pinned community tooling and sync discipline |
| Fully managed Rojo | All place content should be built/reviewed from files and CI | Most reproducible; also highest setup/asset/merge complexity |

Roblox's current workflow comparison recommends starting with the simplest workflow meeting project needs; many teams do not need fully managed Rojo. Rojo is a community tool, not maintained by Roblox. Confirm current Rojo/Rokit versions and upstream docs before installing or upgrading.

## Selection process
1. Inspect current project and collaboration model.
2. List source-of-truth ownership per asset category.
3. Compare Git review needs, Team Create/artist workflow, build repeatability, and CI needs.
4. Choose a workflow with minimal migration.
5. Pin tool versions and document setup.
6. Prototype sync/build in a branch or copy before changing the main project.
7. Preserve a rollback path and never delete Studio content based on an assumed mapping.
