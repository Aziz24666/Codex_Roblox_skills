# V12 Research Snapshot

Accessed: **2026-11-15**. This snapshot records sources checked while preparing V12. It is a starting point, not a substitute for fresh research on future work.

| Topic | Official source | V12 interpretation |
|---|---|---|
| Performance loop | https://create.roblox.com/docs/performance-optimization | Design for performance, identify with built-in tools, improve, then monitor. |
| Instance streaming | https://create.roblox.com/docs/workspace/streaming | Workspace descendants can stream in/out; scripts must tolerate transient client availability. |
| Streaming techniques | https://create.roblox.com/docs/workspace/streaming/techniques | Evaluate settings and model modes for the actual world; do not copy property values blindly. |
| CollectionService | https://create.roblox.com/docs/reference/engine/classes/CollectionService | Use per-instance added/removed signals and `GetTagged`; older ItemAdded/ItemRemoved are deprecated. |
| ScriptProfilerService | https://create.roblox.com/docs/reference/engine/classes/ScriptProfilerService | API members show Plugin Security; do not assume game Script access. |
| Custom events | https://create.roblox.com/docs/production/analytics/custom-events | Current docs specify server/published-only custom event submission and a 100-event cap; re-check limits before implementation. |
| Analytics event limits | https://create.roblox.com/docs/production/analytics/event-types | Event limits and cardinality are governed by current Creator Hub definitions. |
| DataStore best practices | https://create.roblox.com/docs/cloud-services/data-stores/best-practices | Keep persistent data organized and stable; re-check semantics before persistence changes. |
| OpenAI skills guide | https://developers.openai.com/api/docs/guides/tools-skills | Use concise skill metadata and load supporting references/scripts only when required. |
| OpenAI skill design | https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra | Revisit accumulated prompt/skill bloat; keep task routing and instructions focused. |

## Source selection notes
Roblox Creator Hub is authoritative for engine behavior and service permissions. OpenAI developer documentation is authoritative for skill packaging guidance. V12 does not use forum or community snippets as authority for engine API behavior. Community sources may help discover a candidate approach, but any API-specific claim must be confirmed against current official documentation.

## Known caveats
- ScriptProfilerService is not treated as generally callable gameplay API.
- Custom AnalyticsService events are not used as Studio test telemetry.
- Streaming recommendations are design-dependent; the official guide explicitly does not provide a one-size-fits-all world design.
- This snapshot expires as a currentness guarantee; future work must refresh sources.
