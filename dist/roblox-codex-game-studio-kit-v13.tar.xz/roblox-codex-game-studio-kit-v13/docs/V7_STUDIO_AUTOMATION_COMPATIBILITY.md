# V7 Studio Automation Compatibility

## Capability discovery first
The Creator Hub currently documents Studio testing modes including scripted facilities such as `StudioTestService` and `StudioDeviceSimulatorService`, and virtual input workflows. Exact availability, security requirements, and signatures can change. Verify the active Studio version and exact API reference before implementation.

## Separate three contexts
1. Plugin/editor automation that starts and coordinates Studio tests.
2. Server/client test code that runs inside the isolated test session.
3. Production game code that ships to players.
Studio-only test services must not be required by the published runtime.

## Test levels
Manual Studio solo, local server/client, multi-client, device simulation, network simulation, physical device, and staging are distinct. Record which one ran. A plugin automation script is not proof until it was executed in Studio.

## Test data safety
Use isolated test keys/stores and non-production credentials. Roblox documents that Studio DataStore access can interact with the same data as the live experience if enabled; never enable live data access for convenience.

## Unsupported environment
If Codex cannot control Studio, write the test plugin/harness only when the APIs are verified, then mark execution `BLOCKED` or `NOT RUN`. Do not invent an MCP server or bridge.
