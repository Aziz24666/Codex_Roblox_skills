# Documentation Maintenance

Documentation is part of the feature. Update it when public behavior, contracts, data, configuration, controls or operations change.

## Keep current
- `GAME_BRIEF.md`: product identity and target audience;
- `PROJECT_STATUS.md`: current milestone, completed work, blocker and next step;
- `ARCHITECTURE.md`: services, module ownership and data flow;
- `DECISIONS.md`: important choices and alternatives;
- `REMOTE_REGISTRY.md`: client/server contract inventory;
- `DATA_SCHEMA.md`: saved shape and version;
- `ASSET_REGISTER.md`: source and permission record;
- `TEST_PLAN.md`: current verification coverage;
- `RELEASE_NOTES.md`: player-visible changes.

## Writing rules
Prefer concise, accurate documentation with examples. Do not document intended behavior as implemented behavior. Mark assumptions, TODOs and unverified APIs. Avoid duplicating large sections; link to a single source of truth. Remove stale instructions when implementation changes.
