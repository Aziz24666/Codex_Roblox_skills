# V9 — Schema Versioning and Migration

## Version rules
- Each family schema has an integer `schemaVersion`.
- Each definition stores `schemaVersion` and stable `id`.
- Increment schemaVersion when a field is removed/renamed, changes meaning, changes units, or changes compatibility semantics.
- Adding an optional field with a safe default may be backward-compatible, but document the decision.

## Migration
- Migrations are pure functions from old definition data to new definition data.
- Never mutate the original definition during preview.
- Keep migrations deterministic, idempotent where possible, and unit-tested.
- Do not silently map unknown enum values to a different behavior.
- Preserve unknown user-authored data only when the schema contract explicitly supports extension data.
- Report a migration plan and let the author inspect it before writing generated outputs.
