# V4 Player Session, Concurrency, and Recovery

Roblox experiences are concurrent, networked programs. A feature must define what happens when callbacks interleave, a player leaves mid-action, an async operation returns late, or a server shuts down.

## Lifecycle map

For each player-scoped subsystem, document:
- player added and profile/session acquisition;
- character added, removed, and respawned;
- player departure;
- round/party membership transitions;
- server shutdown;
- async task cancellation or invalidation;
- data save and release ownership.

Do not confuse player lifetime, character lifetime, round lifetime, and server lifetime. They are separate scopes.

## Concurrency invariants

Write invariants before code. Examples:
- a reward can be granted at most once per unique transaction ID;
- a player can own no more than one active plot in a server;
- a round accepts a finish only after the player has entered that round;
- a save from an older state cannot overwrite a newer accepted state;
- an async callback cannot mutate a player object after its session has ended.

## Techniques

- Use explicit state machines and transition guards.
- Give each async operation a session/version token and re-check it after yields.
- Use idempotency keys for operations that may be retried.
- Serialize writes for the same logical record where required.
- Bound retries and add jitter/backoff only for transient failures.
- Treat disconnect as a normal lifecycle event, not an exceptional impossibility.
- Define what is restored, retried, canceled, or abandoned.
- Keep recovery observable without logging personal or secret data.

## Failure drills

Test: disconnect during interaction; respawn during async work; duplicate request; two simultaneous purchases; profile load timeout; save timeout; server shutdown during active round; late join; participant leaves before finish; and temporary cross-server coordination failure.

For each drill, verify that no value is duplicated/lost, no player is stuck in an invalid state, cleanup occurs, and recovery is understandable.
