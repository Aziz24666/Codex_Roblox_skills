# NPC AI and Navigation

## Behavior model
Write an NPC behavior table before implementation:
| State | Entry condition | Action | Exit condition | Timeout/recovery |
|---|---|---|---|---|

Use explicit states to avoid contradictory combinations. Keep perception, decision-making and movement responsibilities separated where useful.

## Path planning
- Verify current PathfindingService APIs and agent parameters.
- Compute only when a meaningful destination or obstacle condition changes.
- Detect blocked/failed paths and stale destinations.
- Handle moving targets with bounded replanning.
- Implement stuck detection and safe fallback behavior.
- Avoid unbounded retries and synchronized path computations for many NPCs.

## Update budgets
Stagger NPC decisions. Reduce update frequency for distant or inactive agents. Keep expensive sensing bounded. Do not run multiple per-frame scans per NPC when a shared or event-driven update can work.

## Physics and replication
Choose network ownership and authority based on gameplay consequence. Test collision, player obstruction, respawn, late join and streamed geometry. Keep client presentation separate from authoritative decisions where necessary.

## Test matrix
Test open path, blocked path, narrow passage, dynamic obstacle, moving target, no path, stuck agent, many agents, player leaves, NPC despawns and server shutdown.
