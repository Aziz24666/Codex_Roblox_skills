# Server Authority and Client Trust Boundary

## Core rule
The client is an input and presentation surface, not the authority for valuable outcomes. The server owns shared state and validates every client request that can affect it.

## Server-owned examples
- currency balances and reward grants;
- inventory, item ownership and unlocks;
- score and session outcomes;
- permissions and administrative actions;
- cooldowns and interaction eligibility;
- saved progression and purchase fulfillment;
- shared round or activity state.

## Client responsibilities
- read local input;
- display UI and local effects;
- predict or animate presentation when appropriate;
- request a known action using a narrow payload;
- display the confirmed result.

## Validation checklist
For each request, verify:
1. request type and payload shape;
2. value types and allowed enum/string values;
3. payload size and numeric bounds;
4. player session and character state;
5. permissions and ownership;
6. object class, ancestry and expected location;
7. server-side distance and world context;
8. cooldown, rate limit and action timing;
9. current game state and valid state transition;
10. idempotency/concurrency where duplicate requests matter.

## Special interaction caution
Prompts and detectors can be triggered in ways that ignore some client-visible properties. Validate actual server context and distance as documented for the specific interaction type. For physics-sensitive objects, understand network ownership and whether the client can influence object movement.

## Response design
Return a small success/failure result with a reason code where useful. The server should not return arbitrary instance paths, internal profile structures or secret values. Client UI should only show authoritative success after server confirmation.

Check current official security guidance when creating or auditing any client-triggered action.
