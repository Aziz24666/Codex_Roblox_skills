# V7 End-to-End Feature Factory

A feature is a player outcome crossing design, code, content, UX, persistence, tests, and operations.

## Gate 0 — Request clarity
Write the player outcome, target audience/device, constraints, non-goals, approval-sensitive operations, and smallest demonstrable milestone.

## Gate 1 — Reconnaissance
Inspect callers, ownership, lifecycle, source of truth, tests, data schema, remotes, assets, and API versions. Map dependencies and identify changed files.

## Gate 2 — Contract
Create a short spec with stable feature ID, server/client/shared responsibilities, state owner, module interfaces, remote payload schema, persistence/migration, error behavior, observability, accessibility, and acceptance criteria.

## Gate 3 — Risk prototype
Prototype the most uncertain engine/API, physics, UX, or performance behavior in isolation. Record what the prototype proves and what it does not.

## Gate 4 — Vertical slice
Implement one path that works from player input to authoritative result and feedback. Include invalid input, failure/retry, cleanup, and persistence only if required for the first slice.

## Gate 5 — Integration
Replace temporary adapters, validate interfaces, verify data ownership, remove duplicate state, and check all dependencies.

## Gate 6 — Verification
Run available static/unit/integration/build/Studio/client-server/multi-client/device/network checks in order. Use the most relevant levels; do not claim unavailable levels.

## Gate 7 — Review
Inspect diff, security, data integrity, asset provenance, localization, accessibility, performance, privacy, and regression risk.

## Gate 8 — Evidence and handoff
Map each criterion to test/evidence; mark `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, or `NOT APPLICABLE`. Update docs, known issues, task graph, and next milestone.
