# Genre Blueprints


# Roblox Genre Blueprints

Choose one primary archetype. Hybridize only when the combination has a clear player-facing purpose. Each blueprint is a set of design questions, not a recipe to copy.

## Obstacle/course experience

Core loop: read obstacle → attempt movement → receive feedback → checkpoint/retry → complete segment. Test control feel, camera visibility, collision fairness, checkpoint persistence, and difficulty progression. Keep a safe route for learning and clear recovery after failure.

## Simulator/collection experience

Core loop: perform activity → earn transparent reward → improve capability → access new activity. Define the primary action's feel, reward clarity, inventory constraints, progression pacing, and economy sinks. Server calculates rewards and inventory. Avoid endless repetitive grinds and deceptive reward odds.

## Tycoon/building experience

Core loop: earn resources → choose an upgrade → see a visible build change → unlock a new decision. Test placement rules, ownership permissions, build validation, reconnect recovery, and server cost calculations. Keep build interactions understandable and reversible when practical.

## Round-based party experience

Core loop: queue/lobby → explain objective → start round → resolve outcome → reward/summary → requeue. Model the round state machine, late joins, disconnects, tie rules, team assignment, countdown cancellation, and server authority.

## Exploration/adventure experience

Core loop: discover clue/place → interact → solve or complete objective → unlock next area. Test navigation readability, objective tracking, save checkpoints, streaming, and accessibility of clues. Avoid hiding essential information behind tiny visual details or audio alone.

## Puzzle/co-op experience

Core loop: observe shared problem → coordinate roles → manipulate state → verify solution → transition. Define shared-state ownership, simultaneous interactions, reset rules, late join, griefing prevention, and clear feedback to all participants.

## Racing/time-trial experience

Core loop: start → navigate course → record valid completion → compare/retry. Define checkpoint ordering, server validation, reset/finish conditions, timing rules, and fair handling of disconnect/teleport anomalies. Test network delay and device input differences.

## Social/role-play experience

Core loop: arrive → understand shared space → communicate/interact → create a social moment → return. Prioritize privacy, moderation-safe design, report/block affordances where appropriate, safe chat handling, and clear boundaries for user-generated content. Filter text using current Roblox requirements; do not invent a local substitute for platform filtering.

## Arena/objective experience

Core loop: prepare → compete for a clear objective → resolve round → review result. Keep mechanics fictional and age-appropriate. Define map readability, spawn safety, server-side scoring, team fairness, cooldowns, disconnect resolution, and anti-exploit validation.

## Blueprint selection

For each proposed feature, state which loop step it improves and what evidence would show the improvement. Defer features that do not support the core loop or a necessary platform requirement.
