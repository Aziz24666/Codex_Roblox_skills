# V10 Roblox Updates Watch

Roblox's Creator Updates and official Developer Forum Updates/Announcements should be searched for changes that affect the current task. Do not assume a feature is generally available merely because it appears in a roadmap or is announced as pending/beta. Verify the linked Creator Hub documentation and the exact API availability in the installed Studio build.

For each relevant update, record:
- title and exact URL;
- published date;
- status: announced, beta, pending, staged rollout, generally available, deprecated, or unknown;
- affected APIs/Studio surfaces;
- project relevance;
- whether an implementation change is necessary now.

Do not add unrelated new APIs just because the updates feed mentions them. The point is compatibility and better decisions, not chasing novelty.
