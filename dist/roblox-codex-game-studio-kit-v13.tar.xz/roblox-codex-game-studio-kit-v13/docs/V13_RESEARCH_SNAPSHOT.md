# V13 Research Snapshot

Accessed: 2026-11-15. Re-open these references before new implementations; this snapshot documents why V13 is designed as it is, not a promise that the pages will remain unchanged.

| Source | URL | V13 decision supported |
|---|---|---|
| Roblox: Compare file-based workflows | https://create.roblox.com/docs/projects/file-based-workflows | Select Studio-native, partially managed, or fully managed source-of-truth profile; don't over-engineer CI. |
| Roblox: Rojo | https://create.roblox.com/docs/projects/rojo | Treat Rojo as community-maintained; pin versions with a toolchain manager; build into CI only where appropriate. |
| Roblox: Script Sync | https://create.roblox.com/docs/scripting/sync | Script Sync tracks scripts/folders, not all DataModel instances; respect its constraints. |
| Roblox: Studio testing modes | https://create.roblox.com/docs/studio/testing-modes | Use separate manual/scripted Studio test levels; client/server simulation matters. |
| Roblox: StudioTestService | https://create.roblox.com/docs/reference/engine/classes/StudioTestService | Plugin-driven scripted testing is Studio-specific. |
| Roblox: Luau type checking | https://create.roblox.com/docs/luau/type-checking | Prefer deliberate gradual adoption of `--!strict` and Studio analysis. |
| Luau: Getting started | https://luau.org/getting-started/ | `luau` and `luau-analyze` are supported command-line tools for execution/static analysis. |
| Roblox: Open Cloud Luau Execution | https://create.roblox.com/docs/cloud/reference/features/luau-execution | Headless place execution is an external authenticated workflow; separate it from local Studio tests. |
| GitHub: Secure use | https://docs.github.com/en/actions/reference/security/secure-use | Least privilege and immutable action references are CI defaults. |
| GitHub: Securely using pull_request_target | https://docs.github.com/en/actions/reference/security/securely-using-pull_request_target | Never execute untrusted PR code in privileged workflows. |
| OpenAI: Rethinking skills and prompts | https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra | Keep skill descriptions concise; use progressive disclosure and avoid oversized global instructions. |
| Rojo: Project format | https://rojo.space/docs/v7/project-format/ | Validate place mappings and project file before builds. |
| StyLua | https://github.com/JohnnyMorganz/StyLua | Use the Luau-compatible formatter with a pinned version and check-only CI mode. |

## Version examples
V13's example workflow pins `actions/checkout` v7.0.1 to `3d3c42e5aac5ba805825da76410c181273ba90b1` and `actions/setup-python` v7.1.0 to `6d4fd22b20465ccc0f7354476588e8df7c9ca0e0`. Revalidate official release/commit provenance before adopting or updating them.
