# V12 Tool Limits and Evidence Boundaries

| Tool/check | Can support | Cannot prove |
|---|---|---|
| Static streaming audit | Locates source patterns worth reviewing | That streaming is broken or correct at runtime |
| Tag lifecycle audit | Finds possible missing removal/cleanup paths | Complete dynamic Instance ownership behavior |
| Performance budget checker | Compares numeric JSON values with project limits | That captures are real, comparable, or honestly recorded |
| Analytics catalog linter | Checks event catalog shape/count and suspicious field names | Privacy/legal compliance or actual delivery |
| MicroProfiler/Studio capture | Shows a particular measured session | All device performance or every production session |
| Studio MCP playtest | Verifies a specific scenario in the connected place | Physical-device behavior unless tested on hardware |
| Physical device test | Verifies that device/build/scenario | Every model in its device tier |

Always report exact environment, scope, evidence path, and limitations.
