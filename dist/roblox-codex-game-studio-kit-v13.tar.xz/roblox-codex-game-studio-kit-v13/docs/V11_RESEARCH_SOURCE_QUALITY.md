# V11 Research Source Quality

## Source ranking
1. Official Roblox Creator Hub/API reference for platform behavior and signatures.
2. Official Roblox release notes, announcements, and DevForum engineering posts for rollout/known issue context.
3. Upstream documentation and source for Rojo, Luau tooling, packages, CI actions, or MCP clients.
4. Reputable technical articles and maintained examples for alternative patterns.
5. Community discussions for discovering pitfalls—not as the sole authority for platform guarantees.

## Research integrity
Open pages and read relevant sections. Record publication/update date where visible and access date. Separate facts from inference. Cite the source supporting each important claim. Do not copy large code from third parties. Check licenses before reusing code. Identify conflicting docs and explain the resolution. Never claim "best practice" from a single unsourced tutorial.
