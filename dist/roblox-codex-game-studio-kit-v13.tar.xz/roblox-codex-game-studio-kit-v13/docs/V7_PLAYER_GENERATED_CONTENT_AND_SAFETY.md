# V7 Player-Generated Content and Safety

## Design boundary
Define permitted content types and visibility: text labels, naming, placement, structured builds, level layouts, or curated choices. Do not assume that free-form content is necessary.

## Safer architecture
- Store structured content, not executable source.
- Reference approved catalog IDs rather than accepting arbitrary asset URLs or IDs.
- Validate owner, schema, size, bounds, and rate on the server.
- Use platform-provided safety/moderation features according to current documentation and policy.
- Keep reporting, removal, and visibility controls discoverable where relevant.
- Minimize retention and personal data.

## Moderation-aware authoring
Avoid tools intended to bypass platform moderation, disguise harmful content, or expose personal information. Do not build hidden alternate text paths. Define how content is reviewed, reported, removed, and appealed where the platform/product supports it.

## Testing
Malformed content, long strings, invalid Unicode/encoding, repeated submissions, ownership spoofing, visibility leaks, report/removal, deleted catalog references, and stale cached display.
