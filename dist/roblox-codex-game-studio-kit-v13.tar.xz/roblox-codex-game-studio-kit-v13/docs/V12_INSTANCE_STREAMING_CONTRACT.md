# V12 Instance Streaming Contract

## Core behavior
Instance streaming applies to descendants of `Workspace`; it can load and unload 3D content dynamically. Instances that stream out can be parented to `nil` and later stream back. Client code must therefore tolerate references becoming temporarily unavailable and being reintroduced.

## Engineering rules
- Do not store long-lived client assumptions that a Workspace descendant is always present.
- Re-resolve streamed references when entering a region and tear down local bindings when they leave.
- Make setup idempotent because a stream-in can occur more than once during a session.
- Distinguish server authority from client availability. A server may know about an instance that a client has not streamed in.
- `Workspace.StreamingEnabled` is a Studio property and cannot be set from a script. Configure it through the appropriate Studio/project workflow after research.
- Review `ModelStreamingMode` and `Workspace.ModelStreamingBehavior` for the content's role. Avoid broad Persistent usage; document each exception and its memory/replication cost.
- Keep critical state on the server or in data/configuration, not solely in a client instance that may stream out.
- Test region exit/re-entry, respawn, teleport, low-memory behavior, and client/server disagreement about a streamed object.

## Avoid
- Using `WaitForChild()` as a promise that a distant streamed Workspace object will become available.
- Assuming a `Workspace` object reference remains parented indefinitely.
- Moving all game logic into persistent models to avoid lifecycle work.
- Treating local Studio emulation as physical low-memory-device evidence.

See official references in `docs/V12_RESEARCH_SNAPSHOT.md`.
