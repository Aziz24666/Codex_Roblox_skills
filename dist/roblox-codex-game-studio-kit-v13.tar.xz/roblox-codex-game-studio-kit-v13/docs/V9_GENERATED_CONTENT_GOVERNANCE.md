# V9 — Generated Content Governance

## Provenance fields
- `DefinitionId`
- `DefinitionSchemaVersion`
- `ContentFamily`
- `TemplateId`
- `TemplateVersion`
- `GeneratorId`
- `GeneratorVersion`

These values identify how the object was produced. Avoid timestamps as identity keys.

## Ownership split
Generated base content is factory-owned. Manual adjustments belong in a named override layer or separate user-owned descendants. The generator should never assume that all descendants under an existing prefab are safe to delete.

## Drift detection
Compare managed properties and descendants against the stored template/definition baseline. Report added, removed, and modified objects. If there is any user-owned or unknown object, default to `Skip` or generate a side-by-side candidate. Replacement requires an explicit diff and approval.

## Idempotence
The same normalized definition + template version + generator version should produce the same intended structure, ignoring non-semantic metadata. Prefer stable names and deterministic child creation order.

## Template code hygiene
The sample resolver strips Script, LocalScript, and ModuleScript descendants from selected source clones. Do not copy scripts embedded in third-party models into generated prefabs. If a project genuinely needs template-authored logic, move it into reviewed shared modules and attach behavior through an explicit component/definition registry.
