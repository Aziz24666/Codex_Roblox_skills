# V9 — Schema-Generated Studio Editor Architecture

## Goal
Build one reusable Studio authoring surface that can create many related content variants. A new NPC variant should be data, not a copied movement script. A new prop/cosmetic definition should use the same schema-driven editor, validator, preview, and generator infrastructure.

## Architecture
```text
Family Schema Catalog
   ├── field metadata
   ├── defaults and constraints
   ├── template/source requirements
   └── generator family key
          ↓
Dynamic Form Renderer ← Field Control Registry
          ↓
Draft Definition (local editor state only)
          ↓
Schema + Semantic Validator
          ↓
Normalized Definition (immutable snapshot)
          ├── Preview Planner (read-only)
          └── Preview Renderer (ViewportFrame, when possible)
                    ↓ explicit Generate action
Template Resolver → Family Generator → DataModel Transaction
                    ↓
Post-Generation Validator → Provenance Manifest → Report
```

## Separation of concerns
- Schema catalog: declarative field and family metadata; no `Instance.new` and no runtime gameplay logic.
- Form renderer: turns field definitions into GUI controls; it must not generate prefabs.
- Validator: pure validation over values and schema descriptors; no DataModel mutation.
- Preview planner/renderer: shows an anticipated hierarchy and a visual preview; must not write into Workspace/ServerStorage.
- Template resolver (`TemplateResolver.lua`): validates selected approved source/template and required descendants, then strips embedded Script/LocalScript/ModuleScript descendants from source clones so behavior remains in shared runtime systems.
- Generator: family-specific allowlisted construction only; no dynamic class names or free-form code execution.
- Transaction service: brackets the full write set with Studio undo recording.
- Runtime: consumes versioned definitions through shared modules. It never depends on the plugin being installed.

## Authoring flow
1. Pick a family tab.
2. The form renderer constructs controls from `fields` metadata.
3. The user edits an in-memory draft.
4. Validation returns field-path-addressed issues.
5. Preview displays a 3D source/generated proxy and a hierarchy plan.
6. Generate is a separate explicit action.
7. The factory checks the selected source object and collisions.
8. It begins an undo recording, writes a definition and prefab, validates the result, then commits. On any failure, it cancels.
9. The UI reports actual output paths and any unresolved references.

## Extending the system
Add a family by adding a catalog entry, JSON Schema, default/example definition, source requirements, template ID/version, and one generator handler. Do not duplicate `EditorApp` or field renderer code. Add a field kind only when it is reusable across multiple families; register its control, parser, validator, and test cases in one place.

## Non-goals
The plugin is not a game runtime, asset marketplace, remote uploader, or production deployer. It does not validate gameplay balance by itself. It does not prove an asset is usable from the ID's shape. It does not generate arbitrary scripts from user-entered data.
