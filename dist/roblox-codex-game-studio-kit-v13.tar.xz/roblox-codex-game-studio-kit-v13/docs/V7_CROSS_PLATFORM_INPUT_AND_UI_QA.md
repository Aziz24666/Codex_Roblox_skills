# V7 Cross-Platform Input and UI QA

## Input action map
Define semantic actions (confirm, cancel, interact, move, look, inventory, pause) separately from concrete key/button/touch bindings. Document contexts and priority. Verify current input APIs and project conventions before changing them.

## Device review
- Touch: reachable controls, thumb zones, safe-area/layout, orientation, virtual controls, no accidental overlaps.
- Mouse/keyboard: focus, hover not being the only cue, key hints, cursor capture, text input.
- Gamepad: selection order, visible focus, confirm/cancel consistency, no mouse-only dialogs.

## Mode switching
Test joining with one input type and switching to another, modal overlays, respawn, focus loss, device disconnect, and controller reconnect.

## Accessibility
Do not use color alone to convey state. Support readable text, sufficient contrast, reduced-motion alternatives where feasible, subtitles/captions for important audio, and clear error feedback.

## Evidence distinction
Studio device simulation can help catch layout and scaling problems; physical device checks are still needed for touch ergonomics, actual performance, and platform-specific behavior.
