# V10 Runtime Lifecycle and Observability

For every reusable system, document lifecycle events: construct, initialize, start, pause, resume, reconfigure (if supported), stop, destroy. Define who owns each event connection, task, instance reference, animation, and temporary object. Cleanup must be idempotent and safe when initialization partially fails.

## Runtime-state rules
- Per-NPC/per-item/per-player state belongs to an explicit runtime record keyed by stable identity.
- Shared definition tables are read-only.
- Remove state on destruction, despawn, respawn replacement, disconnect, or scene change as appropriate.
- Avoid permanent global registries without bounded ownership and cleanup.
- Avoid polling when events or explicit scheduler registration are clearer; profile scheduled loops.

## Observability
Use structured, rate-limited logs with feature/system IDs and useful context. Do not log secrets or sensitive player data. Add counters/timers for important queues, failures, save retries, generation operations, and expensive updates. Use Roblox profiling tools and server/client logs where available. Make logs actionable, not noisy.
