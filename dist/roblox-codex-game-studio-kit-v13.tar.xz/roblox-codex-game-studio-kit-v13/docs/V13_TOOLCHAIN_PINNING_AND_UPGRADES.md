# V13 Toolchain Pinning and Upgrades

## Pin the tools that affect output
Use a project-managed toolchain file such as `rokit.toml` for Rojo and other supported tools. Keep the exact versions in source control. Use `.python-version` plus an exact dependency lock for Python utilities when CI needs reproducible runs.

## Upgrade procedure
1. Research the upstream release notes and compatibility notes.
2. Create a dedicated toolchain-upgrade branch.
3. Change one major tool at a time.
4. Run formatter check, analyzer, tests, project build, and Studio smoke test as applicable.
5. Compare artifact manifests where reproducibility is expected.
6. Record version, source, reason, expected changes, actual results, and rollback version.

## Rules
- Do not use `latest`, floating branches, or ranges for tools that must be reproducible.
- Pin GitHub Actions to verified full commit SHAs; keep the release tag in a comment.
- A version pin is not a security guarantee. Review upstream trust, releases and known issues.
- Keep Studio plugin and CLI versions compatible. Check both release notes.
