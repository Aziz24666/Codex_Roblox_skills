# V8 — Maintainability Rules

1. A developer should be able to find a feature's entrypoint and config quickly.
2. Each module has one clear purpose and an understandable public API.
3. Names describe domain meaning; use the same terms in code, UI, docs, and config.
4. Shared behavior is implemented once; differences live in schema-checked definitions or explicit strategy modules.
5. Avoid hidden cross-module state and mutation of shared definition tables.
6. Keep functions focused and keep control flow shallow where possible.
7. Use strict types for public contracts. Narrow untyped boundaries and validate decoded data.
8. Avoid premature abstractions; generalize only after a second/third real use case reveals stable commonality.
9. Add comments for decisions, invariants, and API caveats—not line-by-line narration.
10. For every generated system, include a human extension note and one focused example.

## Human readability check
Ask a developer unfamiliar with the feature to locate: the config, the behavior selection, the shared algorithm, the lifecycle owner, the test, and the place to add another variant. If those are hard to find, improve naming and structure before adding more features.
