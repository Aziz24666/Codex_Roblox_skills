# V7 Player Support and Incident Triage

## Severity model
- Critical: confirmed widespread data loss, privacy/security exposure, broken core join/play, or integrity issue with broad impact.
- High: substantial feature unavailable, major progression failure, recurring crash, or exploit affecting shared state.
- Medium: localized feature defect with a workaround.
- Low: cosmetic, copy, or rare non-blocking issue.

Severity is provisional until impact evidence is available. Assign an owner and next update point.

## Report schema
Issue ID, approximate time, build/place, device/input, locale, reproduction steps, expected/actual, frequency, affected feature, privacy/data risk, supporting artifacts, and confidence.

## Privacy
Redact user IDs where not required for internal correlation, never collect credentials or session secrets, and avoid copying private player content into generic logs. Keep evidence access limited.

## Triage loop
Acknowledge → classify → reproduce in safe environment → assess blast radius → mitigate through approved reversible change → verify → communicate factual outcome → postmortem if material.

## External actions
Do not contact players, edit live records, issue refunds, alter permissions, or change production configuration without explicit authorization and an approved process.
