# Data Schema Migrations

A data migration changes the stored shape or meaning of player data. It is a release risk, not an ordinary refactor.

## Migration plan
1. Record current schema version and exact old shape.
2. Define new schema and invariants.
3. Write a pure migration function from each supported old version to the new version.
4. Define behavior for missing, malformed and unknown-version data.
5. Decide whether migration is lazy on load, batched or coordinated; verify current platform constraints.
6. Test migration against representative fixture data.
7. Test idempotence: rerunning migration must not duplicate rewards or corrupt values.
8. Define rollback/forward-fix plan and compatibility window.
9. Deploy only after explicit approval and test-environment verification.

## Rules
- Never casually rename a DataStore or schema key.
- Never assume rollback of code reverses already migrated player data.
- Keep migration code until the supported legacy population is known to be migrated, then retire deliberately.
- Separate display labels from stable IDs.
- Record the version and migration result in a safe diagnostic channel.
