# V11 Migration from V10

V11 retains the V10 skill library, schemas, tools, and schema-generated Studio editor. The main changes are:
- root `AGENTS.md` is shorter and delegates detailed procedures to relevant references;
- oversized skill descriptions are shortened for more reliable skill routing;
- ten new maintenance/reliability skills and corresponding playbooks are added;
- repository inventory, require-graph, change-impact, research, release, generated-drift, skill-audit, and toolchain-report utilities are added;
- V11 schemas formalize change plans, module contracts, generated artifacts, and test evidence.

## Migration steps
1. Back up existing root instructions and check project changes.
2. Replace or merge the root `AGENTS.md` with the V11 contract; retain project-specific instructions.
3. Copy the new V11 skills or the whole updated skills directory.
4. Use `INDEX_V11.md` for routing.
5. Run the skill audit and Python test suite.
6. Keep V10 editor/plugin code until a separate Studio integration test proves any V11 changes are safe.
7. Do not migrate source-of-truth workflow solely because the kit version changed.
