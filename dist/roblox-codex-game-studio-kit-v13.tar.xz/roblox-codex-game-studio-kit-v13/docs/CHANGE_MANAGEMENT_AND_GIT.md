# Change Management And Git



## Before a change

Inspect branch, status, tracked/untracked files, recent commits, and existing diffs. Never reset, clean, stash, or overwrite user work unless specifically authorized. Preserve unrelated modifications.

## Change sizing

Prefer one coherent feature or fix per change. Split unrelated refactors. Use small commits only if the user/project workflow authorizes commits; do not commit or push automatically when that is not expected.

## Review checklist

- Is the diff limited to the requested scope?
- Did any generated file or asset change unexpectedly?
- Are there secret or credential patterns?
- Did project mappings or lockfiles change intentionally?
- Are public module/remote/data contracts compatible?
- Is a migration or rollback needed?
- Are docs and tests updated?

## Migration changes

Document old/new schema, compatibility window, migration ordering, idempotency, failure mode, backup, rollback, and test dataset. Run the migration against isolated sample data. Never run it against production without explicit authorization.

## Handoff

Leave the repository in a known state. Report changed files, commands, checks, and any uncommitted work. Do not claim a commit/push/PR exists unless the operation succeeded and the result is verified.
