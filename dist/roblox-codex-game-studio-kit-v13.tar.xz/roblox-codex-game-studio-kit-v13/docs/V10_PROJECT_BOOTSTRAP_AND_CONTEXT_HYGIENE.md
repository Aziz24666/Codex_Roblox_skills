# V10 Project Bootstrap and Context Hygiene

Codex should start with a project map, not a speculative rewrite. Inspect source files, DataModel mapping, project manifests, assets, skills, tests, toolchain, generated artifacts, and user changes. Record the actual source of truth by content category.

Load skills progressively: always load `roblox-game-builder` and `roblox-research-first-engineering`; add only the specialist skills required for the task. Read docs referenced by those skills. Do not dump all 96 skills into one prompt.

Maintain a short `PROJECT_STATUS.md` with current milestone, confirmed architecture, open decisions, failing tests, blockers, and next task. Keep durable decisions in research/ADR records, not in conversational memory alone.

Before each milestone, refresh the project map if mappings or tools changed. Never replace a working source-of-truth workflow without an explicit migration plan.
