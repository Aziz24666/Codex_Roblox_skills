# V6 Requirements Traceability and Definition of Done

## Why traceability matters
A large game can appear finished while important player requirements have no implementation or test. Connect each requirement to the feature, owning system, acceptance criteria, tests, evidence, and release decision.

## Traceability chain
`REQ-ID → FEATURE-ID → SYSTEM-ID → ACCEPTANCE-ID → TEST-ID → EVIDENCE-ID → RELEASE`.

Every link must be explicit. A requirement with no test is unverified. A test with no expected behavior is ambiguous. An evidence record without environment/build identity is difficult to reproduce.

## Acceptance criteria
Write observable outcomes. Prefer Given/When/Then or measurable invariants. Include happy path, invalid input, boundary, concurrency, failure, cleanup, device, accessibility, and persistence cases where relevant.

## Coverage statuses
- `COVERED`: linked to at least one test and evidence.
- `PLANNED`: test exists as a plan but has not run.
- `BLOCKED`: cannot run due to a named dependency or tool limitation.
- `GAP`: no test or acceptance proof exists.
- `NOT APPLICABLE`: justified with a reason.

## Definition of done
A feature is done only when code is integrated, acceptance criteria are verified at appropriate levels, errors and edge cases are addressed, security/data boundaries reviewed, regression checks pass, documentation is current, and known limitations are reported. Not every feature needs every test level; the risk analysis must justify the chosen coverage.

## Traceability review
Before release, filter for requirements with no test, tests with no evidence, evidence with `FAIL`/`BLOCKED`, and features that were deferred without product approval. Do not hide gaps by changing a status label.
