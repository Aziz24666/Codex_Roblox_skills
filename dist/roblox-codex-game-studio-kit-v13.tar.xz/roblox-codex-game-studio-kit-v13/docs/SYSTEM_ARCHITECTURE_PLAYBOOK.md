# System Architecture Playbook



## Architecture goals

Use simple boundaries that reflect gameplay responsibilities. Architecture should make it obvious where behavior lives, who owns state, how systems communicate, and how they stop cleanly.

## Decomposition process

1. List player journeys and system responsibilities.
2. Group responsibilities into bounded domains only where cohesion exists.
3. Assign server/client/shared/external ownership.
4. Map modules and instances to Roblox services.
5. Define public APIs and dependency direction.
6. Define lifecycle start/stop behavior.
7. Define remotes and replicated state contracts.
8. Define data schema and persistence boundaries.
9. Record failure paths and observability.
10. Validate with one end-to-end sequence diagram.

## DataModel placement heuristics

- `ServerScriptService`: server-only orchestration and logic.
- `ServerStorage`: server-only assets/templates not needed immediately by clients.
- `ReplicatedStorage`: only shared modules/configuration and assets clients need.
- `StarterPlayerScripts` / `StarterCharacterScripts`: client behavior with clear lifecycle ownership.
- `StarterGui`: client UI that is intentionally replicated through the starter UI path.
- `Workspace`: live world content, designed with streaming behavior in mind.

These are heuristics, not an instruction to move an existing project. Verify each project's existing architecture and current platform guidance.

## Module contract checklist

For each module record purpose, public methods, input/output types, errors, yield behavior, side effects, dependencies, lifecycle, and tests. Keep private implementation private. Avoid returning mutable internal state when callers can mutate it without validation.

## State ownership table

Every important value must have exactly one authoritative owner. Clients may maintain cached/predicted presentation state, but it must reconcile to authoritative results. If two systems can independently write the same state, define a coordinator or redesign ownership.

## Dependency graph

Prefer dependencies flowing from orchestration toward domain logic and adapters. Keep shared pure modules independent from server-only and client-only services. Break cycles rather than hiding them behind delayed `require` calls.

## Architecture review questions

- Can a new developer locate the owner of a feature in under a minute?
- Can the system be stopped without leaving connections/tasks behind?
- Can the system be tested without starting every other system?
- Are remote payloads narrow and documented?
- Can data schemas evolve without data loss?
- Do streaming and late-join behavior affect assumptions?
- Are dependencies pinned and replaceable?
