# V7 Skill Routing Matrix

Use this table to find likely skills. It is a routing hint, not a requirement to load every listed skill.

| Work area | Primary skill | Add when relevant |
|---|---|---|
| New game / whole project | `roblox-game-builder` | product design, architecture, genre, world/UI, QA |
| Task decomposition / multi-agent work | `roblox-feature-orchestration` | context engineering, architecture, code review |
| Luau module / type defect | `roblox-luau-engineering` | code review, regression engineering |
| Player first session | `roblox-experience-onboarding` | UI/UX, localization, data progression |
| Round / match lifecycle | `roblox-round-based-games` | matchmaking, networking, data, ranking |
| Inventory / equipment | `roblox-inventory-loadouts` | economy, persistence, networking, UI |
| Schema/data migration | `roblox-data-migration-operations` | Open Cloud governance, data progression, QA |
| Performance baseline/regression | `roblox-performance-benchmarking` | QA performance, Studio workflow, technical art |
| Automated regression | `roblox-regression-engineering` | Studio test automation, Studio workflow |
| Touch/gamepad/keyboard parity | `roblox-cross-platform-input` | UI/UX, accessibility, character game feel |
| User-created content | `roblox-player-generated-content` | community safety, content catalog, networking |
| Player-reported incident | `roblox-player-support-triage` | observability, release operations, data migration |
| Catalog/level/wave data | `roblox-content-catalog` | asset pipeline, genre skill, localization |
| Physics/replication | `roblox-physics-simulation` | networking, performance, Studio tests |
| Place transitions | `roblox-multi-place-universe` | matchmaking/teleport, data, release ops |
| Studio plugin | `roblox-plugin-development` | Studio workflow, testing, security |
| Release / publication prep | `roblox-release-operations` | Open Cloud operations, rollback, QA |

Always use exact skill names as they appear in `.agents/skills/<name>/SKILL.md`. Do not assume skills are automatically activated just because they are installed.
