# V11 Release and Rollback

## Candidate checklist
- Requirements and acceptance evidence are complete.
- Research records are current for changed API surfaces.
- Luau/static/schema/build checks pass at the levels available.
- Relevant Studio and multiplayer tests are recorded.
- Data schema migrations have a tested forward path and recovery plan.
- Asset provenance and permissions are checked.
- Configuration differences are reviewed.
- Known issues, monitoring signals, and support steps are documented.

## Rollout
Use the smallest safe rollout unit available: private/disposable test, team/staging verification, limited release where supported, then wider rollout. Do not invent Roblox rollout capabilities; verify current dashboard/platform features.

## Rollback
Define trigger, responsible owner, exact reversible action, data compatibility, player impact, verification after rollback, and communication. A rollback that restores code but corrupts or loses data is not acceptable.

## Approval
Codex may prepare candidates and reports. Publishing, public asset changes, live settings, permission changes, and production-data mutations require explicit user authorization.
