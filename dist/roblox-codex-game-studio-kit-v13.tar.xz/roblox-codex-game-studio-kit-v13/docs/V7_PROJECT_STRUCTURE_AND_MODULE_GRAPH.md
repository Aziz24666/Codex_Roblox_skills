# V7 Project Structure and Module Graph

## Purpose
Make the repository understandable without forcing a migration to a new architecture.

## Map elements
- Entry scripts and boot order.
- Client/server/shared module locations.
- Packages and pinned dependencies.
- Project mapping from file paths into DataModel services.
- Remotes and their owners/contracts.
- Persistence boundaries and schemas.
- Content catalogs and asset references.
- Tests, CI, Studio tooling, and generated artifacts.

## Dependency graph policy
A graph generated from string searches or simple `require` parsing is approximate. It may miss dynamic requires, `WaitForChild` lookups, instance mapping, plugin injection, reflection, and runtime-created references. Label nodes/edges as `STATIC`, `HEURISTIC`, or `MANUALLY VERIFIED`.

## Change impact
Before modifying a module, inspect every call site and replication boundary. Before changing a shared contract, identify client, server, test, and place consumers. Do not move files across mapped services without verifying the project mapping.

## Output
Prefer a concise diagram or table of actual entrypoints and ownership over a huge generated dependency graph that cannot be trusted.
