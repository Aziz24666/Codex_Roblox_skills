# Test Evidence and Release Gates

## Evidence vocabulary

- `PASS`: the exact test ran and the expected result was observed.
- `FAIL`: the test ran and the observed result did not match expectation.
- `BLOCKED`: a prerequisite/tool/environment prevented the test.
- `NOT RUN`: no attempt was made.

Never report a skipped test as passed. Attach logs, screenshots, measurements, build IDs, or clear reproduction notes when available.

## Verification layers

| Layer | Evidence | Does not prove |
|---|---|---|
| Source review | Code/diff inspected | Runtime correctness |
| JSON/config validation | Syntax/schema subset | Rojo mapping/runtime correctness |
| Lint/type check | Tool output | Correct gameplay behavior |
| Rojo build | Place/model build succeeded | Studio playability |
| Solo Studio playtest | One client/server simulation | Multiplayer correctness |
| Server & Clients | Multi-client simulation | All live network/device behavior |
| Device simulation | Emulated device/input result | Physical-device behavior |
| Network simulation | Simulated delay/loss behavior | Every live network condition |
| Private/live-like test | Controlled environment result | Public release success |

## Feature gate

For each feature verify: acceptance criteria, normal flow, invalid flow, cancellation/interruption, lifecycle cleanup, relevant security boundary, persistence, accessibility, performance, and regression.

## Release-candidate gate

- Scope and version are fixed.
- No unresolved critical/high-severity defects without explicit risk acceptance.
- Data schema compatibility and recovery plan are reviewed.
- Asset provenance/permissions are recorded.
- Remote/security contracts are reviewed.
- Purchase receipt path is verified if monetization exists.
- Multiplayer and device tests are run where relevant.
- Performance is measured under representative load.
- Known issues and support/mitigation paths are documented.
- Rollback/disable strategy is prepared.
- External publish/upload/production operations are explicitly approved.

## Test report minimum

Build/version, environment, test mode, client count, device/input, network simulation, setup, test ID, expected and actual result, status, evidence reference, and follow-up issue.
