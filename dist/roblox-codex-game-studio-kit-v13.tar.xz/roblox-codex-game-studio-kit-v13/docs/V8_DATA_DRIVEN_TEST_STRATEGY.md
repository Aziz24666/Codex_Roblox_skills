# V8 — Data-Driven System Test Strategy

Minimum coverage:
- Valid basic definition loads and normalizes.
- Optional field omitted receives exactly one documented default.
- Wrong type, out-of-range number, unknown enum, duplicate ID, and unresolved required reference are rejected.
- Two entities with the same definition receive independent runtime state.
- Two definitions share the same controller implementation but use different values.
- Added tagged instance attaches once; removed instance fully detaches.
- Malformed one-off content does not corrupt the entire registry.
- Prefab factory dry-run matches generated result.
- Re-running generation detects collision/drift rather than overwriting silently.
- Undo restores the pre-generation Studio state.

Use test statuses `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, or `NOT APPLICABLE`. Record place/version, Studio session, test entrypoint, data fixture, and evidence.
