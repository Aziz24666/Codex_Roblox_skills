# V4 Autonomous Feature Execution Loop

Use this loop for every meaningful game feature. It is intentionally small enough to repeat often and strict enough to prevent incomplete, disconnected scripts.

## 1. Input contract

Read the feature request and existing game context. Extract:
- player problem or desired outcome;
- trigger and preconditions;
- visible result and feedback;
- authoritative state changes;
- expected device/input modes;
- persistence, social, and monetization impact;
- constraints, non-goals, and unknowns.

Do not silently invent a major design decision. For routine ambiguity, select a reversible default and record it as an assumption.

## 2. Evidence-based reconnaissance

Search for existing implementations, public APIs, consumers, remotes, state, UI, data schemas, and tests. Trace the whole flow from player input to server state to client presentation. Do not replace a working subsystem before understanding its purpose.

## 3. Design packet

Create a compact feature packet using `templates/FEATURE_TICKET_TEMPLATE.md` plus:
- state diagram or transition table;
- public module interface;
- remote request/response contract, if applicable;
- data schema/version change, if applicable;
- lifecycle/cleanup owner;
- failure and recovery behavior;
- test matrix and acceptance criteria.

## 4. Risk ranking

Rate each dimension Low/Medium/High: client trust, persistence, concurrency, performance, content/player trust, accessibility, compatibility, and external side effects. High-risk features require a targeted review before implementation.

## 5. Prototype the riskiest unknown

Build the smallest disposable proof. State what it is supposed to answer, how success/failure is measured, and whether it is throwaway or intended to evolve. Remove or clearly isolate throwaway code after the decision.

## 6. Implement one complete vertical slice

The slice should include every layer required for the actual player outcome:
1. discoverable world/UI entry;
2. input and immediate feedback;
3. validated server request for consequential actions;
4. authoritative state transition;
5. replicated/reconciled presentation;
6. errors, cooldowns, retry, cancel, and disconnect behavior;
7. persistence only if the feature requires durable state;
8. cleanup when player, character, round, or server lifecycle ends;
9. deterministic tests and Studio plan.

## 7. Verify incrementally

Run the narrowest fast checks after each meaningful edit. Before marking the feature complete, run relevant type/lint/unit checks, project mapping/build, and Studio tests available in the environment. Add multi-client/device/network checks when the feature depends on them.

## 8. Review and harden

Inspect changed lines and surrounding code. Search for temporary prints, TODO placeholders, duplicate logic, hidden assumptions, unbounded loops, unowned connections, stale UI, and inconsistent states. Perform an abuse-case review for every client-facing request.

## 9. Update the project truth

Update feature status, system docs, data/remote contracts, test evidence, asset register, and known issues. Keep the record concise and current.

## 10. Report

State outcome, files, actual checks, Studio status, evidence, known limitations, and the next milestone. Use `BLOCKED` for unavailable checks. Never infer a successful runtime result from a successful file edit.

## Stop conditions

Pause before production data access, public asset upload, publishing, purchases, account/permission changes, irreversible migration, or destructive operations. Local implementation may proceed where safe.
