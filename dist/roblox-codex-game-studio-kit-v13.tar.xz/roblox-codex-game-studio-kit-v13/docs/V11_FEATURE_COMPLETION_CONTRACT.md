# V11 Feature Completion Contract

A feature is complete only when:
- Player/developer outcome and non-goals are clear.
- Research is recorded for affected APIs/approaches.
- Dependencies, ownership, and public contracts are clear.
- The full player path is integrated, including loading, failure, retry, and cleanup where applicable.
- Server authority, persistence, and validation are addressed when relevant.
- Tests are selected from actual change impact and results recorded.
- Generated artifacts are reproducible and schemas/docs updated.
- Diff and human maintainability are reviewed.
- Limitations and residual risk are explicit.

Do not make a feature pass by weakening acceptance criteria after an implementation fails. Update the spec only when the intended behavior genuinely changes and record that change.
