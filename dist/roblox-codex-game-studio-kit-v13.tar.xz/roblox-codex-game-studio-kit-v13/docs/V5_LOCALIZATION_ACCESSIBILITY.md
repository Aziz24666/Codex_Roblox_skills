# V5 Localization and Accessibility Engineering

## Localization
Keep player-visible strings in keyed catalogs. Each key should have source text, context, placeholders, translator notes, length constraints when useful, and review status. Define fallback for missing translation/key. Avoid concatenated fragments; use full translatable messages. Plan text expansion, plurals, number/date formatting, mixed scripts, RTL where supported, font coverage, and avoid text baked into images without a localized image pipeline.

## UI resilience
Use constraints, anchors, scale, safe areas, and responsive layout. Test narrow/wide aspect ratios, long labels, and large text. Keep essential actions visible and operable.

## Input accessibility
Map gameplay actions to input intents so keyboard, mouse, touch, and gamepad share the same gameplay contract. Avoid making one precision gesture essential. Provide focus order and visible selection.

## Audio/visual accessibility
Important information must not depend on audio or color alone. Offer visual cues for important sound events, reduced-motion/reduced-flash options for intense transitions, respect mute settings, and ensure effects do not obscure objectives.

## QA matrix
Test critical screens/loops across aspect ratio, input, locale, text length, focus path, mute, motion preferences, and readability. Record actual tested combinations; emulator-only results do not prove every physical device.
