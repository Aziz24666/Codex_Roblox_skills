# V6 Cinematics, Dialogue, and Presentation Systems

## Separate presentation from game authority
Camera movement, fades, subtitles, and local animation are normally presentation. Objective completion, reward, inventory, permissions, and match transition are server-owned gameplay state. A cutscene finishing locally must not grant an authoritative reward.

## Sequence specification
Each sequence records:
- ID, trigger, audience, priority, and whether it is synchronized.
- State machine: `IDLE`, `PREPARING`, `PLAYING`, `SKIPPED`, `INTERRUPTED`, `COMPLETED`, `CLEANED_UP`.
- Camera/input/UI/audio ownership.
- Required assets and fallback if they fail to load.
- Subtitle/dialogue keys and timing.
- Skip/fast-forward behavior.
- Respawn/disconnect/character-removal behavior.
- Cleanup owner and invariant checks.

## Implementation
Use a single sequence controller and guaranteed cleanup path. Avoid multiple systems independently taking camera or input ownership. Use elapsed-time interpolation, not frame-count assumptions. Do not rely on client clocks for authoritative match outcomes.

## Accessibility and devices
Support subtitles, readable text, localization, user control over audio, reduced motion where appropriate, touch/gamepad skip controls, safe areas, and short/long text layouts.

## QA
Interrupt at every state, test overlap, late assets, failed sound, respawn, device rotation, locale change, low frame rate, and multi-client synchronization where relevant.
