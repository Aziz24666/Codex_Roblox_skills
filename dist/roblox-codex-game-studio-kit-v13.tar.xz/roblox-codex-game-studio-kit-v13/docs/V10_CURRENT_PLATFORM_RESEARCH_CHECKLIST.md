# V10 Current Platform Research Checklist

Before implementing, check only relevant topics but always search fresh:

- [ ] Creator Hub guide for the problem area opened.
- [ ] Exact engine/API reference opened for each new API surface.
- [ ] Release notes/current updates searched for changed/announced behavior.
- [ ] Studio/client/server/plugin security context checked.
- [ ] Beta/deprecated/permission/feature availability checked.
- [ ] Upstream tool docs opened for each external tool.
- [ ] Alternatives searched and compared for non-trivial decisions.
- [ ] Source date, access date, exact URL, claim, and caveats recorded.
- [ ] Research record passes V10 linter.
- [ ] High-risk/ambiguous behavior gets a minimal Studio spike.
- [ ] After implementation, actual test evidence and deviations are recorded.
