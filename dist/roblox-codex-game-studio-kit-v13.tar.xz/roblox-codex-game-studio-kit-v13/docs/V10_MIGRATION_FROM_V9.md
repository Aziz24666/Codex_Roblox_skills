# V10 Migration from V9

V10 preserves V9's schema-generated editor, content families, templates, plugin source, and validation utilities. It adds a mandatory research-first engineering contract, research record schemas/tools, deeper architecture/code-quality standards, current Studio MCP integration guidance, and expanded testing/toolchain decision workflows.

## Safe adoption
1. Back up the project and inspect source-of-truth mappings.
2. Merge `AGENTS.md` instructions; preserve project-specific rules and nested instructions.
3. Add the new `research/` records folder and tools.
4. Update only skills used in the current project; do not load all skills into every task.
5. Run V10 package doctor and record linter on examples.
6. Connect Studio MCP only if supported by the current Studio/client configuration.
7. Do not migrate Studio-native/Script Sync projects to Rojo without explicit analysis and approval.
8. Do not run new plugin source in the production place before disposable-place verification.

## Compatibility
V10 does not force a new game architecture or automatically rewrite existing code. It is an instruction/documentation/tooling layer plus examples. Apply changes incrementally and keep a rollback path.
