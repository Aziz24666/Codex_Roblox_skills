# Studio Workflow And Tooling



## Workflow discovery

Detect the project's source of truth before editing. Inspect `default.project.json`, `rokit.toml`, `aftman.toml`, `wally.toml`, `wally.lock`, CI workflows, Studio plugins, Script Sync, and repository instructions when present. Do not assume any particular tool is installed.

## Workflow modes

| Mode | Source of truth | Codex-safe approach |
|---|---|---|
| Studio-native | Place file/Studio DataModel | Work only on exported/source-controlled scripts; provide Studio steps for unavailable editor actions |
| Rojo | Files + project mapping | Verify mapping, pinned Rojo version, build output, and Studio sync procedure |
| Script Sync | Studio/source sync integration | Confirm exact ownership and sync direction before changing files |
| Mixed | Explicit folder ownership | Maintain a per-folder authority map; prevent duplicate writers |
| Unknown | Not yet established | Inspect, document uncertainty, do not migrate |

## Rojo checks

- Validate project mapping JSON.
- Confirm all `$path` values resolve.
- Confirm class mappings and script suffixes are intentional.
- Inspect generated place/model output only with the project's pinned Rojo version.
- Avoid overwriting Studio-authored assets outside mapped paths.
- Treat a successful build as mapping/build evidence, not a runtime pass.

## Studio capability boundaries

Studio runtime, Explorer, Properties, Output, Asset Manager, Toolbox, publishing, and Creator Dashboard are not automatically controllable from a filesystem session. Use a connected Studio tool/plugin only when its operations are explicitly available. If none exists, provide exact manual steps and mark the Studio check as not run.

## Safe action sequence

Baseline Git status → check project mapping → edit one slice → run static checks/build → synchronize through a real supported tool → inspect Explorer/Output → run correct test mode → capture evidence → review diff.

## Toolchain record

Maintain a table of tool, version, source, pin location, purpose, command, and last verified date. Do not upgrade the whole toolchain as a side effect of a feature task.
