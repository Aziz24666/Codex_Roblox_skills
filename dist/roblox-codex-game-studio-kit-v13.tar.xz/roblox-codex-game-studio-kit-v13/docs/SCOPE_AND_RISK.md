# Scope, Milestones and Risk Management

## Prioritize
Use three buckets:
- **Launch-critical:** required for the core loop, trust, usability or reliability.
- **Valuable later:** improves depth but is not required to validate the game.
- **Out of scope:** intentionally excluded for this version.

Score work by player value, dependency, uncertainty, effort and risk. Do not let a visually exciting feature leap ahead of foundational persistence, security or interaction work.

## Milestone format
Each milestone contains:
- goal and player-visible outcome;
- included and excluded work;
- dependency list;
- implementation steps;
- acceptance criteria;
- tests and evidence;
- risks and rollback notes;
- completion definition.

## Risk register
Track likelihood, impact, detectability, mitigation, owner and status. Common risks include unknown API behavior, toolchain mismatch, data schema changes, streamed instance assumptions, exploit-prone remotes, large world memory, missing asset permissions, mobile UI crowding and untested multi-client behavior.

## Scope-change policy
When new work appears, state what it displaces or delays. Do not silently grow the milestone. Keep a backlog of deferred ideas with a short rationale.
