# V13 Migration from V12

V13 is cumulative. It adds CI, toolchain, testing, artifact, and release-quality engineering and repairs inherited skill metadata that had Markdown research sections inside YAML frontmatter.

## Safe adoption
1. Back up or branch the existing project.
2. Keep the current Studio/Script Sync/Rojo source-of-truth model.
3. Copy the V13 `AGENTS.md` only after merging project-specific instructions.
4. Copy `.agents/skills/`; validate with `tools/v13_skill_frontmatter_audit.py`.
5. Add the workflow profile and toolchain pins.
6. Add read-only CI and run it on a branch.
7. Add Studio or Open Cloud testing only after researching access/permissions and selecting a non-production target.
8. Add production deployment as a separate approved workflow; V13 does not provide a publishing command.

Do not convert an existing Studio-native project to fully managed Rojo just to use CI. Start with metadata, tests and source checks that fit the present workflow.
