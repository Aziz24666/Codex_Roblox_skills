# V10 Architecture Approach Comparison

For a non-trivial system, sketch at least two viable options before coding. Examples:
- shared controller + data definitions vs per-model scripts;
- event-driven state updates vs polling;
- native Roblox feature vs custom framework;
- Studio-native vs Script Sync vs partial/fully managed Rojo;
- direct ModuleScript dependency vs injected interface;
- server-owned state vs client prediction with server reconciliation;
- single/few durable data keys vs multiple access-pattern-specific keys.

Compare only meaningful criteria: correctness, security, coupling, runtime cost, replication, persistence consistency, lifecycle, editor ergonomics, test seams, asset workflow, team size, version control, and migration cost.

## Decision rules
- Prefer the simplest stable design that satisfies current and near-term requirements.
- Add an abstraction when it removes duplication, isolates a real change boundary, or makes testing easier. Do not abstract a single trivial call just to add layers.
- Avoid global registries that become hidden service locators. A registry should have an explicit domain, lifecycle, and typed contract.
- Keep configuration immutable; make runtime state instance-owned.
- Prefer composition and explicit dependencies over inheritance trees and implicit global access.
- Avoid making every system data-driven if the data format adds more complexity than the variation it represents.
- Prototype uncertain/high-cost choices before committing to them.

Include a `notChosen` section in each decision record and state when an alternative should be reconsidered.
