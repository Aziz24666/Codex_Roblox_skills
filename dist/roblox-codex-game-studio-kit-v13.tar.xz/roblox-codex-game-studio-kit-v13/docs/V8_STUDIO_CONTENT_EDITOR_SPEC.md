# V8 — Studio Content Editor Specification

## Purpose
A dockable Studio plugin that edits validated data definitions and generates consistent prefabs from approved templates. The V8 starter plugin demonstrates two safe content families: tagged NPC prefabs and non-combat utility gadgets/interactive props.

## UX flow
1. Choose content type.
2. Load a template/selected source model where required.
3. Edit schema-driven fields with labels, descriptions, defaults, units, and bounds.
4. Validate without changing the DataModel.
5. Preview the resulting hierarchy and asset bindings.
6. Generate to a predictable output folder.
7. Show exactly what was created, skipped, or rejected.
8. Support undo and safe regeneration.

## UI architecture
- `PluginEntry`: creates toolbar button and dock widget.
- `EditorView`: draws fields and validation messages.
- `FormController`: owns draft state and field-level updates.
- `DefinitionParser`: decodes draft data.
- `DefinitionValidator`: pure validation and normalization.
- `PrefabFactory`: creates Instances from validated data and templates.
- `OutputReporter`: lists generated paths, warnings, and provenance.

## Editor field metadata
Each field defines: key, label, description, value type, default, required, min/max, allowed values, asset-reference type, visibility condition, and validation message. The form is generated from this metadata. Avoid hard-coded one-off forms for every content type.

## Safety
No implicit publishing, public uploads, permission changes, purchases, or external requests. Do not execute code found in imported assets. Use approved template folders. Do not overwrite user-authored objects without an explicit replace action and preview.
