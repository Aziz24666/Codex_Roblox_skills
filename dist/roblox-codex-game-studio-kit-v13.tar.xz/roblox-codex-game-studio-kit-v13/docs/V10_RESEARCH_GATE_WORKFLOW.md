# V10 Research Gate Workflow

## Gate R0 — Scope and surfaces
Write a 3–8 line scope note. List the user-visible outcome, Roblox services/classes/members, execution context (plugin/server/client), assets, toolchain, persistent data, security boundaries, and affected modules. Do not start coding yet.

## Gate R1 — Current official documentation
Search Creator Hub by topic and exact API symbol. Open the guide and API pages. Capture exact signatures, security tags, thread-safety/availability notes where relevant, caveats, limits, lifecycle, and examples. Search the current release/update feed and relevant announcement category for new or pending changes.

## Gate R2 — Online alternatives and pitfalls
Search upstream docs for third-party tools. Search maintained projects or expert discussions for practical pitfalls. Confirm any proposed API usage against official docs. Note source date and project/version compatibility. Do not copy code without tracing ownership, lifecycle, and assumptions.

## Gate R3 — Approach comparison
Compare options in a table. Suggested criteria: simplicity, correctness, API stability, security, replication, performance, memory, testability, migration cost, team fit, and human maintainability. Score only criteria that matter; explain uncertainty.

## Gate R4 — Decision record
Create `research/decisions/<date>-<topic>.json` from `schemas/v10-research-decision.schema.json`. Generate an index with `python tools/v10_research_index.py`. Run `python tools/v10_research_record_lint.py <record> --require-today` and `python tools/v10_research_gate.py --record <record> --changed-file <path>` before implementation.

## Gate R5 — Spike when needed
For beta, new, undocumented, ambiguous, or high-impact behavior, create the smallest disposable Studio place/project and test the API. Keep test data isolated. Record exact Studio build, plugin/client versions, expected/actual behavior, and logs.

## Gate R6 — Implement and verify
Implement only the chosen approach. Run the most relevant static, type, schema, build, Studio, multiplayer, device, and performance checks actually available. Update the record with actual evidence and recheck any assumptions.

## Gate R7 — Review and release
Before release, reopen the current docs for every API-sensitive item in scope, check updates/deprecations, and verify toolchain versions. Record whether the chosen approach is still valid. Production action requires approval.
