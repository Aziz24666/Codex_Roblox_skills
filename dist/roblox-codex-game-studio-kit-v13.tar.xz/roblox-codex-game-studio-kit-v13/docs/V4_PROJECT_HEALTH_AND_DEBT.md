# V4 Project Health and Technical Debt

A growing game needs a controlled maintenance loop. Do not create a generic framework for every repeated line; record debt when it increases risk, slows changes, causes defects, or blocks testing.

## Health dimensions

- architecture: ownership, coupling, module boundaries, dependency direction;
- reliability: errors, lifecycle leaks, retry behavior, state recovery;
- security: remote validation, permission checks, purchase/data integrity;
- performance: startup, rendering, memory, network, server work;
- content: asset provenance, stable IDs, broken links, readability;
- player experience: onboarding, accessibility, fairness, session flow;
- delivery: reproducible builds, test evidence, pinned tools, release notes;
- maintainability: duplicated logic, unclear contracts, stale documentation.

## Debt register format

For each item record observed evidence, player/developer impact, likelihood, severity, owner/system, smallest safe remediation, and revisit condition. Prioritize by risk and impact, not aesthetic preference.

## Maintenance cadence

After each milestone: update tests and docs, remove temporary scaffolding, inspect logs, review debt. Before a major release: run a project-health audit, dependency/license check, performance comparison, data recovery review, and full relevant regression matrix.
