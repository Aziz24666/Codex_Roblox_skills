# V9 — Prefab Factory Transactions

## Preflight
1. Validate definition against schema.
2. Normalize a copied snapshot.
3. Resolve an allowlisted family handler.
4. Validate source selection and required descendants.
5. Confirm approved template ID/version.
6. Check definition and prefab output collisions.
7. Build a non-mutating output plan.
8. Disable Generate if any hard error remains.

## Transaction
1. Call `ChangeHistoryService:TryBeginRecording(name, displayName)` before any DataModel write.
2. If it returns nil, report that no change was made.
3. Create all output instances under deterministic folders.
4. Write definition data and provenance.
5. Run post-generation hierarchy checks.
6. Commit with `FinishRecording(recordingId, Enum.FinishRecordingOperation.Commit)`.
7. On any error, cancel with `FinishRecording(recordingId, Enum.FinishRecordingOperation.Cancel)` and report failure.

## Guarantees
- Do not perform DataModel mutation before recording begins.
- No overwrite by default.
- Ensure created objects are all parented within the intended generated roots and covered by the recording.
- Always cancel a started recording on failure.
- Do not leave a half-generated module or prefab.
- Re-test Undo and Redo in actual Studio; a static source check is not proof.
