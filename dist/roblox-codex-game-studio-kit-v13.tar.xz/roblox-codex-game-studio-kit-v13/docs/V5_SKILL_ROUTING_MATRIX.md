# V5 Skill Routing Matrix

| Task | Primary skill | Add when relevant |
|---|---|---|
| Whole game | `roblox-game-builder` | product design, architecture, Studio |
| Luau module | `roblox-luau-engineering` | code review, testing |
| Client/server request | `roblox-networking-security` | data, QA |
| Persistent profile | `roblox-data-progression` | economy, release |
| Map/world | `roblox-worldbuilding` | procedural, asset pipeline |
| Player build | `roblox-building-sandbox` | network, persistence |
| Pets | `roblox-pets-companions` | NPC, audio, persistence |
| Farming/crafting | `roblox-farming-crafting` | economy, persistence |
| Sports | `roblox-sports-games` | character feel, multiplayer |
| Rhythm | `roblox-rhythm-games` | audio, accessibility |
| Party rounds | `roblox-party-minigames` | matchmaking, QA |
| Cross-server | `roblox-matchmaking-teleport` | multiplayer security, data |
| Localization | `roblox-localization` | UI, accessibility |
| Community surfaces | `roblox-community-safety` | roleplay, analytics, QA |
| Transactions | `roblox-economy-transactions` | data, player trust |
| Performance/release | `roblox-qa-performance` / `roblox-release-operations` | Studio, review, assets |

Use the smallest relevant set. Load security/data/test references whenever a feature affects remotes, persistence, shared state, social features, or transactions.
