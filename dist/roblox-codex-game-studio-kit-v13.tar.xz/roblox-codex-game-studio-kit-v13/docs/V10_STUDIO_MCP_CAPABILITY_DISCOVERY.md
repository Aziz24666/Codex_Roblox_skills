# V10 Studio MCP Capability Discovery

The official Roblox Studio MCP server is built into Studio. Its tools can vary by Studio version and connected client. Current Creator Hub documentation describes capabilities for script read/search/edit, DataModel inspection, Luau execution, asset/content generation, specialized subagents, and playtesting. Treat this list as a discovery hint, not a guarantee for a particular session.

At task start:
- inspect the connected MCP tools and their schemas;
- query/list active Studio sessions;
- record the target `studio_id` and place identity;
- confirm whether the Studio session is edit or play mode;
- confirm whether script read/write, execute, and playtest functions exist;
- do not assume publish or Open Cloud operations are within scope.

If MCP exposes a tool that can mutate content, use it only after a narrow plan and backup/diff. Verify the result by reading back the changed instances or scripts. For generated assets, verify status and inspect the resulting content before use. Always use a disposable test place for experiments.
