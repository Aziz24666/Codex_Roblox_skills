# V9 — Schema Catalog Contract

The canonical source of truth is `examples/v9/catalog.json`. The plugin ModuleScript `SchemaCatalog.lua` is generated from it by `python tools/v9_generate_lua_catalog.py`; do not hand-edit the generated ModuleScript.

Each family entry must contain:
- `id`: stable family ID, unique, lowercase kebab-case.
- `label`: short human-facing name.
- `description`: what the content type represents.
- `schemaVersion`: integer starting at 1.
- `templateId` and `templateVersion` where a template is required.
- `sourceRequirement`: `HumanoidModel`, `Accessory`, or `None` in the starter editor.
- `outputKind`: an allowlisted generator key, not a Roblox class name.
- `fields`: ordered list of typed field descriptors.

Each field descriptor includes `path`, `label`, `kind`, `default`, `required`, and optional `help`, `min`, `max`, `maxLength`, `options`, and `assetKind`.

## Allowed field kinds in the starter
- `identifier`: restricted stable ID, 2–48 characters.
- `text`: bounded plain text; never interpreted as code.
- `number`: finite numeric value with optional min/max.
- `boolean`: true/false.
- `enum`: value must match the explicit `options` allowlist.
- `assetId`: blank or canonical `rbxassetid://<digits>` reference. The UI may accept bare digits and normalize them, but this is syntax-only validation.

Do not allow schema metadata to name arbitrary Roblox classes, properties to set, require paths, callbacks, script source, or arbitrary generator functions. The code maps a known `outputKind` to a known handler.

## Field path rules
Nested paths use dot notation (for example, `movement.walkSpeed`). Segments must be identifiers `[A-Za-z][A-Za-z0-9_]*`; reject empty segments and collisions where one path is a scalar and another is its child. The schema catalog lint utility checks basic descriptor consistency.

## Defaults and normalization
- Defaults must be valid under their own constraints.
- Missing optional asset fields normalize to an empty string.
- Numbers must be finite; reject NaN and infinities.
- Never silently clamp a user's input. Display the error and let the author choose.
- The normalized definition is a snapshot; the UI can continue editing a separate draft.
