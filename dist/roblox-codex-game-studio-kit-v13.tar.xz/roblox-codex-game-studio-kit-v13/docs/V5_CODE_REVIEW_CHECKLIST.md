# V5 Code Review Checklist

## Correctness
- Meets every acceptance criterion?
- Legal, deterministic state transitions?
- Duplicate, concurrent, stale, out-of-order paths handled?
- Failure and recovery explicit?

## Luau/architecture
- `--!strict` for new code where practical?
- Narrow meaningful types?
- Cohesive modules and public contracts?
- Correct execution context and dependency direction?
- Engine API signatures verified?

## Security/data
- Every client-originated path validated server-side?
- Permissions, ownership, range, bounds, rate, cost checked?
- Server-only data/secrets excluded from replicated containers?
- Data versioned, bounded, idempotent, recoverable?
- Side effects safe to retry?

## Lifecycle/performance
- Connections/tasks/instances/temp state cleaned up?
- Loops bounded and event-driven where practical?
- Per-frame work justified/profiled?
- Replication limited?
- Streaming and character replacement handled?

## Player experience
- Controls/feedback work across supported inputs?
- Essential info not color/audio-only?
- UI resilient to long text?
- Social and monetization choices fair and age-appropriate?

## Delivery
- Tests meaningful and repeatable?
- Evidence tied to exact build/commit?
- Docs/schemas/assets updated?
- Diff focused and free of secrets/generated junk/unrelated edits?
