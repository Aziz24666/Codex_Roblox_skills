# V6 Data-Driven Content and Asset Validation

## Content catalog contract
Store content in versioned, typed catalogs rather than scattered literals. Each entry should have a stable ID, category, display/localization keys, dependencies, balance metadata, asset references, visibility/availability rules, and provenance. Keep runtime logic separate from authoring data.

## Validation stages
1. Parse file formats and validate schema.
2. Check stable ID uniqueness and reference integrity.
3. Check numeric bounds, enums, ranges, ordering, and required fields.
4. Check cross-entry consistency (unlock prerequisites, recipe graph, wave schedule, quest links, item references).
5. Check localization-key coverage and fallback.
6. Check asset provenance, license/permission evidence, expected type, and availability.
7. Check device/streaming budgets and expected runtime cost.
8. Generate a review report; do not silently rewrite author data.

## Asset provenance
Record source, creator/publisher, asset ID, intended use, license/permission evidence, import date, modifications, embedded scripts inspection, dependency, and replacement plan. Do not assume public visibility means free permission for all uses.

## Procedural content
Use deterministic seeds for reproducible authored layouts where suitable. Keep generator version, parameters, seed, and output hash. Validate generated output after generation; a deterministic generator can still generate invalid or unplayable content.

## Content safety
Review names, dialogue, user-generated text pathways, image/audio use, privacy, and community interaction. Minimize collection and retention of user data. Use platform moderation and safety APIs only after verifying current docs and policy.
