# V9 — Human Extension Guide

This guide explains how to change the system without rewriting it.

## Change an NPC's speed
1. Open the NPC definition in the editor or its generated definition module.
2. Change `movement.walkSpeed`.
3. Validate and preview.
4. Use the game's shared NPC runtime; do not add another movement Script to the model.

## Add a new NPC variant
1. Copy an example definition JSON.
2. Change `id`, display name, behavior, and values.
3. Keep the same schema family and template.
4. Validate; generate from an approved Humanoid rig.
5. Confirm the prefab tag and `DefinitionId` attribute.
6. Confirm the shared NPC bootstrap resolves the new definition.

## Add a field used by multiple families
1. Add a field descriptor to family schemas with a supported `kind`.
2. Add its default and semantic constraints.
3. The generic form renderer automatically renders it.
4. The validator checks it based on the same descriptor.
5. Update JSON Schema and examples.
6. Add positive, boundary, and negative tests.
7. Update generated field reference docs.

## Add a new control kind
Only do this when existing kinds cannot represent the value clearly.
1. Define a precise parse/format contract.
2. Implement one renderer in `DynamicFormRenderer`.
3. Add pure validation/normalization behavior.
4. Add schema lint rules.
5. Add keyboard/accessibility behavior and compact-layout review.
6. Add fixtures for valid, invalid, empty, and boundary states.
7. Keep the control generic; do not tie it to one family.

## Add a content family
1. Add catalog metadata with stable ID, schema/template version, source requirement, and allowlisted generator key to `examples/v9/catalog.json` (the canonical source of truth).
2. Add/validate the family JSON Schema and examples.
3. Run `python tools/v9_schema_catalog_lint.py` and `python tools/v9_generate_lua_catalog.py` to validate and regenerate the plugin catalog module.
4. Add the family-specific generator handler in `PrefabFactory`.
5. Define source/template compatibility and required descendants.
6. Add preview-plan output.
7. Add post-generation hierarchy validator.
8. Add collision, failure, rollback, undo/redo, and two-variant tests.
9. Add a human-facing recipe.

## When to add a separate script/module
Add a module when it has a distinct responsibility, lifecycle, dependency, or test seam. Do not split every 10 lines into its own file. Keep UI, validation, data serialization, template resolution, generation, and game runtime separate because they have different responsibilities and test requirements.
