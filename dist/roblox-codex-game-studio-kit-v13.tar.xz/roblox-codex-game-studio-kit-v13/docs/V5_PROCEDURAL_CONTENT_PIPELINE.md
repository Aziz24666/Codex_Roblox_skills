# V5 Procedural Content Pipeline

## Inputs
Define world grammar, seed policy, layout rules, content constraints, difficulty envelope, spawn safety, navigation, asset catalog, and memory/replication budget before generation.

## Determinism
Use explicit seeds. Version the generator separately from the seed. Record seed, generator version, config ID, and feature flags where replay/debugging needs them. Shared gameplay geometry and rewards remain server-authoritative; local decoration may be client-side.

## Pipeline
1. Validate configuration and bounds.
2. Build a compact abstract layout (graph/grid/room plan).
3. Validate reachability, progression, spawn safety, and forbidden overlaps.
4. Select assets from a reviewed catalog.
5. Instantiate in bounded batches.
6. Apply navigation/interaction tags.
7. Check structure and content budgets.
8. Replicate through the selected streaming model.
9. Record seed/version/config when useful for reproduction.

Set hard limits for rooms, instances, retries, generation attempts, and elapsed work. Every generator must terminate. Use a safe fallback or return a diagnostic when config is invalid.

## Streaming awareness
Do not assume every Workspace instance exists on a client at join. Interaction discovery must tolerate instances streaming in/out. Keep required initial replicated content lean.

## Validation
Fixed-seed samples, extreme/invalid config, reachability/softlock, spawn clearance, overlaps, missing-asset fallback, budgets, streaming, server/client consistency, generation time, and memory.
