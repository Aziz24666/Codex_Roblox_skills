# V8 — Reusable Movement System

Movement code accepts a Humanoid/root adapter and a validated movement profile. It must not contain per-NPC constants such as `VillageGuideSpeed` or `PetSpeed`.

## Profile fields
- `walkSpeed`: validated non-negative number within project policy.
- `jumpPower` or `jumpHeight`: choose one movement model and document it.
- `arrivalRadius`: threshold before destination is considered reached.
- `turnResponsiveness`: controls facing interpolation where implemented.
- `repathInterval`: minimum interval between path recomputations.
- `stuckTimeout`: time without meaningful progress before recovery.
- `maxPathRetries`: bounded retry count.

## Responsibilities
The movement layer owns path calculation/request throttling, waypoint progression, arrival checks, stuck detection, cancellation, and low-level movement commands. Behavior policy decides *where/when* to move. Animation presentation responds to actual movement state.

## Extension guide
To make a slow guide, create a definition with a lower `walkSpeed`; do not edit the shared controller. To change all NPC path recovery behavior, edit the one shared movement module and run the movement regression suite.
