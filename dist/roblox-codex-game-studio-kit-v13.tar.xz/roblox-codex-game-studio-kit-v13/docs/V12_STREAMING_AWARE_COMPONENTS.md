# V12 Streaming-Aware Components

## Separation
Keep the definition/configuration stable and independent of a particular streamed Instance. Resolve a live Instance only when the component is attached or when an interaction is needed. Put transient connections, highlights, prompts, and local presentation in per-instance runtime state.

## Component lifecycle
`Unregistered → Attached → Active → Detached → (optional re-attached)`

Every transition must be idempotent. On detach, disconnect every signal, cancel owned tasks, destroy owned temporary instances, and release references. Do not destroy the server-owned world object merely because it streamed out on a client.

## Lookup pattern
Use current tag signals and a `GetTagged()` startup pass where tag-driven registration is appropriate. Connect signals before enumerating the existing set, then use idempotent attach to avoid a race/duplicate registration. A controller must support Stop/Destroy.

## Validation
- A tag present before the LocalScript starts is handled.
- A tag added later is handled exactly once.
- A tag removed triggers cleanup.
- A streamed-out object does not retain local UI or event connections.
- A streamed-in object can attach again.
- Stopping the system releases all connections and state.

Read `examples/v12/TaggedLifecycleBinder.lua`.
