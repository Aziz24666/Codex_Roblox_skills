# V13 Luau Static Analysis

## Tool roles
- Roblox Studio Script Analysis and type checking are integrated with the editor.
- `luau-analyze` provides command-line static analysis, including type analysis and linting.
- StyLua formats Luau consistently; use check mode in CI and write formatting changes separately.
- Selene can add lint rules when its Luau support and project config have been verified.

## Rules
1. Prefer `--!strict` for new modules and migrated modules where practical.
2. Type public module interfaces, configuration definitions, remote contracts and return values.
3. Avoid `any` as a shortcut; isolate unsafe boundaries and validate/cast only after checks.
4. Configure tool versions explicitly. Do not install `latest` implicitly in CI.
5. Keep engine-specific modules separate from pure Luau modules so pure logic can run outside Roblox.
6. Do not claim `luau-analyze` success if it was missing or not run.

## Adoption
Start with a report-only pass; fix high-confidence errors in changed code; then raise enforcement gradually. Don't mass-rewrite every legacy file in an unrelated feature task.
