# Release Operations and Handoff

## Release candidate checklist
- version/commit identified;
- scope and known issues recorded;
- acceptance criteria reviewed;
- static/build/automated checks run;
- Studio client/server tests run where available;
- multiplayer/device tests run where relevant;
- security review complete for client-triggerable actions;
- data schema/migration compatibility reviewed;
- assets verified and provenance documented;
- privacy, content and platform policy checked against current official guidance;
- performance measured on declared target devices;
- rollback/forward-fix plan documented;
- owner approval obtained before external changes.

## Release note structure
Version, date, player-visible changes, fixes, known issues, migration notes, compatibility notes and operational watch items.

## Incident response
1. Describe player impact and scope.
2. Stop the source of damage if an authorized safe action exists.
3. Preserve logs/evidence without collecting unnecessary personal data.
4. Identify whether issue is code, data, asset, platform or configuration.
5. Prepare fix/rollback recommendation.
6. Obtain approval before live changes.
7. Verify outcome and document follow-up.

## Handoff
Leave the project with an accurate status, test evidence, current milestone, open risks, tool versions and next concrete action.
