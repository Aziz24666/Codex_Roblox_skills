# V13 Automated Quality Pipeline

## Goal
Run `tools/v13_ci_preflight.py` as the local package baseline, then build the smallest useful automated pipeline for the project's actual workflow. Do not bolt a complicated fully-managed release chain onto a Studio-native project without a real need.

## Pipeline stages
1. **Repository preflight:** source-of-truth profile, clean/known diff, expected files, no local secret files.
2. **Metadata/schema checks:** valid skill frontmatter, JSON syntax/schema, catalog/definition validation, project mappings.
3. **Luau static quality:** `luau-analyze` where installed; StyLua check mode and Selene only when configured/pinned. Report missing tools as `BLOCKED` or `NOT APPLICABLE`, never as pass.
4. **Unit tests:** pure Luau modules through a compatible local runner/harness; Python tooling tests through `unittest`; no Roblox engine APIs in pure tests.
5. **Build:** `rojo build` only for managed Rojo profiles with a valid project file and pinned version. Preserve output and build log.
6. **Studio integration:** StudioTestService/Studio MCP or manual Test modes when the project needs engine behavior. Record actual session and client count.
7. **Release candidate:** verify artifact manifest, required evidence, target environment, migration/rollback plan and approval state.
8. **Deployment:** separate, privileged, explicitly approved workflow. Never make a pull-request quality workflow publish.

## Recommended gates
- PR: schema/metadata checks, unit tests, static checks, dependency and CI security audits. Read-only token.
- Main branch: repeat PR checks, managed-profile build, archive artifacts and provenance.
- Release candidate: add Studio/multiplayer/device evidence and explicit approvals.
- Production deployment: separate workflow/environment with restricted approvers and narrowly scoped credentials.

## Quality policy
- Run the affected tests first, then broader regression tests based on change impact.
- A test skipped because the tool is missing is not a pass.
- Store machine-readable results and human-readable summary.
- Do not allow flaky retries to turn a persistent failure into a green result. Capture the first failure and investigate.
- Never upload secrets in artifacts or logs.


## Local package baseline
The V13 kit preflight checks skill metadata, the package doctor, the discovered regression suite, workflow security, the workflow profile, test-matrix coverage, exact toolchain pins, and available Luau/Roblox CLIs. It is package validation, not a substitute for the project-specific Roblox runtime checks selected above. The test runner enforces a non-zero minimum test count so a misspelled test path cannot silently produce a green result.
