# V8 — Schema-Driven Editor Field Model

Represent editor fields as typed metadata so one form renderer can build many content editors.

Example field metadata:
```json
{
  "key": "movement.walkSpeed",
  "label": "Walk speed",
  "description": "How quickly this NPC moves.",
  "type": "number",
  "default": 10,
  "minimum": 0,
  "maximum": 24,
  "step": 0.5,
  "unit": "studs/second",
  "required": true
}
```

The editor must support text, number, boolean, enum, asset-reference, vector, nested object, and list fields. Keep the canonical schema in one place and derive form presentation from it. Do not assume hiding a field means it need not be validated. Validation runs against the full normalized object.
