# V4 Release and Rollback Runbook

This document prepares a candidate. It does not authorize publishing or modifying live resources.

## Candidate package

- commit/hash and branch;
- place/project identifier in approved internal records only;
- toolchain and dependency versions;
- feature list and known issues;
- automated test outputs;
- Studio test evidence;
- asset provenance/license register;
- data schema and migration version;
- performance results;
- moderation, privacy, monetization, and accessibility checks;
- rollback decision and responsible approver.

## Pre-release gate

1. Freeze scope; any late fix requires focused regression.
2. Confirm all release-blocking criteria pass.
3. Review new/changed remotes and server-authoritative state.
4. Confirm data migrations are idempotent, versioned, tested against isolated data, and have recovery instructions.
5. Confirm public assets are original or appropriately licensed.
6. Verify UI labels and purchase descriptions are accurate.
7. Confirm observability is useful but data-minimizing.
8. Record known issues and player impact.
9. Prepare rollback or feature-disable strategy.
10. Obtain explicit authorization before any external/publishing operation.

## Rollback design

Prefer reversible feature flags/configuration over destructive rollback. For schema changes, define forward compatibility, migration status, and safe fallback. Never roll back by blindly overwriting player data with an old snapshot. Decide whether to disable the feature, stop new writes, run a forward repair, or restore from an approved recovery procedure.

## Incident response

Prioritize player safety and data integrity. Preserve evidence, limit further impact, communicate factual status, and avoid exposing player-specific data. Do not make unapproved public statements or contact players through external channels.
