# V11 Repository Health and Ownership

## Objective
Make the repository understandable, navigable, and safe to change over many development sessions.

## Audit dimensions
- Source of truth: Studio-native, Script Sync, Rojo, or a deliberate mixed arrangement.
- DataModel mapping: project files to services/containers; detect duplicate mappings and unmanaged regions.
- Ownership: module purpose, owner/boundary, public interface, runtime context, dependencies, lifecycle, tests.
- Generated content: source schema/template, generator version, deterministic output, provenance, regeneration path.
- Asset provenance: source, permission status, moderation/availability status, license/usage assumptions.
- Tests: unit, integration, Studio, multi-client, device, performance, and release evidence.
- Toolchain: pinned versions, installation instructions, CI parity, and known compatibility constraints.

## Rules
1. Inventory before reorganizing.
2. Preserve user changes and source-of-truth conventions.
3. Detect duplicate responsibilities before moving files.
4. Prefer small changes with explicit before/after maps.
5. Avoid large-scale renames unless migration and rollback are documented.
6. Update docs, project mappings, tests, and generated manifests together.

## Repository map format
Include top-level directories, main entry points, runtime contexts, module families, data/schema locations, generated paths, tests, editor plugins, build tools, and external dependencies. Do not dump a raw recursive tree when a role-based map is clearer.

## Health score is advisory
A static inventory can identify missing docs, duplicate names, large files, or obvious boundaries. It cannot determine architecture quality automatically. Label heuristics and require human/agent review for conclusions.
