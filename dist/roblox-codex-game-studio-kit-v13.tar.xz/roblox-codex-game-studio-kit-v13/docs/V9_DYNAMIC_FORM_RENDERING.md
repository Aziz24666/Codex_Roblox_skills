# V9 — Dynamic Form Rendering

## Rendering contract
`DynamicFormRenderer` receives `(parent, schema, draft, onFieldChanged)`. It creates controls in schema order and returns cleanup handles or a disposable frame. It does not know about ServerStorage, templates, or generation.

## Control behavior
| Kind | Control | Parse/validation |
|---|---|---|
| identifier | TextBox | Allowed characters and length |
| text | TextBox | String, required/maxLength |
| number | TextBox | `tonumber`, finite, min/max |
| boolean | Toggle button | Boolean value |
| enum | Cycle/dropdown control | Exact allowlisted option |
| assetId | TextBox | Blank or `rbxassetid://digits`; separate real asset check |

## UX requirements
- Group fields by section; show label and short help.
- Show required markers and current/default values.
- Parse on focus loss or explicit Apply; do not mutate DataModel on each keystroke.
- Keep invalid text visible where useful and show a precise error.
- Use scrollable forms and stable control heights.
- Re-render only when family/schema changes, not after every keystroke.
- Avoid creating a separate hand-authored form for each family.
- Make destructive/irreversible controls visually distinct and require confirmation.

## State lifecycle
The form owns a draft copy. `Preview` reads a snapshot and is side-effect free. `Generate` reads a validated normalized snapshot. Form changes after preview must invalidate stale preview status.
