# V5 Test Automation Strategy

## Test levels
| Level | What it proves | Does not prove |
|---|---|---|
| Static | Patterns, types, mappings, naming | Runtime behavior |
| Pure unit | Deterministic rules/state transitions | Engine integration |
| Module integration | Modules cooperate with controlled adapters | Full replication |
| Build/mapping | Sources map/build into DataModel | Playability |
| Studio solo | Basic runtime in one local session | Multiplayer correctness |
| Client/server | Ownership and replication separation | All live network conditions |
| Multi-client | Shared session/party/round behavior | Every device condition |
| Device/input | Emulated/physical layout and controls tested | Every device ever made |
| Network simulation | Behavior under selected latency/loss | All production network variance |
| Release smoke | Startup, onboarding, primary loop, save/rejoin | Long-term reliability |

## Remote/interaction tests
Wrong type, missing/oversized fields, non-finite/out-of-range numbers, invalid enum/ID/instance, wrong owner/state, excessive distance, repeated/concurrent/stale calls, disconnect during action, and cleanup.

## Persistent data tests
New/existing profile, migration, transient errors, bounded retries, duplicate requests, unknown write outcome, concurrent session, full inventory/cap, leave/shutdown, isolated test key, and no production-data exposure.

## Multiplayer tests
Min/max capacity, late join, leave/respawn/reconnect, leader change, simultaneous transitions, duplicate/delayed messages, slow client, shutdown, teleport failure, and fallback.

## UI/device tests
Narrow/wide aspect ratio, touch/mouse/gamepad, safe areas, text expansion, focus order, missing locale, mute, reduced motion, and color-independent feedback.

## Evidence
Store test ID, build/commit, level, environment, setup, steps, expected/actual, status, artifact/log pointer, date, and tester/tool. A planned test is not evidence that it ran.

## Flake handling
Record repeats and failure signature; separate test setup from product defect; wait for explicit state with bounded timeout rather than arbitrary sleeps; keep retries bounded; never weaken assertions without product justification.

## CI
Pin tools. Cache reproducible artifacts. Keep secrets out of logs. Never publish from ordinary validation. Use non-production data and explicit protected approval for release operations.

Use `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, and `NOT APPLICABLE` accurately. A linter pass is not Studio gameplay proof.
