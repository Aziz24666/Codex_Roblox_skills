# V4 UI Components and Design Systems

Build a small, consistent UI language before multiplying screens. A design system should improve predictability and reduce one-off UI behavior.

## Define tokens

Document spacing scale, text hierarchy, colors and semantic roles, corner/edge style, motion duration, focus/selection states, icon style, and sound feedback. Avoid using color as the only carrier of meaning.

## Component contracts

For reusable components define:
- purpose and allowed contexts;
- properties and defaults;
- events/callbacks;
- loading, empty, disabled, error, success, and focused states;
- touch target and layout behavior;
- accessibility/contrast considerations;
- owner and cleanup lifecycle.

## Screen architecture

Separate presentation from gameplay state. UI sends intent; server decides consequential outcomes. Prevent a stale UI view from creating duplicate requests. Disable or debounce controls for usability, but never treat that as a security boundary.

## Device behavior

Test representative narrow/wide aspect ratios, safe areas, text scaling, touch, keyboard/mouse, and controller focus. Ensure critical actions remain visible and reachable. Avoid tiny hit areas, hover-only controls, text overflow, and modal traps.

## Review checklist

Can a first-time player identify the goal? Is the primary action visually clear? Are errors actionable? Does the UI recover after respawn/reconnect? Are loading and empty states explicit? Does the same screen work with all supported input modes? Are motion and audio cues non-essential for understanding?
