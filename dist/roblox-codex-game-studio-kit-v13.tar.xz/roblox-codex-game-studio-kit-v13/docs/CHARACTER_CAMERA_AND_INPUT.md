# Character Camera And Input


# Character, Camera, and Input

## Control specification

Document each action with input device, input binding, action priority, context, repeat behavior, cancellation, and UI conflict behavior. Provide keyboard/mouse, touch, and controller mappings for every essential action where those devices are supported.

## Character lifecycle

Account for `CharacterAdded`, `CharacterRemoving`, death, respawn, character replacement, and player removal. Disconnect old events and camera bindings. Do not keep references to destroyed characters or parts after respawn.

## Camera design

Specify default mode, allowed transitions, occlusion behavior, zoom constraints, sensitivity, cut/lerp rules, UI focus interaction, and fallback when the target disappears. Test tight spaces, walls, elevated areas, spawn transitions, and character reset.

## Responsivity and authority

Local feedback can respond immediately to input, but consequential state must reconcile to server decisions. Define what is predicted, what is authoritative, and how corrections appear to the player. Avoid unbounded client-side force/velocity or client trust for competitive outcomes.

## Feel iteration

Change a small number of parameters at a time. Record the desired feel, current observation, parameter changed, and result. Use playtests rather than claims such as “feels smooth” without a stated observation.

## Device test checklist

- Touch target size and placement.
- Thumb reach and screen obstruction.
- Mouse sensitivity and cursor capture.
- Controller focus and button prompts.
- UI overlays and text entry.
- Low frame-rate and latency behavior.
- Camera cleanup after respawn and leave.
