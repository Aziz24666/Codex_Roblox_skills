# V12 MicroProfiler and Script Profiler Workflow

## Tool selection
- Start with current Roblox performance documentation and the current Studio tools available in the connected session.
- Use MicroProfiler/Developer Console views to identify frame, CPU, memory, and engine workload patterns.
- Use Studio MCP tools when present to inspect the active session, run a controlled playtest, and retrieve logs. Confirm the target place/session before edits or tests.
- `ScriptProfilerService` is documented with **Plugin Security** on its methods and events. Do not call it from an ordinary game Script or LocalScript on the assumption that it is generally available. Use a supported plugin/Studio workflow only after verifying current permissions.

## Capture protocol
Record: `buildId`, `placeIdOrName`, `studioVersion`, `captureTimeUtc`, `environment`, `deviceTier`, `hardwareOrEmulator`, `clientCount`, `scenario`, `warmupSeconds`, `sampleSeconds`, `networkProfile`, `graphicsLevel`, and raw evidence path.

## Interpret carefully
- Profile server and client independently.
- Distinguish a single spike from recurring frame cost.
- Check call counts as well as total sampled time.
- Check memory categories and whether memory returns after the scenario/cleanup.
- Use a representative route and normal content density, not an empty test map only.
- A sampled profile is evidence for a capture window, not proof that every player/device has the same result.

## Output
Create a V12 performance baseline JSON plus a human-readable review. Mark unavailable metrics `NOT RUN` or `BLOCKED`; never fill them with estimates.
