# Roblox Codex Game Studio Kit — V10 Index

## Read first
1. `README.md`
2. `AGENTS.md`
3. `docs/V10_RESEARCH_FIRST_STANDARD.md`
4. `docs/V10_RESEARCH_GATE_WORKFLOW.md`
5. `docs/V10_MODULARITY_AND_CLEAN_CODE_STANDARD.md`
6. `docs/V10_STUDIO_MCP_AGENT_WORKFLOW.md`
7. `INDEX_V9.md` for schema-generated editor details

## V10 specialist skills
- `roblox-research-first-engineering`
- `roblox-official-docs-verification`
- `roblox-best-practice-comparison`
- `roblox-api-version-compatibility`
- `roblox-architecture-decision-records`
- `roblox-code-quality-governance`
- `roblox-platform-security-review`
- `roblox-studio-mcp-integration`
- `roblox-toolchain-selection`
- `roblox-performance-evidence`
- `roblox-automation-quality-gates`
- `roblox-asset-provenance`
- `roblox-research-evidence-maintenance`

## V10 documentation
- Research: `docs/V10_RESEARCH_FIRST_STANDARD.md`, `docs/V10_RESEARCH_GATE_WORKFLOW.md`, `docs/V10_SOURCE_RANKING_AND_CONFLICT_RESOLUTION.md`, `docs/V10_RESEARCH_DECISION_RECORDS.md`, `docs/V10_API_CURRENCY_AND_RELEASE_NOTES.md`, `docs/V10_CURRENT_PLATFORM_RESEARCH_CHECKLIST.md`, `docs/V10_ROBLOX_UPDATES_WATCH.md`, `docs/V10_RESEARCH_AND_IMPLEMENTATION_LOOP.md`.
- Architecture: `docs/V10_ARCHITECTURE_APPROACH_COMPARISON.md`, `docs/V10_MODULARITY_AND_CLEAN_CODE_STANDARD.md`, `docs/V10_DATA_DRIVEN_SCHEMA_GOVERNANCE.md`, `docs/V10_RUNTIME_LIFECYCLE_AND_OBSERVABILITY.md`, `docs/V10_CODE_REVIEW_SIMPLICITY_SCORECARD.md`.
- Tooling: `docs/V10_STUDIO_MCP_AGENT_WORKFLOW.md`, `docs/V10_STUDIO_MCP_CAPABILITY_DISCOVERY.md`, `docs/V10_TOOLCHAIN_DECISION_GUIDE.md`.
- Quality: `docs/V10_SECURITY_THREAT_MODEL.md`, `docs/V10_DATASTORE_RELIABILITY.md`, `docs/V10_TESTING_AND_PERFORMANCE_GATES.md`, `docs/V10_ASSET_AND_PACKAGE_PROVENANCE.md`, `docs/V10_CONTENT_FACTORY_QUALITY.md`.
- Migration: `docs/V10_MIGRATION_FROM_V9.md`.
- Baseline snapshot: `docs/V10_RESEARCH_BASELINE_2026-11-15.md`.

## Research workflow
- Create current records in `research/decisions/`.
- Use schema `schemas/v10-research-decision.schema.json`.
- Validate with `python tools/v10_research_record_lint.py <record> --require-today`.
- Check changed-file scope with `python tools/v10_research_gate.py --record <record> --changed-file <path> --require-current`.
- Regenerate index with `python tools/v10_research_index.py`.

## V10 tools
- `v10_research_record_lint.py`
- `v10_research_gate.py`
- `v10_api_surface_inventory.py`
- `v10_architecture_quality_audit.py`
- `v10_research_index.py`
- `v10_package_doctor.py`

## Preserved foundation
All V9 materials, including V1–V9 skill folders, schema-driven editor source, content-family examples, project starter, historical indexes, templates, prompts, docs, and tools, are retained. The V10 contract and V10-specific index take precedence for current behavior.


## V11 note
For current global rules and project reliability workflows, use `AGENTS.md` and `INDEX_V11.md`. V10 guidance remains available for historical context.
