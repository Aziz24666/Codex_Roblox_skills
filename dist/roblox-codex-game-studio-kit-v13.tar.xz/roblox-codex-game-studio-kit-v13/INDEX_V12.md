# Roblox Codex Game Studio Kit — V12 Index

## Start here
- `AGENTS.md` — global research, safety, architecture, runtime-quality, and evidence contract.
- `README.md` — installation and checks.
- `INDEX_V12.md` — routing.
- `PACKAGE_INVENTORY.md` — exact generated counts.
- `V12_TEST_RESULTS.md` — actual package validation and boundaries.

## V12 specialist skills
- `$roblox-runtime-performance-profiling` — repeatable client/server profiling.
- `$roblox-instance-streaming-readiness` — stream-in/out-safe references and components.
- `$roblox-tagged-component-lifecycle` — CollectionService registration and cleanup.
- `$roblox-memory-and-resource-lifecycle` — connections, tasks, caches, and resource ownership.
- `$roblox-performance-budget-governance` — project-specific measured thresholds.
- `$roblox-analytics-event-governance` — minimal event catalogs and privacy review.
- `$roblox-content-loading-optimization` — join time, asset dependencies, and memory.
- `$roblox-device-tier-validation` — representative device/emulator test matrices.
- `$roblox-performance-regression-testing` — comparable before/after performance evidence.
- `$roblox-runtime-observability` — bounded diagnostics and operational signals.

## V12 docs
- Runtime optimization loop: `docs/V12_RUNTIME_PERFORMANCE_LOOP.md`
- Profiling tools: `docs/V12_MICROPROFILER_AND_SCRIPT_PROFILER.md`
- Streaming contract: `docs/V12_INSTANCE_STREAMING_CONTRACT.md`
- Streaming-aware components: `docs/V12_STREAMING_AWARE_COMPONENTS.md`
- CollectionService lifecycle: `docs/V12_COLLECTIONSERVICE_LIFECYCLE.md`
- Memory/resource lifecycle: `docs/V12_MEMORY_AND_RESOURCE_LIFECYCLE.md`
- Budgets: `docs/V12_PERFORMANCE_BUDGETS.md`
- Analytics governance: `docs/V12_ANALYTICS_EVENT_GOVERNANCE.md`
- Content load/memory: `docs/V12_CONTENT_LOAD_AND_MEMORY.md`
- Device matrix: `docs/V12_DEVICE_TIER_TEST_MATRIX.md`
- Regression policy: `docs/V12_PERFORMANCE_REGRESSION_POLICY.md`
- Runtime observability: `docs/V12_RUNTIME_OBSERVABILITY.md`
- Studio profiling workflow: `docs/V12_STUDIO_PROFILING_WORKFLOW.md`
- Tools/evidence limits: `docs/V12_TOOL_LIMITS_AND_EVIDENCE.md`
- Research snapshot: `docs/V12_RESEARCH_SNAPSHOT.md`
- V11 migration: `docs/V12_MIGRATION_FROM_V11.md`
- Maintenance/research refresh: `docs/V12_MAINTENANCE_AND_RESEARCH_REFRESH.md`

## V12 tools
- `tools/v12_perf_budget_check.py`
- `tools/v12_streaming_risk_audit.py`
- `tools/v12_tag_lifecycle_audit.py`
- `tools/v12_analytics_catalog_lint.py`
- `tools/v12_pack_doctor.py`
- `tools/tests/test_v12_tools.py`

## Existing V1–V11 material
All inherited skills, docs, prompts, schemas, templates, examples, and tools remain. Prefer V12 guidance where it adds runtime-quality detail. Keep research fresh; the source snapshot is dated.
